#!/usr/bin/env python3
"""PDF Lab: a tiny local-only web server.

Python 3 standard library plus a vendored copy of pypdf (pure Python, lives in
the "vendor" folder next to this file). Bound to 127.0.0.1 only. Nothing leaves
the machine.

Routes
  GET  /                  static front end (web/)
  GET  /api/ping          heartbeat, also cancels a pending close
  POST /api/upload        raw bytes in the body, name in X-Filename, kind in X-Kind (pdf or file)
  POST /api/merge         {"ids": [...]}                          -> PDF
  POST /api/pages         {"id", "pages": [{"n", "rot"}]}         -> PDF (remove, extract, rotate, reorder)
  POST /api/split         {"id", "groups": [[{"n","rot"}]], "base"} -> ZIP of PDFs
  POST /api/html2pdf      {"html": "..."}                         -> PDF (headless Chrome)
  POST /api/word2pdf      {"html": "...", "overlay": {...}|null}  -> PDF (text pages, then headers and footers laid over)
  POST /api/images2pdf    {"items": [...], "page", "orientation", "margin", "merge"} -> PDF or ZIP
  POST /api/picture       {"id", "page"}                          -> PNG or JPG of a picture Chrome cannot show (TIFF ...)
  POST /api/doc2docx      raw .doc bytes                          -> DOCX (macOS textutil)
  POST /api/build-docx    {"page": {...}, "blocks": [...]}        -> DOCX
  POST /api/build-pptx    {"slides": [...]}                       -> PPTX
  POST /api/edit/open     {"id"}                                  -> page sizes and installed fonts for the editor
  POST /api/edit/lines    {"id", "page"}                          -> editable text lines of a page
  POST /api/edit/preview  {"id", "page", "edits", "scale", "clip"} -> PNG of the page with the edits applied
  POST /api/edit/export   {"id", "edits"}                         -> PDF
  POST /api/zip           {"files": [{"name", "b64"}]}            -> ZIP
  POST /api/discard       {"id": "..."}
  POST /api/update        {"do": "status" | "install" | "seen"}   -> state of the update check (updater.py; "off" without it)
  POST /api/closing       the window is closing, quit shortly unless a ping arrives
  POST /api/shutdown      quit now
"""
import base64
import gc
import glob
import html as htmllib
import io
import json
import mimetypes
import os
import pathlib
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.parse
import urllib.request
import uuid
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "vendor"))
sys.path.insert(0, HERE)

try:
    from pypdf import PdfReader, PdfWriter  # noqa: E402
except BaseException:
    # A broken optional crypto library on this machine must not stop the app: retry without it.
    for _m in [k for k in sys.modules if k.split(".")[0] in ("pypdf", "cryptography", "Crypto", "Cryptodome")]:
        del sys.modules[_m]
    for _n in ("cryptography", "Crypto", "Cryptodome"):
        sys.modules[_n] = None
    from pypdf import PdfReader, PdfWriter  # noqa: E402
from pypdf.errors import DependencyError  # noqa: E402

import builders  # noqa: E402  (docx and pptx writers, same folder)
import updater  # noqa: E402  (looks for a newer version and installs it; same folder)
import editor  # noqa: E402  (Edit PDF engine; its PyMuPDF library is loaded lazily and may be missing)

WEB_DIR = os.path.join(HERE, "web")
HOST = "127.0.0.1"
_FIRST_PORT = int(os.environ.get("PDFLAB_PORT") or 8765)   # a second copy of the app (a test build) gets its own ports
PORTS = list(range(_FIRST_PORT, _FIRST_PORT + 11))
IDENTITY_HEADER = "X-PDF-Lab"
MAX_UPLOAD = 1024 * 1024 * 1024  # 1 GB

# id -> {"name": str, "data": bytes, "pages": int, "kind": str}
STORE = {}
STORE_LOCK = threading.Lock()
EDIT_LOCK = threading.Lock()  # PyMuPDF is not safe to use from several threads at once

_close_timer = None
_close_lock = threading.Lock()


def log(msg):
    print(f"[pdf-lab] {msg}", flush=True)


# ---------------------------------------------------------------- pdf helpers

class LockedError(ValueError):
    """The PDF cannot be opened: it needs a password, or AES support is missing."""


def open_reader(data):
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            if reader.decrypt("") == 0:
                raise LockedError("is password protected.")
            if len(reader.pages):
                reader.pages[0].get_contents()  # proves the streams really decrypt (AES needs an extra package)
    except DependencyError:
        raise LockedError("is protected with AES encryption, which PDF Lab cannot open on this Mac.")
    return reader


def write_pdf(writer):
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def merge_pdfs(readers):
    writer = PdfWriter()
    for reader in readers:
        writer.append(reader)
    return write_pdf(writer)


def pick_pages(reader, picks):
    """picks: list of {"n": 0-based page, "rot": extra clockwise degrees}."""
    total = len(reader.pages)
    writer = PdfWriter()
    if not isinstance(picks, list):
        raise ValueError("No pages selected.")
    for p in picks:
        n = int(p["n"])
        rot = int(p.get("rot") or 0) % 360
        if rot % 90:
            raise ValueError("Rotation must be a multiple of 90 degrees.")
        if n < 0 or n >= total:
            raise ValueError(f"Page {n + 1} does not exist in this PDF.")
        page = writer.add_page(reader.pages[n])
        if rot:
            page.rotate(rot)
    if len(writer.pages) == 0:
        raise ValueError("No pages selected.")
    return write_pdf(writer)


def safe_name(name, fallback="file"):
    name = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", str(name or "")).strip(" .")[:180]
    while len(name.encode("utf-8")) > 180:  # leaves room for suffixes inside the 255 byte file name limit
        name = name[:-1]
    return name.strip(" .") or fallback


def make_zip(entries):
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        used = set()
        for name, data in entries:
            base, ext = os.path.splitext(name)
            candidate, i = name, 2
            while candidate.lower() in used:  # the Mac file system ignores case
                candidate = f"{base} ({i}){ext}"
                i += 1
            used.add(candidate.lower())
            z.writestr(candidate, data)
    return out.getvalue()


# ------------------------------------------------------------ headless Chrome

PRINTING = set()  # headless Chrome processes that are converting right now
OPENED = set()    # profile folders of the Chromes started through "open" (not our children: found again by that folder)
QUITTING = False  # the app is shutting down: no new Chrome may be started

def find_chrome():
    env = os.environ.get("PDFLAB_CHROME")
    if env and os.path.exists(env):
        return env
    home = os.path.expanduser("~")
    candidates = []
    for base in ("/Applications", os.path.join(home, "Applications")):
        candidates += [
            f"{base}/Google Chrome.app/Contents/MacOS/Google Chrome",
            f"{base}/Chromium.app/Contents/MacOS/Chromium",
            f"{base}/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            f"{base}/Brave Browser.app/Contents/MacOS/Brave Browser",
        ]
    for c in candidates:
        if os.path.exists(c):
            return c
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            return found
    for pattern in ("/opt/pw-browsers/chromium-*/chrome-linux*/chrome",):
        hits = sorted(glob.glob(pattern))
        if hits:
            return hits[-1]
    return None


class PrintFailed(ValueError):
    """Chrome produced no PDF. detail says what was tried: the failure card shows it in small print."""

    def __init__(self, message, detail=""):
        super().__init__(message)
        self.detail = detail


class _Attempt(Exception):
    """One way of driving Chrome did not work. slow: it was stopped because it ran out of time."""

    def __init__(self, why, slow=False):
        super().__init__(why)
        self.slow = slow


def state_dir():
    """A small folder that survives restarts (the way of driving Chrome that works on this computer)."""
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Application Support/PDF Lab")
    if os.name == "nt":
        return os.path.join(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir(), "PDF Lab")
    return os.path.join(tempfile.gettempdir(), "pdf-lab-state")


def _chrome_flags(profile):
    flags = [
        "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run", "--no-default-browser-check",
        # nothing but the page: no extensions, no background downloads, no sign-in, no keychain question
        "--disable-extensions", "--disable-background-networking", "--disable-component-update", "--disable-sync",
        "--disable-default-apps", "--use-mock-keychain", "--password-store=basic",
        # On the Mac, Chrome makes a private copy of its own app at every start. macOS sees that as this app
        # "modifying apps" and shows a Privacy & Security warning at each conversion. This turns the copy off.
        "--disable-features=MacAppCodeSignClone,Translate",
        f"--user-data-dir={profile}",
    ]
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        flags.append("--no-sandbox")
    return flags


def _start_chrome(cmd, workdir, tag):
    """Start a hidden Chrome. Its messages go to a file in the work folder (a pipe nobody reads could block it)."""
    if QUITTING:
        raise _Attempt("the app is closing")
    errlog = os.path.join(workdir, f"chrome-{tag}.log")
    with open(errlog, "wb") as err:
        # stdin: a windowless program has no standard input, and without this Windows refuses to start Chrome
        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=err, stderr=err)
    PRINTING.add(proc)
    if QUITTING:   # the app started closing in between: this Chrome must not outlive it
        _stop_chrome(proc)
        raise _Attempt("the app is closing")
    return proc, errlog


def _stop_chrome(proc):
    try:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
    except Exception:
        pass
    finally:
        PRINTING.discard(proc)


def _chrome_said(errlog):
    """The last meaningful line Chrome wrote, shortened: the best hint when it produced nothing."""
    try:
        with open(errlog, "rb") as f:
            lines = f.read()[-4000:].decode("utf-8", "replace").splitlines()
    except OSError:
        return ""
    lines = [ln.strip() for ln in lines if ln.strip() and "DevTools listening" not in ln]
    return lines[-1][:160] if lines else ""


def _pdf_done(path):
    """True when path holds a finished PDF (Chrome writes the end marker last)."""
    try:
        size = os.path.getsize(path)
        if size < 100:
            return False
        with open(path, "rb") as f:
            f.seek(max(0, size - 64))
            return b"%%EOF" in f.read()
    except OSError:
        return False


def _print_direct(chrome, workdir, url, budget, tag):
    """Chrome prints the page by itself and quits. If it printed but does not quit, the PDF is taken anyway."""
    out = os.path.join(workdir, f"out-{tag}.pdf")
    cmd = [chrome] + _chrome_flags(os.path.join(workdir, f"profile-{tag}")) + [
        "--no-pdf-header-footer", "--print-to-pdf-no-header", f"--print-to-pdf={out}", url]
    proc, errlog = _start_chrome(cmd, workdir, tag)
    try:
        end = time.time() + budget
        settled = 0
        while proc.poll() is None and time.time() < end:
            settled = settled + 1 if _pdf_done(out) else 0
            if settled >= 5:   # complete and untouched for half a second, yet Chrome is still there
                log("Chrome printed the PDF but did not quit by itself: the PDF is used and Chrome is stopped.")
                break
            time.sleep(0.1)
        if _pdf_done(out):
            with open(out, "rb") as f:
                return f.read()
        if proc.poll() is None:
            raise _Attempt(f"no PDF after {budget:.0f} s", slow=True)
        said = _chrome_said(errlog)
        raise _Attempt(f"Chrome ended with code {proc.returncode} and no PDF" + (f" ({said})" if said else ""))
    finally:
        _stop_chrome(proc)


class _WebSocket:
    """The few lines of the WebSocket protocol needed to talk to Chrome on this computer (text messages only)."""

    def __init__(self, port, path):
        self.sock = socket.create_connection(("127.0.0.1", port), timeout=10)
        key = base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall((f"GET {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nUpgrade: websocket\r\n"
                           f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        self.buf = b""
        while b"\r\n\r\n" not in self.buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise OSError("Chrome closed the connection")
            self.buf += chunk
        head, self.buf = self.buf.split(b"\r\n\r\n", 1)
        if b" 101 " not in head.split(b"\r\n", 1)[0]:
            raise OSError("Chrome refused the connection")

    def _take(self, n, deadline):
        while len(self.buf) < n:
            left = deadline - time.time()
            if left <= 0:
                raise socket.timeout()
            self.sock.settimeout(left)
            chunk = self.sock.recv(1 << 16)
            if not chunk:
                raise OSError("Chrome closed the connection")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def send(self, text, opcode=1):
        data = text if isinstance(text, bytes) else text.encode("utf-8")
        mask = os.urandom(4)
        n = len(data)
        head = bytes([0x80 | opcode])
        if n < 126:
            head += bytes([0x80 | n])
        elif n < 65536:
            head += bytes([0x80 | 126]) + n.to_bytes(2, "big")
        else:
            head += bytes([0x80 | 127]) + n.to_bytes(8, "big")
        body = bytes(b ^ mask[i % 4] for i, b in enumerate(data)) if n < 4096 else \
            (int.from_bytes(data, "big") ^ int.from_bytes((mask * (n // 4 + 1))[:n], "big")).to_bytes(n, "big")
        self.sock.settimeout(20)
        self.sock.sendall(head + mask + body)

    def recv(self, deadline):
        """The next text message (pieces are joined, pings answered)."""
        parts = []
        while True:
            b0, b1 = self._take(2, deadline)
            n = b1 & 0x7F
            if n == 126:
                n = int.from_bytes(self._take(2, deadline), "big")
            elif n == 127:
                n = int.from_bytes(self._take(8, deadline), "big")
            data = self._take(n, deadline)   # Chrome does not mask what it sends
            op = b0 & 0x0F
            if op == 9:
                self.send(data, opcode=10)
                continue
            if op == 8:
                raise OSError("Chrome closed the connection")
            if op in (0, 1, 2):
                parts.append(data)
                if b0 & 0x80:
                    return b"".join(parts).decode("utf-8", "replace")

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


class _Pilot:
    """Commands to Chrome over its DevTools connection, answers matched by number."""

    def __init__(self, ws):
        self.ws = ws
        self.n = 0
        self.events = []

    def call(self, method, params=None, session=None, deadline=None):
        self.n += 1
        mine = self.n
        msg = {"id": mine, "method": method, "params": params or {}}
        if session:
            msg["sessionId"] = session
        self.ws.send(json.dumps(msg))
        deadline = deadline or time.time() + 30
        while True:
            got = json.loads(self.ws.recv(deadline))
            if got.get("id") == mine:
                if "error" in got:
                    raise OSError(f"{method}: {got['error'].get('message', 'refused')}")
                return got.get("result") or {}
            if "method" in got:
                self.events.append(got)

    def wait(self, event, deadline):
        while True:
            for i, ev in enumerate(self.events):
                if ev.get("method") == event:
                    del self.events[:i + 1]
                    return ev
            got = json.loads(self.ws.recv(deadline))
            if "method" in got:
                self.events.append(got)


def _print_piloted(chrome, workdir, url, budget, tag, through_open=False):
    """Chrome is started empty, then told step by step what to do: open the page, print it, hand the PDF over.
    A different road inside Chrome than _print_direct, and each step that fails is known by name.
    through_open (Mac): Chrome is started by macOS itself (open), not as a child of this app."""
    profile = os.path.join(workdir, f"profile-{tag}")
    flags = _chrome_flags(profile) + ["--remote-debugging-port=0", "about:blank"]
    proc = errlog = None
    if through_open:
        if QUITTING:
            raise _Attempt("the app is closing")
        # no MacAppCodeSignClone here on purpose: this Chrome is started by macOS, it is not a child of the app
        flags = [f for f in flags if not f.startswith("--disable-features=")] + ["--disable-features=Translate"]
        app = chrome.split(".app/")[0] + ".app"
        OPENED.add(profile)
        subprocess.run(["/usr/bin/open", "-n", "-g", "-j", "-a", app, "--args"] + flags,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
    else:
        proc, errlog = _start_chrome([chrome] + flags, workdir, tag)
    ws = None
    step = "Chrome did not start"
    end = time.time() + budget
    try:
        port_file = os.path.join(profile, "DevToolsActivePort")
        start_end = time.time() + min(30, budget)
        lines = []
        while time.time() < start_end:
            if proc is not None and proc.poll() is not None:
                said = _chrome_said(errlog)
                raise _Attempt(f"Chrome ended at once with code {proc.returncode}" + (f" ({said})" if said else ""))
            try:
                with open(port_file, encoding="utf-8") as f:
                    lines = f.read().split()
            except OSError:
                lines = []
            if len(lines) >= 2:
                break
            time.sleep(0.1)
        if len(lines) < 2:
            raise _Attempt(f"Chrome did not start within {min(30, budget):.0f} s", slow=True)
        step = "Chrome started but did not answer"
        ws = _WebSocket(int(lines[0]), lines[1])
        pilot = _Pilot(ws)
        target = pilot.call("Target.createTarget", {"url": "about:blank"}, deadline=end)["targetId"]
        session = pilot.call("Target.attachToTarget", {"targetId": target, "flatten": True}, deadline=end)["sessionId"]
        pilot.call("Page.enable", session=session, deadline=end)
        step = "the page did not finish loading"
        pilot.call("Page.navigate", {"url": url}, session=session, deadline=end)
        pilot.wait("Page.loadEventFired", end)
        try:   # fonts that are still being prepared would print as blanks
            pilot.call("Runtime.evaluate", {"expression": "document.fonts.ready.then(() => 1)", "awaitPromise": True},
                       session=session, deadline=min(end, time.time() + 15))
        except (OSError, socket.timeout):
            pass
        step = "the page loaded but printing did not finish"
        got = pilot.call("Page.printToPDF", {
            "printBackground": True, "preferCSSPageSize": True, "displayHeaderFooter": False,
            "marginTop": 0, "marginBottom": 0, "marginLeft": 0, "marginRight": 0,
        }, session=session, deadline=end)
        data = base64.b64decode(got.get("data") or "")
        if len(data) < 100:
            raise _Attempt("printing gave an empty PDF")
        try:
            pilot.call("Browser.close", deadline=time.time() + 3)
        except (OSError, socket.timeout):
            pass
        return data
    except socket.timeout:
        raise _Attempt(f"{step} within {budget:.0f} s", slow=True)
    except (OSError, ValueError, KeyError) as e:
        raise _Attempt(f"{step} ({str(e)[:120]})")
    finally:
        if ws:
            ws.close()
        if proc is not None:
            _stop_chrome(proc)
        elif through_open:   # not our child: found again by its private profile folder
            subprocess.run(["/usr/bin/pkill", "-f", profile], stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            OPENED.discard(profile)


def _print_opened(chrome, workdir, url, budget, tag):
    return _print_piloted(chrome, workdir, url, budget, tag, through_open=True)


# The ways of getting a PDF out of Chrome, in the order they are tried. The first one that works on this computer
# is remembered (also after a restart) and used first from then on.
_PRINTERS = {"direct": _print_direct, "piloted": _print_piloted, "opened": _print_opened}
PRINT_METHOD = None


def _print_order(chrome):
    global PRINT_METHOD
    names = ["direct", "piloted"]
    if sys.platform == "darwin" and ".app/" in chrome:
        names.append("opened")
    if PRINT_METHOD is None:
        PRINT_METHOD = ""
        try:
            with open(os.path.join(state_dir(), "print-method.txt"), encoding="utf-8") as f:
                PRINT_METHOD = f.read().strip()
        except OSError:
            pass
    first = (os.environ.get("PDFLAB_PRINT") or PRINT_METHOD or "").strip().lower()
    if first in names:
        names.remove(first)
        names.insert(0, first)
    return names


def _remember_print_method(name):
    global PRINT_METHOD
    if name == PRINT_METHOD:
        return
    PRINT_METHOD = name
    try:
        os.makedirs(state_dir(), exist_ok=True)
        with open(os.path.join(state_dir(), "print-method.txt"), "w", encoding="utf-8") as f:
            f.write(name)
    except OSError:
        pass


def chrome_version(chrome):
    """Chrome's version, read from its files (asking Chrome itself would start it once more)."""
    try:
        if ".app/" in chrome:
            import plistlib
            with open(chrome.split(".app/")[0] + ".app/Contents/Info.plist", "rb") as f:
                return str(plistlib.load(f).get("CFBundleShortVersionString") or "")
        if os.name == "nt":
            for name in os.listdir(os.path.dirname(chrome)):
                if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", name):
                    return name
    except Exception:
        pass
    return ""


def _print_budget(weight):
    """Seconds one try may take, from the size of what is printed: a long document may take its time."""
    return max(45.0, min(300.0, 45 + 8 * weight / 1e6))


def html_to_pdf(workdir, html_name="index.html"):
    """Print workdir/html_name to PDF with a hidden Chrome of its own. Returns bytes.
    Several ways of driving Chrome are tried in turn, so one way that hangs on a computer does not stop the tool."""
    chrome = find_chrome()
    if not chrome:
        raise ValueError("Google Chrome is needed for this tool but was not found.")
    url = pathlib.Path(os.path.join(workdir, html_name)).as_uri()   # file:///C:/... on Windows
    weight = 0
    for name in os.listdir(workdir):
        full = os.path.join(workdir, name)
        if os.path.isfile(full):
            weight += os.path.getsize(full)
    budget = _print_budget(weight)
    notes, slow = [], False
    for n, method in enumerate(_print_order(chrome)):
        if QUITTING:
            break
        started = time.time()
        try:
            data = _PRINTERS[method](chrome, workdir, url, budget, str(n))
        except _Attempt as e:
            slow = slow or e.slow
            notes.append(f"{method}: {e}")
            log(f"Chrome, way '{method}', failed after {time.time() - started:.1f} s: {e}")
            continue
        except Exception as e:   # a way that breaks must never hide the next one
            notes.append(f"{method}: {type(e).__name__} {str(e)[:120]}")
            log(f"Chrome, way '{method}', broke: {traceback.format_exc()}")
            continue
        if notes:
            log(f"Chrome, way '{method}', worked after: {' | '.join(notes)}")
        _remember_print_method(method)
        return data
    version = chrome_version(chrome)
    detail = (f"Chrome {version}. " if version else "") + " | ".join(notes)
    raise PrintFailed("The conversion took too long and was stopped." if slow else "Chrome could not produce the PDF.", detail)


# ----------------------------------------------------------------------------------------------------------------
# Pictures the browser cannot show (TIFF, JPEG 2000, JPEG XL, Photoshop, PNM, camera RAW ...)
# ----------------------------------------------------------------------------------------------------------------
# Image to PDF prints the pictures with Chrome, so every picture must be one Chrome can show. The page itself
# turns iPhone photos (HEIC, HEIF) into JPG (web/js/heic-worker.js). Everything else that Chrome cannot show comes
# here and leaves as a PNG: first with the PDF engine of the app (PyMuPDF, the same on the Mac and on Windows),
# then, on a Mac only, with the picture tool of macOS (sips), which also knows camera RAW files.
RAW_EXT = {".cr2", ".cr3", ".crw", ".nef", ".nrw", ".arw", ".srf", ".sr2", ".dng", ".orf", ".rw2", ".raf", ".pef",
           ".srw", ".x3f", ".3fr", ".erf", ".kdc", ".dcr", ".mrw", ".raw", ".rwl", ".iiq", ".mos", ".mef", ".fff", ".gpr"}
TIFF_MAGIC = (b"II*\x00", b"MM\x00*", b"II+\x00", b"MM\x00+")
PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
MAX_PICTURE_PIXELS = 268000000     # what Chrome can draw (16384 x 16384)
MAX_PICTURE_PAGES = 500


class PictureError(ValueError):
    """kind: "raw", "large", "damaged" or "unknown". The route turns it into a sentence with the file name."""

    def __init__(self, kind):
        super().__init__(kind)
        self.kind = kind


def tiff_pictures(data):
    """[(width, height, orientation)] for the pictures of a TIFF, read from its headers alone (no decoding).
    Empty when the headers cannot be followed (BigTIFF, damaged file): the engine then decides."""
    out = []
    try:
        order = "<" if data[:2] == b"II" else ">"
        if data[2:4] not in (b"*\x00", b"\x00*"):
            return out
        (off,) = struct.unpack(order + "I", data[4:8])
        seen = set()
        while off and off not in seen and len(out) < MAX_PICTURE_PAGES:
            seen.add(off)
            (count,) = struct.unpack(order + "H", data[off:off + 2])
            got = {274: 1}
            for i in range(min(count, 400)):
                tag, typ, _n, raw = struct.unpack(order + "HHI4s", data[off + 2 + i * 12:off + 14 + i * 12])
                if tag in (256, 257, 274):
                    got[tag] = struct.unpack(order + "H", raw[:2])[0] if typ == 3 else struct.unpack(order + "I", raw)[0]
            if 256 not in got or 257 not in got:
                return []
            out.append((got[256], got[257], got[274] if 1 <= got[274] <= 8 else 1))
            (off,) = struct.unpack(order + "I", data[off + 2 + count * 12:off + 6 + count * 12])
    except Exception:
        return []
    return out


# TIFF orientation value -> (quarter turns in degrees, mirror first). Found by trying each on the eight cases.
TIFF_TURN = {1: (0, False), 2: (0, True), 3: (180, False), 4: (180, True), 5: (270, True), 6: (90, False), 7: (90, True), 8: (270, False)}


def _mu_png(mu, pix):
    """A decoded picture as PNG: grey or RGB, 8 bits a channel, transparency kept, square pixels."""
    cs = pix.colorspace
    if cs is None or cs.n not in (1, 3):                 # CMYK, Lab, a bare mask
        pix = mu.Pixmap(mu.csRGB, pix)
    xres, yres = pix.xres or 0, pix.yres or 0
    if xres > 0 and yres > 0 and max(xres, yres) / min(xres, yres) > 1.03:   # a fax: its pixels are not square
        w = round(pix.width * max(xres, yres) / xres)
        h = round(pix.height * max(xres, yres) / yres)
        if w * h <= MAX_PICTURE_PIXELS:
            pix = mu.Pixmap(pix, w, h)
    if pix.width * pix.height > MAX_PICTURE_PIXELS or max(pix.width, pix.height) > 32767:
        raise PictureError("large")
    return pix.tobytes("png")


def picture_with_engine(mu, data, page):
    """(PNG bytes, number of pictures in the file) for picture number "page" (from 0). Only a TIFF can hold several."""
    if data[:4] in TIFF_MAGIC:
        heads = tiff_pictures(data)
        if any(w * h > MAX_PICTURE_PIXELS or max(w, h) > 32767 for w, h, _o in heads):
            raise PictureError("large")
        doc = mu.open(stream=data, filetype="tiff")
        try:
            pages = doc.page_count
            turn, mirror = TIFF_TURN[heads[page][2]] if len(heads) == pages and 0 <= page < pages else (0, False)
            if pages > 1 or turn or mirror:
                # Drawn as a page: the only way to reach the other pictures of the file, and to turn a picture the
                # way its orientation mark asks (the engine ignores that mark). At this exact zoom nothing is resampled.
                if not 0 <= page < pages:
                    raise PictureError("damaged")
                pg = doc[page]
                info = pg.get_image_info()
                if not info or pg.rect.width <= 0 or pg.rect.height <= 0:
                    raise PictureError("damaged")
                w, h = info[0]["width"], info[0]["height"]
                if w * h > MAX_PICTURE_PIXELS:
                    raise PictureError("large")
                zoom = max(w / pg.rect.width, h / pg.rect.height)     # one zoom for both sides: square pixels
                m = mu.Matrix(zoom, zoom)
                if mirror:
                    m = m * mu.Matrix(-1, 0, 0, 1, 0, 0)
                if turn:
                    m = m * mu.Matrix(turn)
                grey = info[0].get("colorspace") == 1      # a grey scan stays grey: a third of the size
                pix = pg.get_pixmap(matrix=m, alpha=pages == 1, colorspace=mu.csGRAY if grey else mu.csRGB)
                return _mu_png(mu, pix), min(pages, MAX_PICTURE_PAGES)
        finally:
            doc.close()
    return _mu_png(mu, mu.Pixmap(data)), 1


def picture_with_sips(data, ext, raw):
    """The picture as PNG (JPG for a camera RAW photo) made by the picture tool of macOS, or None."""
    tool = os.environ.get("PDFLAB_SIPS") or (shutil.which("sips") if sys.platform == "darwin" else None)
    if not tool:
        return None
    work = tempfile.mkdtemp(prefix="pdflab-")
    try:
        src = os.path.join(work, "in" + (ext if re.fullmatch(r"\.[a-z0-9]{1,5}", ext) else ".img"))
        dst = os.path.join(work, "out.jpg" if raw else "out.png")
        with open(src, "wb") as f:
            f.write(data)
        cmd = [tool, "-s", "format", "jpeg", "-s", "formatOptions", "92"] if raw else [tool, "-s", "format", "png"]
        try:
            subprocess.run(cmd + [src, "--out", dst], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=180)
        except Exception:
            return None
        if not os.path.isfile(dst):
            return None
        with open(dst, "rb") as f:
            out = f.read()
        ok = out[:3] == b"\xff\xd8\xff" if raw else out[:8] == PNG_MAGIC
        return out if ok and len(out) > 100 else None
    finally:
        remove_dir(work)


def read_picture(data, name, page=0):
    """(bytes, "image/png" or "image/jpeg", number of pictures in the file). Raises PictureError."""
    ext = os.path.splitext(name or "")[1].lower()
    raw = ext in RAW_EXT
    problem = "unknown"
    # A camera RAW file looks like a TIFF, and what the engine would find in it is the small preview: never use it.
    if not raw and editor.load_engine(HERE):
        try:
            png, pages = picture_with_engine(editor.pymupdf, data, page)
            return png, "image/png", pages
        except PictureError as e:
            if e.kind == "large":
                raise
            problem = e.kind
        except MemoryError:
            raise PictureError("large")
        except Exception as e:
            log(f"picture not read by the engine ({ext or 'no extension'}): {type(e).__name__}: {str(e)[:120]}")
            if re.search(r"memory|malloc|too large|overflow", str(e), re.I):
                raise PictureError("large")
            if data[:4] in TIFF_MAGIC or data[:4] in (b"8BPS", b"\x00\x00\x00\x0c", b"\xff\x4f\xff\x51"):
                problem = "damaged"       # it is one of the formats the engine reads, and it could not be read
    out = picture_with_sips(data, ext, raw) if page == 0 else None
    if out:
        return out, ("image/jpeg" if raw else "image/png"), 1
    raise PictureError("raw" if raw else problem)


MARGINS_MM = {"none": 0, "small": 10, "big": 20}
PAGES_MM = {"a4": (210, 297), "letter": (215.9, 279.4)}


def images_to_pdf_html(workdir, items, page, orientation, margin):
    """items: [{"file": str, "w": px, "h": px}]. Returns (html text, [(page width, page height) in points])."""
    m_mm = MARGINS_MM.get(margin, 0)
    px_per_mm = 96 / 25.4
    pages, sizes = [], []
    for it in items:
        w, h = float(it["w"]), float(it["h"])
        if not (0 < w <= 100000 and 0 < h <= 100000):
            raise ValueError("An image has an invalid size.")
        if page == "fit":
            m = m_mm * px_per_mm
            k = min(1.0, 19200 / (max(w, h) + 2 * m))  # a PDF page cannot exceed 200 inches a side
            w, h, m = w * k, h * k, m * k
            pw, ph = w + 2 * m, h + 2 * m
            unit = "px"
            size_w, size_h, margin_css = pw, ph, f"{m:.2f}px"
            inner_w, inner_h = w, h
        else:
            base_w, base_h = PAGES_MM[page]
            land = orientation == "landscape" or (orientation == "auto" and w > h)
            if land:
                base_w, base_h = base_h, base_w
            unit = "mm"
            size_w, size_h, margin_css = base_w, base_h, f"{m_mm}mm"
            inner_w = (base_w - 2 * m_mm) * px_per_mm
            inner_h = (base_h - 2 * m_mm) * px_per_mm
        pt = 0.75 if unit == "px" else 72 / 25.4
        sizes.append((size_w * pt, size_h * pt))
        # a drawing (SVG) has no pixels of its own: it fills the space it gets, a photo is never blown up
        fill = ' style="width:100%;height:100%"' if str(it["file"]).lower().endswith(".svg") else ""
        pages.append((
            f"size: {size_w:.3f}{unit} {size_h:.3f}{unit}; margin: {margin_css};",
            f'<section style="width:{inner_w - 0.5:.2f}px;height:{inner_h - 0.5:.2f}px;">'
            f'<img src="{htmllib.escape(it["file"])}"{fill}></section>',
        ))
    # Chrome drops a named page (and falls back to US Letter) when the name sits on the sized block itself,
    # so one plain @page rule is used when every page is alike and a wrapper block carries the name otherwise.
    if len({rule for rule, _ in pages}) == 1:
        css = [f"@page {{ {pages[0][0]} }}", "section{break-after:page}section:last-child{break-after:auto}"]
        body = [sec for _, sec in pages]
    else:
        css = [f"@page p{i} {{ {rule} }}" for i, (rule, _) in enumerate(pages)]
        body = [f'<div style="page:p{i}">{sec}</div>' for i, (_, sec) in enumerate(pages)]
    return (
        "<!doctype html><html><head><meta charset='utf-8'><style>"
        "html,body{margin:0;padding:0;background:#fff}"
        "section{display:flex;align-items:center;justify-content:center;overflow:hidden}"
        "img{max-width:100%;max-height:100%;object-fit:contain;display:block}"
        + "".join(css)
        + "</style></head><body>" + "".join(body) + "</body></html>"
    ), sizes


def pages_match(data, sizes):
    """True when the PDF has exactly the expected pages, each of the expected size (points)."""
    try:
        pages = PdfReader(io.BytesIO(data)).pages
        if len(pages) != len(sizes):
            return False
        for p, (w, h) in zip(pages, sizes):
            if abs(float(p.mediabox.width) - w) > 3 or abs(float(p.mediabox.height) - h) > 3:
                return False
        return True
    except Exception:
        return False


def remove_dir(path):
    """Delete a work folder. Chrome helpers can still be writing for a moment, so try a few times."""
    for _ in range(6):
        shutil.rmtree(path, ignore_errors=True)
        if not os.path.exists(path):
            return
        time.sleep(0.3)


# The printed document may only use what is already inside it: no scripts, no frames, no network, no local files.
PRINT_CSP_X = ('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
               'style-src \'unsafe-inline\'; img-src data: blob:; font-src data: blob:"/>')   # the same, for an XHTML page
PRINT_CSP = ('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
             'style-src \'unsafe-inline\'; img-src data: blob:; font-src data: blob:">')


# ------------------------------------------------- Word to PDF: headers, footers and page numbers

GROUP_MARK = "https://pdflab.invalid/g/"   # an invisible link the page puts where a group of pages starts
TOKEN_RE = re.compile("\ue8a4(PAGE|NUMPAGES|SECTIONPAGES)\\|(\\w*)\ue8a5")


def _roman(n):
    out = ""
    for value, sign in ((1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
                        (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")):
        while n >= value:
            out += sign
            n -= value
    return out


def page_number_text(n, style):
    """A page number the way Word writes it: 3, iii, III, c, C."""
    style = (style or "").lower()
    if n < 1 or n > 4999:
        return str(n)
    if "roman" in style:
        text = _roman(n)
        return text if style.startswith("upper") or style == "roman_upper" else text.lower()
    if "letter" in style or "alphabetic" in style:
        letter = chr(ord("a") + (n - 1) % 26) * ((n - 1) // 26 + 1)
        return letter.upper() if style.startswith("upper") else letter
    return str(n)


def add_page_margins(data, overlay, workdir):
    """Draw the headers and footers of a Word document on the pages Chrome made from its text.

    The page sends one transparent page per kind of header and footer (templates), and the groups of pages they
    belong to. Each group starts at an invisible link in the PDF, which says where the groups begin. The number of
    every page is known only now, so the page numbers are written here, then all header pages are printed in one
    go and laid over the text pages."""
    templates = overlay.get("templates") or []
    groups = overlay.get("groups") or []
    sizes = overlay.get("sizes") or []
    if not templates or not groups:
        return data
    reader = PdfReader(io.BytesIO(data))
    writer = PdfWriter()
    writer.append(reader)
    plan = []            # for every page: (group, page inside the group)
    g, k = 0, -1
    for page in writer.pages:
        found = None
        annots = page.get("/Annots")
        if annots is not None:
            keep = []
            for ref in annots.get_object() if hasattr(annots, "get_object") else annots:
                try:
                    action = ref.get_object().get("/A")
                    uri = action.get_object().get("/URI") if action is not None else None
                except Exception:
                    uri = None
                if isinstance(uri, str) and uri.startswith(GROUP_MARK):
                    try:
                        found = int(uri[len(GROUP_MARK):])
                    except ValueError:
                        pass
                    continue
                keep.append(ref)
            if len(keep):
                from pypdf.generic import ArrayObject, NameObject
                page[NameObject("/Annots")] = ArrayObject(keep)
            else:
                del page["/Annots"]
        if found is not None and 0 <= found < len(groups):
            g, k = found, 0
        else:
            k += 1
        plan.append((g, max(k, 0)))
    total = len(plan)
    in_group = {}
    for grp, _k in plan:
        in_group[grp] = in_group.get(grp, 0) + 1
    even_odd = bool(overlay.get("evenOdd"))
    number = 0
    parts, targets = [], []
    for i, (grp, k) in enumerate(plan):
        info = groups[grp]
        start = info.get("start")
        number = start if (k == 0 and isinstance(start, int)) else number + 1
        if info.get("title") and k == 0:
            which = info.get("first", -1)
        elif even_odd and number % 2 == 0:
            which = info.get("even", -1)
        else:
            which = info.get("normal", -1)
        if not isinstance(which, int) or not 0 <= which < len(templates):
            continue
        style = info.get("format") or "decimal"

        def fill(m):
            name, switch = m.group(1), m.group(2)
            value = number if name == "PAGE" else total if name == "NUMPAGES" else in_group.get(grp, 1)
            how = {"roman": "lowerRoman", "ROMAN": "upperRoman", "alphabetic": "lowerLetter", "ALPHABETIC": "upperLetter",
                   "Arabic": "decimal", "arabic": "decimal"}.get(switch, style if name == "PAGE" else "decimal")
            return page_number_text(value, how)

        size = info.get("size", 0)
        parts.append(f'<div class="pl-ovp" style="page: ov{int(size) if isinstance(size, int) else 0}">'
                     + TOKEN_RE.sub(fill, templates[which]) + "</div>")
        targets.append(i)
    if not parts:
        return write_pdf(writer)
    rules = "".join(f"@page ov{n} {{ size: {float(w):.2f}pt {float(h):.2f}pt; margin: 0; }}\n"
                    for n, (w, h) in enumerate(sizes))
    html = ('<?xml version="1.0" encoding="UTF-8"?>\n<html xmlns="http://www.w3.org/1999/xhtml"><head><title>margins</title>'
            + PRINT_CSP_X + str(overlay.get("head") or "") + "<style>\n@page { margin: 0; }\n" + rules
            + "html, body { margin: 0; padding: 0; background: transparent; -webkit-print-color-adjust: exact; print-color-adjust: exact; }\n"
            ".pl-ovp { break-after: page; break-inside: avoid; margin: 0; padding: 0; overflow: hidden; }\n"
            ".pl-ovp:last-child { break-after: auto; }\n</style></head><body class=\"pl-root\">" + "\n".join(parts) + "</body></html>")
    sub = os.path.join(workdir, "margins")
    os.makedirs(sub)
    with open(os.path.join(sub, "index.xhtml"), "w", encoding="utf-8", errors="replace") as f:
        f.write(html)
    layer = PdfReader(io.BytesIO(html_to_pdf(sub, "index.xhtml")))
    if len(layer.pages) != len(targets):
        log(f"headers and footers: {len(layer.pages)} pages printed for {len(targets)} expected, they are left out")
        return write_pdf(writer)
    for n, i in enumerate(targets):
        writer.pages[i].merge_page(layer.pages[n])
    return write_pdf(writer)


# ------------------------------------------------- where a saved file went

def locate_saved(name, size):
    """Folder of the file the browser has just saved, or None.

    A web page is never told which folder the user picked in the save dialog, only the file name. The file is
    on this computer though, so it is looked up by its exact name, its exact size and a change time in the
    last few minutes. On the Mac the lookup is a Spotlight query: this app never opens or lists the user's
    folders itself, so macOS has nothing to ask permission for. Elsewhere the usual folders are scanned."""
    try:
        size = int(size)
    except (TypeError, ValueError):
        return None
    if not name or size <= 0 or len(name) > 255 or "/" in name or "\\" in name or "\x00" in name:
        return None
    try:
        if sys.platform == "darwin":
            return _locate_spotlight(name, size)
        return _locate_scan(name, size)
    except Exception:
        log(traceback.format_exc())
        return None


def _locate_spotlight(name, size):
    import unicodedata
    for form in ("NFC", "NFD"):  # the Mac may store accented names in either form
        text = unicodedata.normalize(form, name)
        quoted = text.replace("\\", "\\\\").replace('"', '\\"').replace("*", "\\*")
        query = f'kMDItemFSName == "{quoted}" && kMDItemFSSize == {size} && kMDItemFSContentChangeDate >= $time.now(-600)'
        out = subprocess.run(["mdfind", query], capture_output=True, text=True, timeout=4).stdout
        for line in out.splitlines():
            path = line.strip()
            if not path or "/.Trash/" in path or path.startswith(("/private/var/", "/var/folders/")):
                continue
            if unicodedata.normalize("NFC", os.path.basename(path)) == unicodedata.normalize("NFC", name):
                return os.path.dirname(path)
    return None


def _locate_scan(name, size, budget=1.5, depth=3):
    home = os.path.expanduser("~")
    roots = [os.path.join(home, d) for d in ("Downloads", "Desktop", "Documents")]
    roots += [os.path.join(home, "OneDrive", d) for d in ("Desktop", "Documents")]
    end, now = time.time() + budget, time.time()
    fold = (lambda s: s.lower()) if os.name == "nt" else (lambda s: s)
    want = fold(name)

    def hit(folder):
        try:
            st = os.stat(os.path.join(folder, name))
        except OSError:
            return False
        return st.st_size == size and now - st.st_mtime < 600

    if hit(home):
        return home
    stack = [(r, 0) for r in roots if os.path.isdir(r)]
    while stack and time.time() < end:
        folder, level = stack.pop(0)
        try:
            with os.scandir(folder) as it:
                entries = list(it)
        except OSError:
            continue
        for e in entries:
            if fold(e.name) == want and hit(folder):
                return folder
        if level < depth:
            stack += [(e.path, level + 1) for e in entries
                      if not e.name.startswith((".", "$")) and e.is_dir(follow_symlinks=False)]
    return None


def friendly_folder(folder):
    """/Users/salim/Desktop/Reports -> "Desktop / Reports" (the full path when it is outside the home folder)."""
    home = os.path.expanduser("~")
    norm = os.path.normpath(folder)
    if norm == os.path.normpath(home):
        return os.path.basename(norm) or norm
    if norm.startswith(os.path.normpath(home) + os.sep):
        return " / ".join(os.path.relpath(norm, home).split(os.sep))
    return norm


# --------------------------------------------------------------- server logic

def cancel_close():
    global _close_timer
    with _close_lock:
        if _close_timer is not None:
            _close_timer.cancel()
            _close_timer = None


def schedule_close(delay=4.0):
    global _close_timer
    with _close_lock:
        if _close_timer is not None:
            _close_timer.cancel()
        _close_timer = threading.Timer(delay, shutdown_now)
        _close_timer.daemon = True
        _close_timer.start()


APP_NAME = os.environ.get("PDFLAB_APP_NAME") or "PDF Lab"
CHROME_PROC = None
# Where the app window lives.
#   "private": a Chrome of our own with an empty profile. The app can close it, but it shows a second Chrome
#              icon in the Dock, and clicking that icon opens an empty Chrome window.
#   "shared":  an app window inside the Chrome the user already runs (their profile, no extra icon). The app
#              never touches that Chrome: the page closes its own window, and the server watches the page.
# The Mac uses "shared". PDFLAB_WINDOW=private (or shared) in the Launcher overrides the choice.
WINDOW_MODE = (os.environ.get("PDFLAB_WINDOW") or "").lower()
if WINDOW_MODE not in ("shared", "private"):
    WINDOW_MODE = "shared" if sys.platform == "darwin" else "private"
LAST_PING = 0.0   # when the page last said it is alive (shared window: the only sign that the window exists)
UPDATER = None    # updater.Updater when this copy of the app updates itself (Mac app bundle, Windows launcher)
ACTIVE = 0        # requests being worked on right now: the app never quits by itself in the middle of a job
ACTIVE_LOCK = threading.Lock()


def chrome_profile_dir():
    base = os.path.expanduser("~/Library/Application Support/PDF Lab") if sys.platform == "darwin" \
        else os.path.join(tempfile.gettempdir(), "pdf-lab-profile")
    return os.path.join(base, "Chrome")


def stop_window():
    """Close the app window by ending the private Chrome instance that owns it."""
    global CHROME_PROC
    if WINDOW_MODE == "shared":
        return  # the window belongs to the user's own Chrome: the page closes itself, nothing is killed here
    proc, CHROME_PROC = CHROME_PROC, None
    if proc is not None:
        try:
            proc.terminate()
            proc.wait(timeout=1.5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
    # Fallback for the case where Chrome handed the window to an instance that was already running.
    try:
        subprocess.run(["pkill", "-f", "--", f"--user-data-dir={chrome_profile_dir()}"],
                       timeout=2, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def stop_wrapper():
    """When packaged, this process runs as a child of the small launcher app that owns the Dock icon.
    Ending that parent makes the Dock icon disappear at once instead of lingering."""
    try:
        parent = os.getppid()
        if parent > 1:
            comm = subprocess.run(["ps", "-p", str(parent), "-o", "comm="], capture_output=True,
                                  text=True, timeout=1).stdout.strip()
            if os.path.basename(comm) == APP_NAME:
                os.kill(parent, signal.SIGTERM)
    except Exception:
        pass
    if sys.platform == "darwin":
        try:
            subprocess.run(["osascript", "-e", f'tell application "{APP_NAME}" to quit'],
                           timeout=2, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


def watch_window(proc, started):
    """The app lives as long as its window: when our Chrome instance ends (Cmd+Q, crash), quit as well.
    A very quick exit only means Chrome handed the window to an instance that was already running."""
    proc.wait()
    if CHROME_PROC is proc and time.time() - started > 4:
        log("window closed")
        shutdown_now()


def shutdown_now(*_args):
    global QUITTING
    QUITTING = True   # first: a conversion that is retrying must not start another Chrome now
    log("shutting down")
    for proc in list(PRINTING):  # a conversion that is still running must not outlive the app
        try:
            proc.kill()
        except Exception:
            pass
    for profile in list(OPENED):
        try:
            subprocess.run(["/usr/bin/pkill", "-f", profile], stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
        except Exception:
            pass
    stop_window()
    stop_wrapper()
    os._exit(0)


class Handler(BaseHTTPRequestHandler):
    server_version = "PDFLab/2.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    # helpers -------------------------------------------------------------
    def _trusted(self, post=False):
        """Only this app's own page may use the server. A foreign Host means DNS rebinding, a foreign
        Origin means some web site is posting to us from the user's browser."""
        port = self.server.server_address[1]
        hosts = (f"{HOST}:{port}", f"localhost:{port}")
        if (self.headers.get("Host") or "").lower() not in hosts:
            return False
        if post:
            origin = self.headers.get("Origin")
            if origin is not None and origin.lower() not in tuple("http://" + h for h in hosts):
                return False
            if self.headers.get("Sec-Fetch-Site", "same-origin") not in ("same-origin", "none"):
                return False
        return True

    def _send(self, status, body=b"", ctype="application/json", extra=None):
        self.send_response(status)
        self.send_header(IDENTITY_HEADER, "1")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if self.close_connection:
            self.send_header("Connection", "close")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj).encode("utf-8"))

    def _error(self, msg, status=400, detail=""):
        self._json({"error": msg, "detail": detail} if detail else {"error": msg}, status)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = -1
        if length < 0 or self.headers.get("Transfer-Encoding"):
            raise ValueError("Bad request.")
        if length > MAX_UPLOAD:
            raise ValueError("This file is too large. The limit is 1 GB.")
        data = self.rfile.read(length) if length else b""
        if len(data) != length:
            raise ValueError("The upload was interrupted.")
        self._body_read = True
        return data

    def _body_json(self):
        raw = self._body()
        try:
            obj = json.loads(raw or b"{}")
        except ValueError:
            obj = None
        if not isinstance(obj, dict):
            raise ValueError("Bad request.")
        return obj

    # GET -----------------------------------------------------------------
    def do_GET(self):
        if not self._trusted():
            return self._send(403, b"Forbidden", "text/plain")
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/ping":
            global LAST_PING
            LAST_PING = time.time()
            cancel_close()
            return self._json({"ok": True})
        if path == "/":
            path = "/index.html"
        rel = urllib.parse.unquote(path).lstrip("/")
        root = os.path.realpath(WEB_DIR)
        full = "" if "\x00" in rel else os.path.realpath(os.path.join(root, rel))
        if not full.startswith(root + os.sep) or not os.path.isfile(full):
            return self._send(404, b"Not found", "text/plain")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if full.endswith(".mjs") or full.endswith(".js"):
            ctype = "text/javascript"
        if full.endswith(".woff2"):
            ctype = "font/woff2"
        with open(full, "rb") as f:
            self._send(200, f.read(), ctype)

    do_HEAD = do_GET

    # POST ----------------------------------------------------------------
    ROUTES = {
        "/api/upload": "_upload",
        "/api/merge": "_merge",
        "/api/pages": "_pages",
        "/api/split": "_split",
        "/api/organize": "_organize",
        "/api/rotate-all": "_rotate_all",
        "/api/html2pdf": "_html2pdf",
        "/api/word2pdf": "_word2pdf",
        "/api/images2pdf": "_images2pdf",
        "/api/picture": "_picture",
        "/api/doc2docx": "_doc2docx",
        "/api/build-docx": "_build_docx",
        "/api/build-pptx": "_build_pptx",
        "/api/edit/open": "_edit_open",
        "/api/edit/lines": "_edit_lines",
        "/api/edit/preview": "_edit_preview",
        "/api/edit/export": "_edit_export",
        "/api/zip": "_zip",
        "/api/locate": "_locate",
        "/api/discard": "_discard",
        "/api/update": "_update",
        "/api/closing": "_closing",
        "/api/shutdown": "_shutdown",
    }

    def do_POST(self):
        global ACTIVE
        self._body_read = False
        with ACTIVE_LOCK:
            ACTIVE += 1
        try:
            self._do_post()
        finally:
            with ACTIVE_LOCK:
                ACTIVE -= 1

    def _do_post(self):
        try:
            self._route()
        except ValueError as e:
            self._fail(str(e), 400, getattr(e, "detail", ""))
        except (KeyError, TypeError, AttributeError, IndexError) as e:
            log(traceback.format_exc())
            self._fail(f"This could not be processed ({type(e).__name__}).", 400)
        except Exception as e:  # pypdf and friends can raise many things on broken files
            log(traceback.format_exc())
            self._fail(f"{type(e).__name__}: {e}", 500)

    def _fail(self, msg, status, detail=""):
        if not self._body_read:
            self.close_connection = True  # the unread body would be parsed as the next request
        self._error(msg, status, detail)

    def _route(self):
        if not self._trusted(post=True):
            return self._fail("Forbidden", 403)
        name = self.ROUTES.get(urllib.parse.urlparse(self.path).path)
        if not name:
            return self._fail("Unknown route", 404)
        getattr(self, name)()

    def _upload(self):
        name = urllib.parse.unquote(self.headers.get("X-Filename", "document.pdf"))
        kind = self.headers.get("X-Kind", "pdf")
        data = self._body()
        item = {"name": name, "data": data, "pages": 0, "kind": kind}
        if kind == "pdf":
            if b"%PDF-" not in data[:1024]:
                raise ValueError(f"'{name}' does not look like a PDF file.")
            try:
                item["pages"] = len(open_reader(data).pages)
            except LockedError as e:
                raise ValueError(f"'{name}' {e}")
            except Exception:
                raise ValueError(f"'{name}' could not be read. It may be damaged.")
            if not item["pages"]:
                raise ValueError(f"'{name}' has no pages.")
        fid = uuid.uuid4().hex
        with STORE_LOCK:
            STORE[fid] = item
        self._json({"id": fid, "name": name, "pages": item["pages"], "size": len(data)})

    def _get(self, fid):
        with STORE_LOCK:
            item = STORE.get(fid) if isinstance(fid, str) else None
        if item is None:
            raise ValueError("A file is no longer available. Please add it again.")
        return item

    def _discard(self):
        fid = self._body_json().get("id")
        with STORE_LOCK:
            if isinstance(fid, str):
                STORE.pop(fid, None)
        with EDIT_LOCK:  # the collector may finalise MuPDF objects, which must not overlap with an edit request
            gc.collect()  # parsed PDFs form reference cycles that keep the whole file in memory until collected
            editor.free_cache()
        self._json({"ok": True})

    def _merge(self):
        ids = self._body_json().get("ids") or []
        if not isinstance(ids, list) or len(ids) < 2:
            raise ValueError("Add at least 2 PDF files to merge.")
        data = merge_pdfs([open_reader(self._get(i)["data"]) for i in ids])
        self._send(200, data, "application/pdf")

    def _pages(self):
        body = self._body_json()
        item = self._get(body.get("id"))
        data = pick_pages(open_reader(item["data"]), body.get("pages") or [])
        self._send(200, data, "application/pdf")

    def _organize(self):
        """items: [{"id", "n", "rot"}] drawn from any number of uploaded PDFs, in order."""
        items = self._body_json().get("items") or []
        if not items:
            raise ValueError("The document has no pages.")
        readers = {}
        writer = PdfWriter()
        for it in items:
            rid = it["id"]
            if rid not in readers:
                readers[rid] = open_reader(self._get(rid)["data"])
            reader = readers[rid]
            n = int(it["n"])
            rot = int(it.get("rot") or 0) % 360
            if n < 0 or n >= len(reader.pages) or rot % 90:
                raise ValueError("Invalid page selection.")
            page = writer.add_page(reader.pages[n])
            if rot:
                page.rotate(rot)
        self._send(200, write_pdf(writer), "application/pdf")

    def _rotate_all(self):
        """jobs: [{"id", "rot"}], one output PDF per job. One job returns a PDF, several a ZIP."""
        body = self._body_json()
        jobs = body.get("jobs") or []
        if not jobs:
            raise ValueError("Add at least one PDF.")
        # the page sends the ending in its language ("_rotated", or "_pivoté" in French)
        suffix = safe_name(body.get("suffix") or "", "_rotated").encode("utf-8")[:40].decode("utf-8", "ignore")
        outs = []
        for j in jobs:
            item = self._get(j["id"])
            rot = int(j.get("rot") or 0) % 360
            if rot % 90:
                raise ValueError("Rotation must be a multiple of 90 degrees.")
            reader = open_reader(item["data"])
            data = pick_pages(reader, [{"n": i, "rot": rot} for i in range(len(reader.pages))])
            outs.append((safe_name(os.path.splitext(item["name"])[0]) + suffix + ".pdf", data))
        if len(outs) == 1:
            return self._send(200, outs[0][1], "application/pdf")
        self._send(200, make_zip(outs), "application/zip")

    def _split(self):
        body = self._body_json()
        item = self._get(body.get("id"))
        groups = body.get("groups") or []
        if not groups:
            raise ValueError("Nothing to split.")
        reader = open_reader(item["data"])
        base = safe_name(body.get("base") or os.path.splitext(item["name"])[0], "document")
        width = max(2, len(str(len(groups))))
        entries = []
        for i, picks in enumerate(groups, start=1):
            entries.append((f"{base}_{i:0{width}d}.pdf", pick_pages(reader, picks)))
        self._send(200, make_zip(entries), "application/zip")

    def _html2pdf(self):
        body = self._body_json()
        html = body.get("html") or ""
        if not isinstance(html, str) or len(html) < 20:
            raise ValueError("Nothing to convert.")
        head = re.search(r"<head[^>]*>", html, re.I)
        cut = head.end() if head else 0
        html = html[:cut] + PRINT_CSP + html[cut:]
        work = tempfile.mkdtemp(prefix="pdflab-")
        try:
            with open(os.path.join(work, "index.html"), "w", encoding="utf-8", errors="replace") as f:
                f.write(html)
            self._send(200, html_to_pdf(work), "application/pdf")
        finally:
            remove_dir(work)

    def _word2pdf(self):
        """{"html": the document as a printable page, "overlay": its headers and footers, or null} -> PDF."""
        body = self._body_json()
        html = body.get("html") or ""
        overlay = body.get("overlay")
        if not isinstance(html, str) or len(html) < 20:
            raise ValueError("Nothing to convert.")
        head = re.search(r"<head[^>]*>", html, re.I)
        if not head:
            raise ValueError("Nothing to convert.")
        html = html[:head.end()] + PRINT_CSP_X + html[head.end():]
        work = tempfile.mkdtemp(prefix="pdflab-")
        try:
            with open(os.path.join(work, "index.xhtml"), "w", encoding="utf-8", errors="replace") as f:
                f.write(html)
            data = html_to_pdf(work, "index.xhtml")
            if isinstance(overlay, dict):
                try:
                    data = add_page_margins(data, overlay, work)
                except PrintFailed:
                    raise
                except Exception:   # the text pages exist: a PDF without headers beats no PDF
                    log("headers and footers could not be added:\n" + traceback.format_exc())
            self._send(200, data, "application/pdf")
        finally:
            remove_dir(work)

    def _images2pdf(self):
        body = self._body_json()
        items = body.get("items") or []
        if not items:
            raise ValueError("Add at least one image.")
        page = body.get("page", "a4")
        if page not in ("fit", "a4", "letter"):
            raise ValueError("Unknown page size.")
        orientation = body.get("orientation", "auto")
        margin = body.get("margin", "none")
        merge = body.get("merge", True)
        work = tempfile.mkdtemp(prefix="pdflab-")
        try:
            files = []
            for i, it in enumerate(items):
                stored = self._get(it["id"])
                ext = os.path.splitext(stored["name"])[1].lower()
                if not re.fullmatch(r"\.[a-z0-9]{1,5}", ext):  # "#", "?" or "%" would break the file URL
                    ext = ".img"
                fname = f"img{i}{ext}"
                with open(os.path.join(work, fname), "wb") as f:
                    f.write(stored["data"])
                files.append({"file": fname, "w": it["w"], "h": it["h"], "name": stored["name"]})

            def one_pdf(i, it):
                sub = os.path.join(work, f"job{i}")
                os.makedirs(sub)
                shutil.copy(os.path.join(work, it["file"]), os.path.join(sub, it["file"]))
                html, _sizes = images_to_pdf_html(sub, [it], page, orientation, margin)
                with open(os.path.join(sub, "index.html"), "w", encoding="utf-8") as f:
                    f.write(html)
                return html_to_pdf(sub)

            if merge or len(files) == 1:
                html, sizes = images_to_pdf_html(work, files, page, orientation, margin)
                with open(os.path.join(work, "index.html"), "w", encoding="utf-8") as f:
                    f.write(html)
                data = html_to_pdf(work)
                if len(files) > 1 and not pages_match(data, sizes):
                    # This Chrome did not honour the mixed page sizes: build one page at a time and join them.
                    log("mixed page sizes not honoured, converting one image at a time")
                    data = merge_pdfs([PdfReader(io.BytesIO(one_pdf(i, it))) for i, it in enumerate(files)])
                return self._send(200, data, "application/pdf")
            entries = []
            for i, it in enumerate(files):
                entries.append((safe_name(os.path.splitext(it["name"])[0]) + ".pdf", one_pdf(i, it)))
            self._send(200, make_zip(entries), "application/zip")
        finally:
            remove_dir(work)

    def _picture(self):
        """A picture Chrome cannot show, as PNG (or JPG). The result is kept like an uploaded file: its id comes
        back in X-Id, ready for /api/images2pdf, and X-Pages says how many pictures the file holds."""
        body = self._body_json()
        item = self._get(body.get("id"))
        name = item["name"]
        try:
            page = int(body.get("page") or 0)
        except (TypeError, ValueError):
            page = 0
        try:
            data, ctype, pages = read_picture(item["data"], name, page)
        except PictureError as e:
            raise ValueError({
                "raw": f"'{name}' is a camera RAW file. Export the photo as JPG or TIFF first, then add it.",
                "large": f"'{name}' is too large to convert.",
                "damaged": f"'{name}' could not be read. It may be damaged.",
            }.get(e.kind, f"'{name}' is not a picture PDF Lab can read."))
        stem = os.path.splitext(name)[0] + (f"_{page + 1}" if pages > 1 else "")
        fid = uuid.uuid4().hex
        with STORE_LOCK:
            STORE[fid] = {"name": stem + (".jpg" if ctype == "image/jpeg" else ".png"), "data": data, "pages": 0, "kind": "file"}
        self._send(200, data, ctype, {"X-Id": fid, "X-Pages": str(pages)})

    def _doc2docx(self):
        data = self._body()
        if sys.platform != "darwin" or not shutil.which("textutil"):
            raise ValueError("Old .doc files are not supported here. Please save the file as .docx first.")
        work = tempfile.mkdtemp(prefix="pdflab-")
        try:
            src = os.path.join(work, "in.doc")
            with open(src, "wb") as f:
                f.write(data)
            subprocess.run(["textutil", "-convert", "docx", "-output", os.path.join(work, "out.docx"), src],
                           check=True, timeout=60, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            with open(os.path.join(work, "out.docx"), "rb") as f:
                self._send(200, f.read(),
                           "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        except Exception:
            raise ValueError("This .doc file could not be converted. Please save it as .docx first.")
        finally:
            shutil.rmtree(work, ignore_errors=True)

    def _build_docx(self):
        body = self._body_json()
        data = builders.build_docx(body.get("page") or {}, body.get("blocks") or [])
        self._send(200, data, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")

    def _build_pptx(self):
        body = self._body_json()
        data = builders.build_pptx(body.get("slides") or [])
        self._send(200, data, "application/vnd.openxmlformats-officedocument.presentationml.presentation")

    # ---- Edit PDF -------------------------------------------------------
    def _edit_state(self, fid):
        """The editing engine plus per-file facts (font usage across the document), computed once per upload."""
        if not editor.load_engine(HERE):
            raise ValueError("The Edit PDF engine could not be loaded on this Mac. (" + str(editor.ENGINE_ERROR) + ")")
        item = self._get(fid)
        if item.get("kind") != "pdf":
            raise ValueError("This file is not a PDF.")
        st = item.get("edit")
        if st is None:
            doc = editor.pymupdf.open(stream=item["data"], filetype="pdf")
            try:
                if doc.needs_pass:
                    raise ValueError("This PDF is password protected and cannot be edited.")
                usage, groups = editor.doc_usage(doc, 120)
                st = {"usage": usage, "groups": groups, "pages": editor.view_pages(doc)}
            finally:
                doc.close()
            item["edit"] = st
        return item, st

    def _edit_edits(self, body):
        edits = body.get("edits") or []
        if not isinstance(edits, list):
            raise ValueError("Bad request.")
        return edits

    def _edit_open(self):
        with EDIT_LOCK:
            item, st = self._edit_state(self._body_json().get("id"))
            self._json({"pages": st["pages"], "fonts": editor.font_families()})

    def _edit_lines(self):
        body = self._body_json()
        with EDIT_LOCK:
            item, st = self._edit_state(body.get("id"))
            pno = body.get("page")
            if not isinstance(pno, int) or not (0 <= pno < len(st["pages"])):
                raise ValueError("Invalid page.")
            self._json({"lines": editor.lines_payload(item["data"], pno, st["usage"], st["groups"])})

    def _edit_session(self, item, st, edits, only_page=None):
        S = editor.Session(item["data"], st["usage"], st["groups"], editor.FontResolver())
        try:
            S.apply(edits, only_page)
        except editor.EditError as e:
            S.close()
            raise ValueError(str(e))
        except Exception:
            S.close()
            raise
        return S

    def _edit_preview(self):
        body = self._body_json()
        with EDIT_LOCK:
            item, st = self._edit_state(body.get("id"))
            pno = body.get("page")
            if not isinstance(pno, int) or not (0 <= pno < len(st["pages"])):
                raise ValueError("Invalid page.")
            scale = max(0.5, min(6.0, float(body.get("scale") or 2)))
            S = self._edit_session(item, st, self._edit_edits(body), pno)
            clip = body.get("clip")
            if clip is not None and not (isinstance(clip, list) and len(clip) == 4):
                clip = None
            try:
                png = S.png(pno, scale, clip)
            finally:
                S.close()  # inside the lock: MuPDF must never be used from two threads at once
            self._send(200, png, "image/png", {"X-Edit-Report": json.dumps(S.summary())})

    def _edit_export(self):
        body = self._body_json()
        with EDIT_LOCK:
            item, st = self._edit_state(body.get("id"))
            S = self._edit_session(item, st, self._edit_edits(body))
            try:
                data = S.save()
            finally:
                S.close()
            self._send(200, data, "application/pdf", {"X-Edit-Report": json.dumps(S.summary())})

    def _zip(self):
        files = self._body_json().get("files") or []
        if not isinstance(files, list):
            raise ValueError("Bad request.")
        entries = [(safe_name(f.get("name")), base64.b64decode(f.get("b64") or "")) for f in files]
        self._send(200, make_zip(entries), "application/zip")

    def _locate(self):
        """Where did the browser save the file? {"name", "size"} -> {"folder", "display"} or {} when not found."""
        body = self._body_json()
        folder = locate_saved(str(body.get("name") or ""), body.get("size"))
        self._json({"folder": folder, "display": friendly_folder(folder)} if folder else {})

    def _update(self):
        """What the update bar of the page asks and tells (web/js/update.js). Without an updater (the project
        folder, a test server) the answer is "off" and the page shows nothing."""
        do = self._body_json().get("do")
        u = UPDATER
        if u is None:
            return self._json({"state": "off"})
        if do == "install":
            u.install()
        elif do == "seen":
            u.seen_updated()
        self._json(u.status())

    def _closing(self):
        self._body()
        schedule_close()
        self._json({"ok": True})

    def _shutdown(self):
        self._body()
        self._json({"ok": True})
        threading.Timer(0.2, shutdown_now).start()


# window / launch ---------------------------------------------------------

def is_ours(port):
    try:
        with urllib.request.urlopen(f"http://{HOST}:{port}/api/ping", timeout=1.5) as r:
            return r.headers.get(IDENTITY_HEADER) == "1"
    except Exception:
        return False


def open_window(url):
    """Open the UI in its own chromeless Chrome window (a private Chrome instance, so it can be closed cleanly)."""
    global CHROME_PROC
    if os.environ.get("PDFLAB_NO_BROWSER") or "--no-browser" in sys.argv:
        return
    chrome = find_chrome()
    if not chrome:
        if sys.platform == "darwin":
            subprocess.Popen(["open", url])
        return
    if WINDOW_MODE == "shared":
        return open_shared_window(chrome, url)
    profile = chrome_profile_dir()
    os.makedirs(profile, exist_ok=True)
    cmd = [chrome, f"--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check",
           "--hide-crash-restore-bubble", "--disable-features=Translate,MacAppCodeSignClone", "--new-window", f"--app={url}"]
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        cmd.append("--no-sandbox")
    try:
        CHROME_PROC = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        threading.Thread(target=watch_window, args=(CHROME_PROC, time.time()), daemon=True).start()
    except Exception as e:
        log(f"could not open Chrome: {e}")
        if sys.platform == "darwin":
            subprocess.Popen(["open", url])


def open_shared_window(chrome, url):
    """Open the UI as an app window of the Chrome the user already uses (their own profile).

    On the Mac this goes through "open", so Chrome is started by macOS and not as a child of this app: a Chrome
    that is already running takes the window over, and one that was closed starts normally. No option of ours
    is passed along, because it would apply to the user's whole Chrome session. "?window=shared" tells the page
    that it has to close its own window when the app quits."""
    url = url.rstrip("/") + "/?window=shared"
    if sys.platform == "darwin" and ".app/" in chrome:
        cmd = ["open", "-n", "-a", chrome.split(".app/")[0] + ".app", "--args", "--new-window", f"--app={url}"]
    else:
        cmd = [chrome, f"--app={url}"]
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.append("--no-sandbox")
    try:
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log(f"could not open Chrome: {e}")
        if sys.platform == "darwin":
            subprocess.Popen(["open", url])


def browser_running():
    """Is the browser that holds the shared window still running at all?"""
    chrome = find_chrome()
    if not chrome:
        return True  # cannot tell: never quit because of this
    try:
        if sys.platform == "darwin":  # the main process is called exactly "Google Chrome"; helpers have longer names
            cmd = ["pgrep", "-x", os.path.basename(chrome)]
        else:
            cmd = ["pgrep", "-f", chrome]
        return subprocess.run(cmd, capture_output=True, timeout=3).returncode == 0
    except Exception:
        return True


def watch_shared_window():
    """Shared window only. The page tells us when its window closes, but when the user quits the whole of Chrome
    that message can be lost. So: once the page has been seen, if it is silent and Chrome is not running any more,
    the window cannot exist and the app quits. A page that is merely slowed down in the background (Chrome does
    that to hidden windows) never triggers this, because Chrome itself is still running."""
    while True:
        time.sleep(5)
        if ACTIVE or PRINTING:
            continue  # a job is running: never quit under it
        if LAST_PING and time.time() - LAST_PING > 20 and not browser_running():
            log("the browser was closed")
            shutdown_now()


def restart_in_place(port):
    """After an update of the Mac app: run the new code in this same process, on the same port. The Dock icon and
    the window stay; the page notices the new version and reloads itself."""
    global QUITTING
    QUITTING = True
    for proc in list(PRINTING):
        try:
            proc.kill()
        except Exception:
            pass
    os.environ["PDFLAB_PORT"] = str(port)
    cmd = [sys.executable, os.path.join(HERE, "server.py"), f"--after-update={os.getpid()}"]
    try:
        sys.stdout.flush()
        os.execv(sys.executable, cmd)
    except OSError as e:
        # This process cannot be replaced: start the new version next to it and leave. It waits for this one to end.
        log(f"could not restart in place ({e}); starting the new version as a new process")
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, start_new_session=True)
        os._exit(0)


def start_updater(port):
    """The Mac app updates itself when it runs from an app bundle that it may change. The project folder never does."""
    global UPDATER
    if os.name == "nt" or UPDATER is not None:
        return  # Windows: the launcher sets UPDATER (its installer does the replacing)
    conf = os.path.join(HERE, "update.json")
    if not updater.bundle_of(HERE) or not os.path.isfile(conf):
        return
    UPDATER = updater.Updater(conf, state_dir(), kind="files", log=log, app_files=HERE, restart=lambda: restart_in_place(port))
    UPDATER.start()


def window_after_update(url, started, patience=8.0):
    """The app was just updated in place: its window is still open and reloads itself. Only when no page shows up
    (the window was closed meanwhile) a new window is opened."""
    end = time.time() + patience
    while time.time() < end:
        if LAST_PING > started:
            return
        time.sleep(0.25)
    log("no window came back after the update, opening one")
    open_window(url)


def main():
    server = None
    port = None
    started = time.time()
    after_update = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--after-update=")), None)
    if after_update and after_update.isdigit() and int(after_update) != os.getpid():
        end = time.time() + 8      # started next to the old version: let it leave the port first
        while time.time() < end:
            try:
                os.kill(int(after_update), 0)
            except OSError:
                break
            time.sleep(0.1)
    for p in PORTS:
        try:
            server = ThreadingHTTPServer((HOST, p), Handler)
            port = p
            break
        except OSError:
            if is_ours(p):
                log(f"already running on port {p}, opening a window")
                open_window(f"http://{HOST}:{p}/")
                return
    if server is None:
        log("no free port found")
        stop_wrapper()  # otherwise the Dock icon of the wrapper app stays behind with nothing running
        sys.exit(1)
    server.daemon_threads = True
    for stale in glob.glob(os.path.join(tempfile.gettempdir(), "pdflab-*")):  # left by a crash, we are the only instance
        shutil.rmtree(stale, ignore_errors=True)
    for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        try:
            signal.signal(sig, shutdown_now)
        except Exception:
            pass
    log(f"serving on http://{HOST}:{port}/ ({WINDOW_MODE} window)")
    if WINDOW_MODE == "shared":
        threading.Thread(target=watch_shared_window, daemon=True).start()
    start_updater(port)
    if after_update:
        threading.Thread(target=window_after_update, args=(f"http://{HOST}:{port}/", started), daemon=True).start()
    else:
        threading.Timer(0.4, open_window, args=(f"http://{HOST}:{port}/",)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
