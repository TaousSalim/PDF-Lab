import * as pdfjsLib from "../vendor/pdf.min.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("../vendor/pdf.worker.min.mjs", import.meta.url).href;

export { pdfjsLib };
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const DPR = Math.min(window.devicePixelRatio || 1, 2);

export const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;

export function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
}

export function fmtSize(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

/** File name parts follow the language chosen with the FR | EN switch (js/i18n.js): "_edited" or "_modifié". */
export const fname = (key) => (window.PDFLabI18n ? window.PDFLabI18n.name(key) : key);

export function stem(name) {
  return name.replace(/\.[^.]+$/, "");
}

/* ---------- colours: one tool colour, several jobs ---------- */
// A tool colour is chosen for looks. Used as a surface under text, or as text on a card, it is adjusted here
// (same hue) until it reaches the reading norm, so that a new colour can never bring unreadable labels.
const WHITE = "#ffffff", DARK_INK = "#2a2a31", LIGHT_CARD = "#ffffff", DARK_CARD = "#1a1c22";
const rgbOf = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
function lumOf(hex) {
  const [r, g, b] = rgbOf(hex).map((v) => { v /= 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a, b) {
  const x = lumOf(a), y = lumOf(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
function toHsl(hex) {
  const [r, g, b] = rgbOf(hex).map((v) => v / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
  if (!d) return [0, 0, l];
  const s = d / (1 - Math.abs(2 * l - 1));
  const h = max === r ? ((g - b) / d + 6) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h * 60, s, l];
}
function fromHsl(h, s, l) {
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = l - c / 2;
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  return "#" + [r, g, b].map((v) => Math.round((v + m) * 255).toString(16).padStart(2, "0")).join("");
}
/** The same hue, darker (on a light ground) or lighter (on a dark one), until it stands out by "target" to 1. */
export function shade(hex, against, target) {
  if (contrast(hex, against) >= target) return hex;
  const [h, s, l] = toHsl(hex), down = lumOf(against) > 0.4;
  for (let i = 1; i <= 240; i++) {
    const out = fromHsl(h, down ? s * 0.85 : s, Math.min(1, Math.max(0, l + (down ? -1 : 1) * i * 0.0025)));
    if (contrast(out, against) >= target) return out;
  }
  return down ? DARK_INK : WHITE;
}
const paletteCache = new Map();
/** ink: the text colour on the plain colour. fill: the surface for small labels (badges). onLight and onDark:
 *  the colour used as text on a light or a dark card. A pale colour (yellow) carries dark text and stays as it is. */
export function palette(color) {
  let p = paletteCache.get(color);
  if (!p) {
    const pale = contrast(color, WHITE) < 2.4;
    p = { ink: pale ? DARK_INK : WHITE, fill: pale ? color : shade(color, WHITE, 4.6),
          onLight: shade(color, LIGHT_CARD, 4.9), onDark: shade(color, DARK_CARD, 4.6) };
    paletteCache.set(color, p);
  }
  return p;
}
/** The style variables of a tool page (see styles.css, "tool colour"). */
export function toolVars(tool) {
  const p = palette(tool.color);
  return `--tc:${tool.color};--tc-light:${tool.light};--tc-ink:${p.ink};--tc-fill:${p.fill};--tc-tl:${p.onLight};--tc-td:${p.onDark}`;
}

/* ---------- toasts ---------- */
export function toast(msg, kind = "") {
  const t = el("div", `toast ${kind}`);
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => {
    t.style.transition = "opacity .3s";
    t.style.opacity = "0";
    setTimeout(() => t.remove(), 320);
  }, kind === "error" ? 6000 : 3600);
}

/* ---------- render queue: one canvas render at a time ---------- */
let chain = Promise.resolve();
export function enqueue(fn) {
  const run = chain.then(fn);
  chain = run.catch((e) => console.error("render failed", e && (e.message || e)));
  return run;
}

export async function renderPage(doc, pageNumber, canvas, cssWidth, opts = {}) {
  const page = await doc.getPage(pageNumber);
  const base = page.getViewport({ scale: 1 });
  const scale = opts.scale ?? (cssWidth * DPR) / base.width;
  const viewport = page.getViewport({ scale });
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvasContext: ctx, viewport }).promise;
  page.cleanup();
}

/* ---------- api ---------- */
export async function readError(res) {
  try {
    return (await res.json()).error || "Something went wrong.";
  } catch {
    return "Something went wrong.";
  }
}

/** The server's refusal as an Error. detail: the technical reason when the server gives one (shown small). */
export async function failure(res) {
  let info = {};
  try { info = await res.json(); } catch { /* not JSON */ }
  const err = new Error(info.error || "Something went wrong.");
  if (info.detail) err.detail = String(info.detail);
  return err;
}

/**
 * The job that is running now (one at a time): the tool page fills this in while its action runs.
 * signal stops the job's requests when the user presses Cancel; the two hooks tell the progress card that the
 * work has started (with the name of the file being produced) and that the result is about to be written.
 */
export const job = { signal: null, onProduce: null, onWrite: null, onSaved: null };

/** Rough time a server step takes for this many bytes, used to move the progress bar while no real figure exists. */
export const estMs = (bytes, base = 400, perMB = 6) => base + (bytes / 1048576) * perMB;

export function post(path, body, signal) {
  return fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
    signal: signal || undefined,
  });
}

/** POST json for the running job and return the response body as a Blob, or throw with the server's message. */
export async function postBlob(path, body) {
  const res = await post(path, body, job.signal);
  if (!res.ok) throw await failure(res);
  return res.blob();
}

export function discard(id) {
  if (id) post("/api/discard", { id }).catch(() => {});
}

/** Free an opened PDF everywhere: the server copy and the pdf.js document (worker memory, cached thumbnails). */
export function release(f) {
  if (!f) return;
  discard(f.id);
  try { f.doc?.__thumbs?.clear(); f.doc?.destroy(); } catch (e) { /* already gone */ }
}

export const MAX_UPLOAD = 1024 * 1024 * 1024;

/** Upload a file to the local server. kind: "pdf" validates it, "file" stores it as is. */
export async function upload(file, kind = "pdf") {
  if (file.size > MAX_UPLOAD) throw new Error(`${file.name} is larger than 1 GB, which is too big for PDF Lab.`);
  const res = await fetch("/api/upload", {
    method: "POST",
    headers: { "X-Filename": encodeURIComponent(file.name), "X-Kind": kind },
    body: file,
  });
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}

/** Upload a PDF and open it with pdf.js. */
export async function openPdf(file) {
  const info = await upload(file, "pdf");
  try {
    const buf = await file.arrayBuffer();
    const doc = await pdfjsLib.getDocument({ data: new Uint8Array(buf) }).promise;
    return { ...info, doc, file };
  } catch (e) {
    discard(info.id); // do not leave the copy on the server when the preview cannot open it
    throw new Error(`${file.name} could not be opened for preview. It may be damaged.`);
  }
}

/* ---------- saving ---------- */
const TYPES = {
  pdf: { "application/pdf": [".pdf"] },
  zip: { "application/zip": [".zip"] },
  docx: { "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"] },
  pptx: { "application/vnd.openxmlformats-officedocument.presentationml.presentation": [".pptx"] },
  jpg: { "image/jpeg": [".jpg"] },
  png: { "image/png": [".png"] },
};

/** Ask where to save first (needs the click), then build the file, then write it. */
export async function saveFile(suggestedName, produce) {
  const ext = (suggestedName.split(".").pop() || "").toLowerCase();
  let handle = null;
  if (window.showSaveFilePicker && TYPES[ext]) {
    try {
      handle = await window.showSaveFilePicker({
        suggestedName,
        types: [{ description: ext.toUpperCase(), accept: TYPES[ext] }],
      });
    } catch (e) {
      if (e.name === "AbortError") return null;
      handle = null;
    }
  }
  let blob;
  try {
    job.onProduce?.(handle ? handle.name : suggestedName);
    blob = await produce();
    if (!blob) throw new Error("Nothing was produced.");
    job.onWrite?.(); // last moment to cancel: this throws when the user did
  } catch (e) {
    // The save dialog already created an empty file: do not leave it behind when the job fails.
    try { await handle?.remove?.(); } catch (e2) { /* older browsers */ }
    throw e;
  }
  if (handle) {
    try {
      await writeChecked(handle, blob);
      job.onSaved?.({ name: handle.name, size: blob.size, picked: true });
      return handle.name;
    } catch (e) {
      // The work is done and must not be lost: when the chosen place cannot be written (the browser or the
      // system refused it), the file goes to the Downloads folder instead, and the summary says so.
      console.warn("could not write to the chosen place:", e && (e.message || e));
      try { await handle.remove?.(); } catch (e2) { /* nothing to clean */ }
      download(blob, handle.name);
      job.onSaved?.({ name: handle.name, size: blob.size, picked: false, moved: true });
      return handle.name;
    }
  }
  download(blob, suggestedName);
  job.onSaved?.({ name: suggestedName, size: blob.size, picked: false });
  return suggestedName;
}

/** Write the blob through the handle from the save dialog, then read the file back: it must be there, complete. */
async function writeChecked(handle, blob) {
  const w = await handle.createWritable();
  await w.write(blob);
  await w.close();
  if (!handle.getFile) return;
  const written = await handle.getFile();
  if (written.size !== blob.size) throw new Error(`the file on disk has ${written.size} bytes instead of ${blob.size}`);
}

/** The plain browser download, into the Downloads folder. */
function download(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
}

/* ---------- page range helpers ---------- */

/** "1, 3, 5-7" -> Set of 1-based numbers. Throws a friendly Error. */
export function parseSet(text, total) {
  const set = new Set();
  for (const part of text.replace(/\s+/g, "").split(",")) {
    if (!part) continue;
    for (const n of expandToken(part, total)) set.add(n);
  }
  return set;
}

/** Each comma separated token becomes one group (array of 1-based page numbers). */
export function parseGroups(text, total) {
  const groups = [];
  for (const part of text.replace(/\s+/g, "").split(",")) {
    if (!part) continue;
    groups.push(expandToken(part, total));
  }
  return groups;
}

function expandToken(part, total) {
  let a, b;
  if (/^\d+$/.test(part)) a = b = Number(part);
  else {
    const m = part.match(/^(\d*)-(\d*)$/);
    if (!m || (m[1] === "" && m[2] === "")) throw new Error(`"${part}" is not a valid page or range.`);
    a = m[1] === "" ? 1 : Number(m[1]);
    b = m[2] === "" ? total : Number(m[2]);
  }
  if (a < 1 || b < 1 || a > total || b > total) throw new Error(`Page ${a < 1 || a > total ? a : b} is out of range. The PDF has ${total} pages.`);
  if (a > b) throw new Error(`"${part}" is backwards. Write it as ${b}-${a}.`);
  const out = [];
  for (let i = a; i <= b; i++) out.push(i);
  return out;
}

/** Set of numbers -> "1, 3-5". */
export function formatRanges(nums) {
  const s = [...nums].sort((a, b) => a - b);
  const out = [];
  for (let i = 0; i < s.length; ) {
    let j = i;
    while (j + 1 < s.length && s[j + 1] === s[j] + 1) j++;
    out.push(j > i ? `${s[i]}-${s[j]}` : `${s[i]}`);
    i = j + 1;
  }
  return out.join(", ");
}

export function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",")[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

export function canvasToBlob(canvas, type = "image/jpeg", quality = 0.92) {
  return new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}
