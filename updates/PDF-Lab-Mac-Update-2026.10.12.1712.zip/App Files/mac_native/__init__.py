"""PDF Lab: the part that exists only in the native Mac app (see runner.py). Never copied to the Windows version."""
