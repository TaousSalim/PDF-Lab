/* Writes a WebP picture, apart from the page (a worker), so the window never freezes while a page is encoded.
 * The writing itself is done by libwebp (webp/, unmodified). Native Mac app only: see native.js, "WebP".
 *
 * In:  { id, pixels (RGBA bytes), width, height, quality (0 to 1) }
 * Out: { id, ok: true, bytes }   or   { id, ok: false, error }
 */
import factory from "./webp/webp_enc.js";

// The settings of libwebp (struct WebPConfig), as its own defaults, with the quality the page asks for.
const SETTINGS = {
  quality: 75, target_size: 0, target_PSNR: 0, method: 4, sns_strength: 50, filter_strength: 60, filter_sharpness: 0,
  filter_type: 1, partitions: 0, segments: 4, pass: 1, show_compressed: 0, preprocessing: 0, autofilter: 0,
  partition_limit: 0, alpha_compression: 1, alpha_filtering: 1, alpha_quality: 100, lossless: 0, exact: 0,
  image_hint: 0, emulate_jpeg_size: 0, thread_level: 0, low_memory: 0, near_lossless: 100, use_delta_palette: 0,
  use_sharp_yuv: 0,
};

let lib = null;
const engine = () => lib || (lib = factory({ noInitialRun: true }));

self.onmessage = async (e) => {
  const { id, pixels, width, height, quality } = e.data || {};
  try {
    const m = await engine();
    const q = Math.round(Math.max(0, Math.min(1, typeof quality === "number" ? quality : 0.8)) * 100);
    const out = m.encode(new Uint8ClampedArray(pixels), width, height, { ...SETTINGS, quality: q });
    if (!out) throw new Error("the picture could not be written");
    const bytes = out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength);
    self.postMessage({ id, ok: true, bytes }, [bytes]);
  } catch (err) {
    lib = null;      // a failed start, or memory that ran out: the next picture starts afresh
    self.postMessage({ id, ok: false, error: String(err && err.message || err) });
  }
};
