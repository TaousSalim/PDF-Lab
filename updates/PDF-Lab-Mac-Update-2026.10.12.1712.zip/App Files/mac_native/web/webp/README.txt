@jsquash/webp 1.5.0 (files codec/enc/webp_enc.js and webp_enc.wasm), unmodified.
What it is: Google's libwebp compiled to WebAssembly. It writes WebP pictures.
Used by: ../webp-worker.js, the only file that loads it. Needed in the native Mac app only: its web view
         (WebKit) cannot write WebP by itself, which PDF to Image offers as a format. Chrome can, so the
         Windows version does not carry this folder.
Source: https://github.com/jamsinclair/jSquash (npm package "@jsquash/webp"), built from
        https://github.com/GoogleChromeLabs/squoosh and https://chromium.googlesource.com/webm/libwebp
License: Apache 2.0 (the wrapper) and BSD 3-clause (libwebp), see LICENSE.txt.
