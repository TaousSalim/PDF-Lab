/* PDF Lab: what the pages need in the native Mac app, and only there.
 *
 * The native app adds this file to the page while serving it (mac_native/runner.py). The window is the Mac's own
 * web view (WebKit), not Chrome, and it belongs to the app. This file fills the gaps, without the tools knowing:
 *
 *   first start      the language follows the Mac (German, French, otherwise English) until one is chosen
 *   DE button        its "chosen" look (styles.css only knows FR and EN)
 *   saving           WebKit has no "save as" window for pages. window.showSaveFilePicker is provided here: the
 *                    app shows the Mac's own save window and writes the file where the user said.
 *   WebP             WebKit cannot write WebP pictures (PDF to Image): libwebp does it here (webp-worker.js)
 *   menus            the app is told which language is chosen, so its menu bar speaks it too
 *   an old macOS     a plain message instead of a page that half works
 *
 * Plain script loaded in <head>, before the language layer. window.__TAURI__ is how a page talks to the app; it
 * is missing when the pages are opened in an ordinary browser (tests), and then this file only sets the language.
 */
(function () {
  "use strict";

  var app = window.__TAURI__ && window.__TAURI__.core;
  var ask = function (what, args) { return app.invoke(what, args || {}); };

  /* ---------------- first start: the language of the Mac ---------------- */
  var mac = String(navigator.language || "en").slice(0, 2).toLowerCase();
  window.PDFLAB_DEFAULT_LANG = mac === "de" || mac === "fr" ? mac : "en";

  /* ---------------- the DE button ---------------- */
  var style = document.createElement("style");
  style.textContent = 'html[lang="de"] .lang-switch [data-set-lang="de"] { background: var(--accent); color: var(--accent-ink); }';
  document.head.appendChild(style);

  /* ---------------- an old macOS ---------------- */
  // The previews (pdf.js) need a web view from macOS 14.4 or later. Before that the app would open and then
  // show empty pages, so it says what is wrong instead.
  if (typeof Promise.withResolvers !== "function") {
    var TOO_OLD = {
      en: ["PDF Lab needs a newer macOS.", "Update this Mac to macOS 14.4 or newer, then open PDF Lab again."],
      fr: ["PDF Lab a besoin d’une version plus récente de macOS.", "Mettez ce Mac à jour vers macOS 14.4 ou une version ultérieure, puis rouvrez PDF Lab."],
      de: ["PDF Lab braucht ein neueres macOS.", "Aktualisiere diesen Mac auf macOS 14.4 oder neuer und öffne PDF Lab dann erneut."],
    };
    document.addEventListener("DOMContentLoaded", function () {
      var lang = (window.PDFLabI18n && window.PDFLabI18n.lang()) || window.PDFLAB_DEFAULT_LANG;
      var text = TOO_OLD[lang] || TOO_OLD.en;
      var note = document.createElement("div");
      note.className = "closed-note";
      note.setAttribute("translate", "no");
      note.style.cssText = "position:fixed;inset:0;z-index:99;background:var(--bg, #fff)";
      var strong = document.createElement("strong"), span = document.createElement("span");
      strong.textContent = text[0];
      span.textContent = text[1];
      note.append(strong, span);
      document.body.appendChild(note);
    });
  }

  /* ---------------- WebP ---------------- */
  // PDF to Image offers WebP. Chrome writes it by itself; this web view answers with a PNG instead, and the
  // tool would then refuse the page. So a canvas asked for WebP is written by libwebp here (webp-worker.js).
  // A web view that learns to write WebP one day is noticed, and then left to do it by itself.
  var plainToBlob = HTMLCanvasElement.prototype.toBlob;
  var writesWebp = null;      // a promise: true when the web view writes WebP by itself
  var webpWorker = null, webpJobs = new Map(), webpSerial = 0;

  function webpByWorker(pixels, width, height, quality) {
    if (!webpWorker) {
      webpWorker = new Worker("/native/webp-worker.js", { type: "module" });
      webpWorker.onmessage = function (e) {
        var job = webpJobs.get(e.data.id);
        if (!job) return;
        webpJobs.delete(e.data.id);
        job(e.data.ok ? new Blob([e.data.bytes], { type: "image/webp" }) : null);
      };
      webpWorker.onerror = function () {
        webpJobs.forEach(function (job) { job(null); });
        webpJobs.clear();
        webpWorker = null;
      };
    }
    return new Promise(function (done) {
      var id = ++webpSerial;
      webpJobs.set(id, done);
      webpWorker.postMessage({ id: id, pixels: pixels.buffer, width: width, height: height, quality: quality }, [pixels.buffer]);
    });
  }

  HTMLCanvasElement.prototype.toBlob = function (callback, type, quality) {
    if (type !== "image/webp") return plainToBlob.apply(this, arguments);
    var canvas = this;
    if (!writesWebp) {
      writesWebp = new Promise(function (ok) {
        var probe = document.createElement("canvas");
        probe.width = probe.height = 1;
        plainToBlob.call(probe, function (b) { ok(!!b && b.type === "image/webp"); }, "image/webp", 0.8);
      });
    }
    writesWebp.then(function (yes) {
      if (yes) return plainToBlob.call(canvas, callback, type, quality);
      var pixels = null;
      try {
        var g = canvas.getContext("2d");
        if (g && canvas.width && canvas.height) pixels = g.getImageData(0, 0, canvas.width, canvas.height).data;
      } catch (e) { pixels = null; }      // too large to read back
      if (!pixels) return callback(null);
      webpByWorker(pixels, canvas.width, canvas.height, quality).then(callback);
    });
  };

  if (!app) return;

  /* ---------------- saving ---------------- */
  // The app shows the save window ("save_dialog"). The file itself travels as an ordinary download of the web
  // view, which the app sends to the chosen place ("arm_download") and reports on (window.__pdflabNative.saved),
  // so even a very large file is written straight to disk.
  var waiting = null;     // the save in progress: { started(), finished(ok, why) }

  window.__pdflabNative = {
    /** Called by the app. stage: "start" (the file is being written) or "done". */
    saved: function (stage, ok, why) {
      if (!waiting) return;
      if (stage === "start") waiting.started();
      else waiting.finished(!!ok, why);
    },
  };

  function deliver(blob, name, token) {
    return ask("arm_download", { token: token }).then(function () {
      return new Promise(function (resolve, reject) {
        var a = document.createElement("a");
        var url = URL.createObjectURL(blob);
        var begun = false;
        var end = function () { waiting = null; clearTimeout(timer); URL.revokeObjectURL(url); a.remove(); };
        // the web view must start writing within a few seconds; after that a big file may take its time
        var timer = setTimeout(function () {
          if (begun) return;
          end();
          ask("cancel_save", {}).catch(function () {});
          reject(new Error("the save did not start"));
        }, 20000);
        waiting = {
          started: function () { begun = true; },
          finished: function (ok, why) { end(); if (ok) resolve(); else reject(new Error(why || "the file could not be written")); },
        };
        a.href = url;
        a.download = name;
        a.hidden = true;
        document.body.appendChild(a);
        a.click();
      });
    });
  }

  /** The part of the File System Access API that js/core.js uses (saveFile and writeChecked). */
  window.showSaveFilePicker = function (options) {
    var suggested = (options && options.suggestedName) || "document";
    return ask("save_dialog", { suggestedName: suggested }).then(function (picked) {
      if (!picked) throw new DOMException("The user closed the save window.", "AbortError");
      var blob = null;
      return {
        kind: "file",
        name: picked.name,
        createWritable: function () {
          return Promise.resolve({
            write: function (data) { blob = data instanceof Blob ? data : new Blob([data]); return Promise.resolve(); },
            close: function () { return blob ? deliver(blob, picked.name, picked.token) : Promise.reject(new Error("nothing to write")); },
          });
        },
        // nothing was created by the save window, so there is nothing to take back: only forget the chosen place
        remove: function () { return ask("cancel_save", {}).catch(function () {}); },
      };
    });
  };

  /* ---------------- the menu bar speaks the chosen language ---------------- */
  var tell = function () {
    var lang = (window.PDFLabI18n && window.PDFLabI18n.lang()) || window.PDFLAB_DEFAULT_LANG;
    ask("set_language", { lang: lang }).catch(function () {});
  };
  window.addEventListener("pdflab:lang", tell);
  document.addEventListener("DOMContentLoaded", tell);
})();
