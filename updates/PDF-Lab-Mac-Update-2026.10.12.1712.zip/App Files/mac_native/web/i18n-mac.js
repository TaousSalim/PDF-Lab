/* PDF Lab language layer of the native Mac app (English, French and German).
 *
 * The native app serves this file in the place of js/i18n.js (mac_native/runner.py). It is that file, taught to
 * handle any number of dictionaries instead of exactly one: everything else works the same way and has the same
 * names, so the tools and js/update.js see no difference.
 *   - the dictionaries are window.PDFLAB_FR (js/lang-fr.js) and window.PDFLAB_DE (lang-de.js in this folder);
 *   - every piece of text the app puts on the page is looked up in the dictionary of the chosen language and
 *     replaced on the spot; the English original is remembered, so switching language is instant, reloads
 *     nothing, and goes straight from one language to another;
 *   - anything marked translate="no" is never touched.
 *
 * When js/i18n.js changes, make the same change here (runner.py --check reminds of it).
 * Plain script loaded in <head>, after the dictionaries, so the first paint is already in the right language.
 */
(function () {
  "use strict";

  var has = Object.prototype.hasOwnProperty;
  var DICTS = {};
  if (window.PDFLAB_FR) DICTS.fr = window.PDFLAB_FR;
  if (window.PDFLAB_DE) DICTS.de = window.PDFLAB_DE;
  if (!DICTS.fr && window.console) console.warn("PDF Lab: the French dictionary (js/lang-fr.js) did not load.");
  if (!DICTS.de && window.console) console.warn("PDF Lab: the German dictionary (lang-de.js) did not load.");
  var known = function (v) { return v === "en" || (typeof v === "string" && has.call(DICTS, v)); };

  var STORE_KEY = "pdflab-lang";
  var ATTRS = ["title", "placeholder", "aria-label", "alt"];
  // Never looked at: user content, code, drawings.
  var SKIP = '[translate="no"], [contenteditable]:not([contenteditable="false"]), script, style, noscript, textarea, svg, canvas';
  var root = document.documentElement;

  // The choice is kept in two places: the page's storage, and a cookie. The storage belongs to one port; if the
  // app ever has to use another one, the cookie still has the choice.
  function saved() {
    var v = null;
    try { v = localStorage.getItem(STORE_KEY); } catch (e) { /* no storage */ }
    if (!known(v)) {
      var m = /(?:^|;\s*)pdflab-lang=([a-z]{2})\b/.exec(document.cookie || "");
      v = m && known(m[1]) ? m[1] : null;
    }
    return v;
  }
  function remember(v) {
    try { localStorage.setItem(STORE_KEY, v); } catch (e) { /* no storage */ }
    try { document.cookie = STORE_KEY + "=" + v + "; path=/; max-age=315360000; SameSite=Lax"; } catch (e) { /* no cookies */ }
  }
  var lang = saved();
  if (!known(lang)) lang = known(window.PDFLAB_DEFAULT_LANG) ? window.PDFLAB_DEFAULT_LANG : "en";

  /* ---------------- which texts have no translation yet (used by the tests) ---------------- */
  // While a language other than English is shown, every English text that has no entry in its dictionary is
  // noted. audit("fr") does the same while the app stays in English.
  var audit = null;
  var misses = {};       // language -> Set of English texts
  function miss(which, core) {
    if (!/[A-Za-z]{2}/.test(core) || /^#[0-9a-f]{3,8}$/i.test(core)) return;
    (misses[which] || (misses[which] = new Set())).add(core);
  }

  /* ---------------- looking a text up ---------------- */
  function lookup(d, core, node, kind) {
    var exact = d.exact || {}, patterns = d.patterns || [];
    if (has.call(exact, core)) {
      var hit = exact[core];
      return typeof hit === "function" ? hit(node) : hit;
    }
    for (var i = 0; i < patterns.length; i++) {
      var p = patterns[i];
      if (p[2] === "attr" && kind !== "attr") continue;
      var m = p[0].exec(core);
      if (m) return p[1](m, function (s) { return phrase(d, s); }, node);
    }
    return undefined;
  }

  /** One phrase in the language of dictionary d, or undefined. "a · b" is translated part by part. */
  function translated(d, core, node, kind) {
    var out = lookup(d, core, node, kind);
    if (out !== undefined) return out;
    if (core.indexOf("·") > 0) {
      var parts = core.split(/\s*·\s*/);
      for (var i = 0; i < parts.length; i++) {
        if (!/[A-Za-z%]|\d\.\d/.test(parts[i])) continue;
        var one = lookup(d, parts[i], node, kind);
        if (one === undefined) return undefined;
        parts[i] = one;
      }
      return parts.join(" · ");
    }
    return undefined;
  }

  /** A phrase used inside another one (a count inside a message, a tool name inside the window title). */
  function phrase(d, s) {
    var out = translated(d, String(s));
    return out === undefined ? String(s) : out;
  }

  /** The text to show for an English source text in the current language. */
  function render(src, node, kind) {
    var which = lang !== "en" ? lang : audit;
    if (!which || !DICTS[which]) return src;
    var core = src.replace(/\s+/g, " ").trim();
    if (!core || !/[A-Za-z%]|\d\.\d/.test(core)) return src;   // nothing to say: empty, or a plain whole number
    var out = translated(DICTS[which], core, node, kind);
    if (out === undefined) {
      miss(which, core);
      return src;
    }
    if (lang === "en") return src;
    return src.match(/^\s*/)[0] + out + src.match(/\s*$/)[0];
  }

  /* ---------------- the page ---------------- */
  var texts = new WeakMap();   // text node -> { src: English, out: what this file last wrote }
  var attrs = new WeakMap();   // element -> { attribute: { src, out } }

  function doText(n) {
    var cur = n.data;
    var rec = texts.get(n);
    if (!rec || cur !== rec.out) { rec = { src: cur, out: cur }; texts.set(n, rec); }  // the app wrote a new text
    var want = render(rec.src, n, "text");
    rec.out = want;
    if (want !== cur) n.data = want;
  }

  function doAttr(el, name) {
    var cur = el.getAttribute(name);
    if (cur == null) return;
    var all = attrs.get(el);
    if (!all) { all = {}; attrs.set(el, all); }
    var rec = all[name];
    if (!rec || cur !== rec.out) rec = all[name] = { src: cur, out: cur };
    var want = render(rec.src, el, "attr");
    rec.out = want;
    if (want !== cur) el.setAttribute(name, want);
  }

  function doAttrs(el) {
    for (var i = 0; i < ATTRS.length; i++) if (el.hasAttribute(ATTRS[i])) doAttr(el, ATTRS[i]);
  }

  var FILTER = {
    acceptNode: function (n) {
      return n.nodeType === 1 && n.matches(SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
    },
  };

  function walk(node) {
    if (!node.isConnected) return;   // removed again before we got here: its place on the page is unknown
    if (node.nodeType === 3) {
      var parent = node.parentElement;
      if (parent && !parent.closest(SKIP)) doText(node);
      return;
    }
    if (node.nodeType !== 1 || node.closest(SKIP)) return;
    doAttrs(node);
    var w = document.createTreeWalker(node, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, FILTER);
    var n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 1) doAttrs(n); else doText(n);
    }
  }

  var usedOther = lang !== "en";
  var observer = new MutationObserver(function (list) {
    // English is what the app writes: nothing to do, unless another language was shown before (a piece put back
    // on the page may still carry its translated text)
    if (lang === "en" && !audit && !usedOther) return;
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.type === "childList") {
        for (var k = 0; k < r.addedNodes.length; k++) walk(r.addedNodes[k]);
      } else if (r.type === "characterData") {
        walk(r.target);
      } else if (r.attributeName === "translate") {
        walk(r.target);
      } else if (!r.target.closest(SKIP)) {
        doAttr(r.target, r.attributeName);
      }
    }
  });
  observer.observe(root, {
    subtree: true, childList: true, characterData: true,
    attributes: true, attributeFilter: ATTRS.concat("translate"),
  });

  /* ---------------- the FR | EN | DE switch ---------------- */
  function paintSwitch() {
    var buttons = document.querySelectorAll("[data-set-lang]");
    for (var i = 0; i < buttons.length; i++) {
      var on = buttons[i].getAttribute("data-set-lang") === lang;
      buttons[i].setAttribute("aria-pressed", on ? "true" : "false");
    }
  }

  function set(next, keep) {
    lang = known(next) ? next : "en";
    if (lang !== "en") usedOther = true;
    if (keep !== false) remember(lang);
    root.lang = lang;
    walk(root);
    paintSwitch();
    window.dispatchEvent(new CustomEvent("pdflab:lang", { detail: lang }));
  }

  root.lang = lang;
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-set-lang]");
    if (b) set(b.getAttribute("data-set-lang"));
  });
  document.addEventListener("DOMContentLoaded", function () { walk(root); paintSwitch(); });

  window.PDFLabI18n = {
    /** "en", "fr" or "de". */
    lang: function () { return lang; },
    /** The languages this app can show. */
    languages: function () { return ["en"].concat(Object.keys(DICTS)); },
    set: set,
    /** A text that is not shown through the page: in the current language. */
    t: function (s) { return lang !== "en" && DICTS[lang] ? phrase(DICTS[lang], s) : String(s); },
    /** Part of a suggested file name: name("_edited") is "_edited" in English, "_modifié" in French, "_bearbeitet" in German. */
    name: function (key) {
      var names = lang !== "en" && DICTS[lang] ? DICTS[lang].names || {} : {};
      return has.call(names, key) ? names[key] : key;
    },
    /** Tests: note the English texts that have no entry in a dictionary while the app stays in English
     *  (audit("fr"), audit("de"); audit(false) stops), and list what was noted for a language so far. */
    audit: function (which) { audit = which === false ? null : (known(which) && which !== "en" ? which : "fr"); if (audit) walk(root); },
    missing: function (which) { return Array.from(misses[which || (lang !== "en" ? lang : audit) || "fr"] || []); },
  };
})();
