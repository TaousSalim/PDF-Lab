/* PDF Lab: the German dictionary (native Mac app only).
 *
 * Same shape as js/lang-fr.js:
 * exact     English text as the app writes it  ->  German text
 * patterns  texts that contain a number or a file name: [pattern, function(match, T) -> German]
 *           T(text) translates a smaller phrase with this same dictionary.
 *           A third item "attr" limits a pattern to tooltips and labels.
 * names     parts of suggested file names
 *
 * Conventions used here: "du" (as macOS itself does), the words of the Mac ("sichern", "widerrufen", "Schrift"),
 * German quotation marks („ “), a no-break space before units and %, the decimal comma, no long dashes.
 * Written as German, not as a word for word translation: say what the button does, the way a German app would.
 * To add a text: write it in English in the app, add it to js/lang-fr.js, then add one line here.
 */
(function () {
  "use strict";

  var NB = " ";
  var Q = function (s) { return "„" + s + "“"; };      // „…“
  /** 1.5 -> "1,5" */
  var num = function (s) { return String(s).replace(".", ","); };
  /** German plural: only 1 is singular (0 Seiten, 1 Seite, 2 Seiten). */
  var pl = function (n, one, many) { return Number(n) === 1 ? one : many; };
  var COUNT = {
    page: ["Seite", "Seiten"], file: ["Datei", "Dateien"], image: ["Bild", "Bilder"],
    slide: ["Folie", "Folien"], PDF: ["PDF", "PDFs"],
  };
  var count = function (n, word) {
    var w = COUNT[word.replace(/s$/, "")] || COUNT[word] || [word, word];
    return n + " " + pl(n, w[0], w[1]);
  };
  /** The number shown in bold just before a text (font report). */
  var before = function (node) {
    var p = node && node.previousElementSibling;
    return p ? parseInt(p.textContent, 10) || 0 : 2;
  };

  var exact = {
    /* ------------------------------------------------ top bar */
    "All": "Alle",
    "Organize PDF": "PDF organisieren",
    "Edit PDF": "PDF bearbeiten",
    "Convert PDF": "PDF umwandeln",
    "PDF Lab": "PDF Lab",
    "PDF Lab home": "Startseite von PDF Lab",
    "Main": "Hauptnavigation",
    "Language": "Sprache",
    "FR": "FR",
    "EN": "EN",
    "DE": "DE",
    "Français": "Français",
    "English": "English",
    "Deutsch": "Deutsch",
    "Switch light or dark theme": "Zwischen hellem und dunklem Design wechseln",
    "Switch theme": "Design wechseln",
    "Quit PDF Lab": "PDF Lab beenden",
    "Drop to add": "Zum Hinzufügen loslassen",
    "PDF Lab is closed.": "PDF Lab ist beendet.",
    "You can close this window.": "Du kannst dieses Fenster schließen.",

    /* ------------------------------------------------ home */
    "Every tool you need to work with PDFs in one place": "Alle PDF-Werkzeuge an einem Ort",
    "Merge, split, organize, rotate and convert your PDFs with a few clicks. Everything runs on your Mac, your files never leave it.":
      "PDFs zusammenfügen, teilen, organisieren, drehen und umwandeln, mit wenigen Klicks. Alles läuft auf deinem Mac: Deine Dateien verlassen ihn nie.",
    "Merge PDF": "PDF zusammenfügen",
    "Combine PDFs in the order you want with the easiest PDF merger available.": "Füge mehrere PDFs in der gewünschten Reihenfolge zu einem einzigen zusammen. Einfacher geht es nicht.",
    "Split PDF": "PDF teilen",
    "Separate one page or a whole set for easy conversion into independent PDF files.": "Löse einzelne Seiten oder ganze Seitenbereiche heraus und sichere sie als eigene PDF-Dateien.",
    "Remove pages": "Seiten entfernen",
    "Click the pages you do not need and export the rest. Every page is shown as a preview.": "Klicke die Seiten an, die du nicht brauchst, und sichere den Rest. Jede Seite wird als Vorschau angezeigt.",
    "Extract pages": "Seiten extrahieren",
    "Pull selected pages out of a PDF into a new file, or save every page on its own.": "Übernimm ausgewählte Seiten eines PDFs in eine neue Datei oder sichere jede Seite einzeln.",
    "Sort pages of your PDF file however you like. Delete PDF pages or add PDF pages to your document at your convenience.":
      "Bringe die Seiten deines PDFs in die Reihenfolge, die dir passt. Lösche Seiten oder füge neue hinzu, ganz wie du möchtest.",
    "Rotate PDF": "PDF drehen",
    "Rotate your PDFs the way you need them. You can even rotate multiple PDFs at once!": "Drehe deine PDFs so, wie du sie brauchst. Das geht sogar mit mehreren PDFs auf einmal!",
    "Add text, images, shapes or freehand annotations to a PDF document. Edit the size, font, and color of the added content.":
      "Ergänze ein PDF um Text, Bilder, Formen oder Freihandnotizen. Größe, Schrift und Farbe kannst du jederzeit anpassen.",
    "PDF to Word": "PDF in Word",
    "Turn your PDF files into easy to edit DOCX documents with paragraphs, headings, bold and italic kept.":
      "Mache aus deinen PDFs gut bearbeitbare DOCX-Dokumente. Absätze, Überschriften, Fett- und Kursivschrift bleiben erhalten.",
    "PDF to PowerPoint": "PDF in PowerPoint",
    "Turn your PDF files into easy to edit PPTX slideshows, as page images or editable text.":
      "Mache aus deinen PDFs gut bearbeitbare PPTX-Präsentationen, als Seitenbilder oder als bearbeitbaren Text.",
    "PDF to Image": "PDF in Bild",
    "Turn each PDF page into a PNG, JPG, WebP or TIFF image, in the quality you choose.": "Mache aus jeder PDF-Seite ein Bild im Format PNG, JPG, WebP oder TIFF, in der Qualität deiner Wahl.",
    "Word to PDF": "Word in PDF",
    "Make DOC and DOCX files easy to read by converting them to PDF.": "Wandle DOC- und DOCX-Dateien in PDFs um, die sich überall bequem lesen lassen.",
    "Image to PDF": "Bild in PDF",
    "Turn any image into a PDF: JPG, PNG, iPhone photos (HEIC), TIFF, WebP and more. Adjust page size, orientation and margins.":
      "Mache aus jedem Bild ein PDF: JPG, PNG, iPhone-Fotos (HEIC), TIFF, WebP und viele mehr. Seitenformat, Ausrichtung und Ränder legst du selbst fest.",
    "All tools": "Alle Werkzeuge",
    "Pick a tool first, then drop your files.": "Wähle zuerst ein Werkzeug und ziehe dann deine Dateien hinein.",

    /* ------------------------------------------------ shared */
    "Something went wrong.": "Da ist etwas schiefgelaufen.",
    "Nothing was produced.": "Es wurde keine Datei erstellt.",
    "That file type is not supported here.": "Dieser Dateityp wird hier nicht unterstützt.",
    "Only PDF files are supported here.": "Hier werden nur PDF-Dateien unterstützt.",
    "Remove": "Entfernen",
    "Add more files": "Weitere Dateien hinzufügen",
    "Select PDF file": "PDF-Datei auswählen",
    "Select PDF files": "PDF-Dateien auswählen",
    "or drop a PDF here": "oder ein PDF hierher ziehen",
    "or drop PDFs here": "oder PDFs hierher ziehen",
    "Choose another file": "Andere Datei wählen",
    "Save PDF": "PDF sichern",
    "Files": "Dateien",
    "Pages": "Seiten",
    "Size": "Größe",
    "Select all": "Alle auswählen",
    "Clear": "Auswahl aufheben",
    "Reset": "Zurücksetzen",
    "Result": "Ergebnis",
    "PDF": "PDF", "ZIP": "ZIP", "JPG": "JPG", "PNG": "PNG", "WebP": "WebP", "TIFF": "TIFF", "DOC": "DOC", "DOCX": "DOCX",

    /* ------------------------------------------------ progress card */
    "Progress": "Fortschritt",
    "Cancel": "Abbrechen",
    "Saving": "Wird gesichert",
    "Done": "Fertig",
    "Cancelled. Nothing was saved.": "Abgebrochen. Es wurde nichts gesichert.",
    "Close": "Schließen",
    "Saved in the folder you chose.": "Im gewählten Ordner gesichert.",
    "Saved in your Downloads folder.": "In deinem Ordner " + Q("Downloads") + " gesichert.",
    "Saved in:": "Gesichert in:",
    "The folder you chose could not be written to. Saved in your Downloads folder instead.":
      "In den gewählten Ordner konnte nicht geschrieben werden. Die Datei liegt stattdessen in deinem Ordner " + Q("Downloads") + ".",
    "Not completed": "Nicht abgeschlossen",
    "Nothing was saved.": "Es wurde nichts gesichert.",
    "PDF Lab is not responding. Quit it, open it again, then try once more.": "PDF Lab reagiert nicht. Beende die App, öffne sie erneut und versuche es dann noch einmal.",
    "Merging": "Wird zusammengefügt",
    "Removing pages": "Seiten werden entfernt",
    "Extracting pages": "Seiten werden extrahiert",
    "Splitting": "Wird geteilt",
    "Organizing pages": "Seiten werden angeordnet",
    "Rotating": "Wird gedreht",
    "Reading the document": "Dokument wird gelesen",

    /* ------------------------------------------------ Merge PDF */
    "Drag the files to put them in the order you want. Pages are merged from first to last.":
      "Ziehe die Dateien in die gewünschte Reihenfolge. Zusammengefügt wird von der ersten bis zur letzten Datei.",
    "Sort A to Z": "Von A bis Z sortieren",
    "Reverse": "Umkehren",
    "Clear all": "Alle entfernen",
    "Add PDFs": "PDFs hinzufügen",
    "Add one more PDF": "Füge noch ein PDF hinzu",

    /* ------------------------------------------------ Remove pages, Extract pages */
    "Click the pages you want to delete. Shift-click selects a range. You can also type page numbers.":
      "Klicke die Seiten an, die du löschen möchtest. Mit Umschalt-Klick wählst du einen ganzen Bereich aus. Du kannst die Seitenzahlen auch eintippen.",
    "Pages to remove": "Zu entfernende Seiten",
    "Marked for removal": "Zum Entfernen markiert",
    "Pages remaining": "Verbleibende Seiten",
    "Clear selection": "Auswahl aufheben",
    "Keep at least one page.": "Mindestens eine Seite muss übrig bleiben.",
    "Click the pages you want to keep. Shift-click selects a range. You can also type page numbers.":
      "Klicke die Seiten an, die du behalten möchtest. Mit Umschalt-Klick wählst du einen ganzen Bereich aus. Du kannst die Seitenzahlen auch eintippen.",
    "Pages to extract": "Zu extrahierende Seiten",
    "Output": "Ausgabe",
    "One PDF": "Ein PDF",
    "One PDF per page": "Ein PDF pro Seite",
    "Selected pages": "Ausgewählte Seiten",

    /* ------------------------------------------------ Split PDF */
    "Ranges": "Bereiche",
    "Every N": "Alle N Seiten",
    "Each page": "Jede Seite",
    "Pages for each file": "Seiten der einzelnen Dateien",
    "Each comma separated entry becomes its own PDF. Use \"8-\" for page 8 to the end.":
      "Jeder durch Komma getrennte Eintrag wird zu einem eigenen PDF. Mit " + Q("8-") + " erfasst du alles von Seite 8 bis zum Ende.",
    "Merge all ranges into one PDF": "Alle Bereiche zu einem PDF zusammenfügen",
    "Pages per file": "Seiten pro Datei",
    "Every page is saved as its own PDF.": "Jede Seite wird als eigenes PDF gesichert.",
    "Enter a number of pages, 1 or more.": "Gib eine Seitenzahl ein, mindestens 1.",
    "Type the pages for each file.": "Gib die Seiten für jede Datei ein.",
    "Extract PDF": "PDF extrahieren",

    /* ------------------------------------------------ Organize PDF, Rotate PDF */
    "Add more PDFs": "Weitere PDFs hinzufügen",
    "Drag pages to reorder them. Use the buttons on a page to rotate or delete it. Add more PDFs to bring their pages in at the end.":
      "Ziehe die Seiten in eine neue Reihenfolge. Mit den Schaltflächen auf einer Seite drehst oder löschst du sie. Weitere PDFs, die du hinzufügst, werden mit ihren Seiten am Ende angehängt.",
    "Source files": "Quelldateien",
    "Rotate all left": "Alle nach links drehen",
    "Rotate all right": "Alle nach rechts drehen",
    "Reverse order": "Reihenfolge umkehren",
    "Start over": "Neu beginnen",
    "Rotate left": "Nach links drehen",
    "Rotate right": "Nach rechts drehen",
    "Delete page": "Seite löschen",
    "Rotate each PDF with the buttons under its preview, or rotate all of them at once. Every page of a file is turned together.":
      "Drehe jedes PDF mit den Schaltflächen unter seiner Vorschau oder alle auf einmal. Dabei drehen sich alle Seiten einer Datei gemeinsam.",
    "Files to rotate": "Zu drehende Dateien",
    "Every page is shown. Click a page to turn it to the right, or use the buttons on it to turn it either way. The buttons below turn every page at once.":
      "Alle Seiten werden angezeigt. Ein Klick auf eine Seite dreht sie nach rechts, mit ihren Schaltflächen drehst du sie in beide Richtungen. Die Schaltflächen unten drehen alle Seiten auf einmal.",
    "Pages to rotate": "Zu drehende Seiten",
    "Rotate this file left": "Diese Datei nach links drehen",
    "Rotate this file right": "Diese Datei nach rechts drehen",
    "Remove this file": "Diese Datei entfernen",
    "Click to rotate this page right": "Klicken, um diese Seite nach rechts zu drehen",

    /* ------------------------------------------------ PDF to Image */
    "Every selected page becomes an image. Click pages to include or skip them.": "Aus jeder ausgewählten Seite wird ein Bild. Klicke Seiten an, um sie aufzunehmen oder auszulassen.",
    "Image format": "Bildformat",
    "Quality": "Qualität",
    "Standard": "Standard",
    "High": "Hoch",
    "Maximum": "Maximal",
    "Pages to convert": "Umzuwandelnde Seiten",
    "Packing files": "Dateien werden gepackt",

    /* ------------------------------------------------ Image to PDF */
    "Please choose image files: JPG, PNG, iPhone photos (HEIC), TIFF, WebP and more.": "Bitte wähle Bilddateien aus: JPG, PNG, iPhone-Fotos (HEIC), TIFF, WebP und viele mehr.",
    "Select images": "Bilder auswählen",
    "or drop any images here, iPhone photos included": "oder Bilder hierher ziehen, auch iPhone-Fotos",
    "Reading the image": "Bild wird gelesen",
    "Convert to PDF": "In PDF umwandeln",
    "Convert to PDFs (ZIP)": "In PDFs umwandeln (ZIP)",
    "Page size": "Seitenformat",
    "Fit image": "Bildgröße",
    "A4": "A4",
    "US Letter": "US Letter",
    "Orientation": "Ausrichtung",
    "Auto": "Auto",
    "Portrait": "Hochformat",
    "Landscape": "Querformat",
    "Margin": "Rand",
    "None": "Ohne",
    "Small": "Schmal",
    "Big": "Breit",
    "Merge all images into one PDF": "Alle Bilder in einem PDF zusammenfassen",
    "Drag the images to change their order.": "Ziehe die Bilder, um ihre Reihenfolge zu ändern.",
    "Add images": "Bilder hinzufügen",

    /* ------------------------------------------------ Word to PDF */
    "Please choose a Word file (.docx or .doc).": "Bitte wähle eine Word-Datei aus (.docx oder .doc).",
    "Select Word files": "Word-Dateien auswählen",
    "or drop DOC and DOCX files here": "oder DOC- und DOCX-Dateien hierher ziehen",
    "Your document is converted on this Mac. Page size, margins, headers, footers, page numbers, lists, tables, pictures and shapes follow the Word file.":
      "Dein Dokument wird auf diesem Mac umgewandelt. Seitenformat, Ränder, Kopf- und Fußzeilen, Seitenzahlen, Listen, Tabellen, Bilder und Formen werden aus der Word-Datei übernommen.",
    "Several files at once are saved together as a ZIP.": "Mehrere Dateien auf einmal werden gemeinsam als ZIP gesichert.",
    "Add Word files": "Word-Dateien hinzufügen",
    "Converting": "Wird umgewandelt",
    "This document is empty or could not be read.": "Dieses Dokument ist leer oder konnte nicht gelesen werden.",
    "This Word file could not be opened. It may be damaged.": "Diese Word-Datei ließ sich nicht öffnen. Möglicherweise ist sie beschädigt.",
    "This Word file is protected by a password. Remove the password in Word, then try again.": "Diese Word-Datei ist mit einem Passwort geschützt. Entferne das Passwort in Word und versuche es dann erneut.",

    /* ------------------------------------------------ PDF to Word */
    "The text of your PDF is rebuilt as an editable Word document, with paragraphs, headings, bold and italic.":
      "Der Text deines PDFs wird als bearbeitbares Word-Dokument neu aufgebaut, mit Absätzen, Überschriften, Fett- und Kursivschrift.",
    "Start a new Word page for every PDF page": "Für jede PDF-Seite eine neue Word-Seite beginnen",
    "Good to know": "Gut zu wissen",
    "Pictures, tables and colors are not carried over, and scanned PDFs need text recognition first because they contain no real text.":
      "Bilder, Tabellen und Farben werden nicht übernommen. Gescannte PDFs brauchen zuerst eine Texterkennung, denn sie enthalten keinen echten Text.",
    "Convert to Word": "In Word umwandeln",
    "This PDF has no selectable text. It looks like a scan, so it needs text recognition (OCR) first.":
      "Dieses PDF enthält keinen auswählbaren Text. Es ist vermutlich ein Scan und braucht zuerst eine Texterkennung (OCR).",
    "Building the Word file": "Word-Datei wird erstellt",

    /* ------------------------------------------------ PDF to PowerPoint */
    "Every PDF page becomes one slide.": "Aus jeder PDF-Seite wird eine Folie.",
    "Slide content": "Folieninhalt",
    "Page images": "Seitenbilder",
    "Editable text": "Bearbeitbarer Text",
    "Each slide shows the page exactly as it looks in the PDF. Best for a faithful look.":
      "Jede Folie zeigt die Seite genau so, wie sie im PDF aussieht. Ideal, wenn es originalgetreu sein soll.",
    "Text is placed in editable text boxes on blank slides. Best when you want to change the words. Pictures and colors are not carried over.":
      "Der Text steht in bearbeitbaren Textfeldern auf leeren Folien. Ideal, wenn du am Wortlaut feilen möchtest. Bilder und Farben werden nicht übernommen.",
    "Slides": "Folien",
    "Convert to PowerPoint": "In PowerPoint umwandeln",
    "This PDF has no selectable text. Use Page images instead.": "Dieses PDF enthält keinen auswählbaren Text. Verwende stattdessen " + Q("Seitenbilder") + ".",
    "Building the presentation": "Präsentation wird erstellt",

    /* ------------------------------------------------ Edit PDF: toolbar */
    "Edit": "Bearbeiten",
    "Text": "Text",
    "Image": "Bild",
    "Box": "Rechteck",
    "Oval": "Oval",
    "Line": "Linie",
    "Arrow": "Pfeil",
    "Draw": "Zeichnen",
    "Mark": "Markieren",
    "Erase": "Radieren",
    "Select and edit text": "Text auswählen und bearbeiten",
    "Add text": "Text hinzufügen",
    "Add image": "Bild hinzufügen",
    "Rectangle": "Rechteck",
    "Ellipse": "Ellipse",
    "Highlight": "Hervorheben",
    "Cover or erase": "Abdecken oder entfernen",
    "Click any text to edit it, or click a shape to move it": "Klicke auf einen Text, um ihn zu bearbeiten, oder auf eine Form, um sie zu verschieben",
    "Click on the page and type": "Klicke auf die Seite und schreibe los",
    "Choose a picture to place on the page": "Wähle ein Bild, das auf die Seite soll",
    "Drag on the page": "Ziehe auf der Seite",
    "Draw freehand on the page": "Zeichne frei Hand auf der Seite",
    "Drag over the text to highlight": "Ziehe über den Text, um ihn hervorzuheben",
    "Drag over anything to hide it": "Ziehe über eine Stelle, um sie abzudecken",
    "Zoom out": "Verkleinern",
    "Zoom in": "Vergrößern",
    "Fit to width": "An Breite anpassen",

    /* ------------------------------------------------ Edit PDF: side panel */
    "Changes": "Änderungen",
    "Edits": "Bearbeitungen",
    "Pages touched": "Geänderte Seiten",
    "Undo": "Widerrufen",
    "Redo": "Wiederholen",
    "Discard all": "Alle verwerfen",
    "Click any text on the page to edit it. Your new text keeps the original font and spacing, and a live preview shows the exact result. Click a shape or picture to move it.":
      "Klicke auf einen Text auf der Seite, um ihn zu bearbeiten. Der neue Text behält Schrift und Abstände des Originals, und eine Live-Vorschau zeigt das genaue Ergebnis. Klicke auf eine Form oder ein Bild, um es zu verschieben.",
    "Click where the text should go, then type. Press Esc or click away when you are done.":
      "Klicke an die Stelle, an der der Text stehen soll, und schreibe los. Drücke Esc oder klicke daneben, wenn du fertig bist.",
    "Pick a picture and it is placed on the page. Drag it to move it, drag a corner to resize.":
      "Wähle ein Bild, es landet direkt auf der Seite. Ziehe es an die gewünschte Stelle und ändere seine Größe an einer Ecke.",
    "Drag on the page to draw a rectangle.": "Ziehe auf der Seite, um ein Rechteck zu zeichnen.",
    "Drag on the page to draw an ellipse.": "Ziehe auf der Seite, um eine Ellipse zu zeichnen.",
    "Drag to draw a line. Hold Shift for straight angles.": "Ziehe, um eine Linie zu zeichnen. Mit gedrückter Umschalttaste rastet der Winkel in 15°-Schritten ein.",
    "Drag to draw an arrow. Hold Shift for straight angles.": "Ziehe, um einen Pfeil zu zeichnen. Mit gedrückter Umschalttaste rastet der Winkel in 15°-Schritten ein.",
    "Draw freely with the mouse or trackpad.": "Zeichne frei mit der Maus oder dem Trackpad.",
    "Drag over text to highlight it.": "Ziehe über einen Text, um ihn hervorzuheben.",
    "Drag over anything to hide it. The content underneath is removed for good, and the colour matches the page.":
      "Ziehe über eine Stelle, um sie abzudecken. Der Inhalt darunter wird endgültig entfernt, und die Farbe passt sich der Seite an.",
    "Sans (Helvetica style)": "Serifenlos (wie Helvetica)",
    "Serif (Times style)": "Mit Serifen (wie Times)",
    "Mono (Courier style)": "Feste Breite (wie Courier)",
    "Original font": "Originalschrift",
    "Text style": "Textstil",
    "Style": "Stil",
    "Selected text": "Ausgewählter Text",
    "Font": "Schrift",
    "close font used": "ähnliche Schrift verwendet",
    "Color": "Farbe",
    "B": "F",
    "I": "K",
    "Original style": "Originalstil",
    "Squeeze to the original width": "Auf Originalbreite stauchen",
    "Changing the font here uses an installed font instead of the one in the PDF.": "Wenn du hier die Schrift änderst, wird statt der Schrift aus dem PDF eine installierte Schrift verwendet.",
    "Left": "Links",
    "Center": "Mitte",
    "Right": "Rechts",
    "Line height": "Zeilenabstand",
    "Line color": "Linienfarbe",
    "Fill": "Füllung",
    "Fill color": "Füllfarbe",
    "Thickness": "Stärke",
    "Opacity": "Deckkraft",
    "Strength": "Intensität",
    "Bring to front": "Ganz nach vorne",
    "Send to back": "Ganz nach hinten",
    "Delete": "Löschen",
    "Drawing": "Zeichnung",
    "Cover": "Abdeckung",
    "Remove what is underneath": "Inhalt darunter entfernen",
    "When on, text and pictures under the box are deleted from the file, not just hidden.":
      "Ist diese Option aktiv, werden Text und Bilder unter der Abdeckung aus der Datei gelöscht und nicht nur verdeckt.",
    "Picture": "Bild",
    "Drag the picture to move it. Drag a corner to resize it.": "Ziehe das Bild, um es zu verschieben. Ziehe an einer Ecke, um seine Größe zu ändern.",

    /* ------------------------------------------------ Edit PDF: page, font report, messages */
    "No editable text on this page. You can still add text, images and shapes.":
      "Auf dieser Seite gibt es keinen bearbeitbaren Text. Text, Bilder und Formen kannst du trotzdem hinzufügen.",
    "The text of this page could not be read.": "Der Text dieser Seite konnte nicht gelesen werden.",
    "All changes were discarded. Undo brings them back.": "Alle Änderungen wurden verworfen. Mit " + Q("Widerrufen") + " holst du sie zurück.",
    "The preview could not be updated.": "Die Vorschau konnte nicht aktualisiert werden.",
    "Fidelity": "Originaltreue",
    "letters use the original font": function (node) { return pl(before(node), "Buchstabe verwendet die Originalschrift", "Buchstaben verwenden die Originalschrift"); },
    "letters use a matching installed font:": function (node) {
      return pl(before(node), "Buchstabe verwendet eine passende installierte Schrift:", "Buchstaben verwenden eine passende installierte Schrift:");
    },
    "No font has:": "In keiner Schrift enthalten:",
    "Letters that already exist in the PDF keep their exact shape and spacing. New letters use the closest installed font.":
      "Buchstaben, die im PDF schon vorkommen, behalten exakt ihre Form und ihren Abstand. Für neue Buchstaben wird die ähnlichste installierte Schrift verwendet.",
    "Enter to apply": "Eingabetaste zum Übernehmen",
    "Esc to cancel": "Esc zum Abbrechen",
    "Custom font selected": "Eigene Schrift gewählt",
    "Close font used for this line": "Für diese Zeile wird eine ähnliche Schrift verwendet",
    "Close font for:": "Ähnliche Schrift für:",
    "That image could not be read.": "Dieses Bild konnte nicht gelesen werden.",
    "That file is not a picture PDF Lab can read.": "Diese Datei ist kein Bild, das PDF Lab lesen kann.",
    "Applying your edits": "Änderungen werden angewendet",

    /* ------------------------------------------------ messages from the server */
    "No pages selected.": "Keine Seiten ausgewählt.",
    "Rotation must be a multiple of 90 degrees.": "Die Drehung muss ein Vielfaches von 90 Grad sein.",
    "Google Chrome is needed for this tool but was not found.": "Dieses Werkzeug braucht Google Chrome, aber Chrome wurde nicht gefunden.",
    "The conversion took too long and was stopped.": "Die Umwandlung hat zu lange gedauert und wurde abgebrochen.",
    "Chrome could not produce the PDF.": "Chrome konnte das PDF nicht erzeugen.",
    "An image has an invalid size.": "Ein Bild hat eine ungültige Größe.",
    "Bad request.": "Ungültige Anfrage.",
    "This file is too large. The limit is 1 GB.": "Diese Datei ist zu groß. Die Obergrenze liegt bei 1" + NB + "GB.",
    "The upload was interrupted.": "Das Laden der Datei wurde unterbrochen.",
    "A file is no longer available. Please add it again.": "Eine Datei ist nicht mehr verfügbar. Bitte füge sie erneut hinzu.",
    "Add at least 2 PDF files to merge.": "Füge mindestens 2 PDF-Dateien zum Zusammenfügen hinzu.",
    "The document has no pages.": "Das Dokument enthält keine Seiten.",
    "Invalid page selection.": "Ungültige Seitenauswahl.",
    "Add at least one PDF.": "Füge mindestens ein PDF hinzu.",
    "Nothing to split.": "Es gibt nichts zu teilen.",
    "Nothing to convert.": "Es gibt nichts umzuwandeln.",
    "Add at least one image.": "Füge mindestens ein Bild hinzu.",
    "Unknown page size.": "Unbekanntes Seitenformat.",
    "Old .doc files are not supported here. Please save the file as .docx first.":
      "Alte .doc-Dateien werden hier nicht unterstützt. Bitte sichere die Datei zuerst als .docx.",
    "This .doc file could not be converted. Please save it as .docx first.": "Diese .doc-Datei ließ sich nicht umwandeln. Bitte sichere sie zuerst als .docx.",
    "This file is not a PDF.": "Diese Datei ist kein PDF.",
    "This PDF is password protected and cannot be edited.": "Dieses PDF ist mit einem Passwort geschützt und kann nicht bearbeitet werden.",
    "Invalid page.": "Ungültige Seite.",
    "No pages to convert.": "Keine Seiten zum Umwandeln.",
    "A page has an invalid size.": "Eine Seite hat eine ungültige Größe.",
    "Forbidden": "Zugriff verweigert",
    "Unknown route": "Unbekannte Adresse",
    "This line contains special glyph groups and cannot be edited safely.": "Diese Zeile enthält besondere Zeichengruppen und lässt sich nicht gefahrlos bearbeiten.",
    "This text uses a script the editor cannot write.": "Dieser Text verwendet ein Schriftsystem, das der Editor nicht schreiben kann.",
    "This line is too long to be written in one piece.": "Diese Zeile ist zu lang, um sie in einem Stück zu schreiben.",
    "An image could not be read.": "Ein Bild konnte nicht gelesen werden.",
    "The page changed since the text was selected. Please reopen the file.": "Die Seite hat sich geändert, seit der Text ausgewählt wurde. Bitte öffne die Datei erneut.",
    "Arabic text set at a slant cannot be edited. Erase it and add new text instead.":
      "Schräg gesetzter arabischer Text kann nicht bearbeitet werden. Entferne ihn und füge stattdessen neuen Text hinzu.",
    "This line could not be read reliably. Erase it and add new text instead.":
      "Diese Zeile konnte nicht zuverlässig gelesen werden. Entferne sie und füge stattdessen neuen Text hinzu.",

    /* ------------------------------------------------ updates (js/update.js) */
    "Update": "Update",
    "A new version of PDF Lab is ready.": "Eine neue Version von PDF Lab ist da.",
    "Install the update": "Update installieren",
    "Later": "Später",
    "PDF Lab restarts to install the update. Work that is not saved will be lost.":
      "Für das Update startet PDF Lab neu. Nicht gesicherte Arbeit geht dabei verloren.",
    "Install now": "Jetzt installieren",
    "Try again": "Erneut versuchen",
    "The update could not be downloaded. Check the internet connection, then try again.":
      "Das Update konnte nicht geladen werden. Prüfe die Internetverbindung und versuche es dann erneut.",
    "The update could not be started. Try again, or keep working: PDF Lab works as before.":
      "Das Update ließ sich nicht starten. Versuche es erneut oder arbeite einfach weiter: PDF Lab funktioniert wie bisher.",
    "Updating PDF Lab": "PDF Lab wird aktualisiert",
    "Downloading": "Wird geladen",
    "Installing": "Wird installiert",
    "PDF Lab restarts by itself.": "PDF Lab startet von selbst neu.",
    "Wait until the current task is finished, then install the update.": "Warte, bis der laufende Vorgang abgeschlossen ist, und installiere dann das Update.",
    "PDF Lab has been updated.": "PDF Lab wurde aktualisiert.",
  };

  var patterns = [
    /* window title */
    [/^(.+) \| PDF Lab$/, function (m, T) { return T(m[1]) + " | PDF Lab"; }],

    /* numbers and sizes */
    [/^(\d+) (pages?|files?|images?|slides?|PDFs?)$/, function (m) { return count(m[1], m[2]); }],
    [/^(\d+) KB$/, function (m) { return m[1] + NB + "KB"; }],
    [/^(\d+(?:\.\d+)?) MB$/, function (m) { return num(m[1]) + NB + "MB"; }],
    [/^(\d+(?:\.\d+)?) pt$/, function (m) { return num(m[1]) + NB + "pt"; }],
    [/^(\d+)%$/, function (m) { return m[1] + NB + "%"; }],
    [/^Version (\d[\d.]*)$/, function (m) { return "Version " + m[1]; }],
    [/^(\d+)\.(\d+)$/, function (m) { return m[1] + "," + m[2]; }],
    [/^(\d+) × (\d+)$/, function (m) { return m[1] + " × " + m[2]; }],
    [/^(\d+) PDF files$/, function (m) { return m[1] + " PDF-" + pl(m[1], "Datei", "Dateien"); }],
    [/^file (\d+)$/, function (m) { return "Datei " + m[1]; }],
    [/^e\.g\. (.+)$/, function (m) { return "z." + NB + "B. " + m[1]; }],
    [/^Page (\d+) \/ (\d+)$/, function (m) { return "Seite " + m[1] + " / " + m[2]; }],
    [/^Page (\d+)$/, function (m) { return "Seite " + m[1]; }],   // the name of a page tile for the keyboard
    [/^Page (\d+) of (\d+)$/, function (m) { return "Seite " + m[1] + " von " + m[2]; }],

    /* buttons */
    [/^Remove (\d+) pages?$/, function (m) { return count(m[1], "page") + " entfernen"; }],
    [/^Extract (\d+) files \(ZIP\)$/, function (m) { return m[1] + " Dateien extrahieren (ZIP)"; }],
    [/^Extract (\d+) pages?$/, function (m) { return count(m[1], "page") + " extrahieren"; }],
    [/^Convert to (JPG|PNG|WebP|TIFF)$/, function (m) { return "In " + m[1] + " umwandeln"; }],
    [/^Remove (.+)$/, function (m) { return m[1] + " entfernen"; }, "attr"],

    /* progress */
    [/^Page (\d+) \((\d+) of (\d+)\)$/, function (m) { return "Seite " + m[1] + " (" + m[2] + " von " + m[3] + ")"; }],
    [/^Reading page (\d+) of (\d+)$/, function (m) { return "Seite " + m[1] + " von " + m[2] + " wird gelesen"; }],
    [/^File (\d+) of (\d+)$/, function (m) { return "Datei " + m[1] + " von " + m[2]; }],
    [/^Slide (\d+) of (\d+)$/, function (m) { return "Folie " + m[1] + " von " + m[2]; }],
    [/^(.+) \((\d+) of (\d+)\)$/, function (m) { return m[1] + " (" + m[2] + " von " + m[3] + ")"; }],
    [/^(\d+) dpi, good size and quality\.$/, function (m) { return m[1] + NB + "dpi, gutes Verhältnis von Größe und Qualität."; }],
    [/^(\d+) dpi, lossless, larger files\.$/, function (m) { return m[1] + NB + "dpi, verlustfrei, größere Dateien."; }],
    [/^(\d+) dpi, smallest files, good quality\.$/, function (m) { return m[1] + NB + "dpi, kleinste Dateien, gute Qualität."; }],
    [/^(\d+) dpi, lossless, for printing and archives\.$/, function (m) { return m[1] + NB + "dpi, verlustfrei, für Druck und Archiv."; }],

    /* messages with a file name, a page number or a detail */
    [/^(.+) is ready\. Click any text to edit it\.$/, function (m) { return m[1] + " ist bereit. Klicke auf einen Text, um ihn zu bearbeiten."; }],
    [/^(.+) is larger than 1 GB, which is too big for PDF Lab\.$/, function (m) { return m[1] + " ist größer als 1" + NB + "GB und damit zu groß für PDF Lab."; }],
    [/^(.+) could not be opened for preview\. It may be damaged\.$/, function (m) { return "Für " + m[1] + " ließ sich keine Vorschau öffnen. Möglicherweise ist die Datei beschädigt."; }],
    [/^Could not open (.+)$/, function (m) { return m[1] + " ließ sich nicht öffnen"; }],
    [/^'(.*)' is not a picture PDF Lab can read\.$/, function (m) { return Q(m[1]) + " ist kein Bild, das PDF Lab lesen kann."; }],
    [/^'(.*)' is too large to convert\.$/, function (m) { return Q(m[1]) + " ist zu groß zum Umwandeln."; }],
    [/^'(.*)' is a camera RAW file\. Export the photo as JPG or TIFF first, then add it\.$/, function (m) { return Q(m[1]) + " ist eine RAW-Datei aus einer Kamera. Exportiere das Foto zuerst als JPG oder TIFF und füge es dann hinzu."; }],
    [/^"(.*)" is not a valid page or range\.$/, function (m) { return Q(m[1]) + " ist weder eine gültige Seite noch ein gültiger Bereich."; }],
    [/^"(.*)" is backwards\. Write it as (.+)\.$/, function (m) { return Q(m[1]) + " steht verkehrt herum. Schreibe stattdessen " + m[2] + "."; }],
    [/^Page (\d+) is out of range\. The PDF has (\d+) pages\.$/, function (m) { return "Seite " + m[1] + " gibt es nicht. Das PDF hat " + count(m[2], "page") + "."; }],
    [/^Page (\d+) is too large to turn into an image\.$/, function (m) { return "Seite " + m[1] + " ist zu groß, um ein Bild daraus zu machen."; }],
    [/^Page (\d+) does not exist in this PDF\.$/, function (m) { return "Seite " + m[1] + " gibt es in diesem PDF nicht."; }],
    [/^'(.*)' does not look like a PDF file\.$/, function (m) { return Q(m[1]) + " sieht nicht nach einer PDF-Datei aus."; }],
    [/^'(.*)' is password protected\.$/, function (m) { return Q(m[1]) + " ist mit einem Passwort geschützt."; }],
    [/^'(.*)' is protected with AES encryption, which PDF Lab cannot open on this (Mac|computer)\.$/, function (m) {
      return Q(m[1]) + " ist mit AES verschlüsselt. Das kann PDF Lab auf diesem Mac nicht öffnen.";
    }],
    [/^'(.*)' could not be read\. It may be damaged\.$/, function (m) { return Q(m[1]) + " konnte nicht gelesen werden. Möglicherweise ist die Datei beschädigt."; }],
    [/^'(.*)' has no pages\.$/, function (m) { return Q(m[1]) + " enthält keine Seiten."; }],
    [/^The Edit PDF engine could not be loaded on this (Mac|computer)\. \((.*)\)$/, function (m) {
      return "Die Engine für " + Q("PDF bearbeiten") + " konnte auf diesem Mac nicht geladen werden. (" + m[2] + ")";
    }],
    [/^No installed font with Arabic letters was found on this (Mac|computer)\.$/, function () {
      return "Auf diesem Mac wurde keine installierte Schrift mit arabischen Buchstaben gefunden.";
    }],
    [/^This could not be processed \((.+)\)\.$/, function (m) { return "Das ließ sich nicht verarbeiten (" + m[1] + ")."; }],
    [/^This text could not be laid out \((.+)\)\.$/, function (m) { return "Dieser Text ließ sich nicht setzen (" + m[1] + ")."; }],
    /* what a finished job did (the summary card) */
    [/^(\d+) files merged$/, function (m) { return m[1] + " Dateien zusammengefügt"; }],
    [/^(\d+) pages? removed$/, function (m) { return count(m[1], "page") + " entfernt"; }],
    [/^(\d+) pages? extracted$/, function (m) { return count(m[1], "page") + " extrahiert"; }],
    [/^(\d+) pages extracted, one PDF each$/, function (m) { return m[1] + " Seiten extrahiert, je ein PDF"; }],
    [/^Split into (\d+) PDFs$/, function (m) { return "In " + m[1] + " PDFs geteilt"; }],
    [/^(\d+) pages? saved in the new order$/, function (m) { return count(m[1], "page") + " in neuer Reihenfolge gesichert"; }],
    [/^(\d+) files? rotated$/, function (m) { return count(m[1], "file") + " gedreht"; }],
    [/^(\d+) pages? rotated$/, function (m) { return count(m[1], "page") + " gedreht"; }],
    [/^(\d+) pages? rotated in (\d+) files$/, function (m) { return count(m[1], "page") + " in " + count(m[2], "file") + " gedreht"; }],
    [/^(\d+) pages? converted to (JPG|PNG|WebP|TIFF|Word|PowerPoint)$/, function (m) { return count(m[1], "page") + " in " + m[2] + " umgewandelt"; }],
    [/^(\d+) images? converted to PDF$/, function (m) { return count(m[1], "image") + " in PDF umgewandelt"; }],
    [/^(\d+) Word files? converted to PDF$/, function (m) { return m[1] + pl(m[1], " Word-Datei", " Word-Dateien") + " in PDF umgewandelt"; }],
    [/^(\d+) edits? applied$/, function (m) { return m[1] + pl(m[1], " Änderung angewendet", " Änderungen angewendet"); }],
    [/^Letters (.+) use a close font, everything else keeps the original\.$/, function (m) {
      var one = Array.from(m[1]).length === 1;
      return (one ? "Der Buchstabe " + m[1] + " verwendet" : "Die Buchstaben " + m[1] + " verwenden") + " eine ähnliche Schrift, alles andere behält die Originalschrift.";
    }],
  ];

  /* Parts of the file names the app suggests when saving. */
  var names = {
    "merged": "zusammengefügt",
    "_edited": "_bearbeitet",
    "_pages": "_seiten",
    "_extracted": "_auszug",
    "_split": "_geteilt",
    "_organized": "_organisiert",
    "organized": "organisiert",
    "_rotated": "_gedreht",
    "rotated_pdfs": "gedrehte_pdfs",
    "word_to_pdf": "word_in_pdf",
  };

  window.PDFLAB_DE = { exact: exact, patterns: patterns, names: names };
})();
