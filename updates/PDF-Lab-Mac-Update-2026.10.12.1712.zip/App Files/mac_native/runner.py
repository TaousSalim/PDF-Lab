"""PDF Lab for the Mac: what the native app adds around the shared server.

The native app is a small shell (Mac Native/src-tauri) that owns the window, plus a Python of its own
(pdflab-runtime) that runs this file. This file plays the part the launcher plays on Windows
(Windows version/launcher/pdflab_launcher.pyw): it starts the shared server (server.py) unchanged and takes over
the few things that were written for a Chrome window the app did not own.

  window and quit   The shell owns the window. The server never opens one, never watches Chrome, and never quits
                    because a page went quiet. It stops when the shell says so (SIGTERM), when the shell is gone,
                    or when the page's quit button asks for it; the shell then closes the app.
  updates           The shared updater (updater.py), with its checks untouched. The download is the small ZIP of
                    "App Files". The app itself is never changed: the new files go into the app's own data folder
                    (~/Library/Application Support/PDF Lab/native/App Files), this program starts again from
                    there, and from then on the shell starts whichever copy is newer, that one or the one inside
                    the app. Before a new version is put in place it is started once on the side, to be sure it
                    runs. (Nothing has to be allowed by macOS, and it works wherever the app was put.)
  the hidden browser  Word to PDF and Image to PDF print through a hidden browser of the Chrome kind. The shared
                    code takes the first it finds (Chrome, Chromium, Edge, Brave). On the Mac the order is: Brave
                    when it is installed (Salim, 2026-10-12: his Mac and his friend's both print with Brave), then
                    the Mac's default browser when it is of the Chrome kind, then the shared order.
  the pages         The shared pages, as they are. Three additions are made while serving them, for this app only:
                    German (web/lang-de.js, with a language layer that knows more than two languages), the DE
                    button, and web/native.js (save window, language of the menus).

Nothing in this folder is copied to the Windows version (tools/sync_app_files.py copies a fixed list of files).

Started by pdflab-runtime:  --app-files <folder> --port <n> --parent-pid <pid> --shell-level <n>
                            [--updates-dir <folder>]   where an updated copy of "App Files" lives (none: no updates)
Other uses:                 --selfcheck    load the app's code and leave (0 when it loads)
                            --feed-check   read the small file on GitHub the way the app does, and say what it names
                            --check        are the Mac additions still in step with the shared pages? (0 when yes)
"""
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))          # .../App Files/mac_native
APP_FILES = os.path.dirname(HERE)
NATIVE_WEB = os.path.join(HERE, "web")

# The shared language layer this folder's own one (web/i18n-mac.js) was made from. When js/i18n.js changes, the
# same change has to be made in i18n-mac.js and this value updated: "--check" (run by every build) says so.
I18N_BASE_SHA256 = "ed46457eec3288ec3b55058f44b40a12b090246425e303c1b40a7f5ec8eb8e67"

# The oldest shell (SHELL_LEVEL in Mac Native/src-tauri/src/main.rs) these files work with. Written into the small
# file on GitHub as "shell", so an app with an older shell is not offered this version. Raise it, together with
# SHELL_LEVEL, when these files start to need something new from the shell.
NEEDS_SHELL = 1

TYPES = {".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css", ".json": "application/json",
         ".html": "text/html", ".wasm": "application/wasm", ".txt": "text/plain"}


def log(msg):
    print(f"[pdf-lab] {msg}", flush=True)


def option(args, name, default=None):
    for i, a in enumerate(args):
        if a == name and i + 1 < len(args):
            return args[i + 1]
    return default


def sha256_of(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


# ------------------------------------------------------------------ the pages, with the Mac additions

# (what it is for, pattern that must be found exactly once, what replaces it)
INDEX_CHANGES = [
    ("the German dictionary and the native helpers, loaded before the language layer",
     re.compile(r'(<script src="js/lang-fr\.js[^"]*"></script>)'),
     r'\1\n<script src="/native/lang-de.js"></script>\n<script src="/native/native.js"></script>'),
    ("the DE button of the language switch",
     re.compile(r'(<button type="button" data-set-lang="en"[^>]*>EN</button>)'),
     r'\1\n        <button type="button" data-set-lang="de" lang="de" title="Deutsch" aria-label="Deutsch" aria-pressed="false">DE</button>'),
]


def mac_index(text, problems=None):
    """index.html as the native app shows it. A change that no longer fits is left out (and reported)."""
    for why, pattern, new in INDEX_CHANGES:
        if len(pattern.findall(text)) != 1:
            if problems is not None:
                problems.append(f"web/index.html: could not add {why}")
            continue
        text = pattern.sub(new, text, count=1)
    return text


def check():
    """Are the Mac additions still in step with the shared pages? Returns the list of problems (empty: all fine)."""
    problems = []
    with open(os.path.join(APP_FILES, "web", "index.html"), encoding="utf-8") as f:
        mac_index(f.read(), problems)
    got = sha256_of(os.path.join(APP_FILES, "web", "js", "i18n.js"))
    if got != I18N_BASE_SHA256:
        problems.append("web/js/i18n.js changed: make the same change in mac_native/web/i18n-mac.js, then set "
                        f"I18N_BASE_SHA256 in mac_native/runner.py to {got}")
    for name in ("i18n-mac.js", "lang-de.js", "native.js", "webp-worker.js", "webp/webp_enc.js", "webp/webp_enc.wasm"):
        if not os.path.isfile(os.path.join(NATIVE_WEB, name)):
            problems.append(f"mac_native/web/{name} is missing")
    return problems


def install_pages(server):
    """Serve the shared pages with the Mac additions."""
    plain_get = server.Handler.do_GET

    def do_GET(self):
        if not self._trusted():
            return self._send(403, b"Forbidden", "text/plain")
        path = urllib.parse.urlparse(self.path).path
        try:
            if path in ("/", "/index.html"):
                with open(os.path.join(server.WEB_DIR, "index.html"), encoding="utf-8") as f:
                    return self._send(200, mac_index(f.read()).encode("utf-8"), "text/html")
            if path == "/js/i18n.js":
                with open(os.path.join(NATIVE_WEB, "i18n-mac.js"), "rb") as f:
                    return self._send(200, f.read(), "text/javascript")
            if path.startswith("/native/"):       # the files of mac_native/web, and nothing outside that folder
                name = urllib.parse.unquote(path[len("/native/"):])
                root = os.path.realpath(NATIVE_WEB)
                full = "" if "\x00" in name else os.path.realpath(os.path.join(root, name))
                if full.startswith(root + os.sep) and os.path.isfile(full):
                    with open(full, "rb") as f:
                        return self._send(200, f.read(), TYPES.get(os.path.splitext(full)[1], "application/octet-stream"))
                return self._send(404, b"Not found", "text/plain")
        except OSError:
            log(traceback.format_exc())      # a Mac addition could not be read: the shared page is served as it is
        return plain_get(self)

    server.Handler.do_GET = do_GET
    server.Handler.do_HEAD = do_GET


# ------------------------------------------------------------------ updates

def copy_folder(src, dst):
    """A copy of a folder. On the Mac's own disk format the copy shares its data with the original, so even the
    PDF engine (about 95 MB) is copied at once and takes no room."""
    done = subprocess.run(["/bin/cp", "-cR", src, dst], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if done.returncode != 0 or not os.path.isfile(os.path.join(dst, "server.py")):
        shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", ".DS_Store", "*.pyc"))
    # The app may sit somewhere read only (a disk image, an app installed by someone else). Its copy is ours to
    # change: an update moves folders in and out of it, and the shell removes it when it is out of date.
    for base, dirs, files in os.walk(dst):
        for name in dirs + files:
            path = os.path.join(base, name)
            try:
                if not os.path.islink(path):
                    os.chmod(path, os.stat(path).st_mode | (0o700 if os.path.isdir(path) else 0o600))
            except OSError:
                pass
    os.chmod(dst, os.stat(dst).st_mode | 0o700)


def make_updater(server, updater, shell_level, restart, updates_dir):
    target = os.path.join(updates_dir, "App Files")     # the copy that updates replace; the app itself is never touched

    class NativeUpdater(updater.Updater):
        """The shared updater: same looking, same download, same checks. Four things are added for this app."""

        def _can_replace(self):
            try:
                os.makedirs(updates_dir, exist_ok=True)
            except OSError:
                return False
            return os.access(updates_dir, os.W_OK)

        def _replace_files(self, path, version):
            # (0) the files that get replaced are a copy outside the app. The first update makes that copy from
            #     the files that are running; the shared code then swaps the new version into it as it always did.
            if os.path.abspath(APP_FILES) != os.path.abspath(target):
                shutil.rmtree(target, ignore_errors=True)
                seed = target + ".copying"
                shutil.rmtree(seed, ignore_errors=True)
                copy_folder(APP_FILES, seed)
                os.rename(seed, target)
            super()._replace_files(path, version)

        def _read_feed(self, feed):
            offer = super()._read_feed(feed)
            if offer is None:
                return None
            # (1) a version that needs a newer shell than this app has cannot be installed from inside: that
            #     one is downloaded again by hand. It is not offered here.
            need = feed.get("shell")
            if isinstance(need, int) and not isinstance(need, bool) and need > shell_level:
                self.log(f"updates: version {offer['version']} needs a newer app (shell {need}, this is {shell_level}): download PDF Lab again")
                return None
            # (2) what is new, in German too
            notes = feed.get("notes") if isinstance(feed.get("notes"), dict) else {}
            offer["notes"]["de"] = str(notes.get("de") or "")[:300]
            return offer

        def _unpack(self, path, into):
            super()._unpack(path, into)
            # (3) the new version must be one for this app, and must start: it is run once on the side, from
            #     where it was unpacked, before anything of the running version is touched.
            new = os.path.join(into, "App Files")
            if not os.path.isfile(os.path.join(new, "mac_native", "runner.py")):
                raise ValueError("the ZIP is not a version for the native app")
            cmd = runtime_command() + ["--app-files", new, "--selfcheck"]
            done = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120,
                                  env=fresh_environment())
            if done.returncode != 0:
                tail = done.stdout.decode("utf-8", "replace").strip().splitlines()[-3:]
                raise ValueError("the new version does not start: " + " | ".join(tail))

    conf = os.path.join(APP_FILES, "update.json")
    if not os.path.isfile(conf):
        return None
    return NativeUpdater(conf, server.state_dir(), kind="files", log=log, app_files=target, restart=restart)


def runtime_command():
    """How this program was started: the frozen runtime alone, or a Python and the runtime's script (tests)."""
    if getattr(sys, "frozen", False):
        return [sys.executable]
    return [sys.executable, os.path.abspath(sys.argv[0])]


def fresh_environment():
    env = dict(os.environ)
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"    # the frozen runtime starts as a new program, not as a part of this one
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


# ------------------------------------------------------------------ the hidden browser

# Browsers of the Chrome kind that can print for the app: what macOS calls them, and the name of the app.
CHROME_KIND = {
    "com.google.chrome": "Google Chrome",
    "com.brave.browser": "Brave Browser",
    "com.microsoft.edgemac": "Microsoft Edge",
    "org.chromium.chromium": "Chromium",
}


def installed(name):
    """The program of a browser by the name of its app ("Brave Browser"), or None when the Mac does not have it."""
    for base in ("/Applications", os.path.expanduser("~/Applications")):
        path = f"{base}/{name}.app/Contents/MacOS/{name}"
        if os.path.exists(path):
            return path
    return None


def default_browser_id(handlers):
    """The default browser, as macOS names it ("com.brave.browser"), from its list of handlers (LSHandlers).
    Empty when nothing was ever chosen: the default is then Safari."""
    for entry in handlers if isinstance(handlers, list) else []:
        if isinstance(entry, dict) and str(entry.get("LSHandlerURLScheme", "")).lower() == "https":
            return str(entry.get("LSHandlerRoleAll") or "").lower()
    return ""


def default_browser():
    """The program of the Mac's default browser when it is of the Chrome kind and installed, else None."""
    try:
        import plistlib
        out = subprocess.run(["/usr/bin/defaults", "export", "com.apple.LaunchServices/com.apple.launchservices.secure", "-"],
                             stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=5).stdout
        name = CHROME_KIND.get(default_browser_id(plistlib.loads(out).get("LSHandlers")))
    except Exception:
        return None
    return installed(name) if name else None


def install_browser_choice(server):
    plain = server.find_chrome

    def find_chrome():
        forced = os.environ.get("PDFLAB_CHROME")
        if forced and os.path.exists(forced):
            return forced
        return installed("Brave Browser") or default_browser() or plain()

    server.find_chrome = find_chrome

    # Brave does not print the "direct" way (it starts, and no PDF ever comes: measured on 2026-10-12 with Brave
    # 1.97). The app would find that out by itself, but only after waiting 45 seconds or more on the first
    # conversion. So with Brave the direct way is tried last; the other ways print in under a second.
    plain_order = server._print_order

    def print_order(chrome):
        names = plain_order(chrome)
        if "Brave Browser" in chrome and "direct" in names and not os.environ.get("PDFLAB_PRINT"):
            names.remove("direct")
            names.append("direct")
        return names

    server._print_order = print_order


# ------------------------------------------------------------------ https

def trust_this_mac(folder):
    """The Python inside the app brings no list of trusted certificate authorities, so without this no https
    address could be checked and the app would never see an update. The Mac has such a list, kept current by
    macOS: it is written out once per start and given to Python. (Checking is not relaxed in any way: this is what
    makes it possible.)"""
    try:
        done = subprocess.run(["/usr/bin/security", "find-certificate", "-a", "-p",
                               "/System/Library/Keychains/SystemRootCertificates.keychain"],
                              stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=30)
        pem = done.stdout
        if pem.count(b"BEGIN CERTIFICATE") < 20:
            raise OSError(f"only {pem.count(b'BEGIN CERTIFICATE')} certificates were listed")
        path = os.path.join(folder, "trusted-roots.pem")
        with open(path, "wb") as f:
            f.write(pem)
        os.environ["SSL_CERT_FILE"] = path
        return True
    except Exception as e:
        log(f"https: the Mac's list of trusted authorities could not be read ({type(e).__name__}: {e}); updates will not be found")
        return False


def feed_check():
    """Read the feed named in update.json exactly as a running app does. Prints what it names; 0 when it could be read."""
    import updater
    with open(os.path.join(APP_FILES, "update.json"), encoding="utf-8") as f:
        conf = json.load(f)
    feed = os.environ.get("PDFLAB_UPDATE_FEED", str(conf.get("feed") or "")).strip()
    if not feed:
        print("no feed in update.json: this copy never looks for updates")
        return 1
    with tempfile.TemporaryDirectory(prefix="pdf-lab-feed-") as tmp:
        trust_this_mac(tmp)
        try:
            with updater._open(feed, updater.FEED_TIMEOUT, f"PDF-Lab/{conf.get('version')}") as r:
                got = json.loads(r.read(updater.MAX_FEED + 1).decode("utf-8-sig"))
        except Exception as e:
            print(f"the feed could not be read: {type(e).__name__}: {e}")
            return 1
    print(f"feed: {feed}\n  names version {got.get('version')} (this copy is {conf.get('version')}), file {got.get('file')}, shell {got.get('shell', '-')}")
    return 0


# ------------------------------------------------------------------ start, run, stop

def selfcheck():
    """Load the app's code the way a start does, without serving anything."""
    import server      # noqa: F401  (brings builders, updater, editor and pypdf with it)
    for base, dirs, files in os.walk(APP_FILES):
        dirs[:] = [d for d in dirs if d not in ("vendor", "vendor_mu", "web", "__pycache__")]
        for fn in files:
            if fn.endswith(".py"):
                path = os.path.join(base, fn)
                with open(path, encoding="utf-8") as f:
                    compile(f.read(), path, "exec")
    print("selfcheck ok", flush=True)
    return 0


def main(args):
    if "--check" in args:
        problems = check()
        for p in problems:
            print(p)
        print("The Mac additions are in step with the shared pages." if not problems else f"{len(problems)} problem(s).")
        return 1 if problems else 0
    if "--selfcheck" in args:
        return selfcheck()
    if "--feed-check" in args:
        return feed_check()

    port = int(option(args, "--port", "0") or 0)
    parent = int(option(args, "--parent-pid", "0") or 0)
    shell_level = int(option(args, "--shell-level", "1") or 1)
    updates_dir = option(args, "--updates-dir")      # not given (the project folder, a test): this copy is never updated
    if not port:
        log("no --port given")
        return 2

    # Work folders of conversions live in a folder of this app's own, so that another PDF Lab on the same Mac
    # (the older app, a test build), which clears "pdflab-*" at its start, never touches a job running here.
    work = os.path.join(tempfile.gettempdir(), "pdf-lab-native")
    shutil.rmtree(work, ignore_errors=True)      # left by a crash: this is the only instance
    os.makedirs(work, exist_ok=True)
    tempfile.tempdir = work
    trust_this_mac(work)

    import server
    import updater

    def quit_now(*_args):
        server.QUITTING = True                   # first: a conversion that is retrying must not start another Chrome
        log("shutting down")
        for proc in list(server.PRINTING):       # a conversion must not outlive the app
            try:
                proc.kill()
            except Exception:
                pass
        for profile in list(server.OPENED):
            try:
                subprocess.run(["/usr/bin/pkill", "-f", profile], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, timeout=3)
            except Exception:
                pass
        shutil.rmtree(work, ignore_errors=True)
        try:
            sys.stdout.flush()
        except Exception:
            pass
        os._exit(0)

    def restart():
        """After an update: the new code, in this same process (so the shell keeps its child) and on the same port."""
        server.QUITTING = True
        for proc in list(server.PRINTING):
            try:
                proc.kill()
            except Exception:
                pass
        keep = [a for a in args if a != "--after-update"]
        keep[keep.index("--app-files") + 1] = os.path.join(updates_dir, "App Files")     # the new files live there
        cmd = runtime_command() + keep + ["--after-update"]
        os.environ.update({"PYINSTALLER_RESET_ENVIRONMENT": "1"})
        try:
            sys.stdout.flush()
            os.execv(cmd[0], cmd)
        except OSError as e:
            log(f"could not start the new version in place ({e}); leaving, the app closes")
            os._exit(1)

    # The shell owns the window and the life of the app.
    server.shutdown_now = quit_now               # the quit button ("/api/shutdown"), and the signals below
    server.schedule_close = lambda *a, **k: None  # a page that closes or reloads never stops the app
    server.stop_window = lambda: None
    server.stop_wrapper = lambda: None
    server.open_window = lambda *a, **k: None
    install_pages(server)
    install_browser_choice(server)

    httpd = None
    end = time.time() + (8 if "--after-update" in args else 0)
    while True:                                  # after an update the same port is taken again, as soon as it is free
        try:
            httpd = server.ThreadingHTTPServer((server.HOST, port), server.Handler)
            break
        except OSError as e:
            if time.time() >= end:
                log(f"port {port} cannot be used ({e})")
                return 3
            time.sleep(0.1)
    httpd.daemon_threads = True

    for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        try:
            signal.signal(sig, quit_now)
        except Exception:
            pass

    if parent:
        def watch_parent():
            while True:
                time.sleep(1)
                if os.getppid() != parent:       # the shell is gone (crash, force quit): nothing may be left behind
                    log("the app is gone")
                    quit_now()
        threading.Thread(target=watch_parent, daemon=True).start()

    problems = check()
    for p in problems:
        log("pages: " + p)

    server.UPDATER = make_updater(server, updater, shell_level, restart, updates_dir) if updates_dir else None
    if server.UPDATER is not None:
        server.UPDATER.start()
    else:
        log("updates: off (not started by the app, or no update.json)")

    log(f"serving on http://{server.HOST}:{port}/ (native window, shell {shell_level}, Python {sys.version.split()[0]}, files: {APP_FILES})")
    log(f"hidden browser for Word to PDF and Image to PDF: {server.find_chrome() or 'none found'}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0
