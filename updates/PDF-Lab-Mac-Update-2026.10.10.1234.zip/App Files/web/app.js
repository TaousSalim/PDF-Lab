import { $, $$, el, esc, toast } from "./js/core.js";
import { icon } from "./js/icons.js";
import { mountMerge, mountSplit, mountRemove, mountExtract, mountOrganize, mountRotate } from "./js/tools-organize.js";
import { mountEdit } from "./js/tools-edit.js";
import { mountPdf2Word, mountPdf2Ppt, mountPdf2Jpg, mountWord2Pdf, mountJpg2Pdf } from "./js/tools-convert.js";
import "./js/update.js";   // the update bar (shows only where the app updates itself: the Windows version)

/* ------------------------------------------------------------------ */
/* tool registry                                                       */
/* ------------------------------------------------------------------ */
// Colours that carry a white label reach 3.5 to 1 against white at least; smaller labels sit on a deeper
// shade worked out in js/core.js (palette). Yellow is too pale for white: its labels are dark.
const ORANGE = { color: "#db6544", light: "#f4d3c7" };
export const TOOLS = [
  { id: "merge", title: "Merge PDF", cat: "organize", icon: "merge", ...ORANGE, mount: mountMerge,
    desc: "Combine PDFs in the order you want with the easiest PDF merger available." },
  { id: "split", title: "Split PDF", cat: "organize", icon: "split", ...ORANGE, mount: mountSplit,
    desc: "Separate one page or a whole set for easy conversion into independent PDF files." },
  { id: "remove", title: "Remove pages", cat: "organize", icon: "remove", color: "#e5484d", light: "#f9d3d5", mount: mountRemove,
    desc: "Click the pages you do not need and export the rest. Every page is shown as a preview." },
  { id: "extract", title: "Extract pages", cat: "organize", icon: "extract", color: "#0b8f83", light: "#cbe9e5", mount: mountExtract,
    desc: "Pull selected pages out of a PDF into a new file, or save every page on its own." },
  { id: "organize", title: "Organize PDF", cat: "organize", icon: "organize", color: "#dd6449", light: "#efc9bb", mount: mountOrganize,
    desc: "Sort pages of your PDF file however you like. Delete PDF pages or add PDF pages to your document at your convenience." },
  { id: "rotate", title: "Rotate PDF", cat: "organize", icon: "rotate", color: "#a06a8e", light: "#e6d3df", mount: mountRotate,
    desc: "Rotate your PDFs the way you need them. You can even rotate multiple PDFs at once!" },
  { id: "edit", title: "Edit PDF", cat: "edit", icon: "edit", color: "#a76a93", light: "#e9d5e2", mount: mountEdit,
    desc: "Add text, images, shapes or freehand annotations to a PDF document. Edit the size, font, and color of the added content." },
  { id: "pdf2word", title: "PDF to Word", cat: "convert", icon: "pdf2word", color: "#6580c0", light: "#dde3f5", mount: mountPdf2Word,
    desc: "Turn your PDF files into easy to edit DOCX documents with paragraphs, headings, bold and italic kept." },
  { id: "pdf2ppt", title: "PDF to PowerPoint", cat: "convert", icon: "pdf2ppt", color: "#dd643e", light: "#f3d9cd", mount: mountPdf2Ppt,
    desc: "Turn your PDF files into easy to edit PPTX slideshows, as page images or editable text." },
  // the ids "pdf2jpg" and "jpg2pdf" date from the first names of these two tools; they stay as the page addresses
  { id: "pdf2jpg", title: "PDF to Image", cat: "convert", icon: "pdf2jpg", color: "#d2bd47", light: "#f7eeb4", mount: mountPdf2Jpg,
    desc: "Turn each PDF page into a PNG, JPG, WebP or TIFF image, in the quality you choose." },
  { id: "word2pdf", title: "Word to PDF", cat: "convert", icon: "word2pdf", color: "#6580c0", light: "#dde3f5", mount: mountWord2Pdf,
    desc: "Make DOC and DOCX files easy to read by converting them to PDF." },
  { id: "jpg2pdf", title: "Image to PDF", cat: "convert", icon: "jpg2pdf", color: "#d2bd47", light: "#f7eeb4", mount: mountJpg2Pdf,
    desc: "Turn any image into a PDF: JPG, PNG, iPhone photos (HEIC), TIFF, WebP and more. Adjust page size, orientation and margins." },
];
const byId = Object.fromEntries(TOOLS.map((t) => [t.id, t]));

/* ------------------------------------------------------------------ */
/* header                                                              */
/* ------------------------------------------------------------------ */
$("#themeBtn").addEventListener("click", () => {
  const root = document.documentElement;
  const explicit = root.getAttribute("data-theme");
  const dark = explicit ? explicit === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
  const next = dark ? "light" : "dark";
  root.setAttribute("data-theme", next);
  try { localStorage.setItem("pdflab-theme", next); } catch (e) {}
});

/* ------------------------------------------------------------------ */
/* home                                                                */
/* ------------------------------------------------------------------ */
// The top bar is the only navigation: its items are the tool groups, and picking one filters this grid.
const CATS = ["all", "organize", "edit", "convert"];
let homeCat = "all";

function renderHome() {
  const home = $("#home");
  home.innerHTML = `
    <div class="hero">
      <h1>Every tool you need to work with PDFs in one place</h1>
      <p>Merge, split, organize, rotate and convert your PDFs with a few clicks. Everything runs on your Mac, your files never leave it.</p>
    </div>
    <div class="tool-grid"></div>`;
  const grid = $(".tool-grid", home);
  TOOLS.forEach((t, i) => {
    const a = el("a", "tool-card");
    a.href = `#/${t.id}`;
    a.dataset.cat = t.cat;
    a.style.setProperty("--tc", t.color);
    a.style.setProperty("--i", i);
    a.innerHTML = `<div class="ic">${icon(t.icon, t.color, t.light, 64)}</div><h3>${esc(t.title)}</h3><p>${esc(t.desc)}</p>`;
    grid.appendChild(a);
  });
}

function showCat(cat) {
  homeCat = cat;
  $$("#home .tool-card").forEach((c) => { c.hidden = cat !== "all" && c.dataset.cat !== cat; });
}

/* ------------------------------------------------------------------ */
/* router                                                              */
/* ------------------------------------------------------------------ */
let current = null; // { tool, ctx }

function route() {
  const id = (location.hash.match(/^#\/([\w-]+)/) || [])[1];
  const tool = byId[id];
  if (current) { current.ctx.dispose(); current = null; }
  const host = $("#toolHost");
  host.innerHTML = "";
  // "#/" lists every tool, "#/cat-<group>" one group; inside a tool its group stays marked
  const cat = id && id.startsWith("cat-") && CATS.includes(id.slice(4)) ? id.slice(4) : "all";
  $$(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.cat === (tool ? tool.cat : cat)));
  $("#view").scrollTop = 0;
  if (!tool) {
    showCat(cat);
    $("#home").hidden = false;
    host.hidden = true;
    document.title = "PDF Lab";
    return;
  }
  $("#home").hidden = true;
  host.hidden = false;
  document.title = `${tool.title} | PDF Lab`;
  const crumb = el("a", "crumb", '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg> All tools');
  crumb.href = "#/";
  const body = el("div", "tool-body");
  host.append(crumb, body);
  current = { tool, ctx: tool.mount(tool, body) };
}
window.addEventListener("hashchange", route);

/* ------------------------------------------------------------------ */
/* global drag and drop                                                */
/* ------------------------------------------------------------------ */
let dragDepth = 0;
const hasFiles = (e) => e.dataTransfer && [...e.dataTransfer.types].includes("Files");
window.addEventListener("dragenter", (e) => {
  if (!hasFiles(e)) return;
  dragDepth++;
  $("#veil").classList.add("show");
});
window.addEventListener("dragleave", (e) => {
  if (!hasFiles(e)) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) $("#veil").classList.remove("show");
});
window.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
window.addEventListener("drop", (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth = 0;
  $("#veil").classList.remove("show");
  const files = [...e.dataTransfer.files];
  if (!current) { toast("Pick a tool first, then drop your files.", ""); return; }
  current.ctx.drop(files);
});

/* ------------------------------------------------------------------ */
/* lifecycle                                                           */
/* ------------------------------------------------------------------ */
// Shared window: the app window lives in the user's own Chrome (see server.py), so nobody can close it from
// outside and the page has to close itself. Chrome only allows that while the window has a single entry in
// its history, so in this mode moving between screens replaces the entry instead of adding one.
const SHARED = new URLSearchParams(location.search).get("window") === "shared";
if (SHARED) {
  document.addEventListener("click", (e) => {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest('a[href^="#/"]');
    if (!a) return;
    e.preventDefault();
    location.replace(a.getAttribute("href"));
  });
}

/** The app has stopped: close this window. If the browser refuses, leave a short note instead of a dead screen. */
function closeWindow() {
  window.close();
  setTimeout(() => {
    document.title = "PDF Lab";
    document.body.innerHTML = '<div class="closed-note"><strong>PDF Lab is closed.</strong><span>You can close this window.</span></div>';
  }, 600);
}

let missed = 0;
const ping = () => fetch("/api/ping").then(() => { missed = 0; }).catch(() => {
  // the app was quit from the Dock: its window goes with it (not while it restarts to install an update, js/update.js)
  if (SHARED && !window.PDFLAB_UPDATING && ++missed >= 2) closeWindow();
});
ping();
// A second open window keeps the server alive when the first one is closed.
setInterval(ping, 2000);
window.addEventListener("pagehide", () => navigator.sendBeacon("/api/closing", "{}"));

// Quit: no confirmation and no goodbye screen. The server closes the window, the Dock icon and itself.
$("#quitBtn").addEventListener("click", () => {
  if (!navigator.sendBeacon("/api/shutdown", "{}")) fetch("/api/shutdown", { method: "POST", keepalive: true }).catch(() => {});
  if (SHARED) setTimeout(closeWindow, 150);
});

renderHome();
route();
