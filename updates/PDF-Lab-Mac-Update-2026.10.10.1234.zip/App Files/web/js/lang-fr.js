/* PDF Lab: the French dictionary.
 *
 * exact     English text as the app writes it  ->  French text
 * patterns  texts that contain a number or a file name: [pattern, function(match, T) -> French]
 *           T(text) translates a smaller phrase with this same dictionary.
 *           A third item "attr" limits a pattern to tooltips and labels.
 * names     parts of suggested file names
 *
 * Conventions used here: "vous", sentence case, the curved apostrophe, and a no-break space ( ) before
 * : ; ! ? and inside « ». Texts for the Mac ("this Mac") and for Windows ("this computer") are both listed.
 * To add a text: write it in English in the app, then add one line here. js/i18n.js explains the rest.
 */
(function () {
  "use strict";

  var NB = " ";
  /** 1.5 -> "1,5" */
  var num = function (s) { return String(s).replace(".", ","); };
  /** French plural: 0 and 1 are singular. */
  var pl = function (n, one, many) { return Number(n) > 1 ? many : one; };
  var COUNT = {
    page: ["page", "pages"], file: ["fichier", "fichiers"], image: ["image", "images"],
    slide: ["diapositive", "diapositives"], PDF: ["PDF", "PDF"],
  };
  var count = function (n, word) {
    var w = COUNT[word.replace(/s$/, "")] || COUNT[word] || [word, word];
    return n + " " + pl(n, w[0], w[1]);
  };
  var here = function (word) { return word === "Mac" ? "ce Mac" : "cet ordinateur"; };
  /** The number shown in bold just before a text (font report). */
  var before = function (node) {
    var p = node && node.previousElementSibling;
    return p ? parseInt(p.textContent, 10) || 0 : 2;
  };

  var exact = {
    /* ------------------------------------------------ top bar */
    "All": "Tous",
    "Organize PDF": "Organiser PDF",
    "Edit PDF": "Modifier PDF",
    "Convert PDF": "Convertir PDF",
    "PDF Lab": "PDF Lab",
    "PDF Lab home": "Accueil de PDF Lab",
    "Main": "Navigation principale",
    "Language": "Langue",
    "FR": "FR",
    "EN": "EN",
    "Français": "Français",
    "English": "English",
    "Switch light or dark theme": "Basculer entre le thème clair et le thème sombre",
    "Switch theme": "Changer de thème",
    "Quit PDF Lab": "Quitter PDF Lab",
    "Drop to add": "Déposez pour ajouter",
    "PDF Lab is closed.": "PDF Lab est fermé.",
    "You can close this window.": "Vous pouvez fermer cette fenêtre.",

    /* ------------------------------------------------ home */
    "Every tool you need to work with PDFs in one place": "Tous vos outils PDF réunis au même endroit",
    "Merge, split, organize, rotate and convert your PDFs with a few clicks. Everything runs on your Mac, your files never leave it.":
      "Fusionnez, divisez, organisez, faites pivoter et convertissez vos PDF en quelques clics. Tout se passe sur votre Mac" + NB + ": vos fichiers ne le quittent jamais.",
    "Merge, split, organize, rotate and convert your PDFs with a few clicks. Everything runs on your computer, your files never leave it.":
      "Fusionnez, divisez, organisez, faites pivoter et convertissez vos PDF en quelques clics. Tout se passe sur votre ordinateur" + NB + ": vos fichiers ne le quittent jamais.",
    "Merge PDF": "Fusionner PDF",
    "Combine PDFs in the order you want with the easiest PDF merger available.": "Réunissez vos PDF dans l’ordre de votre choix, avec l’outil de fusion le plus simple qui soit.",
    "Split PDF": "Diviser PDF",
    "Separate one page or a whole set for easy conversion into independent PDF files.": "Séparez une page ou tout un groupe de pages pour en faire des fichiers PDF indépendants.",
    "Remove pages": "Supprimer des pages",
    "Click the pages you do not need and export the rest. Every page is shown as a preview.": "Cliquez sur les pages dont vous n’avez pas besoin et exportez le reste. Chaque page est affichée en aperçu.",
    "Extract pages": "Extraire des pages",
    "Pull selected pages out of a PDF into a new file, or save every page on its own.": "Extrayez les pages choisies d’un PDF dans un nouveau fichier, ou enregistrez chaque page séparément.",
    "Sort pages of your PDF file however you like. Delete PDF pages or add PDF pages to your document at your convenience.":
      "Classez les pages de votre PDF comme bon vous semble. Supprimez des pages ou ajoutez-en à votre document, à votre convenance.",
    "Rotate PDF": "Faire pivoter PDF",
    "Rotate your PDFs the way you need them. You can even rotate multiple PDFs at once!": "Faites pivoter vos PDF comme vous le souhaitez. Vous pouvez même en faire pivoter plusieurs à la fois" + NB + "!",
    "Add text, images, shapes or freehand annotations to a PDF document. Edit the size, font, and color of the added content.":
      "Ajoutez du texte, des images, des formes ou des annotations à main levée dans un document PDF. Modifiez la taille, la police et la couleur du contenu ajouté.",
    "PDF to Word": "PDF en Word",
    "Turn your PDF files into easy to edit DOCX documents with paragraphs, headings, bold and italic kept.":
      "Transformez vos PDF en documents DOCX faciles à modifier, en conservant les paragraphes, les titres, le gras et l’italique.",
    "PDF to PowerPoint": "PDF en PowerPoint",
    "Turn your PDF files into easy to edit PPTX slideshows, as page images or editable text.":
      "Transformez vos PDF en présentations PPTX faciles à modifier, sous forme d’images de pages ou de texte modifiable.",
    "PDF to Image": "PDF en image",
    "Turn each PDF page into a PNG, JPG, WebP or TIFF image, in the quality you choose.": "Transformez chaque page d’un PDF en image PNG, JPG, WebP ou TIFF, dans la qualité de votre choix.",
    "Word to PDF": "Word en PDF",
    "Make DOC and DOCX files easy to read by converting them to PDF.": "Rendez vos fichiers DOC et DOCX faciles à lire en les convertissant en PDF.",
    "Image to PDF": "Image en PDF",
    "Turn any image into a PDF: JPG, PNG, iPhone photos (HEIC), TIFF, WebP and more. Adjust page size, orientation and margins.":
      "Transformez n’importe quelle image en PDF" + NB + ": JPG, PNG, photos d’iPhone (HEIC), TIFF, WebP et bien d’autres. Réglez le format de page, l’orientation et les marges.",
    "All tools": "Tous les outils",
    "Pick a tool first, then drop your files.": "Choisissez d’abord un outil, puis déposez vos fichiers.",

    /* ------------------------------------------------ shared */
    "Something went wrong.": "Une erreur s’est produite.",
    "Nothing was produced.": "Aucun fichier n’a été produit.",
    "That file type is not supported here.": "Ce type de fichier n’est pas pris en charge ici.",
    "Only PDF files are supported here.": "Seuls les fichiers PDF sont pris en charge ici.",
    "Remove": "Retirer",
    "Add more files": "Ajouter des fichiers",
    "Select PDF file": "Sélectionner un fichier PDF",
    "Select PDF files": "Sélectionner des fichiers PDF",
    "or drop a PDF here": "ou déposez un PDF ici",
    "or drop PDFs here": "ou déposez vos PDF ici",
    "Choose another file": "Choisir un autre fichier",
    "Save PDF": "Enregistrer le PDF",
    "Files": "Fichiers",
    "Pages": "Pages",
    "Size": "Taille",
    "Select all": "Tout sélectionner",
    "Clear": "Désélectionner",
    "Reset": "Réinitialiser",
    "Result": "Résultat",
    "PDF": "PDF", "ZIP": "ZIP", "JPG": "JPG", "PNG": "PNG", "WebP": "WebP", "TIFF": "TIFF", "DOC": "DOC", "DOCX": "DOCX",

    /* ------------------------------------------------ progress card */
    "Progress": "Progression",
    "Cancel": "Annuler",
    "Saving": "Enregistrement",
    "Done": "Terminé",
    "Cancelled. Nothing was saved.": "Opération annulée. Rien n’a été enregistré.",
    "Close": "Fermer",
    "Saved in the folder you chose.": "Enregistré dans le dossier que vous avez choisi.",
    "Saved in your Downloads folder.": "Enregistré dans votre dossier Téléchargements.",
    "Saved in:": "Enregistré dans" + NB + ":",
    "The folder you chose could not be written to. Saved in your Downloads folder instead.": "Impossible d’écrire dans le dossier choisi. Le fichier a été enregistré dans votre dossier Téléchargements.",
    "Not completed": "Non terminé",
    "Nothing was saved.": "Rien n’a été enregistré.",
    "PDF Lab is not responding. Quit it, open it again, then try once more.": "PDF Lab ne répond pas. Quittez-le, rouvrez-le, puis réessayez.",
    "Merging": "Fusion en cours",
    "Removing pages": "Suppression des pages",
    "Extracting pages": "Extraction des pages",
    "Splitting": "Division en cours",
    "Organizing pages": "Organisation des pages",
    "Rotating": "Rotation en cours",
    "Reading the document": "Lecture du document",

    /* ------------------------------------------------ Merge PDF */
    "Drag the files to put them in the order you want. Pages are merged from first to last.":
      "Faites glisser les fichiers pour les placer dans l’ordre voulu. Les pages sont fusionnées du premier fichier au dernier.",
    "Sort A to Z": "Trier de A à Z",
    "Reverse": "Inverser",
    "Clear all": "Tout retirer",
    "Add PDFs": "Ajouter des PDF",
    "Add one more PDF": "Ajoutez encore un PDF",

    /* ------------------------------------------------ Remove pages, Extract pages */
    "Click the pages you want to delete. Shift-click selects a range. You can also type page numbers.":
      "Cliquez sur les pages à supprimer. Maj+clic sélectionne une plage. Vous pouvez aussi saisir les numéros de page.",
    "Pages to remove": "Pages à supprimer",
    "Marked for removal": "Pages marquées",
    "Pages remaining": "Pages restantes",
    "Clear selection": "Tout désélectionner",
    "Keep at least one page.": "Conservez au moins une page.",
    "Click the pages you want to keep. Shift-click selects a range. You can also type page numbers.":
      "Cliquez sur les pages à conserver. Maj+clic sélectionne une plage. Vous pouvez aussi saisir les numéros de page.",
    "Pages to extract": "Pages à extraire",
    "Output": "Sortie",
    "One PDF": "Un seul PDF",
    "One PDF per page": "Un PDF par page",
    "Selected pages": "Pages sélectionnées",

    /* ------------------------------------------------ Split PDF */
    "Ranges": "Plages",
    "Every N": "Lots de N",
    "Each page": "Par page",
    "Pages for each file": "Pages de chaque fichier",
    "Each comma separated entry becomes its own PDF. Use \"8-\" for page 8 to the end.":
      "Chaque entrée séparée par une virgule devient un PDF distinct. Saisissez «" + NB + "8-" + NB + "» pour aller de la page 8 à la fin.",
    "Merge all ranges into one PDF": "Fusionner toutes les plages en un seul PDF",
    "Pages per file": "Pages par fichier",
    "Every page is saved as its own PDF.": "Chaque page est enregistrée dans son propre PDF.",
    "Enter a number of pages, 1 or more.": "Saisissez un nombre de pages, 1 ou plus.",
    "Type the pages for each file.": "Saisissez les pages de chaque fichier.",
    "Extract PDF": "Extraire PDF",

    /* ------------------------------------------------ Organize PDF, Rotate PDF */
    "Add more PDFs": "Ajouter d’autres PDF",
    "Drag pages to reorder them. Use the buttons on a page to rotate or delete it. Add more PDFs to bring their pages in at the end.":
      "Faites glisser les pages pour les réordonner. Les boutons d’une page permettent de la faire pivoter ou de la supprimer. Ajoutez d’autres PDF pour placer leurs pages à la fin.",
    "Source files": "Fichiers sources",
    "Rotate all left": "Tout faire pivoter à gauche",
    "Rotate all right": "Tout faire pivoter à droite",
    "Reverse order": "Inverser l’ordre",
    "Start over": "Recommencer",
    "Rotate left": "Pivoter à gauche",
    "Rotate right": "Pivoter à droite",
    "Delete page": "Supprimer la page",
    "Rotate each PDF with the buttons under its preview, or rotate all of them at once. Every page of a file is turned together.":
      "Faites pivoter chaque PDF avec les boutons situés sous son aperçu, ou tous les PDF d’un coup. Toutes les pages d’un fichier pivotent ensemble.",
    "Files to rotate": "Fichiers à faire pivoter",
    "Every page is shown. Click a page to turn it to the right, or use the buttons on it to turn it either way. The buttons below turn every page at once.":
      "Toutes les pages sont affichées. Cliquez sur une page pour la faire pivoter vers la droite, ou utilisez ses boutons pour la faire pivoter dans un sens ou dans l’autre. Les boutons ci-dessous permettent de faire pivoter toutes les pages d’un coup.",
    "Pages to rotate": "Pages à faire pivoter",
    "Rotate this file left": "Faire pivoter ce fichier à gauche",
    "Rotate this file right": "Faire pivoter ce fichier à droite",
    "Remove this file": "Retirer ce fichier",
    "Click to rotate this page right": "Cliquez pour faire pivoter cette page vers la droite",

    /* ------------------------------------------------ PDF to Image */
    "Every selected page becomes an image. Click pages to include or skip them.": "Chaque page sélectionnée devient une image. Cliquez sur les pages pour les inclure ou les exclure.",
    "Image format": "Format d’image",
    "Quality": "Qualité",
    "Standard": "Standard",
    "High": "Élevée",
    "Maximum": "Maximale",
    "Pages to convert": "Pages à convertir",
    "Packing files": "Finalisation",

    /* ------------------------------------------------ Image to PDF */
    "Please choose image files: JPG, PNG, iPhone photos (HEIC), TIFF, WebP and more.": "Choisissez des images" + NB + ": JPG, PNG, photos d’iPhone (HEIC), TIFF, WebP et bien d’autres.",
    "Select images": "Sélectionner des images",
    "or drop any images here, iPhone photos included": "ou déposez vos images ici, photos d’iPhone comprises",
    "Reading the image": "Lecture de l’image",
    "Convert to PDF": "Convertir en PDF",
    "Convert to PDFs (ZIP)": "Convertir en PDF (ZIP)",
    "Page size": "Format de page",
    "Fit image": "Ajusté",
    "A4": "A4",
    "US Letter": "Lettre US",
    "Orientation": "Orientation",
    "Auto": "Auto",
    "Portrait": "Portrait",
    "Landscape": "Paysage",
    "Margin": "Marge",
    "None": "Aucune",
    "Small": "Petite",
    "Big": "Grande",
    "Merge all images into one PDF": "Fusionner toutes les images en un seul PDF",
    "Drag the images to change their order.": "Faites glisser les images pour changer leur ordre.",
    "Add images": "Ajouter des images",

    /* ------------------------------------------------ Word to PDF */
    "Please choose a Word file (.docx or .doc).": "Choisissez un fichier Word (.docx ou .doc).",
    "Select Word files": "Sélectionner des fichiers Word",
    "or drop DOC and DOCX files here": "ou déposez vos fichiers DOC et DOCX ici",
    "Your document is converted on this Mac. Page size, margins, headers, footers, page numbers, lists, tables, pictures and shapes follow the Word file.":
      "Votre document est converti sur ce Mac. Le format de page, les marges, les en-têtes, les pieds de page, les numéros de page, les listes, les tableaux, les images et les formes sont repris du fichier Word.",
    "Your document is converted on this computer. Page size, margins, headers, footers, page numbers, lists, tables, pictures and shapes follow the Word file.":
      "Votre document est converti sur cet ordinateur. Le format de page, les marges, les en-têtes, les pieds de page, les numéros de page, les listes, les tableaux, les images et les formes sont repris du fichier Word.",
    "Several files at once are saved together as a ZIP.": "Plusieurs fichiers convertis en même temps sont enregistrés ensemble dans un ZIP.",
    "Add Word files": "Ajouter des fichiers Word",
    "Converting": "Conversion en cours",
    "This document is empty or could not be read.": "Ce document est vide ou illisible.",
    "This Word file could not be opened. It may be damaged.": "Ce fichier Word n’a pas pu être ouvert. Il est peut-être endommagé.",
    "This Word file is protected by a password. Remove the password in Word, then try again.": "Ce fichier Word est protégé par un mot de passe. Retirez le mot de passe dans Word, puis réessayez.",

    /* ------------------------------------------------ PDF to Word */
    "The text of your PDF is rebuilt as an editable Word document, with paragraphs, headings, bold and italic.":
      "Le texte de votre PDF est reconstitué dans un document Word modifiable, avec ses paragraphes, ses titres, le gras et l’italique.",
    "Start a new Word page for every PDF page": "Commencer une nouvelle page Word à chaque page du PDF",
    "Good to know": "Bon à savoir",
    "Pictures, tables and colors are not carried over, and scanned PDFs need text recognition first because they contain no real text.":
      "Les images, les tableaux et les couleurs ne sont pas repris. Les PDF numérisés doivent d’abord passer par une reconnaissance de texte, car ils ne contiennent pas de vrai texte.",
    "Convert to Word": "Convertir en Word",
    "This PDF has no selectable text. It looks like a scan, so it needs text recognition (OCR) first.":
      "Ce PDF ne contient aucun texte sélectionnable. Il s’agit sans doute d’un document numérisé" + NB + ": il faut d’abord lui appliquer une reconnaissance de texte (OCR).",
    "Building the Word file": "Création du fichier Word",

    /* ------------------------------------------------ PDF to PowerPoint */
    "Every PDF page becomes one slide.": "Chaque page du PDF devient une diapositive.",
    "Slide content": "Contenu des diapositives",
    "Page images": "Images des pages",
    "Editable text": "Texte modifiable",
    "Each slide shows the page exactly as it looks in the PDF. Best for a faithful look.":
      "Chaque diapositive montre la page exactement telle qu’elle apparaît dans le PDF. Idéal pour un rendu fidèle.",
    "Text is placed in editable text boxes on blank slides. Best when you want to change the words. Pictures and colors are not carried over.":
      "Le texte est placé dans des zones de texte modifiables, sur des diapositives vierges. Idéal pour retoucher le texte. Les images et les couleurs ne sont pas reprises.",
    "Slides": "Diapositives",
    "Convert to PowerPoint": "Convertir en PowerPoint",
    "This PDF has no selectable text. Use Page images instead.": "Ce PDF ne contient aucun texte sélectionnable. Utilisez plutôt «" + NB + "Images des pages" + NB + "».",
    "Building the presentation": "Création de la présentation",

    /* ------------------------------------------------ Edit PDF: toolbar */
    "Edit": "Modifier",
    "Text": "Texte",
    "Image": "Image",
    "Box": "Cadre",
    "Oval": "Ovale",
    "Line": "Ligne",
    "Arrow": "Flèche",
    "Draw": "Dessin",
    "Mark": "Surligner",
    "Erase": "Effacer",
    "Select and edit text": "Sélectionner et modifier le texte",
    "Add text": "Ajouter du texte",
    "Add image": "Ajouter une image",
    "Rectangle": "Rectangle",
    "Ellipse": "Ellipse",
    "Highlight": "Surlignage",
    "Cover or erase": "Masquer ou effacer",
    "Click any text to edit it, or click a shape to move it": "Cliquez sur un texte pour le modifier, ou sur une forme pour la déplacer",
    "Click on the page and type": "Cliquez sur la page et saisissez votre texte",
    "Choose a picture to place on the page": "Choisissez une image à placer sur la page",
    "Drag on the page": "Faites glisser sur la page",
    "Draw freehand on the page": "Dessinez à main levée sur la page",
    "Drag over the text to highlight": "Faites glisser sur le texte à surligner",
    "Drag over anything to hide it": "Faites glisser sur un élément pour le masquer",
    "Zoom out": "Zoom arrière",
    "Zoom in": "Zoom avant",
    "Fit to width": "Ajuster à la largeur",

    /* ------------------------------------------------ Edit PDF: side panel */
    "Changes": "Modifications",
    "Edits": "Nombre de modifications",
    "Pages touched": "Pages modifiées",
    "Undo": "Annuler",
    "Redo": "Rétablir",
    "Discard all": "Tout supprimer",
    "Click any text on the page to edit it. Your new text keeps the original font and spacing, and a live preview shows the exact result. Click a shape or picture to move it.":
      "Cliquez sur un texte de la page pour le modifier. Le nouveau texte conserve la police et l’espacement d’origine, et un aperçu en direct montre le résultat exact. Cliquez sur une forme ou une image pour la déplacer.",
    "Click where the text should go, then type. Press Esc or click away when you are done.":
      "Cliquez à l’endroit où placer le texte, puis saisissez-le. Appuyez sur Échap ou cliquez ailleurs quand vous avez terminé.",
    "Pick a picture and it is placed on the page. Drag it to move it, drag a corner to resize.":
      "Choisissez une image" + NB + ": elle est placée sur la page. Faites-la glisser pour la déplacer, tirez un coin pour la redimensionner.",
    "Drag on the page to draw a rectangle.": "Faites glisser sur la page pour tracer un rectangle.",
    "Drag on the page to draw an ellipse.": "Faites glisser sur la page pour tracer une ellipse.",
    "Drag to draw a line. Hold Shift for straight angles.": "Faites glisser pour tracer une ligne. Maintenez la touche Maj enfoncée pour contraindre l’angle par pas de 15°.",
    "Drag to draw an arrow. Hold Shift for straight angles.": "Faites glisser pour tracer une flèche. Maintenez la touche Maj enfoncée pour contraindre l’angle par pas de 15°.",
    "Draw freely with the mouse or trackpad.": "Dessinez librement à la souris ou au pavé tactile.",
    "Drag over text to highlight it.": "Faites glisser sur le texte pour le surligner.",
    "Drag over anything to hide it. The content underneath is removed for good, and the colour matches the page.":
      "Faites glisser sur un élément pour le masquer. Le contenu situé dessous est supprimé définitivement, et la couleur s’accorde à celle de la page.",
    "Sans (Helvetica style)": "Sans serif (style Helvetica)",
    "Serif (Times style)": "Serif (style Times)",
    "Mono (Courier style)": "Chasse fixe (style Courier)",
    "Original font": "Police d’origine",
    "Text style": "Style du texte",
    "Style": "Style",
    "Selected text": "Texte sélectionné",
    "Font": "Police",
    "close font used": "police similaire utilisée",
    "Color": "Couleur",
    "B": "G",
    "I": "I",
    "Original style": "Style d’origine",
    "Squeeze to the original width": "Ajuster à la largeur d’origine",
    "Changing the font here uses an installed font instead of the one in the PDF.": "Si vous changez la police ici, une police installée est utilisée à la place de celle du PDF.",
    "Left": "Gauche",
    "Center": "Centre",
    "Right": "Droite",
    "Line height": "Interligne",
    "Line color": "Couleur du trait",
    "Fill": "Remplissage",
    "Fill color": "Couleur de remplissage",
    "Thickness": "Épaisseur",
    "Opacity": "Opacité",
    "Strength": "Intensité",
    "Bring to front": "Mettre au premier plan",
    "Send to back": "Mettre à l’arrière-plan",
    "Delete": "Supprimer",
    "Drawing": "Dessin",
    "Cover": "Cache",
    "Remove what is underneath": "Supprimer ce qui se trouve dessous",
    "When on, text and pictures under the box are deleted from the file, not just hidden.":
      "Si cette option est activée, le texte et les images situés sous le cache sont supprimés du fichier, et pas seulement masqués.",
    "Picture": "Image",
    "Drag the picture to move it. Drag a corner to resize it.": "Faites glisser l’image pour la déplacer. Tirez un coin pour la redimensionner.",

    /* ------------------------------------------------ Edit PDF: page, font report, messages */
    "No editable text on this page. You can still add text, images and shapes.":
      "Aucun texte modifiable sur cette page. Vous pouvez tout de même ajouter du texte, des images et des formes.",
    "The text of this page could not be read.": "Le texte de cette page n’a pas pu être lu.",
    "All changes were discarded. Undo brings them back.": "Toutes les modifications ont été supprimées. Le bouton Annuler permet de les récupérer.",
    "The preview could not be updated.": "L’aperçu n’a pas pu être mis à jour.",
    "Fidelity": "Fidélité",
    "letters use the original font": function (node) { return pl(before(node), "lettre utilise la police d’origine", "lettres utilisent la police d’origine"); },
    "letters use a matching installed font:": function (node) {
      return pl(before(node), "lettre utilise une police installée similaire", "lettres utilisent une police installée similaire") + NB + ":";
    },
    "No font has:": "Aucune police ne contient" + NB + ":",
    "Letters that already exist in the PDF keep their exact shape and spacing. New letters use the closest installed font.":
      "Les lettres déjà présentes dans le PDF conservent exactement leur forme et leur espacement. Les nouvelles lettres utilisent la police installée la plus proche.",
    "Enter to apply": "Entrée pour valider",
    "Esc to cancel": "Échap pour annuler",
    "Custom font selected": "Police personnalisée",
    "Close font used for this line": "Police similaire utilisée pour cette ligne",
    "Close font for:": "Police similaire pour" + NB + ":",
    "That image could not be read.": "Cette image n’a pas pu être lue.",
    "That file is not a picture PDF Lab can read.": "Ce fichier n’est pas une image lisible par PDF Lab.",
    "Applying your edits": "Application de vos modifications",

    /* ------------------------------------------------ messages from the server */
    "No pages selected.": "Aucune page sélectionnée.",
    "Rotation must be a multiple of 90 degrees.": "La rotation doit être un multiple de 90 degrés.",
    "Google Chrome is needed for this tool but was not found.": "Cet outil a besoin de Google Chrome, mais Chrome est introuvable.",
    "The conversion took too long and was stopped.": "La conversion a pris trop de temps et a été interrompue.",
    "Chrome could not produce the PDF.": "Chrome n’a pas pu produire le PDF.",
    "An image has an invalid size.": "Une image a des dimensions non valides.",
    "Bad request.": "Requête incorrecte.",
    "This file is too large. The limit is 1 GB.": "Ce fichier est trop volumineux. La limite est de 1 Go.",
    "The upload was interrupted.": "Le chargement du fichier a été interrompu.",
    "A file is no longer available. Please add it again.": "Un fichier n’est plus disponible. Ajoutez-le à nouveau.",
    "Add at least 2 PDF files to merge.": "Ajoutez au moins 2 fichiers PDF à fusionner.",
    "The document has no pages.": "Le document ne contient aucune page.",
    "Invalid page selection.": "Sélection de pages non valide.",
    "Add at least one PDF.": "Ajoutez au moins un PDF.",
    "Nothing to split.": "Rien à diviser.",
    "Nothing to convert.": "Rien à convertir.",
    "Add at least one image.": "Ajoutez au moins une image.",
    "Unknown page size.": "Format de page inconnu.",
    "Old .doc files are not supported here. Please save the file as .docx first.":
      "Les anciens fichiers .doc ne sont pas pris en charge ici. Enregistrez d’abord le fichier au format .docx.",
    "This .doc file could not be converted. Please save it as .docx first.": "Ce fichier .doc n’a pas pu être converti. Enregistrez-le d’abord au format .docx.",
    "This file is not a PDF.": "Ce fichier n’est pas un PDF.",
    "This PDF is password protected and cannot be edited.": "Ce PDF est protégé par un mot de passe et ne peut pas être modifié.",
    "Invalid page.": "Page non valide.",
    "No pages to convert.": "Aucune page à convertir.",
    "A page has an invalid size.": "Une page a des dimensions non valides.",
    "Forbidden": "Accès refusé",
    "Unknown route": "Adresse inconnue",
    "This line contains special glyph groups and cannot be edited safely.": "Cette ligne contient des groupes de glyphes particuliers et ne peut pas être modifiée sans risque.",
    "This text uses a script the editor cannot write.": "Ce texte utilise un système d’écriture que l’éditeur ne prend pas en charge.",
    "This line is too long to be written in one piece.": "Cette ligne est trop longue pour être écrite d’un seul tenant.",
    "An image could not be read.": "Une image n’a pas pu être lue.",
    "The page changed since the text was selected. Please reopen the file.": "La page a changé depuis la sélection du texte. Rouvrez le fichier.",
    "Arabic text set at a slant cannot be edited. Erase it and add new text instead.":
      "Un texte arabe écrit en biais ne peut pas être modifié. Effacez-le et ajoutez un nouveau texte à la place.",
    "This line could not be read reliably. Erase it and add new text instead.":
      "Cette ligne n’a pas pu être lue de façon fiable. Effacez-la et ajoutez un nouveau texte à la place.",

    /* ------------------------------------------------ updates (js/update.js) */
    "Update": "Mise à jour",
    "A new version of PDF Lab is ready.": "Une nouvelle version de PDF Lab est prête.",
    "Install the update": "Installer la mise à jour",
    "Later": "Plus tard",
    "PDF Lab restarts to install the update. Work that is not saved will be lost.":
      "PDF Lab redémarre pour installer la mise à jour. Le travail non enregistré sera perdu.",
    "Install now": "Installer maintenant",
    "Try again": "Réessayer",
    "The update could not be downloaded. Check the internet connection, then try again.":
      "La mise à jour n’a pas pu être téléchargée. Vérifiez la connexion internet, puis réessayez.",
    "The update could not be started. Try again, or keep working: PDF Lab works as before.":
      "La mise à jour n’a pas pu démarrer. Réessayez, ou continuez à travailler : PDF Lab fonctionne comme avant.",
    "Updating PDF Lab": "Mise à jour de PDF Lab",
    "Downloading": "Téléchargement",
    "Installing": "Installation",
    "PDF Lab restarts by itself.": "PDF Lab redémarre tout seul.",
    "Wait until the current task is finished, then install the update.": "Attendez la fin de la tâche en cours, puis installez la mise à jour.",
    "PDF Lab has been updated.": "PDF Lab a été mis à jour.",
  };

  var patterns = [
    /* window title */
    [/^(.+) \| PDF Lab$/, function (m, T) { return T(m[1]) + " | PDF Lab"; }],

    /* numbers and sizes */
    [/^(\d+) (pages?|files?|images?|slides?|PDFs?)$/, function (m) { return count(m[1], m[2]); }],
    [/^(\d+) KB$/, function (m) { return m[1] + NB + "Ko"; }],
    [/^(\d+(?:\.\d+)?) MB$/, function (m) { return num(m[1]) + NB + "Mo"; }],
    [/^(\d+(?:\.\d+)?) pt$/, function (m) { return num(m[1]) + NB + "pt"; }],
    [/^(\d+)%$/, function (m) { return m[1] + NB + "%"; }],
    [/^Version (\d[\d.]*)$/, function (m) { return "Version " + m[1]; }],
    [/^(\d+)\.(\d+)$/, function (m) { return m[1] + "," + m[2]; }],
    [/^(\d+) \u00d7 (\d+)$/, function (m) { return m[1] + " \u00d7 " + m[2]; }],
    [/^(\d+) PDF files$/, function (m) { return m[1] + " " + pl(m[1], "fichier", "fichiers") + " PDF"; }],
    [/^file (\d+)$/, function (m) { return "fichier " + m[1]; }],
    [/^e\.g\. (.+)$/, function (m) { return "ex." + NB + ": " + m[1]; }],
    [/^Page (\d+) \/ (\d+)$/, function (m) { return "Page " + m[1] + " / " + m[2]; }],
    [/^Page (\d+)$/, function (m) { return "Page " + m[1]; }],   // the name of a page tile for the keyboard
    [/^Page (\d+) of (\d+)$/, function (m) { return "Page " + m[1] + " sur " + m[2]; }],

    /* buttons */
    [/^Remove (\d+) pages?$/, function (m) { return "Supprimer " + count(m[1], "page"); }],
    [/^Extract (\d+) files \(ZIP\)$/, function (m) { return "Extraire " + m[1] + " fichiers (ZIP)"; }],
    [/^Extract (\d+) pages?$/, function (m) { return "Extraire " + count(m[1], "page"); }],
    [/^Convert to (JPG|PNG|WebP|TIFF)$/, function (m) { return "Convertir en " + m[1]; }],
    [/^Remove (.+)$/, function (m) { return "Retirer " + m[1]; }, "attr"],

    /* progress */
    [/^Page (\d+) \((\d+) of (\d+)\)$/, function (m) { return "Page " + m[1] + " (" + m[2] + " sur " + m[3] + ")"; }],
    [/^Reading page (\d+) of (\d+)$/, function (m) { return "Lecture de la page " + m[1] + " sur " + m[2]; }],
    [/^File (\d+) of (\d+)$/, function (m) { return "Fichier " + m[1] + " sur " + m[2]; }],
    [/^Slide (\d+) of (\d+)$/, function (m) { return "Diapositive " + m[1] + " sur " + m[2]; }],
    [/^(.+) \((\d+) of (\d+)\)$/, function (m) { return m[1] + " (" + m[2] + " sur " + m[3] + ")"; }],
    [/^(\d+) dpi, good size and quality\.$/, function (m) { return m[1] + NB + "ppp, bon compromis entre taille et qualité."; }],
    [/^(\d+) dpi, lossless, larger files\.$/, function (m) { return m[1] + NB + "ppp, sans perte, fichiers plus volumineux."; }],
    [/^(\d+) dpi, smallest files, good quality\.$/, function (m) { return m[1] + NB + "ppp, fichiers les plus légers, bonne qualité."; }],
    [/^(\d+) dpi, lossless, for printing and archives\.$/, function (m) { return m[1] + NB + "ppp, sans perte, pour l’impression et l’archivage."; }],

    /* messages with a file name, a page number or a detail */
    [/^(.+) is ready\. Click any text to edit it\.$/, function (m) { return m[1] + " est prêt. Cliquez sur un texte pour le modifier."; }],
    [/^(.+) is larger than 1 GB, which is too big for PDF Lab\.$/, function (m) { return m[1] + " dépasse 1 Go, ce qui est trop volumineux pour PDF Lab."; }],
    [/^(.+) could not be opened for preview\. It may be damaged\.$/, function (m) { return "Impossible d’afficher l’aperçu du fichier " + m[1] + ". Il est peut-être endommagé."; }],
    [/^Could not open (.+)$/, function (m) { return "Impossible d’ouvrir " + m[1]; }],
    [/^'(.*)' is not a picture PDF Lab can read\.$/, function (m) { return "«" + NB + m[1] + NB + "» n’est pas une image lisible par PDF Lab."; }],
    [/^'(.*)' is too large to convert\.$/, function (m) { return "«" + NB + m[1] + NB + "» est trop volumineux pour être converti."; }],
    [/^'(.*)' is a camera RAW file\. Export the photo as JPG or TIFF first, then add it\.$/, function (m) { return "«" + NB + m[1] + NB + "» est un fichier RAW d’appareil photo. Exportez d’abord la photo en JPG ou en TIFF, puis ajoutez-la."; }],
    [/^"(.*)" is not a valid page or range\.$/, function (m) { return "«" + NB + m[1] + NB + "» n’est pas une page ni une plage valide."; }],
    [/^"(.*)" is backwards\. Write it as (.+)\.$/, function (m) { return "«" + NB + m[1] + NB + "» est à l’envers. Écrivez plutôt " + m[2] + "."; }],
    [/^Page (\d+) is out of range\. The PDF has (\d+) pages\.$/, function (m) { return "La page " + m[1] + " n’existe pas. Le PDF compte " + count(m[2], "page") + "."; }],
    [/^Page (\d+) is too large to turn into an image\.$/, function (m) { return "La page " + m[1] + " est trop grande pour être convertie en image."; }],
    [/^Page (\d+) does not exist in this PDF\.$/, function (m) { return "La page " + m[1] + " n’existe pas dans ce PDF."; }],
    [/^'(.*)' does not look like a PDF file\.$/, function (m) { return "«" + NB + m[1] + NB + "» ne semble pas être un fichier PDF."; }],
    [/^'(.*)' is password protected\.$/, function (m) { return "«" + NB + m[1] + NB + "» est protégé par un mot de passe."; }],
    [/^'(.*)' is protected with AES encryption, which PDF Lab cannot open on this (Mac|computer)\.$/, function (m) {
      return "«" + NB + m[1] + NB + "» est protégé par un chiffrement AES" + NB + ": PDF Lab ne peut pas l’ouvrir sur " + here(m[2]) + ".";
    }],
    [/^'(.*)' could not be read\. It may be damaged\.$/, function (m) { return "«" + NB + m[1] + NB + "» est illisible. Le fichier est peut-être endommagé."; }],
    [/^'(.*)' has no pages\.$/, function (m) { return "«" + NB + m[1] + NB + "» ne contient aucune page."; }],
    [/^The Edit PDF engine could not be loaded on this (Mac|computer)\. \((.*)\)$/, function (m) {
      return "Le moteur de modification des PDF n’a pas pu être chargé sur " + here(m[1]) + ". (" + m[2] + ")";
    }],
    [/^No installed font with Arabic letters was found on this (Mac|computer)\.$/, function (m) {
      return "Aucune police installée contenant des lettres arabes n’a été trouvée sur " + here(m[1]) + ".";
    }],
    [/^This could not be processed \((.+)\)\.$/, function (m) { return "Le traitement a échoué (" + m[1] + ")."; }],
    [/^This text could not be laid out \((.+)\)\.$/, function (m) { return "Ce texte n’a pas pu être mis en page (" + m[1] + ")."; }],
    /* what a finished job did (the summary card) */
    [/^(\d+) files merged$/, function (m) { return m[1] + " fichiers fusionnés"; }],
    [/^(\d+) pages? removed$/, function (m) { return count(m[1], "page") + pl(m[1], " supprimée", " supprimées"); }],
    [/^(\d+) pages? extracted$/, function (m) { return count(m[1], "page") + pl(m[1], " extraite", " extraites"); }],
    [/^(\d+) pages extracted, one PDF each$/, function (m) { return m[1] + " pages extraites, un PDF par page"; }],
    [/^Split into (\d+) PDFs$/, function (m) { return "Divisé en " + m[1] + " PDF"; }],
    [/^(\d+) pages? saved in the new order$/, function (m) { return count(m[1], "page") + pl(m[1], " enregistrée", " enregistrées") + " dans le nouvel ordre"; }],
    [/^(\d+) files? rotated$/, function (m) { return count(m[1], "file") + pl(m[1], " pivoté", " pivotés"); }],
    [/^(\d+) pages? rotated$/, function (m) { return count(m[1], "page") + pl(m[1], " pivotée", " pivotées"); }],
    [/^(\d+) pages? rotated in (\d+) files$/, function (m) { return count(m[1], "page") + pl(m[1], " pivotée", " pivotées") + " dans " + count(m[2], "file"); }],
    [/^(\d+) pages? converted to (JPG|PNG|WebP|TIFF|Word|PowerPoint)$/, function (m) { return count(m[1], "page") + pl(m[1], " convertie", " converties") + " en " + m[2]; }],
    [/^(\d+) images? converted to PDF$/, function (m) { return count(m[1], "image") + pl(m[1], " convertie", " converties") + " en PDF"; }],
    [/^(\d+) Word files? converted to PDF$/, function (m) { return m[1] + pl(m[1], " fichier Word converti", " fichiers Word convertis") + " en PDF"; }],
    [/^(\d+) edits? applied$/, function (m) { return m[1] + pl(m[1], " modification appliquée", " modifications appliquées"); }],
    [/^Letters (.+) use a close font, everything else keeps the original\.$/, function (m) {
      var one = Array.from(m[1]).length === 1;
      return (one ? "La lettre " + m[1] + " utilise" : "Les lettres " + m[1] + " utilisent") + " une police similaire, tout le reste conserve la police d’origine.";
    }],
  ];

  /* Parts of the file names the app suggests when saving. */
  var names = {
    "merged": "fusion",
    "_edited": "_modifié",
    "_pages": "_pages",
    "_extracted": "_extrait",
    "_split": "_divisé",
    "_organized": "_organisé",
    "organized": "organisé",
    "_rotated": "_pivoté",
    "rotated_pdfs": "pdf_pivotés",
    "word_to_pdf": "word_en_pdf",
  };

  window.PDFLAB_FR = { exact: exact, patterns: patterns, names: names };
})();
