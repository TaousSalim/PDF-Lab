/* PDF Lab: updates, as the user sees them.
 *
 * The page never looks at the internet itself. It asks the app ("/api/update") what it found, and tells it when
 * the user accepts. Where the app does not update itself (the project folder, a test server), the answer is "off"
 * and nothing of this file ever shows.
 *
 *   a newer version exists   a bar under the top bar: "Install the update" or "Later" (hidden until the next start)
 *   the user accepts         a card over the whole window with the progress of the download. Then:
 *                            Windows: the app closes, the installer replaces it and opens it again;
 *                            Mac: the app swaps its files and restarts in place, and this page reloads itself.
 *   something fails          the bar comes back with "Try again"; the app keeps working as it is
 *   first start afterwards   one short message: "PDF Lab has been updated."
 */
import { $, el, esc, toast, palette } from "./core.js";

const BRAND = "#db6544";
const bar = $("#updateBar");
const LATER_KEY = "pdflab-update-later";   // the version the user answered "Later" to, for this window only

let S = { state: "off" };   // the last answer of the app
let confirming = false;     // the bar is asking "work that is not saved will be lost"
let drawn = "";             // what the bar shows now (redrawn only when this changes, so buttons keep the focus)
let veil = null;
let timer = 0;
let quiet = 0;              // answers in a row that did not come
let leaving = "";           // the version that was running when "installing" was first seen

const ask = (what) => fetch("/api/update", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ do: what }) })
  .then((r) => (r.ok ? r.json() : null)).catch(() => null);

const later = () => { try { return sessionStorage.getItem(LATER_KEY); } catch (e) { return null; } };
const lang = () => (window.PDFLabI18n ? window.PDFLabI18n.lang() : "en");

/** A conversion is running: the app must not close under it. (A finished one whose summary is still on screen
 *  does not count: its file is saved.) */
const working = () => [...document.querySelectorAll(".action.busy")].some((a) => !a.closest(".tool")?.querySelector(".job-done:not([hidden])"));
/** Files are open in a tool: closing the app loses what was done to them. */
const hasWork = () => !!document.querySelector("#toolHost:not([hidden]) .stage-work:not([hidden])");

function hideBar() {
  if (bar.hidden) return;
  bar.hidden = true;
  bar.innerHTML = "";
  drawn = "";
}

function showBar(key, text, note, buttons) {
  if (drawn === key) return;
  drawn = key;
  bar.innerHTML = `
    <svg class="up-ic" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 15V4"/><path d="M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19h14"/></svg>
    <div class="up-text" aria-live="polite"><strong>${esc(text)}</strong>${note ? `<span translate="no">${esc(note)}</span>` : ""}</div>
    <div class="up-btns"></div>`;
  const row = $(".up-btns", bar);
  buttons.forEach(([label, kind, act]) => {
    const b = el("button", `pill-btn small ${kind}`);
    b.type = "button";
    b.textContent = label;
    b.addEventListener("click", act);
    row.appendChild(b);
  });
  bar.hidden = false;
}

function showVeil() {
  if (!veil) {
    veil = el("div", "update-veil");
    veil.setAttribute("role", "dialog");
    veil.setAttribute("aria-modal", "true");
    veil.setAttribute("aria-label", "Updating PDF Lab");
    veil.style.setProperty("--tc", BRAND);
    veil.innerHTML = `
      <div class="job-card">
        <div class="job-title">Updating PDF Lab</div>
        <div class="job-bar"><span></span></div>
        <div class="job-row"><div class="job-pct">0%</div><div class="job-step" aria-live="polite"></div></div>
        <div class="up-hint">PDF Lab restarts by itself.</div>
      </div>`;
    document.body.appendChild(veil);
    $(".app").inert = true;          // nothing behind the card can be clicked or reached with the keyboard
    document.activeElement?.blur?.();
  }
  const installing = S.state === "installing";
  const pct = installing ? 100 : Math.max(0, Math.min(99, Math.floor((S.progress || 0) * 100)));
  $(".job-bar span", veil).style.width = pct + "%";
  const label = pct + "%", step = installing ? "Installing" : "Downloading";
  if ($(".job-pct", veil).textContent !== label) $(".job-pct", veil).textContent = label;
  if ($(".job-step", veil).textContent !== step) $(".job-step", veil).textContent = step;
}

function hideVeil() {
  if (!veil) return;
  veil.remove();
  veil = null;
  $(".app").inert = false;
}

function install() {
  if (working()) { toast("Wait until the current task is finished, then install the update.", ""); return; }
  if (hasWork() && !confirming) { confirming = true; draw(); return; }
  confirming = false;
  S = { ...S, state: "downloading", progress: 0 };
  draw();
  ask("install").then(take);
}

function notNow() {
  try { sessionStorage.setItem(LATER_KEY, S.version || "?"); } catch (e) { /* no storage: the bar hides until a reload */ }
  confirming = false;
  hideBar();
  drawn = "later";
}

function draw() {
  const st = S.state;
  if (st === "downloading" || st === "installing") { hideBar(); showVeil(); return; }
  hideVeil();
  if (st !== "available" && st !== "failed") { hideBar(); return; }
  if (later() === (S.version || "?") || drawn === "later") { hideBar(); drawn = "later"; return; }
  if (confirming) {
    showBar("confirm", "PDF Lab restarts to install the update. Work that is not saved will be lost.", "", [
      ["Install now", "primary", install],
      ["Cancel", "ghost", () => { confirming = false; draw(); }],
    ]);
  } else if (st === "failed") {
    showBar("failed-" + S.error, S.error === "start"
      ? "The update could not be started. Try again, or keep working: PDF Lab works as before."
      : "The update could not be downloaded. Check the internet connection, then try again.", "", [
      ["Try again", "primary", install],
      ["Later", "ghost", notNow],
    ]);
  } else {
    const note = (S.notes && (S.notes[lang()] || S.notes.en || S.notes.fr)) || "";
    showBar("available-" + S.version + "-" + note, "A new version of PDF Lab is ready.", note, [
      ["Install the update", "primary", install],
      ["Later", "ghost", notNow],
    ]);
  }
}

/** The installed version: a tooltip on the name of the app, and one quiet line at the foot of the home screen. */
function showVersion(version) {
  const text = "Version " + version;
  $(".brand-name").title = text;
  const home = $("#home");
  let line = $(".home-version", home);
  if (!line) {
    line = el("p", "home-version");
    home.appendChild(line);
  }
  if (line.textContent !== text) line.textContent = text;
}

function take(answer) {
  clearTimeout(timer);
  if (!answer) {
    // the app did not answer (it is restarting to install, or it is busy): keep what is shown and ask again
    if (++quiet <= (leaving ? 40 : 8)) timer = setTimeout(poll, leaving ? 1000 : 2000);
    else window.PDFLAB_UPDATING = false;       // it never came back: the window may close itself (app.js)
    return;
  }
  quiet = 0;
  if (leaving && answer.state !== "installing") {
    window.PDFLAB_UPDATING = false;
    // the app answers again after installing: with another version it is the new app, and this page is the old one
    if (answer.current && answer.current !== leaving) { location.reload(); return; }
    leaving = "";
  }
  if (answer.state === "installing" && !leaving) {
    leaving = answer.current || "?";
    window.PDFLAB_UPDATING = true;             // the app is about to go away for a moment: do not close the window
  }
  S = answer;
  if (S.state === "off") return;                      // this app does not update itself: nothing more to do
  if (S.current) showVersion(S.current);
  if (S.updated) {
    toast("PDF Lab has been updated.", "ok");
    ask("seen");
  }
  draw();
  const wait = { checking: 1000, downloading: 350, installing: 1000 }[S.state] || 30 * 60 * 1000;
  timer = setTimeout(poll, wait);
}

function poll() { ask("status").then(take); }

if (bar) {
  const p = palette(BRAND);
  bar.style.setProperty("--tc-fill", p.fill);
  window.addEventListener("pdflab:lang", draw);   // the note about what is new exists once per language
  poll();
}
