/* Word to PDF: the layout engine.
 *
 * A .docx is read by the vendored Word library (docx-preview), which gives a simple picture of the document:
 * paragraphs, tables, pictures. That library was made to show a document on screen, so this file does what a
 * printed document needs on top of it:
 *   - real pages: Chrome cuts the text into pages itself, with the page size and margins of each section;
 *   - headers, footers and page numbers on every page (drawn as a second layer by the server);
 *   - tab stops with their dotted leaders, list numbers with their hanging indent, Word's line spacing;
 *   - shapes and text boxes (word-shapes.js), fields, column breaks, "keep with next", repeated table headings;
 *   - the Office fonts Calibri and Cambria replaced by their free twins when the computer does not have them.
 *
 * The library file itself is not modified. Its reader is extended once (extendLibrary), the document it produced
 * is adjusted before drawing (prepare), and the drawn page is finished afterwards (the finish* functions).
 */
import { drawShapes } from "./word-shapes.js";

const W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const EMU = 12700;
const PX_PER_PT = 96 / 72;
// Private characters used as place holders inside the text while the library draws the document.
const M = { TAB: "\uE8A0", COL: "\uE8A1", OPEN: "\uE8A2", CLOSE: "\uE8A3", TOKEN_OPEN: "\uE8A4", TOKEN_CLOSE: "\uE8A5" };
const MARK_RE = /[\uE8A0-\uE8A3]/;

let cx = null;          // the conversion that is running: { reg, n, fonts, ... }
let extended = false;

/* ------------------------------------------------------------------ small helpers */
const xkid = (node, name) => {
  if (!node) return null;
  for (const c of node.children) if (c.localName === name) return c;
  return null;
};
const xattr = (node, name) => {
  if (!node) return null;
  for (const a of node.attributes) if (a.localName === name) return a.value;
  return null;
};
const xbool = (node) => {
  const v = xattr(node, "val");
  return !(v === "0" || v === "false" || v === "off");
};
const pt = (s) => (s == null ? 0 : parseFloat(s) || 0);     // "72.00pt" -> 72
const fmt = (n) => `${(+n).toFixed(2)}pt`;

/** Remember data for a model element: its drawn element is found again by a class name. */
function note(model, patch) {
  if (!model.$pl) {
    const id = ++cx.n;
    model.$pl = {};
    cx.reg.set(id, model.$pl);
    model.className = `${model.className ? model.className + " " : ""}plx-${id}`;
  }
  return Object.assign(model.$pl, patch);
}
function noted(domEl) {
  const m = /(?:^|\s)plx-(\d+)/.exec((domEl.getAttribute && domEl.getAttribute("class")) || "");
  return m ? cx.reg.get(+m[1]) || null : null;
}
function addClass(model, name) {
  model.className = `${model.className ? model.className + " " : ""}${name}`;
}

/* ------------------------------------------------------------------ fonts */
// Fonts the app carries: free twins with the same letter widths as the Office fonts, used when those are missing.
const TWINS = {
  "calibri": { family: "Carlito", files: { n400: "Carlito-Regular", n700: "Carlito-Bold", i400: "Carlito-Italic", i700: "Carlito-BoldItalic" } },
  "calibri light": { family: "Carlito", files: { n400: "Carlito-Regular", n700: "Carlito-Bold", i400: "Carlito-Italic", i700: "Carlito-BoldItalic" } },
  "cambria": { family: "Caladea", files: { n400: "Caladea-Regular", n700: "Caladea-Bold", i400: "Caladea-Italic", i700: "Caladea-BoldItalic" } },
  "cambria math": { family: "Caladea", files: { n400: "Caladea-Regular", n700: "Caladea-Bold", i400: "Caladea-Italic", i700: "Caladea-BoldItalic" } },
};
// Close relatives that are tried, in order, when a font is not on this computer.
const RELATIVES = {
  "arial": ["Liberation Sans", "Helvetica"], "helvetica": ["Arial", "Liberation Sans"], "helvetica neue": ["Helvetica", "Arial"],
  "times new roman": ["Liberation Serif", "Times"], "times": ["Times New Roman", "Liberation Serif"],
  "courier new": ["Liberation Mono", "Courier"], "courier": ["Courier New", "Liberation Mono"],
  "calibri": ["Carlito"], "calibri light": ["Calibri", "Carlito"], "cambria": ["Caladea"], "cambria math": ["Cambria", "Caladea"],
  "aptos": ["Aptos Narrow", "Segoe UI", "Helvetica Neue", "Arial", "Liberation Sans"], "aptos display": ["Aptos", "Segoe UI", "Helvetica Neue", "Arial"],
  "segoe ui": ["Helvetica Neue", "Arial"], "tahoma": ["Verdana", "DejaVu Sans"], "verdana": ["DejaVu Sans", "Tahoma"],
  "georgia": ["Gelasio", "DejaVu Serif"], "consolas": ["Menlo", "DejaVu Sans Mono", "Liberation Mono"],
  "arial narrow": ["Liberation Sans Narrow", "Arial"], "century gothic": ["Avenir", "Futura", "Arial"],
  "symbol": ["Arial"], "wingdings": ["Arial"], "wingdings 2": ["Arial"], "wingdings 3": ["Arial"], "webdings": ["Arial"],
};
const quoteFont = (name) => `"${String(name).replace(/["\\]/g, "")}"`;
function genericOf(name) {
  const fam = cx.fontKinds.get(name.toLowerCase());
  if (fam === "roman") return "serif";
  if (fam === "modern") return "monospace";
  if (fam === "swiss") return "sans-serif";
  if (/courier|mono|consol|menlo|typewriter/i.test(name)) return "monospace";
  if (/times|serif|georgia|garamond|cambria|book|roman|minion|palatino|baskerville|century school|didot|bodoni|constantia|caladea/i.test(name) && !/sans/i.test(name)) return "serif";
  return "sans-serif";
}
/** The CSS value that stands for a font of the document (a variable, filled in once all fonts are known). */
function fontVar(name) {
  let i = cx.fonts.get(name);
  if (i == null) { i = cx.fonts.size; cx.fonts.set(name, i); }
  return i;
}

const haveFont = (() => {
  let ctx2d = null;
  const cache = new Map();
  return (name) => {
    const key = name.toLowerCase();
    if (cache.has(key)) return cache.get(key);
    if (!ctx2d) ctx2d = document.createElement("canvas").getContext("2d");
    const probe = "mmmmmmmmmmlliWQ@#0123456789";
    const widths = ["monospace", "serif"].map((base) => {
      ctx2d.font = `72px ${base}`;
      const plain = ctx2d.measureText(probe).width;
      ctx2d.font = `72px ${quoteFont(name)}, ${base}`;
      return ctx2d.measureText(probe).width !== plain;
    });
    const yes = widths[0] || widths[1];
    cache.set(key, yes);
    return yes;
  };
})();

const twinData = new Map();    // file name -> data: URL (kept for the next conversions)
const twinFaces = new Set();   // font families already added to this page
async function twinUrl(file) {
  if (!twinData.has(file)) {
    const res = await fetch(`fonts/${file}.woff2`);
    if (!res.ok) throw new Error("font file missing");
    const bytes = new Uint8Array(await res.arrayBuffer());
    let bin = "";
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    twinData.set(file, `data:font/woff2;base64,${btoa(bin)}`);
  }
  return twinData.get(file);
}

/** Decide what each font of the document is drawn with, load the carried fonts that are needed.
 *  Returns the CSS for the printed page (font files inside) and the CSS for this page (variables only). */
async function settleFonts(theme) {
  const names = new Map(cx.fonts);               // name -> index
  let faces = "";
  const vars = [];
  const stackOf = async (name) => {
    const key = name.toLowerCase();
    const list = [quoteFont(name)];
    const twin = TWINS[key];
    if (twin && !haveFont(name) && !haveFont(twin.family)) {
      // the Office font is missing: its twin takes its name, so every width stays the same
      try {
        for (const [slot, file] of Object.entries(twin.files)) {
          const url = await twinUrl(file);
          const desc = { style: slot[0] === "i" ? "italic" : "normal", weight: slot.slice(1) };
          faces += `@font-face { font-family: ${quoteFont(name)}; font-style: ${desc.style}; font-weight: ${desc.weight}; src: url(${url}) format("woff2"); }\n`;
          const id = `${key}|${slot}`;
          if (!twinFaces.has(id)) {
            const face = new FontFace(name, `url(${url}) format("woff2")`, desc);
            await face.load();
            document.fonts.add(face);
            twinFaces.add(id);
          }
        }
      } catch (e) {
        console.warn("a carried font could not be loaded:", e && e.message);
      }
    }
    for (const r of RELATIVES[key] || []) list.push(quoteFont(r));
    list.push(genericOf(name));
    return list.join(", ");
  };
  const stacks = new Map();
  for (const [name, i] of names) {
    const stack = await stackOf(name);
    stacks.set(name, stack);
    vars.push(`--pl-f${i}: ${stack};`);
  }
  const themeStack = async (name) => (name ? stacks.get(name) || (await stackOf(name)) : "sans-serif");
  const major = await themeStack(theme.major), minor = await themeStack(theme.minor);
  vars.push(`--pl-major: ${major};`, `--pl-minor: ${minor};`);
  try { await document.fonts.ready; } catch (e) { /* keep going */ }

  // Word's "single" line spacing is the font's own line height, which differs from font to font.
  const probe = document.createElement("span");
  probe.textContent = "Hxg";
  probe.style.cssText = "position:absolute;visibility:hidden;white-space:nowrap;font-size:200px;line-height:normal;padding:0;border:0;display:inline-block;";
  cx.holder.appendChild(probe);
  const ratio = (stack) => {
    probe.style.fontFamily = stack;
    const r = probe.getBoundingClientRect().height / 200;
    return r > 0.8 && r < 2.5 ? +r.toFixed(4) : 1.2;
  };
  for (const [name, i] of names) vars.push(`--fr-f${i}: ${ratio(stacks.get(name))};`);
  vars.push(`--fr-major: ${ratio(major)};`, `--fr-minor: ${ratio(minor)};`);
  probe.remove();
  return { faces, vars: `.docx { ${vars.join(" ")} }\n` };
}

/* ------------------------------------------------------------------ the library's reader, extended once */
function wrap(proto, name, make) {
  const orig = proto[name];
  if (typeof orig !== "function") throw new Error(`Word library: ${name} is missing`);
  proto[name] = make(orig);
}

/** <w:fldSimple> (a field written in the short way) is rewritten in the long way, which the rest understands. */
function simpleFieldsToComplex(par) {
  const fields = Array.from(par.getElementsByTagNameNS(W, "fldSimple"));
  for (const f of fields) {
    const d = f.ownerDocument;
    const firstRun = Array.from(f.children).find((c) => c.localName === "r");
    const rPr = xkid(firstRun, "rPr");
    const run = (inner) => {
      const r = d.createElementNS(W, "w:r");
      if (rPr) r.appendChild(rPr.cloneNode(true));
      r.appendChild(inner);
      return r;
    };
    const fc = (t) => { const e = d.createElementNS(W, "w:fldChar"); e.setAttributeNS(W, "w:fldCharType", t); return e; };
    const instr = d.createElementNS(W, "w:instrText");
    instr.textContent = xattr(f, "instr") || "";
    f.replaceWith(run(fc("begin")), run(instr), run(fc("separate")), ...Array.from(f.childNodes), run(fc("end")));
  }
  // Form fields: a check box is drawn as a box (ticked or not), a drop-down list shows the chosen entry.
  for (const data of Array.from(par.getElementsByTagNameNS(W, "ffData"))) {
    const host = data.parentNode && data.parentNode.parentNode;       // the run that opens the field
    if (!host || host.localName !== "r" || !host.parentNode) continue;
    const box = xkid(data, "checkBox"), list = xkid(data, "ddList");
    let text = null;
    if (box) {
      const on = xkid(box, "checked") ? xbool(xkid(box, "checked")) : (xkid(box, "default") ? xbool(xkid(box, "default")) : false);
      text = on ? "\u2612" : "\u2610";
    } else if (list) {
      const entries = Array.from(list.children).filter((c) => c.localName === "listEntry");
      const pick = parseInt(xattr(xkid(list, "result"), "val") || xattr(xkid(list, "default"), "val") || "0", 10) || 0;
      if (entries.length) text = xattr(entries[Math.min(pick, entries.length - 1)], "val") || "";
    }
    if (text == null) continue;
    const d = host.ownerDocument;
    const r = d.createElementNS(W, "w:r");
    const rPr = xkid(host, "rPr");
    if (rPr) r.appendChild(rPr.cloneNode(true));
    const t = d.createElementNS(W, "w:t");
    t.textContent = text;
    r.appendChild(t);
    host.parentNode.insertBefore(r, host);
    data.remove();
  }
}

/** Wrappers the library does not look into are removed, their content stays: content controls (w:sdt), custom XML,
 *  moved text. Text moved away and phonetic guides are dropped, the base text of a guide is kept. */
function tidyXml(root) {
  const all = (name) => Array.from(root.getElementsByTagNameNS(W, name));
  for (const sdt of all("sdt")) {
    const content = xkid(sdt, "sdtContent");
    if (sdt.parentNode) sdt.replaceWith(...(content ? Array.from(content.childNodes) : []));
  }
  for (const name of ["customXml", "moveTo"]) for (const el of all(name)) {
    if (el.parentNode) el.replaceWith(...Array.from(el.childNodes).filter((c) => c.nodeType !== 1 || !/Pr$/.test(c.localName)));
  }
  for (const el of all("moveFrom")) el.remove();
  for (const ruby of all("ruby")) {
    const run = ruby.parentNode;
    const base = xkid(ruby, "rubyBase");
    if (run && run.localName === "r" && run.parentNode) run.replaceWith(...(base ? Array.from(base.childNodes) : []));
  }
}

/** A shape or a group of shapes, as an element the library draws as an empty box (the art is added afterwards). */
function shapeModel(parser, g) {
  const model = { type: "drawing", children: [], cssStyle: {} };
  switch (g.localName) {
    case "wsp": case "sp": {
      const content = xkid(xkid(g, "txbx"), "txbxContent");
      if (content) model.children = parser.parseBodyElements(content);
      note(model, { kind: "shape", xml: g });
      break;
    }
    case "wgp": case "grpSp": case "wpc": {
      for (const c of g.children) {
        if (c.localName === "wsp" || c.localName === "grpSp" || c.localName === "sp") model.children.push(shapeModel(parser, c));
        else if (c.localName === "pic") {
          const pic = parser.parsePicture(c);
          delete pic.cssStyle.left; delete pic.cssStyle.top;
          note(pic, { kind: "picture", xml: c });
          addClass(pic, "pl-shape-pic");
          model.children.push(pic);
        }
      }
      note(model, { kind: "group", xml: g });
      break;
    }
    default: return null;
  }
  addClass(model, "pl-shape");
  return model;
}

async function extendLibrary() {
  if (extended) return;
  const lib = window.docx;
  if (!lib || !window.JSZip) throw new Error("The Word reader did not load.");
  // The reader is created inside the library: a tiny empty document gives a way to reach it.
  const zip = new window.JSZip();
  zip.file("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
  zip.file("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  zip.file("word/document.xml", `<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="${W}"><w:body><w:p/></w:body></w:document>`);
  const probe = await lib.parseAsync(await zip.generateAsync({ type: "arraybuffer" }), {});
  const proto = probe && probe._parser && Object.getPrototypeOf(probe._parser);
  if (!proto) throw new Error("Word library: reader not found");

  // Properties the library skips or gets wrong.
  wrap(proto, "parseDefaultProperties", (orig) => function (elem, style = null, childStyle = null, handler = null) {
    style = style || {};
    const out = orig.call(this, elem, style, childStyle, handler);
    if (!cx) return out;
    const where = elem.localName;
    for (const c of elem.children) {
      if (c.namespaceURI !== W) continue;
      switch (c.localName) {
        case "keepNext": style["break-after"] = xbool(c) ? "avoid" : "auto"; break;
        case "keepLines": style["break-inside"] = xbool(c) ? "avoid" : "auto"; break;
        case "cantSplit": style["break-inside"] = xbool(c) ? "avoid" : "auto"; break;
        case "contextualSpacing": style.$ctx = xbool(c); break;
        case "noWrap": if (where === "tcPr" && xbool(c)) style["white-space"] = "nowrap"; break;
        case "dstrike": if (xbool(c)) style["text-decoration"] = "line-through double"; break;
        case "spacing":
          if (where === "rPr") {
            const v = parseInt(xattr(c, "val"), 10);
            if (v) style["letter-spacing"] = fmt(v / 20);
          } else if (where === "pPr") {
            // Line spacing. Without a rule the value is a multiple of the font's own line height ("auto").
            const line = parseInt(xattr(c, "line"), 10);
            if (!isNaN(line)) {
              const rule = xattr(c, "lineRule") || "auto";
              delete style["line-height"];
              if (style["min-height"] === `${line / 20}pt`) delete style["min-height"];
              if (rule === "auto") { style["--lh"] = +(line / 240).toFixed(3); style["--lhx"] = "initial"; }
              else if (rule === "atLeast") style["--lhx"] = `max(${line / 20}pt, calc(1em * var(--fr, 1.2)))`;
              else style["--lhx"] = `${line / 20}pt`;
            }
            if (xattr(c, "beforeAutospacing") === "1") style["margin-top"] = "14pt";
            if (xattr(c, "afterAutospacing") === "1") style["margin-bottom"] = "14pt";
          }
          break;
        case "rFonts": {
          const theme = xattr(c, "asciiTheme") || xattr(c, "hAnsiTheme");
          const name = xattr(c, "ascii") || xattr(c, "hAnsi");
          if (theme) {
            const kind = theme.startsWith("major") ? "major" : "minor";
            style["font-family"] = `var(--pl-${kind})`;
            style["--fr"] = `var(--fr-${kind})`;
          } else if (name) {
            const i = fontVar(name);
            style["font-family"] = `var(--pl-f${i})`;
            style["--fr"] = `var(--fr-f${i})`;
          } else delete style["font-family"];   // only an East Asian or right-to-left font is named: Latin text keeps its font
          break;
        }
        default: break;
      }
    }
    return out;
  });

  wrap(proto, "parseBodyElements", (orig) => function (element) {
    if (cx && element) tidyXml(element);
    return orig.call(this, element);
  });

  // One element the library cannot read must not cost the whole document: it is left out, the rest is kept.
  const guarded = (name, empty) => wrap(proto, name, (orig) => function (...args) {
    try { return orig.apply(this, args); } catch (e) {
      console.warn(`Word reader: one ${name.replace("parse", "").toLowerCase()} was skipped (${e && e.message})`);
      return empty();
    }
  });
  guarded("parsePicture", () => null);
  guarded("parseTable", () => ({ type: "table", children: [] }));
  guarded("parseRun", () => ({ type: "run", children: [] }));
  guarded("parseDrawing", () => null);
  guarded("parseVmlPicture", () => ({ type: "vmlPicture", children: [] }));

  wrap(proto, "parseParagraph", (orig) => function (node) {
    if (cx) simpleFieldsToComplex(node);
    let p;
    try { p = orig.call(this, node); } catch (e) {
      console.warn(`Word reader: one paragraph was skipped (${e && e.message})`);
      return { type: "paragraph", children: [] };
    }
    if (cx) {
      const rPr = xkid(xkid(node, "pPr"), "rPr");
      if (rPr) p.$mark = this.parseDefaultProperties(rPr, {});   // the look of the paragraph mark: the height of an empty line
    }
    return p;
  });

  // <w:tblHeader/> without a value means "yes" (the library reads it as "no"): the row is a heading row.
  wrap(proto, "parseTableRow", (orig) => function (node) {
    const row = orig.call(this, node);
    const th = xkid(xkid(node, "trPr"), "tblHeader");
    if (row && th && xbool(th)) row.isHeader = true;
    return row;
  });

  // Word writes a shape twice: the modern drawing, and an old-style copy for old programs. The modern one is used.
  wrap(proto, "checkAlternateContent", (orig) => function (elem) {
    if (cx && elem.localName === "AlternateContent") {
      const first = xkid(elem, "Choice")?.firstElementChild;
      if (first && first.localName === "drawing") return first;
    }
    return orig.call(this, elem);
  });

  wrap(proto, "parseGraphic", (orig) => function (elem) {
    const pic = orig.call(this, elem);
    if (pic || !cx) return pic;
    const g = xkid(elem, "graphicData")?.firstElementChild;
    return g ? shapeModel(this, g) : null;
  });

  wrap(proto, "parseDrawingWrapper", (orig) => function (node) {
    const r = orig.call(this, node);
    if (!cx || !r) return r;
    const ext = xkid(node, "extent");
    const w = (+xattr(ext, "cx") || 0) / EMU, h = (+xattr(ext, "cy") || 0) / EMU;
    for (const c of r.children) if (c.$pl) { c.$pl.w = w; c.$pl.h = h; }
    if (node.localName === "anchor") {
      // a position or a size can be wrapped in a "new way / old way" pair: the old way (plain numbers) is read
      const deep = (name) => {
        const direct = xkid(node, name);
        if (direct) return direct;
        for (const c of node.children) {
          if (c.localName !== "AlternateContent") continue;
          const hit = xkid(xkid(c, "Fallback"), name) || xkid(xkid(c, "Choice"), name);
          if (hit) return hit;
        }
        return null;
      };
      const rel = (name, part) => {
        const n = deep(name);
        const pct = n ? parseFloat(xkid(n, part)?.textContent) : NaN;
        return n && pct > 0 ? { rel: xattr(n, "relativeFrom") || "margin", pct: pct / 100000 } : null;
      };
      const pos = (name) => {
        const n = deep(name);
        if (!n) return null;
        const align = xkid(n, "align"), off = xkid(n, "posOffset");
        return { rel: xattr(n, "relativeFrom") || "column", align: align ? align.textContent.trim() : null, off: off ? (parseFloat(off.textContent) || 0) / EMU : 0 };
      };
      const wrapKind = ["wrapNone", "wrapSquare", "wrapTight", "wrapThrough", "wrapTopAndBottom"].find((n) => xkid(node, n)) || "wrapNone";
      const dist = (n) => (+xattr(node, n) || 0) / EMU;
      note(r, { kind: "anchor", ph: pos("positionH"), pv: pos("positionV"), wrap: wrapKind, behind: xattr(node, "behindDoc") === "1",
        w, h, relW: rel("sizeRelH", "pctWidth"), relH: rel("sizeRelV", "pctHeight"),
        dist: [dist("distT"), dist("distR"), dist("distB"), dist("distL")] });
      addClass(r, "pl-anchor");
    }
    return r;
  });

  extended = true;
}

/* ------------------------------------------------------------------ the document, adjusted before drawing */
const FONT_KEYS = ["font-family", "--fr", "font-size", "font-weight", "font-style", "color"];
const fieldMark = (kind, text = "") => `${M.OPEN}${kind}${text}${M.CLOSE}`;

function prepare(doc) {
  if (doc.stylesPart?.styles) {
    // a style without an identifier cannot be used by anything, and the library would apply it to every paragraph
    doc.stylesPart.styles = doc.stylesPart.styles.filter((s) => s.id != null || s.name == null);
  }
  const styles = doc.stylesPart?.styles || [];
  const byId = new Map(styles.filter((s) => s.id != null).map((s) => [s.id, s]));
  const defaultP = styles.find((s) => s.isDefault && s.target === "p")?.id ?? null;
  const defaultTable = styles.find((s) => s.isDefault && s.target === "table")?.id ?? null;
  for (const s of styles) {
    // The library writes a broken rule for default styles: every element gets its style by name instead.
    s.isDefault = false;
    if (s.target === "p" || s.target == null) {
      // The font of a paragraph style also goes on the paragraph itself: list numbers are drawn with it.
      const span = s.styles.find((x) => x.target === "span");
      if (span) {
        let par = s.styles.find((x) => x.target === "p");
        if (!par) { par = { target: "p", values: {} }; s.styles.push(par); }
        for (const k of FONT_KEYS) if (span.values[k] != null && par.values[k] == null) par.values[k] = span.values[k];
      }
    }
  }
  const chain = (id) => {
    const out = [];
    for (let s = byId.get(id), guard = 0; s && guard < 30; s = byId.get(s.basedOn), guard++) out.push(s);
    return out;
  };
  const styleCtx = (id) => {
    for (const s of chain(id)) {
      const v = s.styles.find((x) => x.target === "p")?.values?.$ctx;
      if (v != null) return v;
    }
    return false;
  };
  const tabsOf = (par) => {
    const map = new Map();
    const lists = chain(par.styleName).reverse().map((s) => s.paragraphProps?.tabs).concat([par.tabs]);
    for (const list of lists) for (const t of list || []) {
      const pos = pt(t.position);
      if (t.style === "clear") map.delete(pos.toFixed(1));
      else map.set(pos.toFixed(1), { pos, style: t.style || "left", leader: t.leader || "none" });
    }
    return Array.from(map.values()).sort((a, b) => a.pos - b.pos);
  };

  const runChildren = (run, state) => {
    const out = [];
    for (const c of run.children || []) {
      switch (c.type) {
        case "tab": state.tabs = true; out.push({ type: "text", text: M.TAB }); break;
        case "break":
          if (c.break === "lastRenderedPageBreak") break;              // Word's own page cut of its last session: not ours
          if (c.break === "column") out.push({ type: "text", text: M.COL });
          else out.push(c);
          break;
        case "complexField":
          out.push({ type: "text", text: fieldMark(c.charType === "begin" ? "b" : c.charType === "separate" ? "s" : "e") });
          break;
        case "instruction": out.push({ type: "text", text: fieldMark("i", c.text || "") }); break;
        default: out.push(c); break;
      }
    }
    run.children = out;
    run.fieldRun = false;      // the library drops field runs; they are kept as place holders
  };
  const inline = (list, state) => {
    for (const c of list || []) {
      if (c.type === "run" || c.type === "mmlRun") runChildren(c, state);
      if (c.type !== "run" && c.children) {
        if (c.type === "drawing" || c.type === "vmlPicture" || c.type === "vmlElement") blocks(c.children);
        else inline(c.children, state);
      } else if (c.type === "run") for (const d of c.children) if (d.children) blocks([d]);
    }
  };
  const paragraph = (par) => {
    if (!par.styleName && defaultP != null) par.styleName = defaultP;
    const state = { tabs: false };
    inline(par.children, state);
    const ctx = par.cssStyle?.$ctx ?? styleCtx(par.styleName);
    if (ctx) addClass(par, "pl-ctx");
    if (par.numbering) addClass(par, "pl-numd");      // the list is set on the paragraph itself
    if (state.tabs) note(par, { tabs: tabsOf(par) });
    if (par.$mark) note(par, { mark: par.$mark });
  };
  const blocks = (list) => {
    for (const el of list || []) {
      switch (el.type) {
        case "paragraph": paragraph(el); break;
        case "table": {
          if (!el.styleName && defaultTable != null) el.styleName = defaultTable;
          // Word marks first row, last row, banded rows and so on in each row and cell. Files made by other
          // programs often leave the marks out: they are worked out from the table's own settings.
          const look = ` ${el.className || ""} `;
          const rows = el.children || [];
          const marked = rows.some((r) => r.className || (r.children || []).some((c) => c.className));
          const firstRow = look.includes(" first-row "), lastRow = look.includes(" last-row ");
          let band = 0;
          rows.forEach((row, ri) => {
            if (row.isHeader) addClass(row, "pl-th");
            if (!marked) {
              if (firstRow && ri === 0) addClass(row, "first-row");
              else if (lastRow && ri === rows.length - 1 && rows.length > 1) addClass(row, "last-row");
              else if (!look.includes(" no-hband ")) { addClass(row, Math.floor(band / (el.rowBandSize || 1)) % 2 === 0 ? "odd-row" : "even-row"); band++; }
              const cells = row.children || [];
              let cband = 0;
              cells.forEach((cell, ci) => {
                if (look.includes(" first-col ") && ci === 0) addClass(cell, "first-col");
                else if (look.includes(" last-col ") && ci === cells.length - 1 && cells.length > 1) addClass(cell, "last-col");
                else if (!look.includes(" no-vband ")) { addClass(cell, Math.floor(cband / (el.colBandSize || 1)) % 2 === 0 ? "odd-col" : "even-col"); cband++; }
              });
            }
            for (const cell of row.children || []) blocks(cell.children);
          });
          break;
        }
        case "drawing": case "vmlPicture": case "vmlElement": blocks(el.children); break;
        default: if (el.children) blocks(el.children); break;
      }
    }
  };

  const body = doc.documentPart.body;
  blocks(body.children);
  for (const part of doc.parts || []) {
    if (part.rootElement?.children) blocks(part.rootElement.children);     // headers and footers
    if (Array.isArray(part.notes)) for (const nt of part.notes) blocks(nt.children);
  }

  // Sections. Each one starts with a hidden place holder, so its place in the drawn page is known, and a section
  // that must start on a new page gets a page break before it (the library cuts pages at every section otherwise).
  const sections = [];
  const out = [];
  const opener = (i, brk) => {
    const p = { type: "paragraph", children: [], cssStyle: { display: "none" }, className: "pl-sect" };
    note(p, { kind: "section", index: i });
    if (brk) p.pageBreakBefore = true;
    return p;
  };
  let pending = [];
  for (const el of body.children) {
    pending.push(el);
    if (el.type === "paragraph" && el.sectionProps) { sections.push({ props: el.sectionProps, elements: pending }); pending = []; }
  }
  sections.push({ props: body.props || {}, elements: pending });
  sections.forEach((s, i) => {
    const type = s.props.type || "nextPage";
    out.push(opener(i, i > 0 && type !== "continuous"), ...s.elements);
  });
  body.children = out;

  // Headers and footers are inherited from the section before when a section does not name its own.
  let last = { header: {}, footer: {} };
  for (const s of sections) {
    const refs = { header: { ...last.header }, footer: { ...last.footer } };
    for (const r of s.props.headerRefs || []) refs.header[r.type || "default"] = r.id;
    for (const r of s.props.footerRefs || []) refs.footer[r.type || "default"] = r.id;
    s.refs = refs;
    last = refs;
  }
  return sections;
}

/* ------------------------------------------------------------------ drawing with the library */
function makeH(base) {
  let guardedRenderer = false;
  // The library sets styles one by one on the element, which silently drops custom properties ("--lh").
  return function (spec) {
    if (!guardedRenderer && this && typeof this.renderElement === "function") {
      // the first call gives the library's drawing object: one element it cannot draw is left out, not the document
      guardedRenderer = true;
      const proto = Object.getPrototypeOf(this);
      if (!proto.$plGuard) {
        const orig = proto.renderElement;
        proto.renderElement = function (elem) {
          try { return orig.call(this, elem); } catch (e) {
            console.warn(`Word reader: one element could not be drawn (${e && e.message})`);
            return null;
          }
        };
        proto.$plGuard = true;
      }
    }
    if (spec && typeof spec === "object" && !(spec instanceof Node) && spec.style && typeof spec.style === "object") {
      let custom = null;
      const style = {};
      for (const k in spec.style) {
        if (k.startsWith("--")) (custom || (custom = {}))[k] = spec.style[k];
        else if (!k.startsWith("$")) style[k] = spec.style[k];
      }
      const node = base({ ...spec, style });
      if (custom) for (const k in custom) node.style.setProperty(k, String(custom[k]));
      return node;
    }
    return base(spec);
  };
}

// Word's order of strength is: document defaults, table style, list level, paragraph style, character style, then
// what is set on the text itself. CSS layers give exactly that order, whatever the selectors look like.
const LAYERS = "@layer pl-base, pl-defaults, pl-table, pl-num, pl-para, pl-numd, pl-char;\n";
const DEFAULTS_CSS = `
.pl-root { all: initial; display: block; }
.docx p, .docx span { font-family: "Times New Roman", "Liberation Serif", Times, serif; font-size: 10pt; --fr: 1.15; }
`;
const BASE_CSS = `
.docx { hyphens: manual; }
.docx p { line-height: 0; min-height: 0; orphans: 2; widows: 2; }
.docx p span { line-height: var(--lhx, calc(var(--lh, 1) * var(--fr, 1.2))); }
.docx sub, .docx sup { line-height: 0; }
.docx p[class*="docx-num-"]::before { display: inline-block; box-sizing: border-box; min-width: var(--hang, 0px); padding-right: .3em; text-indent: 0; white-space: nowrap; }
.docx .pl-tab { display: inline-block; white-space: nowrap; text-indent: 0; text-align: right; vertical-align: baseline; overflow: visible; }
.docx .pl-shape { text-align: left; }
.docx .pl-shape-art { position: absolute; left: 0; top: 0; overflow: visible; }
.docx .pl-shape-text > p:last-child { margin-bottom: 0; }
.docx .pl-shape-text > p:first-child { margin-top: 0; }
.docx thead { display: table-header-group; }
.docx img { break-inside: avoid; }
section.docx.pl-group { display: block; overflow: visible; min-height: 0; padding-top: 0; padding-bottom: 0; margin: 0; position: relative; box-sizing: content-box; box-shadow: none; background: none; }
section.docx.pl-group > article { margin-bottom: 0; position: relative; }
section.docx.pl-group > ol { margin-top: 12pt; padding-left: 18pt; border-top: 0.5pt solid #000; padding-top: 4pt; }
a.pl-gm { position: absolute; left: 0; top: 0; width: 2pt; height: 2pt; }
section.docx.pl-over { margin: 0; box-shadow: none; background: none; overflow: hidden; position: relative; }
section.docx.pl-over > article { flex: 1 1 auto; }
`;

/** The rules of the document's styles, written in Word's order of strength.
 *  A paragraph style reaches the text of its own paragraph only, not the text of a text box that stands in it,
 *  and a table style stops at a table or a text box inside the table (CSS "scope" does that). */
function styleCss(doc) {
  const styles = doc.stylesPart?.styles || [];
  const byId = new Map(styles.filter((st) => st.id != null).map((st) => [st.id, st]));
  const scoped = typeof CSSScopeRule !== "undefined";
  const body = (values) => {
    let out = "";
    for (const k in values) if (!k.startsWith("$") && values[k] != null) out += `  ${k}: ${values[k]};\n`;
    return out;
  };
  const layers = { "pl-defaults": "", "pl-table": "", "pl-para": "", "pl-char": "" };
  for (const st of styles) {
    if (!st.cssName) continue;
    let subs = st.styles || [];
    const linked = st.linked && byId.get(st.linked);
    if (linked) subs = subs.concat(linked.styles || []);
    const cls = `.${CSS.escape(st.cssName)}`;
    for (const sub of subs) {
      const decl = body(sub.values);
      if (!decl) continue;
      if (st.target == null) {
        if (sub.target === "p" || sub.target === "span") layers["pl-defaults"] += `.docx ${sub.target} {\n${decl}}\n`;
      } else if (st.target === "p") {
        if (sub.target === "p") layers["pl-para"] += `p${cls} {\n${decl}}\n`;
        else if (sub.target === "span") layers["pl-para"] += scoped ? `@scope (p${cls}) to (p) { span {\n${decl}} }\n` : `p${cls} span {\n${decl}}\n`;
      } else if (st.target === "span") {
        if (sub.target === "span") layers["pl-char"] += `span${cls} {\n${decl}}\n`;
      } else if (st.target === "table") {
        if (sub.target === "table") layers["pl-table"] += `table${cls} {\n${decl}}\n`;
        else layers["pl-table"] += scoped ? `@scope (table${cls}) to (table, .pl-shape-text) { ${sub.target} {\n${decl}} }\n` : `table${cls} ${sub.target} {\n${decl}}\n`;
      }
    }
  }
  return Object.entries(layers).map(([name, css]) => `@layer ${name} {\n${css}}\n`).join("");
}

// Word draws some bullets and symbols with the Symbol and Wingdings fonts, whose letters sit in a private area that
// no ordinary font can draw. They are swapped for the same signs in ordinary fonts.
const SYMBOLS = { "\uf0b7": "\u2022", "\uf0a7": "\u25AA", "\uf0d8": "\u27A2", "\uf0fc": "\u2713", "\uf0fb": "\u2717", "\uf076": "\u2756",
  "\uf06c": "\u25CF", "\uf06e": "\u25A0", "\uf0a8": "\u25FB", "\uf0fe": "\u2612", "\uf0e0": "\u2192", "\uf0df": "\u2190", "\uf0e8": "\u2794",
  "\uf0ae": "\u2192", "\uf0de": "\u21D2", "\uf0b0": "\u00B0", "\uf0b1": "\u00B1", "\uf0a3": "\u2264", "\uf0b3": "\u2265", "\uf0b4": "\u00D7",
  "\uf0b9": "\u2260", "\uf0a5": "\u221E", "\uf02d": "\u2013", "\uf071": "\u2751", "\uf0a2": "\u25CB", "\uf06f": "\u25A1", "\uf0d7": "\u00B7" };
const fixSymbols = (text) => text.replace(/[\uf020-\uf0ff]/g, (c) => SYMBOLS[c] || "\u2022");
function fixSymbolCss(css) {
  return fixSymbols(css).replace(/content:\s*"\\(f0[0-9a-f]{2})\s?/gi, (all, hex) => `content: "${SYMBOLS[String.fromCharCode(parseInt(hex, 16))] || "\u2022"}`);
}

/* ------------------------------------------------------------------ the drawn page, finished */

/** Replace the place holders left in the text: fields, tabs, column breaks. inMargin: inside a header or footer. */
function finishMarks(root, inMargin) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const texts = [];
  for (let n = walker.nextNode(); n; n = walker.nextNode()) if (MARK_RE.test(n.data)) texts.push(n);
  // 1. split the text so that every place holder is alone in its node, in document order
  const pieces = [];
  for (const node of texts) {
    const parts = node.data.split(/(\uE8A0|\uE8A1|\uE8A2[^\uE8A3]*\uE8A3)/).filter((s) => s !== "");
    const made = parts.map((s) => document.createTextNode(s));
    node.replaceWith(...made);
    for (const m of made) if (MARK_RE.test(m.data)) pieces.push(m);
  }
  // 2. fields
  const stack = [];
  for (const node of pieces) {
    const ch = node.data[0];
    if (ch === M.TAB) {
      const span = document.createElement("span");
      span.className = "pl-tab";
      node.replaceWith(span);
      continue;
    }
    if (ch === M.COL) {
      const span = document.createElement("span");
      span.className = "pl-colbreak";
      node.replaceWith(span);
      continue;
    }
    const kind = node.data[1], text = node.data.slice(2, -1);
    if (kind === "b") { stack.push({ instr: "", sep: null, begin: node }); node.data = ""; continue; }
    const f = stack[stack.length - 1];
    if (!f) { node.data = ""; continue; }
    if (kind === "i") { f.instr += text; if (!f.at) f.at = node; node.data = ""; continue; }
    if (kind === "s") { f.sep = node; node.data = ""; continue; }
    // end of the field
    stack.pop();
    node.data = "";
    const name = (/^\s*([A-Za-z]+)/.exec(f.instr) || [])[1]?.toUpperCase() || "";
    if (inMargin && (name === "PAGE" || name === "NUMPAGES" || name === "SECTIONPAGES")) {
      // The number is only known once the pages exist: the server writes it. What Word had saved is removed.
      const format = (/\\\*\s*(\w+)/.exec(f.instr) || [])[1] || "";
      const token = `${M.TOKEN_OPEN}${name}|${format}${M.TOKEN_CLOSE}`;
      if (f.sep) {
        const range = document.createRange();
        range.setStartAfter(f.sep);
        range.setEndBefore(node);
        const old = [];
        const w2 = document.createTreeWalker(range.commonAncestorContainer, NodeFilter.SHOW_TEXT);
        for (let t = w2.nextNode(); t; t = w2.nextNode()) if (range.intersectsNode(t) && t !== f.sep && t !== node) old.push(t);
        for (const t of old) t.data = "";
        f.sep.data = token;
      } else (f.at || f.begin).data = token;
    }
  }
  // 3. the Symbol and Wingdings signs
  const w3 = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let n = w3.nextNode(); n; n = w3.nextNode()) if (/[\uf020-\uf0ff]/.test(n.data)) n.data = fixSymbols(n.data);
}

/** A column break in the middle of a paragraph: the paragraph is cut in two, the second half starts the next column. */
function finishColumnBreaks(root) {
  for (const mark of Array.from(root.querySelectorAll(".pl-colbreak"))) {
    const p = mark.closest("p");
    if (!p) { mark.remove(); continue; }
    const range = document.createRange();
    range.setStartBefore(mark);
    range.setEndAfter(p.lastChild);
    const hasBefore = (() => { const r = document.createRange(); r.setStartBefore(p.firstChild); r.setEndBefore(mark); return r.toString().trim() !== "" || !!r.cloneContents().querySelector("img, .pl-shape"); })();
    const tail = range.extractContents();
    mark.remove();
    tail.querySelectorAll(".pl-colbreak").forEach((m) => m.replaceWith());
    const hasAfter = tail.textContent.trim() !== "" || !!tail.querySelector("img, .pl-shape");
    if (!hasBefore) {             // the break opens the paragraph: the whole paragraph moves to the next column
      p.appendChild(tail);
      p.style.breakBefore = "column";
    } else if (hasAfter) {
      const next = p.cloneNode(false);
      next.appendChild(tail);
      next.style.breakBefore = "column";
      next.style.textIndent = "0";
      next.classList.add("pl-cont");
      p.after(next);
    } else if (p.nextElementSibling) p.nextElementSibling.style.breakBefore = "column";
  }
}

function finishParagraphs(root) {
  // empty paragraphs: one line high, in the size of the paragraph mark
  for (const p of root.querySelectorAll("p")) {
    if (p.classList.contains("pl-sect")) continue;
    if (p.textContent === "" && !p.querySelector("img, svg, .pl-shape, .pl-tab, math")) {
      const span = document.createElement("span");
      span.textContent = "\u200B";
      const mark = noted(p)?.mark;
      if (mark) for (const k in mark) if (!k.startsWith("$") && mark[k] != null) span.style.setProperty(k, String(mark[k]));
      p.appendChild(span);
    }
  }
  // "no space between paragraphs of the same style"
  const styleOf = (p) => Array.from(p.classList).find((c) => c.startsWith("docx_")) || "";
  for (const p of root.querySelectorAll("p.pl-ctx")) {
    const next = p.nextElementSibling;
    if (next && next.tagName === "P" && next.classList.contains("pl-ctx") && styleOf(next) === styleOf(p)) {
      p.style.marginBottom = "0";
      next.style.marginTop = "0";
    }
  }
  // list numbers: as wide as the hanging indent, so the text of the first line starts where the next lines do
  for (const p of root.querySelectorAll('p[class*="docx-num-"]')) {
    const cs = getComputedStyle(p);
    const indent = parseFloat(cs.textIndent) || 0;
    const content = getComputedStyle(p, "::before").content || "";
    const tabbed = /\t|\\9/.test(content);
    if (indent < 0 && tabbed) p.style.setProperty("--hang", `${(-indent).toFixed(2)}px`);
  }
  // heading rows of tables are repeated at the top of every page
  for (const table of root.querySelectorAll("table")) {
    const rows = Array.from(table.children).filter((c) => c.tagName === "TR");
    const head = [];
    for (const r of rows) { if (r.classList.contains("pl-th")) head.push(r); else break; }
    if (head.length && head.length < rows.length) {
      const thead = document.createElement("thead");
      head[0].before(thead);
      for (const r of head) thead.appendChild(r);
    }
  }
}

/** Tab stops. Every tab becomes a box as wide as the distance to its stop, with the leader dots drawn in it. */
function finishTabs(root, defaultTab) {
  const step = defaultTab > 0 ? defaultTab : 36;
  const pars = new Set();
  for (const t of root.querySelectorAll(".pl-tab")) { const p = t.closest("p"); if (p) pars.add(p); }
  for (const p of pars) {
    const cs = getComputedStyle(p);
    if (cs.direction === "rtl") continue;
    const marginLeft = parseFloat(cs.marginLeft) || 0;
    const indent = parseFloat(cs.textIndent) || 0;
    const stops = (noted(p)?.tabs || []).map((s) => ({ ...s, px: s.pos * PX_PER_PT }));
    if (indent < 0) stops.push({ px: marginLeft, style: "left", leader: "none", implied: true });   // the hanging indent is a stop
    stops.sort((a, b) => a.px - b.px);
    const tabs = Array.from(p.querySelectorAll(".pl-tab")).filter((t) => t.closest("p") === p);
    tabs.forEach((tab, i) => {
      const pr = p.getBoundingClientRect();
      const origin = pr.left - marginLeft;    // tab positions count from the text margin, not from the indent
      const x = tab.getBoundingClientRect().left - origin;
      let stop = stops.find((s) => s.px > x + 0.75);
      if (!stop) {
        const last = stops.length ? stops[stops.length - 1].px : 0;
        const stepPx = step * PX_PER_PT;
        stop = { px: Math.max(last, Math.floor((x + 0.75) / stepPx) * stepPx) + stepPx, style: "left", leader: "none" };
        if (stop.px <= x + 0.75) stop.px += stepPx;
      }
      let width = stop.px - x;
      if (stop.style === "right" || stop.style === "center" || stop.style === "decimal" || stop.style === "end") {
        // the text after the tab, up to the next tab or the end of the paragraph, is what gets aligned on the stop
        const range = document.createRange();
        range.setStartAfter(tab);
        if (tabs[i + 1]) range.setEndBefore(tabs[i + 1]); else range.setEndAfter(p.lastChild);
        let follow = 0;
        const rects = Array.from(range.getClientRects()).filter((r) => r.width > 0);
        if (rects.length) {
          const top = rects[0].top;
          const line = rects.filter((r) => Math.abs(r.top - top) < 3 || (r.top < rects[0].bottom && r.bottom > rects[0].top));
          follow = Math.max(...line.map((r) => r.right)) - Math.min(...line.map((r) => r.left));
        }
        if (stop.style === "decimal") {
          const text = range.toString();
          // where the decimal sign of the first number is ("1,234.75": the point, "1.234,75": the comma,
          // "1,234" or "12": the end of the number)
          const num = /^(\D*?)(\d[\d.,\u00A0\u202F ]*\d|\d)/.exec(text);
          let upTo = -1;
          if (num) {
            const digits = num[2];
            const lastDot = digits.lastIndexOf("."), lastComma = digits.lastIndexOf(",");
            let sep = Math.max(lastDot, lastComma);
            if (sep >= 0 && (lastDot < 0 || lastComma < 0)) {
              const sign = digits[sep];
              const groups = new RegExp(`^[1-9]\\d{0,2}(\\${sign}\\d{3})+$`).test(digits.replace(/[\u00A0\u202F ]/g, ""));
              if (groups) sep = -1;                       // only thousands separators: no decimals
            }
            upTo = num[1].length + (sep >= 0 ? sep : digits.length);
          }
          if (upTo >= 0) {
            const r2 = document.createRange();
            r2.setStartAfter(tab);
            // measure the part before the decimal sign
            const tw = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
            let count = upTo, done = false;
            for (let n = tw.nextNode(); n && !done; n = tw.nextNode()) {
              if (!range.intersectsNode(n) || (tab.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING) === 0) continue;
              if (count <= n.data.length) { r2.setEnd(n, count); done = true; } else count -= n.data.length;
            }
            if (done) follow = r2.getBoundingClientRect().width;
          }
          width = stop.px - x - follow;
        } else width = stop.px - x - (stop.style === "center" ? follow / 2 : follow);
      }
      width = Math.max(0, Math.floor(width * 100) / 100);
      if (stop.style === "right" || stop.style === "end") width = Math.max(0, width - 0.4);   // a hair of room, so the last word never wraps
      // the leader: as many dots (or dashes) as fit, written as text in the font of the line, like Word does
      const sign = { dot: ".", middleDot: "\u00B7", hyphen: "-", underscore: "_", heavy: "_" }[stop.leader];
      if (sign && width > 2) {
        tab.style.width = "auto";
        tab.textContent = sign.repeat(40);
        const one = tab.getBoundingClientRect().width / 40;
        tab.textContent = one > 0.2 ? sign.repeat(Math.max(0, Math.floor((width - 0.5) / one))) : "";
      }
      tab.style.width = `${width.toFixed(2)}px`;
    });
  }
}

/** Floating objects whose size is a share of the page ("40 % of the page height"): the size is worked out.
 *  geo: the page in points { w, h, ml, mr, mt, mb }. */
function sizeAnchors(root, geo) {
  const span = (rel, horizontal) => {
    const [full, a, b] = horizontal ? [geo.w, geo.ml, geo.mr] : [geo.h, geo.mt, geo.mb];
    if (rel === "page") return full;
    if (rel === "leftMargin" || rel === "topMargin" || rel === "insideMargin") return a;
    if (rel === "rightMargin" || rel === "bottomMargin" || rel === "outsideMargin") return b;
    return full - a - b;
  };
  for (const a of root.querySelectorAll(".pl-anchor")) {
    const info = noted(a);
    if (!info || (!info.relW && !info.relH)) continue;
    if (info.relW) info.w = info.relW.pct * span(info.relW.rel, true);
    if (info.relH) info.h = info.relH.pct * span(info.relH.rel, false);
    const shape = Array.from(a.children).find((c) => c.classList.contains("pl-shape"));
    const si = shape && noted(shape);
    if (si) { si.w = info.w; si.h = info.h; }
  }
}

/** Floating pictures and shapes: placed where Word anchors them, or beside the text when the text flows around.
 *  pageOf(anchor): the page the anchor is on, in px: { left, top, width, height } and its text area { cLeft, cTop, cWidth, cHeight }. */
function finishAnchors(root, pageOf, inMargin) {
  const anchors = Array.from(root.querySelectorAll(".pl-anchor")).filter((a) => noted(a) && a.closest("p"));
  // first every floating object is taken out of the text, so the paragraphs stand where they will stand
  for (const a of anchors) {
    const info = noted(a);
    a.style.cssText += `;display:block;position:absolute;float:none;margin:0;width:${(info.w * PX_PER_PT).toFixed(2)}px;height:${(info.h * PX_PER_PT).toFixed(2)}px;`;
  }
  for (const a of anchors) {
    const info = noted(a);
    const p = a.closest("p");
    const page = pageOf(a);
    const w = info.w * PX_PER_PT, h = info.h * PX_PER_PT;
    const pr = p.getBoundingClientRect();
    const pcs = getComputedStyle(p);
    const colLeft = pr.left - (parseFloat(pcs.marginLeft) || 0);
    const colWidth = pr.width + (parseFloat(pcs.marginLeft) || 0) + (parseFloat(pcs.marginRight) || 0);
    // horizontal place, in px from the left of the screen
    let x = colLeft;
    const ph = info.ph;
    if (ph) {
      let refLeft = colLeft, refWidth = colWidth;
      if (ph.rel === "page") { refLeft = page.left; refWidth = page.width; }
      else if (ph.rel === "margin") { refLeft = page.cLeft; refWidth = page.cWidth; }
      else if (ph.rel === "leftMargin" || ph.rel === "insideMargin") { refLeft = page.left; refWidth = page.cLeft - page.left; }
      else if (ph.rel === "rightMargin" || ph.rel === "outsideMargin") { refLeft = page.cLeft + page.cWidth; refWidth = page.left + page.width - refLeft; }
      if (ph.align === "center") x = refLeft + (refWidth - w) / 2;
      else if (ph.align === "right" || ph.align === "outside") x = refLeft + refWidth - w;
      else if (ph.align) x = refLeft;
      else x = refLeft + ph.off * PX_PER_PT;
    }
    // vertical place
    let y = pr.top;
    const pv = info.pv;
    if (pv) {
      let refTop = pr.top, refHeight = 0, onPage = true;
      if (pv.rel === "page") { refTop = page.top; refHeight = page.height; }
      else if (pv.rel === "margin") { refTop = page.cTop; refHeight = page.cHeight; }
      else if (pv.rel === "topMargin") { refTop = page.top; refHeight = page.cTop - page.top; }
      else if (pv.rel === "bottomMargin") { refTop = page.cTop + page.cHeight; refHeight = page.top + page.height - refTop; }
      else onPage = false;                                   // counted from the paragraph or the line
      if (onPage && pv.align === "center") y = refTop + (refHeight - h) / 2;
      else if (onPage && pv.align === "bottom") y = refTop + refHeight - h;
      else if (onPage && pv.align) y = refTop;
      else y = refTop + pv.off * PX_PER_PT;
    }
    const d = info.dist.map((v) => v * PX_PER_PT);
    const size = `width:${w.toFixed(2)}px;height:${h.toFixed(2)}px;`;
    a.style.textIndent = "0";
    // In a header or footer, and when the object stands in the page margin beside the text, it is put exactly
    // where Word says. Inside the text, an object the text flows around becomes a floating box.
    const outside = x + w <= colLeft + 2 || x >= colLeft + colWidth - 2;
    const mode = info.wrap === "wrapNone" || inMargin || (outside && info.wrap !== "wrapTopAndBottom") ? "fixed"
      : info.wrap === "wrapTopAndBottom" ? "block" : "float";
    if (mode === "block") {
      a.style.cssText += `;display:block;position:relative;float:none;left:0;top:0;${size}text-align:left;` +
        `margin:${d[0].toFixed(2)}px 0 ${d[2].toFixed(2)}px ${Math.max(0, x - pr.left).toFixed(2)}px;`;
      continue;
    }
    if (mode === "fixed") {
      p.style.position = "relative";
      a.style.cssText += `;display:block;position:absolute;float:none;margin:0;${size}` +
        `left:${(x - pr.left).toFixed(2)}px;top:${(y - pr.top).toFixed(2)}px;z-index:${info.behind ? -1 : 2};`;
      // an object that reaches the very bottom of the page must not spill onto a page of its own
      const bottom = page.cTop + page.cHeight;
      if (!inMargin && y < bottom - 4 && y + h > bottom - 1.5) { a.style.height = `${(bottom - 1.5 - y).toFixed(2)}px`; a.style.overflow = "hidden"; }
      continue;
    }
    // the text flows around: the box floats on the side it is nearer to
    const right = x + w / 2 > colLeft + colWidth / 2;
    const side = Math.max(0, right ? pr.right - (x + w) : x - pr.left);
    a.style.cssText += `;display:block;position:relative;left:0;top:0;float:${right ? "right" : "left"};${size}` +
      `margin:${Math.max(0, y - pr.top).toFixed(2)}px ${(right ? side : d[1]).toFixed(2)}px ${d[2].toFixed(2)}px ${(right ? d[3] : side).toFixed(2)}px;`;
    if (p.firstChild !== a) {
      const line = a.parentElement;
      p.insertBefore(a, p.firstChild);
      if (line !== p && line.textContent === "" && !line.querySelector("img, svg, .pl-shape")) line.remove();
    }
  }
}

/* ------------------------------------------------------------------ the whole conversion */

const LIB_OPTIONS = {
  className: "docx", inWrapper: false, ignoreWidth: false, ignoreHeight: false, breakPages: true,
  ignoreLastRenderedPageBreak: false, renderHeaders: false, renderFooters: false, renderFootnotes: true,
  renderEndnotes: true, useBase64URL: true, experimental: false, renderAltChunks: false,   // embedded HTML chunks would run their scripts inside this app
  keepOrigin: true,
};

function readTheme(doc) {
  const out = { colors: {}, lineWidths: [9525, 19050, 28575], major: null, minor: null };
  const t = doc.themePart?.theme;
  if (t?.colorScheme?.colors) out.colors = { ...t.colorScheme.colors };
  out.major = t?.fontScheme?.majorFont?.latinTypeface || null;
  out.minor = t?.fontScheme?.minorFont?.latinTypeface || null;
  const xml = doc.themePart?._xmlDocument;
  if (xml) {
    const widths = Array.from(xml.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/main", "lnStyleLst")[0]?.children || [])
      .map((ln) => +xattr(ln, "w") || 0).filter((v) => v > 0);
    if (widths.length) out.lineWidths = widths;
  }
  return out;
}

/** Draw a header and a footer on an empty page of the section's size (the library does the placing). */
async function drawMargin(doc, options, props, headerId, footerId) {
  const body = doc.documentPart.body;
  doc.documentPart.body = {
    type: body.type, cssStyle: {},
    children: [{ type: "paragraph", children: [], cssStyle: { display: "none" } }],
    props: { ...props, type: undefined, columns: undefined, titlePage: false,
      headerRefs: headerId ? [{ id: headerId, type: "default" }] : undefined,
      footerRefs: footerId ? [{ id: footerId, type: "default" }] : undefined },
  };
  try {
    const nodes = await window.docx.renderDocument(doc, { ...options, renderHeaders: true, renderFooters: true, renderFootnotes: false, renderEndnotes: false });
    return nodes.find((n) => n.nodeName === "SECTION") || null;
  } finally {
    doc.documentPart.body = body;
  }
}

/**
 * Turn a .docx into what the server needs to print it.
 * Returns { html, overlay } where html is the document as a printable page, and overlay (or null) describes the
 * headers and footers: { head, groups: [{ width, height, start, format, title, first, even, normal }], evenOdd }.
 */
export async function wordToPrintable(buffer) {
  await extendLibrary();
  // The document is drawn off screen, in a closed-off part of the page (a shadow tree): the styles of the app do
  // not reach it, its styles do not reach the app, and the language switch never sees the user's words.
  const holder = document.createElement("div");
  holder.setAttribute("translate", "no");
  holder.style.cssText = "position:fixed;left:-100000px;top:0;visibility:hidden;width:auto;";
  const shadow = holder.attachShadow({ mode: "open" });
  const styleEl = document.createElement("style");
  const pageBox = document.createElement("div");
  pageBox.className = "pl-root";
  shadow.append(styleEl, pageBox);
  document.body.appendChild(holder);
  cx = { reg: new Map(), n: 0, fonts: new Map(), fontKinds: new Map(), holder: pageBox };
  try {
    const lib = window.docx;
    const options = { ...LIB_OPTIONS, h: makeH(lib.defaultOptions.h) };
    let doc, nodes, sections, theme;
    const sign = new Uint8Array(buffer.slice(0, 4));
    if (sign[0] === 0xD0 && sign[1] === 0xCF && sign[2] === 0x11 && sign[3] === 0xE0) {
      // not a zip but the old Office container: a .docx saved with a password to open it
      throw new Error("This Word file is protected by a password. Remove the password in Word, then try again.");
    }
    try {
      doc = await lib.parseAsync(buffer, options);
      for (const f of doc.fontTablePart?.fonts || []) if (f.name) cx.fontKinds.set(String(f.name).toLowerCase(), f.family);
      theme = readTheme(doc);
      if (theme.major) fontVar(theme.major);
      if (theme.minor) fontVar(theme.minor);
      sections = prepare(doc);
      nodes = await lib.renderDocument(doc, options);
    } catch (e) {
      console.warn("docx could not be read:", e && (e.message || e));  // the library's own message is technical English
      throw new Error("This Word file could not be opened. It may be damaged.");
    }
    // The library hands back its style sheets (each one after a comment that says what it is), then the pages.
    const libCss = { base: "", theme: "", numbering: "", fonts: "" };
    let kind = "";
    for (const n of nodes) {
      if (n.nodeType === 8) { kind = n.data; continue; }
      if (n.nodeName === "STYLE") {
        const text = n.textContent;
        if (kind.includes("predefined")) libCss.base += text;
        else if (kind.includes("theme")) libCss.theme += text;
        else if (kind.includes("numbering")) libCss.numbering += text;
        else if (kind.includes("font")) libCss.fonts += text;       // fonts stored inside the document
        continue;                                                    // "document styles": written again by styleCss
      }
      pageBox.appendChild(n);
    }
    const groupsEls = Array.from(pageBox.children).filter((n) => n.nodeName === "SECTION");
    if (!groupsEls.length) throw new Error("This document is empty or could not be read.");

    const numbering = fixSymbolCss(libCss.numbering).replace(/:root\b/g, ".pl-root");
    const css = LAYERS +
      `@layer pl-base {\n${libCss.base}\n${DEFAULTS_CSS}}\n` +
      libCss.theme + "\n" +
      fixSymbolCss(styleCss(doc)) +
      `@layer pl-num {\n${numbering}}\n` +
      // a list set on the paragraph itself (not through its style) places the text: it wins over the style's indent
      `@layer pl-numd {\n${numbering.replace(/(^|\n)p\.(docx-num-)/g, "$1p.pl-numd.$2")}}\n` +
      libCss.fonts + "\n" + BASE_CSS;
    styleEl.textContent = css;
    const fonts = await settleFonts(theme);
    styleEl.textContent = css + fonts.vars;

    /* ---- pages: one group per forced page start, with the size and margins of its section ---- */
    const evenOdd = !!doc.settingsPart?.settings?.evenAndOddHeaders;
    const defaultTab = pt(doc.settingsPart?.settings?.defaultTabStop) || 36;
    const geoKeys = [];
    const groups = [];
    let current = 0;
    const firstSect = new Map();
    for (const el of groupsEls) {
      for (const art of Array.from(el.children).filter((c) => c.tagName === "ARTICLE")) {
        const opener = art.querySelector(":scope > p.pl-sect");
        if (opener) { current = noted(opener)?.index ?? current; opener.remove(); }
        art.dataset.sect = String(current);
        if (!firstSect.has(el)) firstSect.set(el, current);
        if (!art.firstChild) art.remove();
      }
      if (!firstSect.has(el)) firstSect.set(el, current);
    }
    // a page start with nothing in it is one the library added twice; a document with no text at all keeps one page
    let kept = groupsEls.filter((el) => el.firstElementChild);
    if (!kept.length) kept = [groupsEls[0]];
    for (const el of groupsEls) if (!kept.includes(el)) el.remove();
    for (const el of kept) {
      const first = firstSect.get(el);
      current = first;
      const s = sections[first ?? current];
      const pr = s.props;
      const size = { w: pt(pr.pageSize?.width) || 595.3, h: pt(pr.pageSize?.height) || 841.9 };
      const mg = pr.pageMargins || {};
      const g = { el, sect: first ?? current, size,
        margin: { top: Math.abs(pt(mg.top)), right: pt(mg.right), bottom: Math.abs(pt(mg.bottom)), left: pt(mg.left), header: pt(mg.header), footer: pt(mg.footer) },
        newSection: groups.length === 0 || groups[groups.length - 1].sect !== (first ?? current) };
      el.removeAttribute("style");
      el.classList.add("pl-group");
      // The side margins are kept inside the page as padding: Chrome cuts off what stands in a real page margin,
      // and Word documents do put things there (a side bar, a line, a logo).
      el.style.width = fmt(size.w - g.margin.left - g.margin.right);
      el.style.paddingLeft = fmt(g.margin.left);
      el.style.paddingRight = fmt(g.margin.right);
      // a continuous section with other side margins, inside this group
      for (const art of el.querySelectorAll(":scope > article")) {
        const m2 = sections[+art.dataset.sect]?.props.pageMargins;
        if (m2 && +art.dataset.sect !== g.sect) {
          const dl = pt(m2.left) - g.margin.left, dr = pt(m2.right) - g.margin.right;
          if (Math.abs(dl) > 0.5) art.style.marginLeft = fmt(dl);
          if (Math.abs(dr) > 0.5) art.style.marginRight = fmt(dr);
        }
      }
      groups.push(g);
    }

    /* ---- headers and footers: one transparent page per kind, drawn once, measured, reused on every page ---- */
    const templates = new Map();     // key -> { el, top, bottom }
    const overBox = document.createElement("div");
    pageBox.appendChild(overBox);
    const template = async (g, headerId, footerId) => {
      if (!headerId && !footerId) return null;
      const key = `${headerId || ""}|${footerId || ""}|${g.size.w}x${g.size.h}|${g.margin.top},${g.margin.right},${g.margin.bottom},${g.margin.left},${g.margin.header},${g.margin.footer}`;
      if (templates.has(key)) return templates.get(key);
      const el = await drawMargin(doc, options, sections[g.sect].props, headerId, footerId);
      if (!el) { templates.set(key, null); return null; }
      el.classList.add("pl-over");
      el.style.height = fmt(g.size.h);
      el.style.minHeight = "";
      overBox.appendChild(el);
      const t = { el, key, index: templates.size };
      templates.set(key, t);
      return t;
    };
    let anyMargin = false;
    for (const g of groups) {
      const refs = sections[g.sect].refs;
      const title = !!sections[g.sect].props.titlePage;
      g.title = title && g.newSection;
      g.normal = await template(g, refs.header.default, refs.footer.default);
      g.first = g.title ? await template(g, refs.header.first, refs.footer.first) : null;
      g.even = evenOdd ? await template(g, refs.header.even, refs.footer.even) : null;
      if (g.normal || g.first || g.even) anyMargin = true;
    }

    /* ---- finishing: place holders, paragraphs, shapes, tabs, floating objects ---- */
    const shapeTheme = { colors: theme.colors, lineWidths: theme.lineWidths };
    const finish = (root, inMargin, g) => {
      finishMarks(root, inMargin);
      finishColumnBreaks(root);
      finishParagraphs(root);
      sizeAnchors(root, { w: g.size.w, h: g.size.h, ml: g.margin.left, mr: g.margin.right, mt: g.margin.top, mb: g.margin.bottom });
      drawShapes(root, shapeTheme, (e) => noted(e));
    };
    const owner = new Map();       // header and footer page -> a group that uses it (for the page size and margins)
    for (const g of groups) for (const t of [g.normal, g.first, g.even]) if (t && !owner.has(t)) owner.set(t, g);
    for (const g of groups) finish(g.el, false, g);
    for (const [t, g] of owner) finish(t.el, true, g);
    try { await document.fonts.ready; } catch (e) { /* keep going */ }

    const pageOfGroup = (g) => (a) => {
      const r = g.el.getBoundingClientRect();
      const k = PX_PER_PT;
      const cHeight = (g.size.h - g.margin.top - g.margin.bottom) * k;
      // which page of the group the anchor falls on, as far as it can be told before printing
      const top = a.closest("p")?.getBoundingClientRect().top ?? r.top;
      const n = cHeight > 0 ? Math.max(0, Math.floor((top - r.top) / cHeight)) : 0;
      const cTop = r.top + n * cHeight;
      return { left: r.left, top: cTop - g.margin.top * k, width: g.size.w * k, height: g.size.h * k,
        cLeft: r.left + g.margin.left * k, cTop, cWidth: r.width - (g.margin.left + g.margin.right) * k, cHeight };
    };
    const pageOfTemplate = (t, g) => () => {
      const r = t.el.getBoundingClientRect();
      const k = PX_PER_PT;
      return { left: r.left, top: r.top, width: r.width, height: r.height, cLeft: r.left + g.margin.left * k, cTop: r.top + g.margin.top * k,
        cWidth: r.width - (g.margin.left + g.margin.right) * k, cHeight: r.height - (g.margin.top + g.margin.bottom) * k };
    };
    for (const g of groups) { finishAnchors(g.el, pageOfGroup(g), false); finishTabs(g.el, defaultTab); }
    for (const [t, g] of owner) { finishAnchors(t.el, pageOfTemplate(t, g), true); finishTabs(t.el, defaultTab); }

    /* ---- a tall header pushes the text down, a tall footer pushes it up (Word does the same) ---- */
    for (const t of templates.values()) {
      if (!t) continue;
      const r = t.el.getBoundingClientRect();
      const head = t.el.querySelector(":scope > header"), foot = t.el.querySelector(":scope > footer");
      const content = (box) => {
        // the lowest and highest point of what is really inside (the box itself is stretched by the library)
        let top = Infinity, bottom = -Infinity;
        for (const c of box.children) {
          const cr = c.getBoundingClientRect();
          if (cr.height > 0) { top = Math.min(top, cr.top); bottom = Math.max(bottom, cr.bottom); }
        }
        return bottom > top ? { top, bottom } : null;
      };
      const hc = head && content(head), fc = foot && content(foot);
      t.top = hc ? (hc.bottom - r.top) / PX_PER_PT : 0;
      t.bottom = fc ? (r.bottom - fc.top) / PX_PER_PT : 0;
    }
    for (const g of groups) {
      const usual = [g.normal, g.even].filter(Boolean);
      const top = Math.max(g.margin.top, ...usual.map((t) => t.top + 1));
      const bottom = Math.max(g.margin.bottom, ...usual.map((t) => t.bottom + 1));
      g.page = { top, right: g.margin.right, bottom, left: g.margin.left };
      if (g.first && g.first.top + 1 > top) {     // a taller header on the first page only: the text starts lower there
        const spacer = document.createElement("div");
        spacer.style.height = fmt(g.first.top + 1 - top);
        g.el.insertBefore(spacer, g.el.firstChild);
      }
    }

    /* ---- the printable page ---- */
    const pageRules = [];
    groups.forEach((g, i) => {
      const key = `${g.size.w}x${g.size.h}|${g.page.top.toFixed(1)},${g.page.bottom.toFixed(1)}`;
      let k = geoKeys.indexOf(key);
      if (k < 0) {
        k = geoKeys.push(key) - 1;
        pageRules.push(`@page pl${k} { size: ${fmt(g.size.w)} ${fmt(g.size.h)}; margin: ${fmt(g.page.top)} 0 ${fmt(g.page.bottom)} 0; }`);
      }
      g.el.style.page = `pl${k}`;
      if (i > 0) g.el.style.breakBefore = "page";
      if (anyMargin) {
        const mark = document.createElement("a");
        mark.className = "pl-gm";
        mark.setAttribute("href", `https://pdflab.invalid/g/${i}`);
        g.el.insertBefore(mark, g.el.firstChild);
      }
    });
    // The page is written as XHTML: read back as HTML, a paragraph that holds a shape or a text box would be cut
    // in two (HTML does not allow a box inside a paragraph), XHTML keeps the page exactly as it was built.
    const xs = new XMLSerializer();
    const esc = (t) => t.replace(/&/g, "&amp;").replace(/</g, "&lt;");
    const clean = (t) => t.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, "");
    const head = clean(`<style>${esc(fonts.faces)}</style>\n<style>${esc(css)}\n${esc(fonts.vars)}</style>`);
    const pageCss = `@page { margin: 0; }\n${pageRules.join("\n")}\n` +
      "html, body { margin: 0; padding: 0; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }";
    const html = `<?xml version="1.0" encoding="UTF-8"?>\n<html xmlns="http://www.w3.org/1999/xhtml"><head><title>document</title>${head}\n` +
      `<style>${esc(pageCss)}</style></head><body class="pl-root">${clean(groups.map((g) => xs.serializeToString(g.el)).join("\n"))}</body></html>`;

    let overlay = null;
    if (anyMargin) {
      const list = Array.from(templates.values()).filter(Boolean);
      const sizes = [];
      const sizeRule = (g) => {
        const key = `${g.size.w}x${g.size.h}`;
        let k = sizes.indexOf(key);
        if (k < 0) k = sizes.push(key) - 1;
        return k;
      };
      const num = (g) => sections[g.sect].props.pageNumber || {};
      overlay = {
        head,                         // the same styles and fonts as the text pages
        templates: list.map((t) => clean(xs.serializeToString(t.el))),
        groups: groups.map((g) => ({
          width: g.size.w, height: g.size.h, size: sizeRule(g),
          start: g.newSection && num(g).start != null ? num(g).start : null, format: num(g).format || "decimal",
          title: !!g.title, first: g.first ? list.indexOf(g.first) : -1, even: g.even ? list.indexOf(g.even) : -1, normal: g.normal ? list.indexOf(g.normal) : -1,
        })),
        sizes: sizes.map((sz) => sz.split("x").map(Number)),
        evenOdd,
      };
    }
    // info: figures for the tests and for looking into a document that comes out wrong (the server ignores it)
    const info = { groups: groups.map((g) => ({ section: g.sect, size: g.size, margin: g.margin, page: g.page })),
      margins: Array.from(templates.values()).filter(Boolean).map((t) => ({ top: +t.top.toFixed(1), bottom: +t.bottom.toFixed(1) })),
      fonts: Array.from(cx.fonts.keys()) };
    return { html, overlay, info };
  } finally {
    cx = null;
    holder.remove();
  }
}
