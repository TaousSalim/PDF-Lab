// Turns pdf.js text items into lines, paragraphs and Word blocks.

const BOLD = /bold|black|heavy|demi|semibold/i;
const PUA_BULLET = /^[\uf000-\uf8ff\u25AA\u25CF\u25CB\u2023\u00B7\u2022]+\s*/;
const ITALIC = /italic|oblique/i;

/** Extract positioned text lines from one pdf.js page. Coordinates are in points from the top left. */
export async function extractLines(page) {
  // Work in the page as displayed (rotation and crop box applied), then turn that frame so the main
  // text direction runs left to right. Otherwise the text of rotated pages looks sideways and is lost.
  const vp = page.getViewport({ scale: 1 });
  const [A, B, C, D, E, F] = vp.transform;
  const tc = await page.getTextContent();
  try { await page.getOperatorList(); } catch (e) { /* fonts stay unnamed */ }

  const fontCache = new Map();
  const fontInfo = (id) => {
    if (fontCache.has(id)) return fontCache.get(id);
    let name = "";
    try { if (page.commonObjs.has(id)) name = page.commonObjs.get(id)?.name || ""; } catch (e) { /* ignore */ }
    const info = { b: BOLD.test(name), i: ITALIC.test(name) };
    fontCache.set(id, info);
    return info;
  };

  const raw = [];
  const votes = [0, 0, 0, 0];
  for (const it of tc.items) {
    if (typeof it.str !== "string" || it.str === "") continue;
    const m = it.transform;
    const t = [A * m[0] + C * m[1], B * m[0] + D * m[1], A * m[2] + C * m[3], B * m[2] + D * m[3], A * m[4] + C * m[5] + E, B * m[4] + D * m[5] + F];
    const size = Math.hypot(t[2], t[3]);
    const turn = Math.atan2(t[1], t[0]) / (Math.PI / 2); // quarter turns, clockwise on screen
    if (!(size >= 1.5) || Math.abs(turn - Math.round(turn)) > 0.125) continue; // skip tiny or slanted text
    const q = ((Math.round(turn) % 4) + 4) % 4;
    votes[q] += it.str.trim().length;
    raw.push({ it, x: t[4], y: t[5], size, q });
  }
  const q = votes.indexOf(Math.max(...votes)); // the direction most of the text runs in
  const W = q % 2 ? vp.height : vp.width;
  const H = q % 2 ? vp.width : vp.height;
  const turned = [(x, y) => [x, y], (x, y) => [y, vp.width - x], (x, y) => [vp.width - x, vp.height - y], (x, y) => [vp.height - y, x]][q];
  const items = [];
  for (const r of raw) {
    const it = r.it;
    if (r.q !== q) continue; // text running across the main direction
    if (!it.str.trim() && it.width > 1.5 * r.size) continue; // layout filler: acts as a gap, not as text
    const f = fontInfo(it.fontName);
    const [x, y] = turned(r.x, r.y);
    items.push({ str: it.str, x, y, w: it.width, size: r.size, b: f.b, i: f.i });
  }
  items.sort((a, b) => a.y - b.y || a.x - b.x);

  // group into lines by baseline
  const rows = [];
  for (const it of items) {
    const row = rows[rows.length - 1];
    if (row && Math.abs(it.y - row.y) <= 0.45 * Math.min(row.size, it.size)) {
      row.items.push(it);
      row.size = Math.max(row.size, it.size);
    } else rows.push({ y: it.y, size: it.size, items: [it] });
  }

  const lines = [];
  for (const row of rows) {
    row.items.sort((a, b) => a.x - b.x);
    const runs = [];
    let prevEnd = null;
    let prevStr = "";
    for (const it of row.items) {
      let text = it.str;
      const gap = prevEnd == null ? 0 : it.x - prevEnd;
      const wide = prevEnd != null && gap > 2.4 * it.size;
      if (!wide && prevEnd != null && gap > 0.18 * it.size && !/\s$/.test(prevStr) && !/^\s/.test(text)) text = " " + text;
      const last = runs[runs.length - 1];
      const sameStyle = last && !wide && last.b === it.b && last.i === it.i && Math.abs(last.sz - it.size) < 0.6;
      if (sameStyle) { last.t += text; last.x1 = it.x + it.w; }
      else runs.push({ t: text, b: it.b, i: it.i, sz: it.size, x0: it.x, x1: it.x + it.w, brk: wide });
      prevEnd = it.x + it.w;
      prevStr = it.str;
    }
    // turn private-use / symbol bullets into a real bullet character
    if (runs.length && PUA_BULLET.test(runs[0].t)) runs[0].t = runs[0].t.replace(PUA_BULLET, "\u2022 ");
    const text = runs.map((r) => r.t).join("");
    if (!text.trim()) continue;
    const x0 = row.items[0].x;
    const x1 = Math.max(...row.items.map((i) => i.x + i.w));
    lines.push({ x0, x1, y: row.y, size: row.size, runs, text });
  }
  return { w: W, h: H, lines };
}

/** Build docx blocks from extracted pages: [{w,h,lines}]. */
export function buildBlocks(pages, { pageBreaks = true } = {}) {
  // body font size = the size carrying the most characters
  const hist = new Map();
  for (const p of pages) for (const l of p.lines) for (const r of l.runs) {
    const k = Math.round(r.sz * 2) / 2;
    hist.set(k, (hist.get(k) || 0) + r.t.length);
  }
  let body = 11, best = 0;
  for (const [k, n] of hist) if (n > best) { best = n; body = k; }

  const lefts = pages.flatMap((p) => p.lines.map((l) => l.x0)).sort((a, b) => a - b);
  const leftMargin = lefts.length ? lefts[Math.floor(lefts.length * 0.05)] : 54;

  const blocks = [];
  pages.forEach((p, pi) => {
    const lines = p.lines.filter((l) => {
      const nearEdge = l.y < p.h * 0.06 || l.y > p.h * 0.94;
      return !(nearEdge && /^(page\s*)?\d{1,4}(\s*(of|\/)\s*\d{1,4})?$/i.test(l.text.trim()));
    });
    let para = null;
    const flush = () => {
      if (!para) return;
      blocks.push(paraToBlock(para, p, body, leftMargin));
      para = null;
    };
    for (const l of lines) {
      const tabbed = l.runs.some((r) => r.brk);
      const startsItem = /^\s*([•▪●‣·\-–—*]|\d{1,3}[.)])\s+/.test(l.text);
      if (para) {
        const prev = para.lines[para.lines.length - 1];
        const gap = l.y - prev.y;
        const sameSize = Math.abs(l.size - prev.size) < 0.8;
        const indentDelta = Math.abs(l.x0 - prev.x0);
        const joins = sameSize && gap > 0 && gap <= 1.5 * l.size && indentDelta < 2.5 * l.size && !startsItem && !tabbed && !prev.runs.some((r) => r.brk);
        if (!joins) flush();
      }
      if (!para) para = { lines: [l] };
      else para.lines.push(l);
    }
    flush();
    if (pageBreaks && pi < pages.length - 1) blocks.push({ style: "pb" });
  });
  const first = pages[0];
  return { blocks, page: { w: first.w, h: first.h, body, margin: Math.min(Math.max(leftMargin, 36), 108) } };
}

function paraToBlock(para, page, body, leftMargin) {
  const ls = para.lines;
  const size = Math.max(...ls.map((l) => l.size));
  const isHeading = size >= body * 1.18 && ls.length <= 3;
  const runs = [];
  ls.forEach((l, li) => {
    l.runs.forEach((r, ri) => {
      let t = (r.brk && ri > 0 ? "\t" : "") + r.t;
      if (ri === 0 && li > 0) {
        const prev = runs[runs.length - 1];
        if (prev && /[A-Za-zÀ-ÿ]-$/.test(prev.t) && /^[a-zà-ÿ]/.test(t)) prev.t = prev.t.slice(0, -1);
        else if (prev && !/\s$/.test(prev.t) && !/^\s/.test(t)) t = " " + t;
      }
      const sz = isHeading ? Math.round(r.sz * 2) / 2 : (Math.abs(r.sz - body) < 0.6 ? undefined : Math.round(r.sz * 2) / 2);
      const last = runs[runs.length - 1];
      if (last && last.b === !!(r.b || isHeading && false) && last.i === !!r.i && last.sz === sz) last.t += t;
      else runs.push({ t, b: !!r.b, i: !!r.i, sz });
    });
  });
  const first = ls[0];
  const x0 = Math.min(...ls.map((l) => l.x0));
  const x1 = Math.max(...ls.map((l) => l.x1));
  const block = { style: "p", runs };
  if (isHeading) {
    block.style = size >= body * 1.7 ? "h1" : size >= body * 1.35 ? "h2" : "h3";
    block.keep = true;
  }
  const mid = (x0 + x1) / 2;
  if (ls.length === 1 && Math.abs(mid - page.w / 2) < page.w * 0.03 && x0 - leftMargin > page.w * 0.08) block.align = "center";
  else if (x0 - leftMargin > 18) block.indent = Math.round(x0 - leftMargin);
  void first;
  return block;
}

/** Boxes for editable PowerPoint slides: one text box per line segment (split at wide gaps), with styled runs. */
export function buildBoxes(page) {
  const boxes = [];
  for (const l of page.lines) {
    const segs = [];
    for (const r of l.runs) {
      if (!segs.length || r.brk) segs.push([]);
      segs[segs.length - 1].push(r);
    }
    for (const seg of segs) {
      if (!seg.some((r) => r.t.trim())) continue;
      const size = Math.max(...seg.map((r) => r.sz));
      boxes.push({
        x: seg[0].x0,
        y: Math.max(l.y - size * 0.88, 0),
        w: Math.max(seg[seg.length - 1].x1 - seg[0].x0, size) + size * 0.5,
        h: size * 1.25,
        runs: seg.map((r) => ({ text: r.t, sz: Math.round(r.sz * 2) / 2, b: r.b, i: r.i })),
      });
    }
  }
  return boxes;
}
