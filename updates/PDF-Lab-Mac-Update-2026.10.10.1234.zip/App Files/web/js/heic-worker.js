/* Reads a HEIC or HEIF picture (the format of iPhone photos) and gives back a picture every browser can show.
 *
 * It runs apart from the page (a worker), so the window never freezes while a photo is being read. The reading
 * itself is done by libheif (vendor/libheif), a free library. This file does the rest:
 *   - picks the main picture of the file (a photo can also hold a small preview, a depth map, a second frame),
 *   - keeps the photo the right way up (libheif applies the rotation and mirroring stored in the file),
 *   - brings the wide colours of recent iPhones (Display P3) back to standard colours (sRGB), like Photos does,
 *   - writes a JPG, or a PNG when the picture has transparent parts.
 *
 * In:  { id, buffer }                     buffer: the bytes of the file
 * Out: { id, ok: true, blob, w, h, type, frames, wide }   or   { id, ok: false, error: "damaged" | "large" | "engine" }
 */
"use strict";

const MAX_PIXELS = 268e6;   // what one canvas can hold in Chrome (16384 x 16384)
let lib = null;

function engine() {
  if (lib) return lib;
  lib = new Promise((resolve, reject) => {
    try {
      importScripts("../vendor/libheif/libheif-bundle.js");
      const m = self.libheif();
      if (m && typeof m.then === "function") { m.then(resolve, reject); return; }
      if (m.calledRun) { resolve(m); return; }
      m.onRuntimeInitialized = () => resolve(m);
    } catch (e) { reject(e); }
  });
  return lib;
}

/** True when the picture's colours are Display P3: the red of its colour profile tells. */
function isDisplayP3(m, ptr) {
  try {
    const four = (s) => (s.charCodeAt(0) << 24 | s.charCodeAt(1) << 16 | s.charCodeAt(2) << 8 | s.charCodeAt(3)) >>> 0;
    const kind = m._heif_image_handle_get_color_profile_type(ptr) >>> 0;
    const err = m._malloc(32);   // the C functions hand their result through a first, hidden pointer
    try {
      if (kind === four("prof") || kind === four("rICC")) {
        const n = m._heif_image_handle_get_raw_color_profile_size(ptr);
        if (n < 132 || n > 4e6) return false;
        const p = m._malloc(n);
        try {
          m._heif_image_handle_get_raw_color_profile(err, ptr, p);
          const icc = m.HEAPU8.slice(p, p + n);
          const v = new DataView(icc.buffer);
          const tags = v.getUint32(128);
          for (let i = 0; i < tags && 132 + i * 12 + 12 <= n; i++) {
            const at = 132 + i * 12;
            if (v.getUint32(at) !== four("rXYZ")) continue;
            const off = v.getUint32(at + 4);
            if (off + 20 > n) return false;
            const x = v.getInt32(off + 8) / 65536, y = v.getInt32(off + 12) / 65536;
            // red, adapted to D50: sRGB 0.436 / 0.222, Display P3 0.515 / 0.241, Adobe RGB 0.609 / 0.311
            return Math.abs(x - 0.515) < 0.02 && Math.abs(y - 0.241) < 0.02;
          }
        } finally { m._free(p); }
        return false;
      }
      if (kind === four("nclx")) {
        const out = m._malloc(8);
        try {
          m._heif_image_handle_get_nclx_color_profile(err, ptr, out);
          const nclx = new DataView(m.HEAPU8.buffer).getUint32(out, true);
          if (!nclx) return false;
          const primaries = new DataView(m.HEAPU8.buffer).getInt32(nclx + 4, true);
          m._heif_nclx_color_profile_free(nclx);
          return primaries === 12;   // SMPTE EG 432-1, the primaries of Display P3
        } finally { m._free(out); }
      }
    } finally { m._free(err); }
  } catch (e) { /* no profile that can be read: standard colours */ }
  return false;
}

async function convert(buffer) {
  let m;
  try { m = await engine(); } catch (e) { lib = null; return { ok: false, error: "engine", detail: String(e && e.message || e) }; }
  const ctx = m.heif_context_alloc();
  let handle = null, image = null;
  try {
    const read = m.heif_context_read_from_memory(ctx, new Uint8Array(buffer));
    if (!read || read.code !== m.heif_error_code.heif_error_Ok) return { ok: false, error: "damaged", detail: read && read.message };
    const ids = m.heif_js_context_get_list_of_top_level_image_IDs(ctx);
    const frames = Array.isArray(ids) ? ids.length : 0;
    handle = m.heif_js_context_get_primary_image_handle(ctx);
    if ((!handle || handle.code) && frames) handle = m.heif_js_context_get_image_handle(ctx, ids[0]);
    if (!handle || handle.code) return { ok: false, error: "damaged", detail: "no picture in the file" };
    const w = m.heif_image_handle_get_width(handle), h = m.heif_image_handle_get_height(handle);
    if (!(w > 0 && h > 0)) return { ok: false, error: "damaged", detail: "empty picture" };
    if (w * h > MAX_PIXELS || w > 32767 || h > 32767) return { ok: false, error: "large", detail: `${w} x ${h}` };
    const alpha = !!m.heif_image_handle_has_alpha_channel(handle);
    const wide = isDisplayP3(m, handle.$$ ? handle.$$.ptr : 0);
    image = await m.heif_js_decode_image2(handle, m.heif_colorspace.heif_colorspace_RGB, m.heif_chroma.heif_chroma_interleaved_RGBA);
    if (!image || image.code || !image.channels) return { ok: false, error: "damaged", detail: image && image.message };
    const ch = image.channels.find((c) => c.id === m.heif_channel.heif_channel_interleaved) || image.channels[0];
    const cw = ch.width, chh = ch.height;   // the decoded size is the one to trust
    let rgba;
    if (ch.stride === cw * 4) rgba = new Uint8ClampedArray(ch.data.buffer, ch.data.byteOffset, cw * chh * 4);
    else {
      rgba = new Uint8ClampedArray(cw * chh * 4);
      for (let y = 0; y < chh; y++) rgba.set(ch.data.subarray(y * ch.stride, y * ch.stride + cw * 4), y * cw * 4);
    }
    let pixels;
    try { pixels = new ImageData(rgba, cw, chh, { colorSpace: wide ? "display-p3" : "srgb" }); }
    catch (e) { pixels = new ImageData(rgba, cw, chh); }
    const canvas = new OffscreenCanvas(cw, chh);
    const g = canvas.getContext("2d");
    if (!g) return { ok: false, error: "large", detail: `${cw} x ${chh}` };
    g.putImageData(pixels, 0, 0);
    pixels = rgba = null;
    const type = alpha ? "image/png" : "image/jpeg";
    const blob = await canvas.convertToBlob({ type, quality: 0.92 });
    canvas.width = canvas.height = 0;
    if (!blob || !blob.size) return { ok: false, error: "large", detail: `${cw} x ${chh}` };
    return { ok: true, blob, w: cw, h: chh, type, frames, wide };
  } catch (e) {
    const text = String(e && e.message || e);
    // out of memory: the page starts a fresh worker for the next photo (see images.js)
    if (/memory|alloc|RangeError|abort/i.test(text)) return { ok: false, error: "large", detail: text };
    return { ok: false, error: "damaged", detail: text };
  } finally {
    try { if (image && image.image) m.heif_image_release(image.image); } catch (e) { /* gone */ }
    try { if (handle && !handle.code) m.heif_image_handle_release(handle); } catch (e) { /* gone */ }
    try { m.heif_context_free(ctx); } catch (e) { /* gone */ }
  }
}

self.onmessage = async (e) => {
  const { id, buffer } = e.data || {};
  let out;
  try { out = await convert(buffer); } catch (err) { out = { ok: false, error: "damaged", detail: String(err && err.message || err) }; }
  self.postMessage({ id, ...out });
};
