/* Word to PDF: drawing shapes (rectangles, ovals, arrows, lines, text boxes, groups) as vector graphics.
 *
 * The Word library knows pictures only. A shape in a .docx is a small piece of XML (DrawingML): a geometry name
 * such as "roundRect" or "rightArrow", a fill, an outline, and sometimes a text. This file turns that XML into an
 * inline SVG picture of the same size, so shapes print sharp at any zoom, with the text kept as real text.
 */

const SVG = "http://www.w3.org/2000/svg";
const EMU = 12700;          // EMU per point
let serial = 0;             // unique ids for arrow heads and gradients inside one page

const kids = (node, name) => (node ? Array.from(node.children).filter((c) => !name || c.localName === name) : []);
const kid = (node, name) => (node ? Array.from(node.children).find((c) => c.localName === name) || null : null);
const attr = (node, name) => {
  if (!node) return null;
  for (const a of node.attributes) if (a.localName === name) return a.value;
  return null;
};
const num = (node, name, fallback = 0) => {
  const v = attr(node, name);
  return v == null || v === "" || isNaN(+v) ? fallback : +v;
};

/* ---------------------------------------------------------------- colours */
const PRESET_COLORS = {
  black: "000000", white: "FFFFFF", red: "FF0000", green: "008000", blue: "0000FF", yellow: "FFFF00", gray: "808080",
  grey: "808080", orange: "FFA500", purple: "800080", cyan: "00FFFF", magenta: "FF00FF", darkBlue: "00008B",
  darkGray: "A9A9A9", darkGreen: "006400", darkRed: "8B0000", lightGray: "D3D3D3", ltGray: "D3D3D3", dkGray: "A9A9A9",
  navy: "000080", teal: "008080", maroon: "800000", olive: "808000", silver: "C0C0C0", lime: "00FF00", brown: "A52A2A",
};
const SCHEME_ALIASES = { tx1: "dk1", tx2: "dk2", bg1: "lt1", bg2: "lt2" };

function hexToRgb(hex) {
  const h = (hex || "000000").replace("#", "").padStart(6, "0").slice(0, 6);
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}
function rgbToHsl([r, g, b]) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min, s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  const h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h / 6, s, l];
}
function hslToRgb([h, s, l]) {
  if (s === 0) return [l * 255, l * 255, l * 255];
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = (t) => {
    t = (t + 1) % 1;
    return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p;
  };
  return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
}

/** A DrawingML colour element (srgbClr, schemeClr ...) as { css, alpha }, or null. ph: the colour "phClr" stands for. */
export function readColor(node, theme, ph) {
  if (!node) return null;
  let rgb = null;
  switch (node.localName) {
    case "srgbClr": rgb = hexToRgb(attr(node, "val")); break;
    case "sysClr": rgb = hexToRgb(attr(node, "lastClr") || (attr(node, "val") === "window" ? "FFFFFF" : "000000")); break;
    case "prstClr": rgb = hexToRgb(PRESET_COLORS[attr(node, "val")] || "000000"); break;
    case "scrgbClr": rgb = [num(node, "r") * 255 / 100000, num(node, "g") * 255 / 100000, num(node, "b") * 255 / 100000]; break;
    case "schemeClr": {
      const key = attr(node, "val");
      if (key === "phClr") { if (!ph) return null; rgb = ph.rgb.slice(); break; }
      const hex = theme.colors[SCHEME_ALIASES[key] || key];
      rgb = hexToRgb(hex || "000000");
      break;
    }
    default: return null;
  }
  let alpha = ph && node.localName === "schemeClr" && attr(node, "val") === "phClr" ? ph.alpha : 1;
  for (const m of node.children) {
    const v = num(m, "val", 100000) / 100000;
    switch (m.localName) {
      case "alpha": alpha = v; break;
      case "tint": rgb = rgb.map((c) => c + (255 - c) * (1 - v)); break;
      case "shade": rgb = rgb.map((c) => c * v); break;
      case "lumMod": { const hsl = rgbToHsl(rgb); hsl[2] = Math.min(1, hsl[2] * v); rgb = hslToRgb(hsl); break; }
      case "lumOff": { const hsl = rgbToHsl(rgb); hsl[2] = Math.min(1, Math.max(0, hsl[2] + v)); rgb = hslToRgb(hsl); break; }
      case "satMod": { const hsl = rgbToHsl(rgb); hsl[1] = Math.min(1, hsl[1] * v); rgb = hslToRgb(hsl); break; }
      default: break;
    }
  }
  rgb = rgb.map((c) => Math.max(0, Math.min(255, Math.round(c))));
  return { rgb, alpha, css: `rgb(${rgb[0]},${rgb[1]},${rgb[2]})` };
}
const firstColor = (node, theme, ph) => {
  for (const c of kids(node)) { const col = readColor(c, theme, ph); if (col) return col; }
  return null;
};

/* ---------------------------------------------------------------- geometry */
const P = (...a) => a.map((v) => (typeof v === "number" ? +v.toFixed(2) : v)).join(" ");

/** Preset shapes as SVG path data in a w x h box. adj: the shape's own adjustment values (or undefined). */
function presetPath(name, w, h, adj) {
  const m = Math.min(w, h);
  const a = (i, def) => (adj[i] == null ? def : adj[i]) / 100000;
  const rect = `M0 0H${w}V${h}H0Z`;
  const round = (r) => { r = Math.min(r, w / 2, h / 2); return P("M", r, 0, "H", w - r, "A", r, r, 0, 0, 1, w, r, "V", h - r, "A", r, r, 0, 0, 1, w - r, h, "H", r, "A", r, r, 0, 0, 1, 0, h - r, "V", r, "A", r, r, 0, 0, 1, r, 0, "Z"); };
  const ellipse = P("M", 0, h / 2, "A", w / 2, h / 2, 0, 1, 1, w, h / 2, "A", w / 2, h / 2, 0, 1, 1, 0, h / 2, "Z");
  const poly = (pts) => "M" + pts.map((p) => P(p[0], p[1])).join("L") + "Z";
  const star = (n, inner) => {
    const pts = [];
    for (let i = 0; i < n * 2; i++) {
      const r = i % 2 ? inner : 1, t = -Math.PI / 2 + (i * Math.PI) / n;
      pts.push([w / 2 + (w / 2) * r * Math.cos(t), h / 2 + (h / 2) * r * Math.sin(t)]);
    }
    return poly(pts);
  };
  const ngon = (n, rot = -Math.PI / 2) => {
    const pts = [];
    for (let i = 0; i < n; i++) pts.push([w / 2 + (w / 2) * Math.cos(rot + (i * 2 * Math.PI) / n), h / 2 + (h / 2) * Math.sin(rot + (i * 2 * Math.PI) / n)]);
    return poly(pts);
  };
  switch (name) {
    case "rect": case "flowChartProcess": case "textBox": case "actionButtonBlank": return { d: rect };
    case "roundRect": case "flowChartAlternateProcess": return { d: round(m * a("adj", 16667)) };
    case "flowChartTerminator": return { d: round(h / 2) };
    case "round1Rect": case "round2SameRect": case "round2DiagRect": case "snipRoundRect": return { d: round(m * 0.16667) };
    case "snip1Rect": { const s = m * a("adj", 16667); return { d: poly([[0, 0], [w - s, 0], [w, s], [w, h], [0, h]]) }; }
    case "snip2SameRect": { const s = m * a("adj1", 16667); return { d: poly([[s, 0], [w - s, 0], [w, s], [w, h], [0, h], [0, s]]) }; }
    case "snip2DiagRect": { const s = m * a("adj2", 16667); return { d: poly([[0, 0], [w - s, 0], [w, s], [w, h], [s, h], [0, h - s]]) }; }
    case "ellipse": case "flowChartConnector": return { d: ellipse };
    case "triangle": case "flowChartExtract": { const x = w * a("adj", 50000); return { d: poly([[x, 0], [w, h], [0, h]]) }; }
    case "flowChartMerge": return { d: poly([[0, 0], [w, 0], [w / 2, h]]) };
    case "rtTriangle": return { d: poly([[0, 0], [w, h], [0, h]]) };
    case "diamond": case "flowChartDecision": return { d: poly([[w / 2, 0], [w, h / 2], [w / 2, h], [0, h / 2]]) };
    case "parallelogram": case "flowChartInputOutput": { const s = Math.min(w, m * a("adj", name === "parallelogram" ? 25000 : 20000) * (name === "parallelogram" ? 1 : w / m)); return { d: poly([[s, 0], [w, 0], [w - s, h], [0, h]]) }; }
    case "trapezoid": { const s = m * a("adj", 25000); return { d: poly([[s, 0], [w - s, 0], [w, h], [0, h]]) }; }
    case "flowChartManualOperation": return { d: poly([[0, 0], [w, 0], [w * 0.8, h], [w * 0.2, h]]) };
    case "flowChartManualInput": return { d: poly([[0, h * 0.2], [w, 0], [w, h], [0, h]]) };
    case "hexagon": case "flowChartPreparation": { const s = Math.min(w / 2, m * a("adj", 25000)); return { d: poly([[s, 0], [w - s, 0], [w, h / 2], [w - s, h], [s, h], [0, h / 2]]) }; }
    case "pentagon": return { d: ngon(5) };
    case "heptagon": return { d: ngon(7) };
    case "octagon": { const s = m * a("adj", 29289); return { d: poly([[s, 0], [w - s, 0], [w, s], [w, h - s], [w - s, h], [s, h], [0, h - s], [0, s]]) }; }
    case "decagon": return { d: ngon(10, 0) };
    case "dodecagon": return { d: ngon(12, -Math.PI / 12) };
    case "plus": case "mathPlus": { const s = m * a("adj", 25000); return { d: poly([[s, 0], [w - s, 0], [w - s, s], [w, s], [w, h - s], [w - s, h - s], [w - s, h], [s, h], [s, h - s], [0, h - s], [0, s], [s, s]]) }; }
    case "star4": return { d: star(4, a("adj", 12500) * 2) };
    case "star5": return { d: star(5, 0.382) };
    case "star6": return { d: star(6, 0.577) };
    case "star7": return { d: star(7, 0.69) };
    case "star8": return { d: star(8, 0.75) };
    case "star10": return { d: star(10, 0.85) };
    case "star12": return { d: star(12, 0.75) };
    case "star16": case "star24": case "star32": return { d: star(+name.slice(4), 0.75) };
    case "rightArrow": case "leftArrow": case "upArrow": case "downArrow": {
      const horiz = name === "rightArrow" || name === "leftArrow";
      const L = horiz ? w : h, T = horiz ? h : w;
      const body = T * a("adj1", 50000), head = Math.min(L, Math.min(L, T) * a("adj2", 50000));
      const t0 = (T - body) / 2, t1 = t0 + body, x = L - head;
      let pts = [[0, t0], [x, t0], [x, 0], [L, T / 2], [x, T], [x, t1], [0, t1]];
      if (name === "leftArrow") pts = pts.map(([px, py]) => [L - px, py]);
      if (!horiz) pts = pts.map(([px, py]) => [py, name === "downArrow" ? px : L - px]);
      return { d: poly(pts) };
    }
    case "leftRightArrow": { const body = h * a("adj1", 50000), head = Math.min(w / 2, m * a("adj2", 50000)), t0 = (h - body) / 2, t1 = t0 + body; return { d: poly([[0, h / 2], [head, 0], [head, t0], [w - head, t0], [w - head, 0], [w, h / 2], [w - head, h], [w - head, t1], [head, t1], [head, h]]) }; }
    case "upDownArrow": { const body = w * a("adj1", 50000), head = Math.min(h / 2, m * a("adj2", 50000)), t0 = (w - body) / 2, t1 = t0 + body; return { d: poly([[w / 2, 0], [w, head], [t1, head], [t1, h - head], [w, h - head], [w / 2, h], [0, h - head], [t0, h - head], [t0, head], [0, head]]) }; }
    case "chevron": { const s = Math.min(w, m * a("adj", 50000)); return { d: poly([[0, 0], [w - s, 0], [w, h / 2], [w - s, h], [0, h], [s, h / 2]]) }; }
    case "homePlate": { const s = Math.min(w, m * a("adj", 50000)); return { d: poly([[0, 0], [w - s, 0], [w, h / 2], [w - s, h], [0, h]]) }; }
    case "notchedRightArrow": { const body = h * a("adj1", 50000), head = Math.min(w, m * a("adj2", 50000)), t0 = (h - body) / 2, t1 = t0 + body, n = (body / 2) * (head / (h / 2)); return { d: poly([[0, t0], [w - head, t0], [w - head, 0], [w, h / 2], [w - head, h], [w - head, t1], [0, t1], [n, h / 2]]) }; }
    case "line": case "straightConnector1": return { d: P("M", 0, 0, "L", w, h), open: true };
    case "bentConnector2": return { d: P("M", 0, 0, "H", w, "V", h), open: true };
    case "bentConnector3": case "bentConnector4": case "bentConnector5": { const x = w * a("adj1", 50000); return { d: P("M", 0, 0, "H", x, "V", h, "H", w), open: true }; }
    case "curvedConnector2": return { d: P("M", 0, 0, "Q", w, 0, w, h), open: true };
    case "curvedConnector3": case "curvedConnector4": case "curvedConnector5": { const x = w * a("adj1", 50000); return { d: P("M", 0, 0, "C", x, 0, x, h, w, h), open: true }; }
    case "arc": return { d: P("M", w / 2, 0, "A", w / 2, h / 2, 0, 0, 1, w, h / 2), open: true };
    case "leftBracket": { const r = Math.min(w, h / 2); return { d: P("M", w, 0, "A", w, r, 0, 0, 0, 0, r, "V", h - r, "A", w, r, 0, 0, 0, w, h), open: true }; }
    case "rightBracket": { const r = Math.min(w, h / 2); return { d: P("M", 0, 0, "A", w, r, 0, 0, 1, w, r, "V", h - r, "A", w, r, 0, 0, 1, 0, h), open: true }; }
    case "bracketPair": { const r = m * a("adj", 16667); return { d: P("M", r, 0, "A", r, r, 0, 0, 0, 0, r, "V", h - r, "A", r, r, 0, 0, 0, r, h, "M", w - r, 0, "A", r, r, 0, 0, 1, w, r, "V", h - r, "A", r, r, 0, 0, 1, w - r, h), open: true }; }
    case "leftBrace": case "rightBrace": case "bracePair": {
      const r = Math.min(w / 2, m * 0.0833 * (name === "bracePair" ? 1 : 2)), mid = h * (name === "bracePair" ? 0.5 : a("adj2", 50000));
      const left = (x0, dir) => P("M", x0 + dir * 2 * r, 0, "A", r, r, 0, 0, dir > 0 ? 0 : 1, x0 + dir * r, r, "V", mid - r, "A", r, r, 0, 0, dir > 0 ? 1 : 0, x0, mid, "A", r, r, 0, 0, dir > 0 ? 1 : 0, x0 + dir * r, mid + r, "V", h - r, "A", r, r, 0, 0, dir > 0 ? 0 : 1, x0 + dir * 2 * r, h);
      if (name === "leftBrace") return { d: left(w - 2 * r < 0 ? 0 : w - 2 * r, 1), open: true };
      if (name === "rightBrace") return { d: left(Math.min(w, 2 * r), -1), open: true };
      return { d: left(0, 1) + left(w, -1), open: true };
    }
    case "wedgeRectCallout": case "wedgeRoundRectCallout": case "wedgeEllipseCallout": case "cloudCallout": case "borderCallout1": case "callout1": {
      const tx = w * (0.5 + a("adj1", -20833)), ty = h * (0.5 + a("adj2", 62500));
      const base = name === "wedgeEllipseCallout" || name === "cloudCallout" ? ellipse : name === "wedgeRoundRectCallout" ? round(m * 0.16667) : rect;
      // the tail leaves from the side of the box that faces the tip
      let p1, p2;
      if (ty > h || ty < 0) { const y = ty > h ? h : 0, x0 = Math.max(w * 0.1, Math.min(w * 0.75, tx > w / 2 ? w * 0.58 : w * 0.17)); p1 = [x0, y]; p2 = [x0 + w * 0.25, y]; }
      else { const x = tx > w ? w : 0, y0 = Math.max(h * 0.1, Math.min(h * 0.65, ty > h / 2 ? h * 0.58 : h * 0.17)); p1 = [x, y0]; p2 = [x, y0 + h * 0.25]; }
      return { d: base + P("M", p1[0], p1[1], "L", tx, ty, "L", p2[0], p2[1], "Z"), union: true };
    }
    case "cloud": return { d: ellipse };
    case "heart": return { d: P("M", w / 2, h * 0.25, "C", w * 0.6, -h * 0.1, w * 1.15, h * 0.2, w / 2, h, "C", -w * 0.15, h * 0.2, w * 0.4, -h * 0.1, w / 2, h * 0.25, "Z") };
    case "donut": { const t = m * a("adj", 25000); return { d: ellipse + P("M", t, h / 2, "A", w / 2 - t, h / 2 - t, 0, 1, 0, w - t, h / 2, "A", w / 2 - t, h / 2 - t, 0, 1, 0, t, h / 2, "Z"), evenodd: true }; }
    case "frame": { const t = m * a("adj1", 12500); return { d: rect + P("M", t, t, "V", h - t, "H", w - t, "V", t, "Z"), evenodd: true }; }
    case "can": case "flowChartMagneticDisk": { const r = Math.min(h / 2, (m * a("adj", 25000)) / 2); return { d: P("M", 0, r, "A", w / 2, r, 0, 0, 1, w, r, "V", h - r, "A", w / 2, r, 0, 0, 1, 0, h - r, "Z"), extra: P("M", 0, r, "A", w / 2, r, 0, 0, 0, w, r) }; }
    case "cube": { const s = m * a("adj", 25000); return { d: poly([[0, s], [s, 0], [w, 0], [w, h - s], [w - s, h], [0, h]]), extra: P("M", 0, s, "H", w - s, "V", h, "M", w - s, s, "L", w, 0) }; }
    case "flowChartDocument": return { d: P("M", 0, 0, "H", w, "V", h * 0.86, "C", w * 0.75, h * 0.72, w * 0.6, h * 0.8, w / 2, h * 0.88, "C", w * 0.35, h * 1.0, w * 0.2, h * 1.02, 0, h * 0.93, "Z") };
    case "flowChartPredefinedProcess": return { d: rect, extra: P("M", w / 8, 0, "V", h, "M", w * 7 / 8, 0, "V", h) };
    case "flowChartInternalStorage": return { d: rect, extra: P("M", w / 8, 0, "V", h, "M", 0, h / 8, "H", w) };
    case "flowChartDelay": return { d: P("M", 0, 0, "H", w / 2, "A", w / 2, h / 2, 0, 0, 1, w / 2, h, "H", 0, "Z") };
    case "flowChartOffpageConnector": return { d: poly([[0, 0], [w, 0], [w, h * 0.8], [w / 2, h], [0, h * 0.8]]) };
    case "flowChartOr": return { d: ellipse, extra: P("M", w / 2, 0, "V", h, "M", 0, h / 2, "H", w) };
    case "flowChartSummingJunction": return { d: ellipse, extra: P("M", w * 0.146, h * 0.146, "L", w * 0.854, h * 0.854, "M", w * 0.854, h * 0.146, "L", w * 0.146, h * 0.854) };
    case "flowChartSort": return { d: poly([[w / 2, 0], [w, h / 2], [w / 2, h], [0, h / 2]]), extra: P("M", 0, h / 2, "H", w) };
    case "flowChartCollate": return { d: poly([[0, 0], [w, 0], [0, h], [w, h]]) };
    case "moon": return { d: P("M", w, 0, "A", w, h / 2, 0, 0, 0, w, h, "A", w / 2, h / 2, 0, 0, 1, w, 0, "Z") };
    case "lightningBolt": return { d: poly([[w * 0.39, 0], [w * 0.6, h * 0.29], [w * 0.5, h * 0.33], [w * 0.77, h * 0.56], [w * 0.68, h * 0.6], [w, h], [w * 0.46, h * 0.68], [w * 0.55, h * 0.64], [w * 0.23, h * 0.44], [w * 0.35, h * 0.39], [0, h * 0.18]]) };
    case "noSmoking": { const t = m * a("adj", 18750); return { d: ellipse + P("M", t, h / 2, "A", w / 2 - t, h / 2 - t, 0, 1, 0, w - t, h / 2, "A", w / 2 - t, h / 2 - t, 0, 1, 0, t, h / 2, "Z"), evenodd: true, extra: P("M", w * 0.2, h * 0.2, "L", w * 0.8, h * 0.8) }; }
    default: return { d: rect };
  }
}

/** A custom geometry (a:custGeom) as SVG path data scaled to w x h. */
function customPath(geom, w, h) {
  let d = "";
  let open = true, any = false;
  for (const path of kids(kid(geom, "pathLst"), "path")) {
    const pw = num(path, "w", 0) || w * EMU, ph = num(path, "h", 0) || h * EMU;
    const sx = w / pw, sy = h / ph;
    const pt = (n) => [num(n, "x") * sx, num(n, "y") * sy];
    let cur = [0, 0];
    for (const cmd of path.children) {
      const pts = kids(cmd, "pt").map(pt);
      switch (cmd.localName) {
        case "moveTo": if (pts[0]) { d += P("M", ...pts[0]); cur = pts[0]; } break;
        case "lnTo": if (pts[0]) { d += P("L", ...pts[0]); cur = pts[0]; } break;
        case "cubicBezTo": if (pts.length === 3) { d += P("C", ...pts[0], ...pts[1], ...pts[2]); cur = pts[2]; } break;
        case "quadBezTo": if (pts.length === 2) { d += P("Q", ...pts[0], ...pts[1]); cur = pts[1]; } break;
        case "arcTo": {
          const rx = num(cmd, "wR") * sx, ry = num(cmd, "hR") * sy;
          const st = (num(cmd, "stAng") / 60000) * Math.PI / 180, sw = (num(cmd, "swAng") / 60000) * Math.PI / 180;
          if (rx <= 0 || ry <= 0) break;
          const cx = cur[0] - rx * Math.cos(st), cy = cur[1] - ry * Math.sin(st);
          const end = [cx + rx * Math.cos(st + sw), cy + ry * Math.sin(st + sw)];
          d += P("A", rx, ry, 0, Math.abs(sw) > Math.PI ? 1 : 0, sw > 0 ? 1 : 0, ...end);
          cur = end;
          break;
        }
        case "close": d += "Z"; open = false; break;
        default: break;
      }
      any = true;
    }
  }
  return any ? { d, open } : null;
}

/* ---------------------------------------------------------------- one shape */
function svgEl(name, attrs) {
  const e = document.createElementNS(SVG, name);
  for (const k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]);
  return e;
}

function lineEnd(defs, node, color, width, atStart) {
  const type = attr(node, "type");
  if (!node || !type || type === "none") return null;
  const size = { sm: 2, med: 3, lg: 5 };
  const lw = size[attr(node, "w")] || 3, ll = size[attr(node, "len")] || 3;
  const id = `pl-end-${++serial}`;
  const mk = svgEl("marker", { id, markerUnits: "strokeWidth", markerWidth: ll + 1, markerHeight: lw + 1, viewBox: `0 0 ${ll + 1} ${lw + 1}`,
    refX: type === "oval" || type === "diamond" ? (ll + 1) / 2 : ll + 0.5, refY: (lw + 1) / 2, orient: atStart ? "auto-start-reverse" : "auto", overflow: "visible" });
  const top = 0.5, bot = lw + 0.5, midY = (lw + 1) / 2, x1 = ll + 0.5;
  let shape;
  if (type === "oval") shape = svgEl("ellipse", { cx: (ll + 1) / 2, cy: midY, rx: ll / 2, ry: lw / 2, fill: color });
  else if (type === "diamond") shape = svgEl("path", { d: P("M", 0.5, midY, "L", (ll + 1) / 2, top, "L", x1, midY, "L", (ll + 1) / 2, bot, "Z"), fill: color });
  else if (type === "arrow") shape = svgEl("path", { d: P("M", 0.5, top, "L", x1, midY, "L", 0.5, bot), fill: "none", stroke: color, "stroke-width": 1, "stroke-linecap": "round" });
  else if (type === "stealth") shape = svgEl("path", { d: P("M", 0.5, top, "L", x1, midY, "L", 0.5, bot, "L", 0.5 + ll * 0.3, midY, "Z"), fill: color });
  else shape = svgEl("path", { d: P("M", 0.5, top, "L", x1, midY, "L", 0.5, bot, "Z"), fill: color });
  mk.appendChild(shape);
  defs.appendChild(mk);
  return `url(#${id})`;
}

const DASHES = { dash: [4, 3], sysDash: [3, 1], dot: [1, 3], sysDot: [1, 1], dashDot: [4, 3, 1, 3], sysDashDot: [3, 1, 1, 1],
  lgDash: [8, 3], lgDashDot: [8, 3, 1, 3], lgDashDotDot: [8, 3, 1, 3, 1, 3], sysDashDotDot: [3, 1, 1, 1, 1, 1] };

/**
 * Draw one shape into its host element.
 * host: the element the library made for the shape (its children are the paragraphs of the shape's text, if any).
 * sp: the shape XML (wps:wsp, or a group child). box: { w, h } in points. theme: { colors, lineWidths }.
 */
function drawShape(host, sp, box, theme) {
  const spPr = kid(sp, "spPr");
  const style = kid(sp, "style");
  const xfrm = kid(spPr, "xfrm");
  const w = Math.max(box.w, 0.01), h = Math.max(box.h, 0.01);
  const texts = Array.from(host.childNodes);

  // geometry
  const prst = kid(spPr, "prstGeom");
  const cust = kid(spPr, "custGeom");
  const adj = {};
  for (const gd of kids(kid(prst, "avLst"), "gd")) {
    const mm = /^val\s+(-?\d+)/.exec(attr(gd, "fmla") || "");
    if (mm) adj[attr(gd, "name")] = +mm[1];
  }
  const name = attr(prst, "prst") || "rect";
  const geo = (cust && customPath(cust, w, h)) || presetPath(name, w, h, adj);
  const isLine = !!geo.open;

  // fill
  const defs = svgEl("defs", {});
  let fill = "none", fillOpacity = null;
  const fillRef = kid(style, "fillRef");
  const refFill = fillRef && num(fillRef, "idx", 0) > 0 ? firstColor(fillRef, theme) : null;
  const solid = kid(spPr, "solidFill"), grad = kid(spPr, "gradFill"), patt = kid(spPr, "pattFill"), blip = kid(spPr, "blipFill");
  if (kid(spPr, "noFill") || isLine) fill = "none";
  else if (solid) { const c = firstColor(solid, theme, refFill); if (c) { fill = c.css; if (c.alpha < 1) fillOpacity = c.alpha; } }
  else if (grad) {
    const stops = kids(kid(grad, "gsLst"), "gs").map((gs) => ({ pos: num(gs, "pos") / 1000, c: firstColor(gs, theme, refFill) })).filter((s) => s.c).sort((x, y) => x.pos - y.pos);
    if (stops.length) {
      const id = `pl-grad-${++serial}`;
      const lin = kid(grad, "lin");
      const ang = lin ? (num(lin, "ang") / 60000) * Math.PI / 180 : Math.PI / 2;
      const g = kid(grad, "path")
        ? svgEl("radialGradient", { id, cx: "50%", cy: "50%", r: "70%" })
        : svgEl("linearGradient", { id, x1: `${50 - 50 * Math.cos(ang)}%`, y1: `${50 - 50 * Math.sin(ang)}%`, x2: `${50 + 50 * Math.cos(ang)}%`, y2: `${50 + 50 * Math.sin(ang)}%` });
      for (const s of stops) g.appendChild(svgEl("stop", { offset: `${s.pos}%`, "stop-color": s.c.css, "stop-opacity": s.c.alpha < 1 ? s.c.alpha : null }));
      defs.appendChild(g);
      fill = `url(#${id})`;
    }
  } else if (patt) { const c = firstColor(kid(patt, "fgClr"), theme, refFill); if (c) { fill = c.css; fillOpacity = 0.5; } }
  else if (blip) fill = "none";
  else if (refFill) { fill = refFill.css; if (refFill.alpha < 1) fillOpacity = refFill.alpha; }

  // outline
  const ln = kid(spPr, "ln");
  const lnRef = kid(style, "lnRef");
  const refIdx = lnRef ? num(lnRef, "idx", 0) : 0;
  const refLine = refIdx > 0 ? firstColor(lnRef, theme) : null;
  let stroke = "none", strokeWidth = 0, strokeOpacity = null;
  if (!(ln && kid(ln, "noFill"))) {
    const lnSolid = kid(ln, "solidFill");
    const c = lnSolid ? firstColor(lnSolid, theme, refLine) : ln && kid(ln, "gradFill") ? firstColor(kid(kid(kid(ln, "gradFill"), "gsLst"), "gs"), theme, refLine) : refLine;
    if (c) {
      stroke = c.css;
      if (c.alpha < 1) strokeOpacity = c.alpha;
      const wEmu = attr(ln, "w") != null ? num(ln, "w") : (theme.lineWidths[refIdx - 1] || 9525);
      strokeWidth = Math.max(0.25, wEmu / EMU);
    }
  }
  const dashName = attr(kid(ln, "prstDash"), "val");
  const dash = DASHES[dashName] ? DASHES[dashName].map((v) => v * strokeWidth).join(" ") : null;

  // the picture
  const svg = svgEl("svg", { viewBox: `0 0 ${+w.toFixed(2)} ${+h.toFixed(2)}`, width: `${w.toFixed(2)}pt`, height: `${h.toFixed(2)}pt`, preserveAspectRatio: "none" });
  svg.setAttribute("class", "pl-shape-art");
  const common = { fill, "fill-opacity": fillOpacity, stroke, "stroke-width": strokeWidth ? +strokeWidth.toFixed(2) : null, "stroke-opacity": strokeOpacity,
    "stroke-dasharray": dash, "stroke-linejoin": attr(kid(ln, "miter"), "lim") != null ? "miter" : "round", "stroke-linecap": attr(ln, "cap") === "rnd" ? "round" : attr(ln, "cap") === "sq" ? "square" : "butt",
    "fill-rule": geo.evenodd ? "evenodd" : null };
  const path = svgEl("path", { d: geo.d, ...common });
  if (stroke !== "none" && (geo.open || name.includes("Connector") || name === "line")) {
    const head = lineEnd(defs, kid(ln, "headEnd"), stroke, strokeWidth, true);
    const tail = lineEnd(defs, kid(ln, "tailEnd"), stroke, strokeWidth, false);
    if (head) path.setAttribute("marker-start", head);
    if (tail) path.setAttribute("marker-end", tail);
  }
  if (defs.childNodes.length) svg.appendChild(defs);
  svg.appendChild(path);
  if (geo.extra) svg.appendChild(svgEl("path", { d: geo.extra, ...common, fill: "none" }));

  // turning and mirroring: the art is mirrored, the text is only turned
  const rot = xfrm ? num(xfrm, "rot") / 60000 : 0;
  const flipH = attr(xfrm, "flipH") === "1" || attr(xfrm, "flipH") === "true";
  const flipV = attr(xfrm, "flipV") === "1" || attr(xfrm, "flipV") === "true";
  const turns = [];
  if (flipH || flipV) turns.push(`scale(${flipH ? -1 : 1}, ${flipV ? -1 : 1})`);
  if (turns.length) svg.style.transform = turns.join(" ");
  if (rot) host.style.transform = `${host.style.transform || ""} rotate(${rot}deg)`.trim();

  host.style.width = `${w.toFixed(2)}pt`;
  host.style.height = `${h.toFixed(2)}pt`;
  host.insertBefore(svg, host.firstChild);

  // the text of the shape
  const hasText = texts.some((n) => n.nodeType === 1 && n.textContent.trim() !== "") || texts.some((n) => n.nodeType === 1 && n.querySelector && n.querySelector("img, svg, .pl-shape"));
  if (texts.length) {
    const bodyPr = kid(sp, "bodyPr");
    const ins = (n, def) => (attr(bodyPr, n) != null ? num(bodyPr, n) : def) / EMU;
    const holder = document.createElement("div");
    holder.className = "pl-shape-text";
    const anchor = attr(bodyPr, "anchor") || "t";
    holder.style.cssText = `position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;display:flex;flex-direction:column;` +
      `justify-content:${anchor === "ctr" ? "center" : anchor === "b" ? "flex-end" : "flex-start"};` +
      `padding:${ins("tIns", 45720).toFixed(2)}pt ${ins("rIns", 91440).toFixed(2)}pt ${ins("bIns", 45720).toFixed(2)}pt ${ins("lIns", 91440).toFixed(2)}pt;`;
    const vert = attr(bodyPr, "vert");
    if (vert === "vert" || vert === "eaVert") holder.style.writingMode = "vertical-rl";
    else if (vert === "vert270") { holder.style.writingMode = "vertical-rl"; holder.style.transform = "rotate(180deg)"; }
    if (attr(bodyPr, "wrap") === "none") holder.style.whiteSpace = "nowrap";
    const fontRef = kid(style, "fontRef");
    const textColor = fontRef ? firstColor(fontRef, theme) : null;
    if (textColor) holder.style.color = textColor.css;
    for (const n of texts) holder.appendChild(n);
    if (!hasText) holder.style.display = "none";
    host.appendChild(holder);
  }
}

const rectOf = (xfrm) => {
  const off = kid(xfrm, "off"), ext = kid(xfrm, "ext");
  return { x: num(off, "x"), y: num(off, "y"), w: num(ext, "cx"), h: num(ext, "cy") };
};

/** Draw a group: every child is placed with the group's own scale, then drawn as a shape (or kept as a picture). */
function drawGroup(host, grp, box, theme, registry) {
  const xfrm = kid(kid(grp, "grpSpPr"), "xfrm");
  const chOff = kid(xfrm, "chOff"), chExt = kid(xfrm, "chExt");
  const cx = num(chOff, "x"), cy = num(chOff, "y");
  const cw = num(chExt, "cx") || box.w * EMU, ch = num(chExt, "cy") || box.h * EMU;
  const sx = box.w / cw, sy = box.h / ch;
  host.style.width = `${box.w.toFixed(2)}pt`;
  host.style.height = `${box.h.toFixed(2)}pt`;
  const rot = xfrm ? num(xfrm, "rot") / 60000 : 0;
  if (rot) host.style.transform = `${host.style.transform || ""} rotate(${rot}deg)`.trim();
  for (const child of Array.from(host.children)) {
    const info = registry(child);
    if (!info) continue;
    const r = rectOf(kid(kid(info.xml, info.kind === "group" ? "grpSpPr" : "spPr"), "xfrm"));
    const cb = { w: r.w * sx, h: r.h * sy };
    child.style.position = "absolute";
    child.style.display = "block";
    child.style.left = `${((r.x - cx) * sx).toFixed(2)}pt`;
    child.style.top = `${((r.y - cy) * sy).toFixed(2)}pt`;
    child.style.margin = "0";
    if (info.kind === "group") drawGroup(child, info.xml, cb, theme, registry);
    else if (info.kind === "picture") {
      child.style.width = `${cb.w.toFixed(2)}pt`; child.style.height = `${cb.h.toFixed(2)}pt`;
      const rotPic = num(kid(kid(info.xml, "spPr"), "xfrm"), "rot") / 60000;
      child.style.transform = rotPic ? `rotate(${rotPic}deg)` : "none";
    } else drawShape(child, info.xml, cb, theme);
  }
}

/**
 * Draw every shape under root.
 * registry(element) gives { kind: "shape" | "group" | "picture", xml, w, h } for an element the engine tagged, else null.
 */
export function drawShapes(root, theme, registry) {
  const hosts = Array.from(root.querySelectorAll(".pl-shape")).filter((e) => !e.parentElement.closest(".pl-shape"));
  for (const host of hosts) {
    const info = registry(host);
    if (!info) continue;
    try {
      const box = { w: info.w, h: info.h };
      host.style.display = "inline-block";
      host.style.position = "relative";
      host.style.verticalAlign = "bottom";
      host.style.textIndent = "0";
      host.style.lineHeight = "normal";
      if (info.kind === "group") drawGroup(host, info.xml, box, theme, registry);
      else drawShape(host, info.xml, box, theme);
    } catch (e) {
      console.warn("a shape could not be drawn:", e && e.message);
    }
  }
}
