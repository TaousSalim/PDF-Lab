// Tool icons: two overlapping rounded tiles, drawn as inline SVG.
// The tile that sits in front gets a ring in the card color so the overlap reads cleanly.

const T = 38; // tile size
const TL = { x: 2, y: 2 };
const BR = { x: 24, y: 24 };

function tile(pos, fill, ring = false) {
  const ringAttr = ring ? ' stroke="var(--card)" stroke-width="3"' : "";
  return `<rect x="${pos.x}" y="${pos.y}" width="${T}" height="${T}" rx="9" fill="${fill}"${ringAttr}/>`;
}

const mid = (p) => [p.x + T / 2, p.y + T / 2];

/** dir: "se" | "nw" | "ne" */
function arrow(pos, dir, color) {
  const [mx, my] = mid(pos);
  const off = pos === TL ? -3 : 3;
  const cx = mx + off, cy = my + off;
  const s = 6;
  const paths = {
    se: `M${cx - s} ${cy - s}L${cx + s} ${cy + s}M${cx + s} ${cy - 1}V${cy + s}H${cx - 1}`,
    nw: `M${cx + s} ${cy + s}L${cx - s} ${cy - s}M${cx - s} ${cy + 1}V${cy - s}H${cx + 1}`,
    ne: `M${cx - s} ${cy + s}L${cx + s} ${cy - s}M${cx - 1} ${cy - s}H${cx + s}V${cx - cx + cy + 1}`,
  };
  return `<path d="${paths[dir]}" fill="none" stroke="${color}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>`;
}

function label(pos, text, color, size = 17) {
  const [cx, cy] = mid(pos);
  return `<text x="${cx}" y="${cy + size * 0.36}" text-anchor="middle" font-family="Manrope,-apple-system,Arial,sans-serif" font-weight="800" font-size="${size}" fill="${color}">${text}</text>`;
}

const GLYPH = {
  image: (pos, color) => {
    const [cx, cy] = mid(pos);
    return `<path d="M${cx - 11} ${cy + 8}L${cx - 3} ${cy - 3}L${cx + 3} ${cy + 4}L${cx + 6} ${cy}L${cx + 11} ${cy + 8}Z" fill="${color}"/><circle cx="${cx + 7}" cy="${cy - 7}" r="2.6" fill="${color}"/>`;
  },
  cross: (pos, color) => {
    const [cx, cy] = mid(pos);
    return `<path d="M${cx - 7} ${cy - 7}L${cx + 7} ${cy + 7}M${cx + 7} ${cy - 7}L${cx - 7} ${cy + 7}" stroke="${color}" stroke-width="3" stroke-linecap="round"/>`;
  },
  rotate: (pos, color) => {
    const [cx, cy] = mid(pos);
    return `<path d="M${cx + 8} ${cy - 2}A8 8 0 1 0 ${cx + 5} ${cy + 6}" fill="none" stroke="${color}" stroke-width="2.8" stroke-linecap="round"/><path d="M${cx + 9} ${cy - 9}V${cy - 1}H${cx + 1}" fill="none" stroke="${color}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>`;
  },
  check: (pos, color) => {
    const [cx, cy] = mid(pos);
    return `<path d="M${cx - 8} ${cy} L${cx - 2} ${cy + 6} L${cx + 8} ${cy - 6}" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`;
  },
  lines: (pos, color) => {
    const [cx, cy] = mid(pos);
    return `<path d="M${cx - 8} ${cy - 6}H${cx + 8}M${cx - 8} ${cy}H${cx + 8}M${cx - 8} ${cy + 6}H${cx + 2}" stroke="${color}" stroke-width="2.6" stroke-linecap="round"/>`;
  },
};

/** White, or dark on a pale colour (yellow), like the labels of the tool pages. */
function inkOn(hex) {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.42 ? "#2a2a31" : "#fff";
}

export function icon(kind, c, light, size = 64) {
  const W = /^#[0-9a-f]{6}$/i.test(c) ? inkOn(c) : "#fff";
  // on its pale tile, a pale colour (yellow) would not show: the arrow takes a deeper shade of it
  const A = W === "#fff" ? c : "#" + [1, 3, 5].map((i) => Math.round(parseInt(c.slice(i, i + 2), 16) * 0.6).toString(16).padStart(2, "0")).join("");
  let body = "";
  switch (kind) {
    case "merge":
      body = tile(TL, c) + arrow(TL, "se", W) + tile(BR, c, true) + arrow(BR, "nw", W);
      break;
    case "split":
      body = tile(TL, c) + arrow(TL, "nw", W) + tile(BR, c, true) + arrow(BR, "se", W);
      break;
    case "remove":
      body = tile(TL, light) + GLYPH.lines(TL, c) + tile(BR, c, true) + GLYPH.cross(BR, W);
      break;
    case "extract":
      body = tile(TL, light) + GLYPH.lines(TL, c) + tile(BR, c, true) + GLYPH.check(BR, W);
      break;
    case "rotate": {
      const cx = 32, cy = 32;
      return `<svg viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true"><rect x="8" y="8" width="48" height="48" rx="11" fill="${c}"/>`
        + `<path d="M${cx - 9} ${cy - 3}A11 11 0 0 1 ${cx + 7} ${cy - 9}" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>`
        + `<path d="M${cx + 10} ${cy - 17}V${cy - 8}H${cx + 1}" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>`
        + `<path d="M${cx + 11} ${cy - 1}A11 11 0 0 1 ${cx + 7} ${cy + 9} M${cx + 2} ${cy + 12}A11 11 0 0 1 ${cx - 6} ${cy + 10} M${cx - 10} ${cy + 5}A11 11 0 0 1 ${cx - 11} ${cy + 1}" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/></svg>`;
    }
    case "organize": {
      const t = (x, y, ch) => `<rect x="${x}" y="${y}" width="24" height="24" rx="7" fill="${light}"/><text x="${x + 12}" y="${y + 17}" text-anchor="middle" font-family="Manrope,-apple-system,Arial,sans-serif" font-weight="800" font-size="14" fill="${c}">${ch}</text>`;
      return `<svg viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true"><rect x="5" y="6" width="26" height="52" rx="8" fill="${c}"/>`
        + `<path d="M12 22l6-6 6 6M12 42l6 6 6-6" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="18" cy="32" r="2.8" fill="#fff"/>`
        + t(36, 6, "A") + t(36, 34, "B") + "</svg>";
    }
    case "edit":
      return `<svg viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true"><rect x="7" y="9" width="40" height="46" rx="9" fill="${light}"/>`
        + `<path d="M15 21h24M15 30h16M15 39h10" stroke="${c}" stroke-width="3.2" stroke-linecap="round"/>`
        + `<path d="M36 50l1-8L53 26a4.2 4.2 0 0 1 6 6L43 48z" fill="${c}"/><path d="M50 29l6 6" stroke="#fff" stroke-width="2.2"/></svg>`;
    case "pdf2word":
      body = tile(TL, light) + arrow(TL, "se", c) + tile(BR, c, true) + label(BR, "W", W, 20);
      break;
    case "pdf2ppt":
      body = tile(TL, light) + arrow(TL, "se", c) + tile(BR, c, true) + label(BR, "P", W, 20);
      break;
    case "pdf2jpg":
      body = tile(TL, light) + arrow(TL, "se", A) + tile(BR, c, true) + GLYPH.image(BR, W);
      break;
    case "word2pdf":
      body = tile(BR, c) + arrow(BR, "se", W) + tile(TL, light, true) + label(TL, "W", c, 20);
      break;
    case "jpg2pdf":
      body = tile(BR, light) + arrow(BR, "se", A) + tile(TL, c, true) + GLYPH.image(TL, W);
      break;
  }
  return `<svg viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true">${body}</svg>`;
}
