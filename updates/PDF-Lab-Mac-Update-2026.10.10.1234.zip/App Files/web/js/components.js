import { $, $$, el, esc, plural, fmtSize, toast, enqueue, renderPage, job, post, toolVars } from "./core.js";

const ARROW = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12h8M12 8l4 4-4 4"/></svg>';

/**
 * Builds the standard tool page: title, a big "select files" stage, and then a
 * workspace with a canvas on the left and an options sidebar on the right.
 *
 * cfg: { test(file)->bool, accept (input accept attr), multiple, pickLabel, dropHint,
 *        sideTitle, actionLabel, wrongType }
 */
export function createToolPage(tool, host, cfg) {
  host.innerHTML = `
    <div class="tool" style="${toolVars(tool)}">
      <section class="stage-pick">
        <h1>${esc(tool.title)}</h1>
        <p class="lead">${esc(tool.desc)}</p>
        <button class="big-btn" data-role="pick">${esc(cfg.pickLabel)}</button>
        <p class="drop-hint">${esc(cfg.dropHint)}</p>
      </section>
      <section class="stage-work" hidden>
        <div class="canvas"><div class="canvas-body" data-role="canvas"></div></div>
        <aside class="side">
          <div class="side-head"><h2>${esc(cfg.sideTitle || tool.title)}</h2></div>
          <div class="side-body" data-role="side"></div>
          <div class="side-foot">
            <button class="action" data-role="action"><span class="lbl">${esc(cfg.actionLabel)}</span>${ARROW}</button>
          </div>
        </aside>
      </section>
      <div class="job" hidden>
        <div class="job-card" role="dialog" aria-modal="true">
          <div class="job-work">
            <div class="job-title"></div>
            <div class="job-name" translate="no"></div>
            <div class="job-bar" role="progressbar" aria-label="Progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span></span></div>
            <div class="job-row"><strong class="job-pct">0%</strong><span class="job-step" aria-live="polite"></span></div>
            <button type="button" class="pill-btn small ghost job-cancel">Cancel</button>
          </div>
          <div class="job-done" hidden>
            <div class="job-done-head"><svg class="i-ok" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><svg class="i-fail" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg><strong class="job-done-title">Done</strong></div>
            <div class="job-did"></div>
            <div class="job-file"><strong class="job-file-name" translate="no"></strong><span class="job-file-size"></span></div>
            <div class="job-where"><span class="job-where-text"></span> <span class="job-where-path" translate="no"></span></div>
            <div class="job-note"></div>
            <div class="job-detail" translate="no" hidden></div>
            <button type="button" class="pill-btn job-close">Close</button>
          </div>
        </div>
      </div>
    </div>`;

  const root = $(".tool", host);
  const input = document.createElement("input");
  input.type = "file";
  input.hidden = true;
  input.multiple = !!cfg.multiple;
  if (cfg.accept) input.accept = cfg.accept;
  root.appendChild(input);

  /* ---- the progress card: one job at a time, shown over the workspace while the action runs ---- */
  const card = $(".job", root);
  const J = { on: false, shown: false, cancelled: false, done: false, writing: false, ctrl: null, plan: null, frac: 0, timer: 0, saved: null, did: "", note: "" };
  let actionText = cfg.actionLabel;
  class Cancelled extends Error {}
  const stopEstimate = () => { clearInterval(J.timer); J.timer = 0; };
  function paint() {
    const pct = J.done ? 100 : Math.min(99, Math.floor(J.frac * 100));
    $(".job-bar span", card).style.width = `${pct}%`;
    $(".job-bar", card).setAttribute("aria-valuenow", pct);
    if (J.pct !== pct) { J.pct = pct; $(".job-pct", card).textContent = `${pct}%`; }
  }
  /** The bar only moves forward. */
  const advance = (f) => { J.frac = Math.max(J.frac, Math.min(Math.max(f, 0), 1)); paint(); };
  function setStep(label) {
    if (label != null && J.step !== label) { J.step = label; $(".job-step", card).textContent = label; }
  }
  function showCard(name) {
    if (!J.on || J.cancelled) return;
    if (!J.shown) {
      J.shown = true;
      J.pct = J.step = null;
      $(".job-step", card).textContent = "";
      card.classList.remove("done");
      $(".job-work", card).hidden = false;
      $(".job-done", card).hidden = true;
      $(".job-title", card).textContent = actionText;
      $(".job-cancel", card).hidden = false;
      $(".job-cancel", card).disabled = false;
      card.hidden = false;
      paint();
    }
    const shown = (J.plan && J.plan.name) || name;
    if (shown) $(".job-name", card).textContent = shown;
  }
  function hideCard() { stopEstimate(); card.hidden = true; J.shown = false; }
  /** No real figure for this step: move steadily towards "to", slowing down, never reaching it before the step ends. */
  function estimate(ms, label, to = 0.95) {
    if (J.cancelled) throw new Cancelled();
    showCard();
    stopEstimate();
    setStep(label);
    const from = J.frac, t0 = performance.now(), tau = Math.max(ms, 200) * 0.55;
    J.timer = setInterval(() => advance(from + (to - from) * (1 - Math.exp(-(performance.now() - t0) / tau))), 100);
  }
  $(".job-cancel", card).addEventListener("click", () => {
    if (!J.on || J.writing || J.done) return;
    J.cancelled = true;
    J.ctrl?.abort();
    hideCard();
  });

  /** The job is finished: the card stays and says what was done, which file came out and where it is,
   *  until the user presses Close. */
  function showSummary() {
    stopEstimate();
    J.done = true;
    const saved = J.saved;
    card.classList.add("done");
    card.classList.remove("failed");
    $(".job-work", card).hidden = true;
    $(".job-done", card).hidden = false;
    $(".job-done-title", card).textContent = "Done";
    $(".job-did", card).textContent = J.did || "";
    $(".job-did", card).hidden = !J.did;
    $(".job-file", card).hidden = false;
    $(".job-file-name", card).textContent = saved.name;
    $(".job-file-size", card).textContent = fmtSize(saved.size);
    $(".job-note", card).textContent = J.note || "";
    $(".job-note", card).hidden = !J.note;
    $(".job-detail", card).hidden = true;
    // The browser does not tell a page which folder the user picked, so the app looks the file up on this computer.
    $(".job-where-text", card).textContent = saved.picked ? "Saved in the folder you chose."
      : saved.moved ? "The folder you chose could not be written to. Saved in your Downloads folder instead."
      : "Saved in your Downloads folder.";
    $(".job-where-path", card).textContent = "";
    let open = true;
    (async () => {
      for (const wait of [250, 900, 1800, 3000, 5000]) {
        await new Promise((ok) => setTimeout(ok, wait));
        if (!open || ctx.dead) return;
        try {
          const res = await post("/api/locate", { name: saved.name, size: saved.size });
          const found = res.ok ? await res.json() : null;
          if (found && found.display && open) {
            $(".job-where-text", card).textContent = "Saved in:";
            $(".job-where-path", card).textContent = found.display;
            $(".job-where-path", card).title = found.folder || "";
            return;
          }
        } catch (e) { /* the generic line stays */ }
      }
    })();
    return untilClosed(() => { open = false; });
  }

  /** The job failed after it had started: the card stays and says why, and that nothing was saved. */
  function showFailure(message, detail) {
    stopEstimate();
    J.done = true;
    card.classList.add("done", "failed");
    $(".job-work", card).hidden = true;
    $(".job-done", card).hidden = false;
    $(".job-done-title", card).textContent = "Not completed";
    $(".job-did", card).textContent = message;
    $(".job-did", card).hidden = false;
    $(".job-file", card).hidden = true;
    $(".job-where-text", card).textContent = "Nothing was saved.";
    $(".job-where-path", card).textContent = "";
    $(".job-note", card).hidden = true;
    $(".job-detail", card).textContent = detail || "";   // the technical reason, as the engine gave it
    $(".job-detail", card).hidden = !detail;
    return untilClosed(() => {});
  }

  function untilClosed(after) {
    const close = $(".job-close", card);
    return new Promise((ok) => {
      const finish = () => { after(); close.removeEventListener("click", finish); document.removeEventListener("keydown", onKey, true); ok(); };
      const onKey = (e) => {
        if (e.key !== "Escape" && e.key !== "Enter") return;
        e.preventDefault(); e.stopPropagation();
        finish();
      };
      close.addEventListener("click", finish);
      document.addEventListener("keydown", onKey, true);
      ctx.onDispose(finish);
      close.focus({ preventScroll: true });
    });
  }

  const disposers = [];
  const ctx = {
    root,
    tool,
    canvas: $('[data-role="canvas"]', root),
    side: $('[data-role="side"]', root),
    action: $('[data-role="action"]', root),
    onFiles: () => {},
    onDispose: (fn) => disposers.push(fn),
    dead: false, // set when the user leaves the tool: files that finish loading afterwards must be released
    dispose: () => { ctx.dead = true; disposers.splice(0).forEach((fn) => { try { fn(); } catch (e) {} }); },

    setStage(stage) {
      $(".stage-pick", root).hidden = stage !== "pick";
      $(".stage-work", root).hidden = stage !== "work";
    },
    openPicker() {
      input.value = "";
      input.click();
    },
    setActionLabel(text) {
      actionText = text;
      $(".lbl", ctx.action).textContent = text;
    },
    setEnabled(on) {
      ctx.action.disabled = !on;
    },
    /** Run an async job while the action button shows a busy state. The progress card appears as soon as the
     *  job starts producing a file (after the save dialog), fills to 100 % and says "Done" when it succeeds. */
    async run(work) {
      if (ctx.action.classList.contains("busy")) return;
      ctx.action.classList.add("busy");
      Object.assign(J, { on: true, shown: false, cancelled: false, done: false, writing: false, plan: null, frac: 0, saved: null, did: "", note: "", ctrl: new AbortController() });
      job.signal = J.ctrl.signal;
      job.onProduce = (name) => {
        showCard(name);
        if (J.plan && J.plan.ms && !J.timer && !J.frac) estimate(J.plan.ms, J.plan.label);
      };
      job.onWrite = () => {
        if (J.cancelled) throw new Cancelled();
        J.writing = true;
        stopEstimate();
        if (J.shown) { advance(0.97); setStep("Saving"); $(".job-cancel", card).disabled = true; }
      };
      job.onSaved = (info) => { J.saved = info; };
      try {
        const result = await work();
        if (J.shown && J.saved && !ctx.dead) await showSummary();   // stays until Close
        return result;
      } catch (e) {
        if (J.cancelled) toast("Cancelled. Nothing was saved.", "");
        else {
          console.error(e);
          // "Failed to fetch" is the browser's way of saying that the app itself did not answer
          const why = e instanceof TypeError && /fetch|network/i.test(e.message || "")
            ? "PDF Lab is not responding. Quit it, open it again, then try once more."
            : e.message || "Something went wrong.";
          if (J.shown && !ctx.dead) await showFailure(why, e.detail);   // stays until Close
          else toast(why, "error");
        }
      } finally {
        hideCard();
        J.on = false;
        job.signal = job.onProduce = job.onWrite = job.onSaved = null;
        ctx.action.classList.remove("busy");
      }
    },
    /** Before saving: what the card shows. name: the file being worked on (default: the file being produced);
     *  ms and label: how long the server step should take and what to call it, for steps without real figures. */
    plan(p) { J.plan = p; },
    /** Real progress of the running job: frac from 0 to 1 and what is happening now. Stops here when cancelled. */
    progress(frac, label) {
      if (frac == null || !J.on) return;
      if (J.cancelled) throw new Cancelled();
      showCard();
      stopEstimate();
      advance(frac);
      setStep(label);
    },
    /** What the finished job did, in a few words ("2 files merged"), and an optional remark. Shown when it ends. */
    summary(did, note = "") { J.did = did; J.note = note; },
    /** The name shown in the card changes (several files in one job). */
    jobName(name) { if (J.shown) $(".job-name", card).textContent = name; },
    estimate,
    drop(files) {
      const ok = files.filter(cfg.test);
      if (!ok.length) {
        toast(cfg.wrongType || "That file type is not supported here.", "error");
        return;
      }
      ctx.onFiles(cfg.multiple ? ok : ok.slice(0, 1));
    },
  };

  /* the side panel says when it holds more than it shows (.side.more in styles.css) */
  const sideBox = $(".side", root);
  let marking = false;
  const markMore = () => {
    if (marking) return;
    marking = true;
    requestAnimationFrame(() => {
      marking = false;
      sideBox.classList.toggle("more", ctx.side.scrollHeight - ctx.side.scrollTop - ctx.side.clientHeight > 6);
    });
  };
  ctx.side.addEventListener("scroll", markMore, { passive: true });
  const sized = new ResizeObserver(markMore), filled = new MutationObserver(markMore);
  sized.observe(ctx.side);
  filled.observe(ctx.side, { childList: true, subtree: true, characterData: true });
  ctx.onDispose(() => { sized.disconnect(); filled.disconnect(); });

  $('[data-role="pick"]', root).addEventListener("click", () => ctx.openPicker());
  input.addEventListener("change", () => ctx.drop([...input.files]));
  return ctx;
}

/* ------------------------------------------------------------------ */
/* Dragging to reorder: the others slide aside, a slot shows the place */
/* ------------------------------------------------------------------ */
const SLIDE_MS = 190;
const calm = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

/**
 * Lets the user reorder the children of a grid by dragging them.
 * The card in hand turns into an empty slot (class "dragging") and travels through the grid under the pointer; the
 * other cards slide aside as it passes, so the place where the card will land is always in view. Released anywhere
 * on the panel around the grid, the order stays. Released anywhere else, everything goes back.
 *
 * cfg: { item: selector of the cards, type: name of the drag data,
 *        started(el), moved(cards) after each move, done(el, cards) on drop, undone(el) when cancelled (default:
 *        the cards go back to where they were) }
 * One controller per grid, kept on the grid: calling this again only replaces cfg.
 * The controller: { el: the card in hand or null, adopt(el): that card was drawn again, here is the new one }.
 */
function liveSort(grid, cfg) {
  if (grid.__sort) { grid.__sort.cfg = cfg; return grid.__sort; }
  const S = grid.__sort = { cfg, el: null, start: null, before: null, dropped: false, inside: false, zone: null, adopt };
  const cards = () => [...grid.children].filter((c) => c.matches(S.cfg.item));

  /** Run a change of order, then let every card glide from where it was to where it now is. */
  function slide(change) {
    const all = cards();
    const before = new Map(all.map((c) => [c, c.getBoundingClientRect()]));
    all.forEach((c) => c.__slide?.cancel());
    change();
    if (calm()) return;
    for (const [c, was] of before) {
      const now = c.getBoundingClientRect();
      const dx = was.left - now.left, dy = was.top - now.top;
      if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) continue;
      const run = c.animate([{ transform: `translate(${dx}px, ${dy}px)` }, { transform: "none" }], { duration: SLIDE_MS, easing: "cubic-bezier(.2, .8, .2, 1)" });
      c.__slide = run;
      run.onfinish = run.oncancel = () => { if (c.__slide === run) c.__slide = null; };
    }
  }

  function over(e) {
    if (!S.el) return;
    e.preventDefault();                       // the whole panel takes the drop: no "not allowed" sign, no flying back
    e.dataTransfer.dropEffect = "move";
    const all = cards();
    const hit = e.target.closest?.(S.cfg.item);
    let before;                               // the slot goes in front of this element (null: at the very end)
    if (hit && hit.parentNode === grid) {
      if (hit === S.el || hit.__slide) return;            // over the slot itself, or over a card that is still gliding
      before = all.indexOf(S.el) < all.indexOf(hit) ? hit.nextElementSibling : hit;
    } else {
      // not over a card: only the empty space after the last card means "to the end" (never the gaps between cards)
      const last = all[all.length - 1];
      if (!last || last === S.el) return;
      const r = last.getBoundingClientRect();
      if (!(e.clientY > r.bottom || (e.clientY >= r.top && e.clientX > r.right))) return;
      before = last.nextElementSibling;
    }
    if (before === S.el || S.el.nextElementSibling === before) return;   // already there
    slide(() => grid.insertBefore(S.el, before));
    S.cfg.moved?.(cards());
  }

  function letGo(e) {
    if (!S.el) return;
    e.preventDefault();
    e.stopPropagation();
    S.dropped = true;
  }

  // Where the pointer last was. A browser only announces a drop on an element that has already answered one
  // "dragover", and a card that has just slid under a still pointer has not: so a release counts by its place.
  function track(e) { S.inside = !!S.zone && S.zone.contains(e.target); }

  /** The drag is over for this grid: no slot, no listening. Gives back the card that was in hand, if any. */
  function stop() {
    const el = S.el;
    if (S.zone) { S.zone.removeEventListener("dragover", over); S.zone.removeEventListener("drop", letGo); S.zone = null; }
    document.removeEventListener("dragover", track, true);
    grid.classList.remove("sorting");
    S.el = null;
    if (el) el.classList.remove("dragging");
    return el;
  }

  function finish() {
    const el = stop();
    if (!el) return;
    if (S.dropped || S.inside) { S.cfg.done?.(el, cards()); return; }
    if (S.cfg.undone) { S.cfg.undone(el); return; }
    const start = S.start.filter((c) => c.parentNode === grid);
    const tail = cards().pop()?.nextElementSibling || null;
    slide(() => start.forEach((c) => grid.insertBefore(c, tail)));
    S.cfg.moved?.(cards());
  }

  /** The card in hand was drawn again (the list changed during the drag): the new card takes over as the slot. */
  function adopt(el) {
    if (!S.el) return;
    if (!el) { stop(); return; }      // it is gone (removed, or replaced by what was read from it): nothing left to place
    S.el = el;
    el.classList.add("dragging");
    grid.classList.add("sorting");
  }

  grid.addEventListener("dragstart", (e) => {
    const el = e.target.closest?.(S.cfg.item);
    if (!el || el.parentNode !== grid || !el.draggable || e.target !== el) return;
    S.el = el; S.start = cards(); S.dropped = false; S.inside = true;
    e.dataTransfer.setData(S.cfg.type, "1");
    e.dataTransfer.effectAllowed = "move";
    S.cfg.started?.(el);
    // one frame later, so that the picture that follows the pointer is the card as it was, not the empty slot
    requestAnimationFrame(() => { if (S.el === el) { el.classList.add("dragging"); grid.classList.add("sorting"); } });
    S.zone = grid.closest(".canvas") || grid;
    S.zone.addEventListener("dragover", over);
    S.zone.addEventListener("drop", letGo);
    document.addEventListener("dragover", track, true);
    // on the card itself: the end of the drag is announced there even if the grid is drawn again meanwhile
    el.addEventListener("dragend", finish, { once: true });
  });
  return S;
}

/* ------------------------------------------------------------------ */
/* Card grid for lists of files, with drag to reorder                  */
/* ------------------------------------------------------------------ */

/**
 * opts: { items, thumb(item, thumbEl), meta(item) -> html, onChange(items), onRemove(item, i),
 *         onAdd(), extra(item, card, i), reorder: true }
 * Reordering by dragging changes opts.items itself, move by move (see liveSort): nothing is drawn again for it.
 */
export function renderFileGrid(grid, opts) {
  const { items } = opts;
  const sortable = opts.reorder !== false && items.length > 1;
  const held = grid.__sort?.el ? grid.__sort.el.__item : null;      // drawn again in the middle of a drag
  grid.innerHTML = "";
  items.forEach((item, i) => {
    const card = el("div", "file");
    card.__item = item;
    card.dataset.index = i;
    card.innerHTML = `
      <span class="badge">${i + 1}</span>
      <button class="x" title="Remove" aria-label="Remove ${esc(item.name)}">&times;</button>
      <div class="thumb loading"></div>
      <div class="name" translate="no" title="${esc(item.name)}">${esc(item.name)}</div>
      <div class="meta">${opts.meta(item)}</div>`;
    opts.thumb(item, $(".thumb", card));
    $(".x", card).addEventListener("click", (e) => {
      e.stopPropagation();
      opts.onRemove(item, items.indexOf(item));       // looked up now: the card may have been moved since it was drawn
    });
    if (opts.extra) opts.extra(item, card, i);
    if (sortable) card.draggable = true;
    grid.appendChild(card);
  });
  if (opts.onAdd) {
    const add = el("button", "add-tile", `<span class="plus">+</span><span>${esc(opts.addLabel || "Add more files")}</span>`);
    add.addEventListener("click", opts.onAdd);
    grid.appendChild(add);
  }
  if (!sortable && !grid.__sort) return;
  const number = (cards) => cards.forEach((c, k) => { c.dataset.index = k; $(".badge", c).textContent = k + 1; });
  const sort = liveSort(grid, {
    item: ".file", type: "text/x-pdflab",
    started() { grid.__sort.before = items.slice(); },
    moved(cards) { items.splice(0, items.length, ...cards.map((c) => c.__item)); number(cards); },
    undone() {
      // back to the order of before the drag; what was added meanwhile stays, at the end
      const before = grid.__sort.before || [];
      const now = new Set(items), old = new Set(before);
      items.splice(0, items.length, ...before.filter((x) => now.has(x)), ...items.filter((x) => !old.has(x)));
      opts.onChange(items);
    },
  });
  if (held) sort.adopt([...grid.children].find((c) => c.__item === held) || null);
}

/** Render the first page of a pdf.js doc into a thumb element, reusing a cached copy. */
export function pdfThumb(item, thumbEl, width = 220) {
  const canvas = document.createElement("canvas");
  thumbEl.appendChild(canvas);
  if (item.thumb) {
    canvas.width = item.thumb.width;
    canvas.height = item.thumb.height;
    canvas.getContext("2d").drawImage(item.thumb, 0, 0);
    thumbEl.classList.remove("loading");
    return;
  }
  enqueue(async () => {
    if (!thumbEl.isConnected) return;      // the card is gone (file removed, tool left): nothing to draw
    await renderPage(item.doc, 1, canvas, width);
    const copy = document.createElement("canvas");
    copy.width = canvas.width;
    copy.height = canvas.height;
    copy.getContext("2d").drawImage(canvas, 0, 0);
    item.thumb = copy;
    thumbEl.classList.remove("loading");
  });
}

/* ------------------------------------------------------------------ */
/* Page grid: lazily rendered page thumbnails with per page state      */
/* ------------------------------------------------------------------ */

export const GROUP_COLORS = ["#de7355", "#6a84c2", "#0b8f83", "#d4be4b", "#8b5cf6", "#e5484d", "#2f9e44", "#d6409f"];

/**
 * Creates a grid of pages. entries: [{doc, n}] (n is 1-based page of that doc).
 * opts: { scroller, width, onTile(tile, entry, index), draggable, onReorder(from,to) }
 * Returns { el, tiles, disconnect }.
 */
export function createPageGrid(entries, opts = {}) {
  const grid = el("div", "grid pages");
  const width = opts.width || 190;
  const observer = new IntersectionObserver(
    (list) => {
      for (const hit of list) {
        if (!hit.isIntersecting) continue;
        observer.unobserve(hit.target);
        const tile = hit.target;
        const entry = entries[Number(tile.dataset.i)];
        const canvas = $("canvas", tile);
        const thumb = $(".thumb", tile);
        const cache = (entry.doc.__thumbs ||= new Map());
        const cached = cache.get(entry.n);
        if (cached) {
          canvas.width = cached.width;
          canvas.height = cached.height;
          canvas.getContext("2d").drawImage(cached, 0, 0);
          thumb.classList.remove("loading");
          continue;
        }
        enqueue(async () => {
          if (!tile.isConnected) return;     // the page is gone (file removed, tool left): nothing to draw
          await renderPage(entry.doc, entry.n, canvas, width);
          const copy = document.createElement("canvas");
          copy.width = canvas.width;
          copy.height = canvas.height;
          copy.getContext("2d").drawImage(canvas, 0, 0);
          cache.set(entry.n, copy);
          thumb.classList.remove("loading");
        });
      }
    },
    // the box that scrolls is the card around the pages; a root that does not scroll would draw every page at once
    { root: opts.scroller?.closest?.(".canvas") || opts.scroller || null, rootMargin: "500px 0px" }
  );

  const tiles = entries.map((entry, i) => {
    const tile = el("div", "page");
    tile.dataset.i = i;
    tile.innerHTML = `
      <div class="thumb loading">
        <div class="rotbox"><canvas></canvas></div>
        <div class="mark"><svg viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M18 18L82 82M82 18L18 82" stroke="var(--danger)" stroke-width="7" stroke-linecap="round" fill="none" vector-effect="non-scaling-stroke"/></svg></div>
        <div class="tick"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div>
        <div class="tools"></div>
      </div>
      <div class="no">${opts.label ? opts.label(entry, i) : entry.n}</div>`;
    if (opts.aspect) $(".thumb", tile).style.aspectRatio = opts.aspect;
    if (opts.keys) { tile.tabIndex = 0; tile.setAttribute("role", "button"); tile.setAttribute("aria-label", `Page ${i + 1}`); }
    if (opts.onTile) opts.onTile(tile, entry, i);
    grid.appendChild(tile);
    observer.observe(tile);
    return tile;
  });

  if (opts.onReorder) enableTileReorder(grid, opts.onReorder);
  // keys: a page that is picked with a click is also reached with Tab and picked with Enter or Space
  if (opts.keys) grid.addEventListener("keydown", (e) => {
    if ((e.key !== "Enter" && e.key !== " ") || !e.target.classList?.contains("page")) return;
    e.preventDefault();
    e.target.dispatchEvent(new MouseEvent("click", { bubbles: true, shiftKey: e.shiftKey }));
  });

  return { el: grid, tiles, disconnect: () => observer.disconnect() };
}

/** Page tiles reordered by dragging (see liveSort). The page numbers under the tiles follow while the tile is in hand. */
function enableTileReorder(grid, onReorder) {
  liveSort(grid, {
    item: ".page", type: "text/x-pdflab-page",
    moved(tiles) { tiles.forEach((t, k) => { const no = $(".no", t); if (no && /^\d+$/.test(no.textContent.trim())) no.textContent = k + 1; }); },
    done(tile, tiles) {
      const from = Number(tile.dataset.i), to = tiles.indexOf(tile);
      if (from !== to) onReorder(from, to);
    },
  });
}

/** Rotate the canvas inside a tile. deg is a multiple of 90. */
export function setTileRotation(tile, deg, aspect = 0.75) {
  const box = $(".rotbox", tile);
  const quarter = ((deg % 360) + 360) % 360;
  const odd = quarter === 90 || quarter === 270;
  const k = odd ? Math.min(aspect, 1 / aspect) : 1;
  box.style.transform = `rotate(${quarter}deg) scale(${k})`;
}

export const seg = (name, options, value) =>
  `<div class="seg" data-seg="${name}">${options
    .map((o) => `<button type="button" class="${o.value === value ? "on" : ""}" data-v="${esc(o.value)}">${esc(o.label)}</button>`)
    .join("")}</div>`;

/** Wire up a segmented control created with seg(); calls fn(value) on change. */
export function bindSeg(root, name, fn) {
  const wrap = $(`[data-seg="${name}"]`, root);
  wrap.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    $$("button", wrap).forEach((x) => x.classList.toggle("on", x === b));
    fn(b.dataset.v);
  });
}

export { plural, fmtSize };
