/* Pictures of every format, in and out.
 *
 * In (Image to PDF): preparePicture(file) gives back pictures that Chrome can show, whatever the file was.
 *   - JPG, PNG, WebP, GIF, BMP, AVIF, SVG, ICO: Chrome shows them, they are used as they are.
 *   - HEIC and HEIF (iPhone photos): turned into JPG, or PNG when they have transparent parts, by heic-worker.js.
 *   - everything else (TIFF, JPEG 2000, JPEG XL, Photoshop, PNM, camera RAW on a Mac ...): turned into PNG by
 *     the app itself (/api/picture in server.py). A TIFF that holds several pictures gives one picture each.
 * The kind of a file is read from its first bytes, not from its name: a HEIC called ".jpg" is still read as a HEIC.
 * When the first way fails, the other one is tried before the file is refused.
 *
 * Out (PDF to Image): canvasToTiff() writes a TIFF, the one format a browser cannot write by itself.
 */
import { upload, discard, post, failure, stem } from "./core.js";

const NATIVE_EXT = ["jpg", "jpeg", "jfif", "pjpeg", "pjp", "jpe", "png", "apng", "webp", "gif", "bmp", "dib", "avif", "svg", "ico", "cur"];
const HEIF_EXT = ["heic", "heif", "hif", "heics", "heifs", "avci", "avcs"];
const ENGINE_EXT = ["tif", "tiff", "jp2", "j2k", "j2c", "jpc", "jpf", "jpx", "jpm", "jxl", "psd", "psb", "pbm", "pgm", "ppm", "pnm", "pam"];
const RAW_EXT = ["dng", "cr2", "cr3", "crw", "nef", "nrw", "arw", "srf", "sr2", "orf", "rw2", "raf", "pef", "srw", "x3f", "3fr", "erf", "kdc", "dcr", "mrw", "raw", "rwl", "iiq", "mos", "mef", "fff", "gpr"];
const OTHER_EXT = ["tga", "icns", "exr", "hdr", "pcx", "sgi", "pict", "pct", "jxr", "wdp", "hdp", "dds", "qoi", "xbm"];   // a Mac reads most of these
const ALL_EXT = [...NATIVE_EXT, ...HEIF_EXT, ...ENGINE_EXT, ...RAW_EXT, ...OTHER_EXT];
const EXT_RE = new RegExp(`\\.(${ALL_EXT.join("|")})$`, "i");

/** A file this tool should try: its type or its name says "picture". */
export const isPicture = (f) => /^image\//i.test(f.type || "") || EXT_RE.test(f.name || "");
/** For the file window: every picture, and the names browsers do not know as pictures. */
export const PICTURE_ACCEPT = "image/*," + ALL_EXT.map((e) => "." + e).join(",");

const extOf = (name) => (/\.([a-z0-9]+)$/i.exec(name || "") || ["", ""])[1].toLowerCase();
const damaged = (name) => new Error(`'${name}' could not be read. It may be damaged.`);
const unknown = (name) => new Error(`'${name}' is not a picture PDF Lab can read.`);
const tooLarge = (name) => new Error(`'${name}' is too large to convert.`);

/** "native" (Chrome shows it), "heif" (iPhone photo) or "other", from the first bytes of the file. */
export async function pictureKind(file) {
  const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
  const text = (a, b) => String.fromCharCode(...head.subarray(a, Math.min(b, head.length)));
  const ext = extOf(file.name);
  if (head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff) return "native";               // JPG
  if (text(0, 8) === "\x89PNG\r\n\x1a\n") return "native";
  if (text(0, 4) === "GIF8") return "native";
  if (text(0, 4) === "RIFF" && text(8, 12) === "WEBP") return "native";
  if (text(0, 2) === "BM" && (ext === "bmp" || ext === "dib" || /bmp/i.test(file.type))) return "native";
  // an icon starts like some TGA files: only the name tells them apart
  if ((ext === "ico" || ext === "cur") && head[0] === 0 && head[1] === 0 && (head[2] === 1 || head[2] === 2) && head[3] === 0) return "native";
  if (text(4, 8) === "ftyp") {
    const size = Math.min(((head[0] << 24) | (head[1] << 16) | (head[2] << 8) | head[3]) >>> 0, head.length);
    const brands = [text(8, 12)];
    for (let at = 16; at + 4 <= size; at += 4) brands.push(text(at, at + 4));
    if (brands.some((b) => b === "avif" || b === "avis")) return "native";
    if (brands.some((b) => /^(hei[cxms]|hev[cxms]|mif1|msf1|miaf|MiHE|MiHB|MiPr)$/.test(b))) return "heif";
    return "other";
  }
  const start = new TextDecoder("utf-8", { fatal: false }).decode(head).replace(/^﻿/, "").trimStart();
  if (start.startsWith("<") && /<svg[\s>]/i.test(start)) return "native";
  if (ext === "svg" && start.startsWith("<")) return "native";
  return "other";
}

/** Let Chrome open the picture: its address for a preview, and its size. Rejects when Chrome cannot show it. */
export function showable(blob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      if (img.naturalWidth > 0 && img.naturalHeight > 0) resolve({ url, w: img.naturalWidth, h: img.naturalHeight });
      else { URL.revokeObjectURL(url); reject(new Error("no size")); }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("not shown")); };
    img.src = url;
  });
}

/** A ".dib" is a BMP that lost its first 14 bytes. With them back, Chrome shows it. Null when it is something else. */
async function dibAsBmp(file) {
  const head = new DataView(await file.slice(0, 64).arrayBuffer());
  if (head.byteLength < 40) return null;
  const size = head.getUint32(0, true);
  if (![12, 40, 52, 56, 108, 124].includes(size)) return null;
  const bits = head.getUint16(size === 12 ? 10 : 14, true);
  const packing = size === 12 ? 0 : head.getUint32(16, true);
  const colours = size === 12 ? 0 : head.getUint32(32, true);
  let extra = bits <= 8 ? (colours || 1 << bits) * (size === 12 ? 3 : 4) : 0;       // the colour table
  if (size === 40 && (packing === 3 || packing === 6)) extra += packing === 3 ? 12 : 16;   // colour masks after the header
  const first = new DataView(new ArrayBuffer(14));
  first.setUint8(0, 0x42); first.setUint8(1, 0x4d);
  first.setUint32(2, 14 + file.size, true);
  first.setUint32(10, 14 + size + extra, true);
  return new File([first, file], stem(file.name) + ".bmp", { type: "image/bmp" });
}

/* ---------------- iPhone photos: one worker, started when the first HEIC arrives ---------------- */
let worker = null, serial = 0;
const waiting = new Map();
function stopWorker(reason) {
  if (worker) worker.terminate();
  worker = null;
  for (const w of waiting.values()) { clearTimeout(w.timer); w.done({ ok: false, error: reason }); }
  waiting.clear();
}
function heic(buffer) {
  if (!worker) {
    worker = new Worker(new URL("./heic-worker.js", import.meta.url));
    worker.onmessage = (e) => {
      const w = waiting.get(e.data.id);
      if (!w) return;
      waiting.delete(e.data.id);
      clearTimeout(w.timer);
      w.done(e.data);
    };
    worker.onerror = () => stopWorker("engine");
  }
  return new Promise((done) => {
    const id = ++serial;
    // a worker that ran out of memory can die without a word: after 3 minutes the photo counts as too large
    waiting.set(id, { done, timer: setTimeout(() => stopWorker("large"), 180000) });
    worker.postMessage({ id, buffer }, [buffer]);
  });
}
/** Free the memory of the photo reader (called when the user leaves the tool). */
export function releaseDecoders() { stopWorker("engine"); }

/* ---------------- one file in, pictures out ---------------- */

/** Ask the app to read a picture Chrome cannot show. Gives [{ id, blob, pages }] one call at a time. */
async function fromApp(sourceId, page) {
  const res = await post("/api/picture", { id: sourceId, page });
  if (!res.ok) throw await failure(res);
  return { id: res.headers.get("X-Id"), pages: Number(res.headers.get("X-Pages")) || 1, blob: await res.blob() };
}

/**
 * Turns one file into pictures ready for /api/images2pdf: [{ id, name, source, size, url, w, h }] (source: the
 * name of the file a picture comes from).
 * One file gives one picture, except a TIFF with several pictures. stopped(): true when the result is no longer
 * wanted (the user removed the file or left the tool); what was made so far is then released.
 */
export async function preparePicture(file, stopped = () => false) {
  const made = [];
  const giveUp = () => { made.forEach(releasePicture); made.length = 0; return made; };
  const add = (id, shown, label) => made.push({ id, name: label || file.name, source: file.name, size: file.size, ...shown });
  if (!file.size) throw damaged(file.name);
  let kind = await pictureKind(file);
  let asIs = file;                       // what Chrome is given to show
  if (kind === "other" && extOf(file.name) === "dib") {
    const bmp = await dibAsBmp(file);
    if (bmp) { asIs = bmp; kind = "native"; }
  }

  // 1. Chrome shows it: used as it is
  if (kind === "native") {
    let shown = null;
    try { shown = await showable(asIs); } catch (e) { /* not shown after all: the app tries below */ }
    if (shown) {
      let info;
      try { info = await upload(asIs, "file"); } catch (e) { URL.revokeObjectURL(shown.url); throw e; }
      add(info.id, shown);
      return stopped() ? giveUp() : made;
    }
  }

  // 2. an iPhone photo: read in the page
  let heicProblem = null;
  if (kind === "heif") {
    const out = await heic(await file.arrayBuffer());
    if (stopped()) return giveUp();
    if (out.ok) {
      let shown;
      try { shown = await showable(out.blob); } catch (e) { throw tooLarge(file.name); }
      const turned = new File([out.blob], stem(file.name) + (out.type === "image/png" ? ".png" : ".jpg"), { type: out.type });
      let info;
      try { info = await upload(turned, "file"); } catch (e) { URL.revokeObjectURL(shown.url); throw e; }
      add(info.id, shown);
      return stopped() ? giveUp() : made;
    }
    if (out.error === "large") { stopWorker("engine"); throw tooLarge(file.name); }
    heicProblem = out.error;
    if (out.error === "engine") { console.error("The iPhone photo reader did not start:", out.detail || ""); stopWorker("engine"); }
  }

  // 3. everything else, and what the two ways above could not read: the app reads it
  const source = await upload(file, "file");
  try {
    let pages = 1;
    for (let page = 0; page < pages; page++) {
      if (stopped()) return giveUp();
      let got;
      try { got = await fromApp(source.id, page); } catch (e) {
        if (page > 0) break;                                   // the first pictures of the file are kept
        if (heicProblem === "damaged" || kind === "native") throw damaged(file.name);
        throw e;
      }
      pages = got.pages;
      let shown;
      try { shown = await showable(got.blob); } catch (e) { discard(got.id); throw tooLarge(file.name); }
      add(got.id, shown, pages > 1 ? `${file.name} · ${page + 1}/${pages}` : file.name);
    }
    if (!made.length) throw unknown(file.name);
    return stopped() ? giveUp() : made;
  } catch (e) { giveUp(); throw e; } finally { discard(source.id); }
}

/** Forget a prepared picture: its preview and the copy the app keeps. */
export function releasePicture(p) {
  if (!p) return;
  if (p.url) URL.revokeObjectURL(p.url);
  if (p.id) discard(p.id);
}

/* ---------------- TIFF out ---------------- */

async function deflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("deflate"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/**
 * The canvas as a TIFF file (a Blob): 8 bit RGB, lossless (Deflate), with its resolution written in.
 * The picture is cut in bands of about 4 million pixels, so even a very large page never needs a second full copy.
 */
export async function canvasToTiff(canvas, dpi = 72) {
  const w = canvas.width, h = canvas.height;
  if (!w || !h) return null;
  const g = canvas.getContext("2d");
  const rows = Math.max(1, Math.min(h, Math.floor(4e6 / w)));
  const strips = [];
  for (let y = 0; y < h; y += rows) {
    const n = Math.min(rows, h - y);
    const rgba = g.getImageData(0, y, w, n).data;
    const rgb = new Uint8Array(w * n * 3);
    for (let i = 0, o = 0; i < rgba.length; i += 4) { rgb[o++] = rgba[i]; rgb[o++] = rgba[i + 1]; rgb[o++] = rgba[i + 2]; }
    strips.push(await deflate(rgb));
  }
  const count = strips.length;
  const dataSize = strips.reduce((s, b) => s + b.length, 0);
  // layout: header (8) | picture data | bits per sample (6) | resolution (8) | strip offsets | strip sizes | directory
  const pad = dataSize & 1;
  const bitsAt = 8 + dataSize + pad, resAt = bitsAt + 6;
  const offsetsAt = resAt + 8, sizesAt = offsetsAt + (count > 1 ? count * 4 : 0), dirAt = sizesAt + (count > 1 ? count * 4 : 0);
  const TAGS = 13;
  const tail = new DataView(new ArrayBuffer(dirAt - (8 + dataSize) + 2 + TAGS * 12 + 4));
  const base = 8 + dataSize;   // file position of the start of "tail"
  let at = bitsAt - base;
  for (let i = 0; i < 3; i++) tail.setUint16(at + i * 2, 8, true);
  at = resAt - base; tail.setUint32(at, Math.round(dpi * 1000), true); tail.setUint32(at + 4, 1000, true);
  let pos = 8;
  for (let i = 0; i < count; i++) {
    if (count > 1) { tail.setUint32(offsetsAt - base + i * 4, pos, true); tail.setUint32(sizesAt - base + i * 4, strips[i].length, true); }
    pos += strips[i].length;
  }
  at = dirAt - base;
  tail.setUint16(at, TAGS, true); at += 2;
  const tag = (id, type, n, value) => { tail.setUint16(at, id, true); tail.setUint16(at + 2, type, true); tail.setUint32(at + 4, n, true); if (type === 3 && n === 1) tail.setUint16(at + 8, value, true); else tail.setUint32(at + 8, value, true); at += 12; };
  tag(256, 4, 1, w);                         // width
  tag(257, 4, 1, h);                         // height
  tag(258, 3, 3, bitsAt);                    // 8, 8, 8 bits
  tag(259, 3, 1, 8);                         // Deflate
  tag(262, 3, 1, 2);                         // RGB
  tag(273, 4, count, count > 1 ? offsetsAt : 8);            // where each band starts
  tag(277, 3, 1, 3);                         // 3 samples a pixel
  tag(278, 4, 1, rows);                      // rows in a band
  tag(279, 4, count, count > 1 ? sizesAt : strips[0].length);   // size of each band
  tag(282, 5, 1, resAt);                     // horizontal resolution
  tag(283, 5, 1, resAt);                     // vertical resolution
  tag(284, 3, 1, 1);                         // samples stored together
  tag(296, 3, 1, 2);                         // resolution in inches
  tail.setUint32(at, 0, true);               // no other picture
  const header = new DataView(new ArrayBuffer(8));
  header.setUint16(0, 0x4949, true); header.setUint16(2, 42, true); header.setUint32(4, dirAt, true);
  if (dirAt + 2 + TAGS * 12 + 4 > 0xffffffff) return null;   // a TIFF of this kind stops at 4 GB
  return new Blob([header, ...strips, tail], { type: "image/tiff" });
}
