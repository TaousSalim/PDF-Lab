import {
  $, $$, el, esc, plural, fmtSize, toast, stem, fname, upload, openPdf, discard, release, post, postBlob, saveFile,
  renderPage, canvasToBlob, blobToBase64, readError, estMs, job,
} from "./core.js";
import { createToolPage, renderFileGrid, createPageGrid, seg, bindSeg } from "./components.js";
import { extractLines, buildBlocks, buildBoxes } from "./textlines.js";
import { wordToPrintable } from "./word.js";
import { isPicture, PICTURE_ACCEPT, preparePicture, releasePicture, releaseDecoders, canvasToTiff } from "./images.js";

const isPdf = (f) => f.type === "application/pdf" || /\.pdf$/i.test(f.name);
const PDF_CFG = { test: isPdf, accept: "application/pdf,.pdf", wrongType: "Only PDF files are supported here." };

async function aspectOf(doc) {
  const page = await doc.getPage(1);
  const v = page.getViewport({ scale: 1 });
  return Math.min(Math.max(v.width / v.height, 0.5), 2);
}

/** Largest render scale a canvas can take: Chrome refuses canvases beyond 65535 px a side or with too many pixels. */
function safeScale(base, scale, maxPixels = 70e6, maxSide = 65000) {
  scale = Math.min(scale, maxSide / Math.max(base.width, base.height));
  if (base.width * base.height * scale * scale > maxPixels) scale = Math.sqrt(maxPixels / (base.width * base.height));
  return scale;
}

/** Shared scaffolding for "one PDF in, preview its pages, convert" tools. */
function pdfSource(tool, host, cfg) {
  const ctx = createToolPage(tool, host, { ...PDF_CFG, multiple: false, pickLabel: "Select PDF file", dropHint: "or drop a PDF here", ...cfg });
  const st = { file: null, grid: null, aspect: 0.75, onGrid: null };
  ctx.state = st;
  ctx.onDispose(() => { release(st.file); st.grid?.disconnect(); });
  ctx.canvas.innerHTML = `
    <div class="doc-head">
      <div class="doc-title"><strong data-k="name" translate="no"></strong><span class="muted" data-k="meta"></span></div>
      <button class="pill-btn small ghost" data-act="change">Choose another file</button>
    </div>
    <div data-role="grid"></div>`;
  $('[data-act="change"]', ctx.canvas).addEventListener("click", () => ctx.openPicker());

  ctx.mountGrid = (gridOpts = {}) => {
    st.grid?.disconnect();
    const holder = $('[data-role="grid"]', ctx.canvas);
    holder.innerHTML = "";
    const entries = Array.from({ length: st.file.pages }, (_, i) => ({ doc: st.file.doc, n: i + 1 }));
    st.grid = createPageGrid(entries, { scroller: ctx.canvas, aspect: st.aspect, width: 170, ...gridOpts });
    holder.appendChild(st.grid.el);
  };
  ctx.loadFile = async (file, after) => {
    try {
      const f = await openPdf(file);
      if (ctx.dead) { release(f); return; }
      f.base = stem(f.name);
      st.grid?.disconnect();
      release(st.file);
      st.file = f;
      st.aspect = await aspectOf(f.doc);
      $('[data-k="name"]', ctx.canvas).textContent = f.name;
      $('[data-k="meta"]', ctx.canvas).textContent = `${plural(f.pages, "page")} · ${fmtSize(f.size)}`;
      ctx.canvas.scrollTop = 0;
      ctx.setStage("work");
      after(f);
    } catch (e) {
      toast(e.message || `Could not open ${file.name}`, "error");
    }
  };
  return ctx;
}

/* ================================================================== */
/* PDF to Image (tool id "pdf2jpg": the address #/pdf2jpg is kept)     */
/* ================================================================== */
const DPI = { standard: 150, high: 200, max: 300 };
// maxSide: the longest side the format can hold. type: what the browser writes by itself (TIFF is written by images.js).
const FORMATS = {
  png: { label: "PNG", ext: "png", type: "image/png", note: "lossless, larger files" },
  jpg: { label: "JPG", ext: "jpg", type: "image/jpeg", note: "good size and quality" },
  webp: { label: "WebP", ext: "webp", type: "image/webp", note: "smallest files, good quality", maxSide: 16383 },
  tiff: { label: "TIFF", ext: "tif", type: null, note: "lossless, for printing and archives" },
};

export function mountPdf2Jpg(tool, host) {
  const ctx = pdfSource(tool, host, { sideTitle: "PDF to Image", actionLabel: "Convert to PNG" });
  const st = ctx.state;
  const sel = new Set();
  const opt = { format: "png", quality: "high" };

  ctx.side.innerHTML = `
    <div class="note">Every selected page becomes an image. Click pages to include or skip them.</div>
    <div class="label">Image format</div>
    ${seg("fmt", Object.entries(FORMATS).map(([value, f]) => ({ value, label: f.label })), opt.format)}
    <div class="label">Quality</div>
    ${seg("q", [{ value: "standard", label: "Standard" }, { value: "high", label: "High" }, { value: "max", label: "Maximum" }], opt.quality)}
    <div class="hint" data-k="dpi"></div>
    <div class="stat-list"><div><span>Pages to convert</span><strong data-k="n">0</strong></div></div>
    <div class="btn-row"><button class="pill-btn small" data-act="all">Select all</button><button class="pill-btn small ghost" data-act="none">Clear</button></div>`;

  function paint() {
    const fmt = FORMATS[opt.format];
    st.grid.tiles.forEach((t, i) => t.classList.toggle("selected", sel.has(i + 1)));
    $('[data-k="n"]', ctx.side).textContent = sel.size;
    $('[data-k="dpi"]', ctx.side).textContent = `${DPI[opt.quality]} dpi, ${fmt.note}.`;
    ctx.setEnabled(sel.size > 0);
    ctx.setActionLabel(`Convert to ${fmt.label}`);
  }
  bindSeg(ctx.side, "fmt", (v) => { opt.format = v; paint(); });
  bindSeg(ctx.side, "q", (v) => { opt.quality = v; paint(); });
  $('[data-act="all"]', ctx.side).addEventListener("click", () => { for (let n = 1; n <= st.file.pages; n++) sel.add(n); paint(); });
  $('[data-act="none"]', ctx.side).addEventListener("click", () => { sel.clear(); paint(); });

  ctx.onFiles = ([file]) => ctx.loadFile(file, (f) => {
    sel.clear();
    for (let n = 1; n <= f.pages; n++) sel.add(n);
    ctx.mountGrid({ keys: true, onTile: (tile, _e, i) => tile.addEventListener("click", () => { sel.has(i + 1) ? sel.delete(i + 1) : sel.add(i + 1); paint(); }) });
    paint();
  });

  async function renderToBlob(doc, n, fmt, dpi) {
    const page = await doc.getPage(n);
    const base = page.getViewport({ scale: 1 });
    const scale = safeScale(base, dpi / 72, 70e6, fmt.maxSide || 65000);
    const canvas = document.createElement("canvas");
    await renderPage(doc, n, canvas, 0, { scale });
    const blob = fmt.type ? await canvasToBlob(canvas, fmt.type, 0.92) : await canvasToTiff(canvas, Math.round(scale * 72));
    canvas.width = canvas.height = 0;
    // a browser that cannot write the format answers with a PNG: that is not what was asked for
    if (!blob || (fmt.type && blob.type !== fmt.type)) throw new Error(`Page ${n} is too large to turn into an image.`);
    return blob;
  }

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const f = st.file;
    const nums = [...sel].sort((a, b) => a - b);
    const fmt = FORMATS[opt.format], dpi = DPI[opt.quality];
    const pad = String(f.pages).length;
    const nameOf = (n) => `${f.base}_page_${String(n).padStart(pad, "0")}.${fmt.ext}`;
    const target = nums.length === 1 ? nameOf(nums[0]) : `${f.base}_images.zip`;
    ctx.plan({ name: f.name });
    const saved = await saveFile(target, async () => {
      const zip = nums.length > 1 ? new window.JSZip() : null;
      let single = null;
      for (let k = 0; k < nums.length; k++) {
        ctx.progress((k / nums.length) * 0.96, `Page ${nums[k]} (${k + 1} of ${nums.length})`);
        const blob = await renderToBlob(f.doc, nums[k], fmt, dpi);
        if (zip) zip.file(nameOf(nums[k]), blob);
        else single = blob;
      }
      ctx.progress(0.96, "Packing files");
      return zip ? zip.generateAsync({ type: "blob", compression: "STORE" }) : single;
    });
    if (saved) ctx.summary(`${plural(nums.length, "page")} converted to ${fmt.label}`);
  }));
  ctx.setEnabled(false);
  return ctx;
}

/* ================================================================== */
/* Image to PDF (tool id "jpg2pdf": the address #/jpg2pdf is kept)     */
/* ================================================================== */
// Every picture format goes in: see images.js for how each one is read.
export function mountJpg2Pdf(tool, host) {
  const ctx = createToolPage(tool, host, {
    test: isPicture,
    accept: PICTURE_ACCEPT,
    wrongType: "Please choose image files: JPG, PNG, iPhone photos (HEIC), TIFF, WebP and more.",
    multiple: true,
    pickLabel: "Select images",
    dropHint: "or drop any images here, iPhone photos included",
    actionLabel: "Convert to PDF",
  });
  // a picture that is ready: { id, name, size, url, w, h }. A file still being read: { pending: true, name, size, file }
  const images = [];
  const opt = { page: "a4", orientation: "auto", margin: "none", merge: true };
  ctx.onDispose(() => { images.forEach((i) => { i.cancelled = true; releasePicture(i); }); releaseDecoders(); });

  ctx.canvas.innerHTML = '<div class="grid files"></div>';
  const grid = $(".grid", ctx.canvas);
  ctx.side.innerHTML = `
    <div class="label">Page size</div>
    ${seg("page", [{ value: "fit", label: "Fit image" }, { value: "a4", label: "A4" }, { value: "letter", label: "US Letter" }], opt.page)}
    <div class="label">Orientation</div>
    ${seg("ori", [{ value: "auto", label: "Auto" }, { value: "portrait", label: "Portrait" }, { value: "landscape", label: "Landscape" }], opt.orientation)}
    <div class="label">Margin</div>
    ${seg("mar", [{ value: "none", label: "None" }, { value: "small", label: "Small" }, { value: "big", label: "Big" }], opt.margin)}
    <label class="check"><input type="checkbox" data-role="merge" checked> <span>Merge all images into one PDF</span></label>
    <div class="hint">Drag the images to change their order.</div>`;
  bindSeg(ctx.side, "page", (v) => { opt.page = v; $('[data-seg="ori"]', ctx.side).classList.toggle("disabled", v === "fit"); });
  bindSeg(ctx.side, "ori", (v) => { opt.orientation = v; });
  bindSeg(ctx.side, "mar", (v) => { opt.margin = v; });
  $('[data-role="merge"]', ctx.side).addEventListener("change", (e) => { opt.merge = e.target.checked; paint(); });

  function paint() {
    ctx.setStage(images.length ? "work" : "pick");
    const ready = images.filter((i) => !i.pending).length;
    renderFileGrid(grid, {
      items: images,
      // a file still being read keeps the moving "loading" look until its picture is there
      thumb: (im, t) => { if (im.pending) return; t.classList.remove("loading"); t.innerHTML = `<img src="${im.url}" alt="">`; },
      meta: (im) => (im.pending ? "Reading the image" : `${im.w} &times; ${im.h} &middot; ${fmtSize(im.size)}`),
      onChange: paint,
      onRemove: (im, i) => { im.cancelled = true; releasePicture(im); images.splice(i, 1); paint(); },
      onAdd: () => ctx.openPicker(), addLabel: "Add images",
    });
    ctx.setEnabled(ready > 0 && ready === images.length);
    ctx.setActionLabel(ready > 1 && !opt.merge ? "Convert to PDFs (ZIP)" : "Convert to PDF");
  }

  ctx.onFiles = async (list) => {
    // every file gets its place at once, then they are read one after the other
    const slots = list.map((file) => ({ pending: true, name: file.name, size: file.size, file }));
    images.push(...slots);
    paint();
    for (const slot of slots) {
      if (ctx.dead) return;
      if (slot.cancelled) continue;
      const gone = () => ctx.dead || slot.cancelled;
      try {
        const made = await preparePicture(slot.file, gone);
        const at = images.indexOf(slot);
        if (gone() || at < 0) made.forEach(releasePicture);
        else images.splice(at, 1, ...made);
      } catch (e) {
        const at = images.indexOf(slot);
        if (at >= 0) images.splice(at, 1);
        if (!gone()) toast(e.message || `'${slot.name}' is not a picture PDF Lab can read.`, "error");
      }
      if (!ctx.dead) paint();
    }
  };

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const items = images.map((i) => ({ id: i.id, w: i.w, h: i.h }));
    const payload = { items, page: opt.page, orientation: opt.orientation, margin: opt.margin, merge: opt.merge };
    const zip = !opt.merge && items.length > 1;
    // pictures that all come from one file (a single picture, or a TIFF with several) give a PDF with its name
    const sources = new Set(images.map((i) => i.source || i.name));
    const target = zip ? "images_pdf.zip" : sources.size === 1 ? `${stem([...sources][0])}.pdf` : "images.pdf";
    ctx.plan({ name: sources.size === 1 ? [...sources][0] : null, ms: 1200 + items.length * 300 + estMs(images.reduce((n, i) => n + i.size, 0), 0, 60), label: "Converting" });
    const name = await saveFile(target, () => postBlob("/api/images2pdf", payload));
    if (name) ctx.summary(`${plural(items.length, "image")} converted to PDF`);
  }));
  ctx.setEnabled(false);
  paint();
  return ctx;
}

/* ================================================================== */
/* Word to PDF                                                         */
/* ================================================================== */
const DOC_RE = /\.(docx|doc)$/i;

async function docToDocxBuffer(file) {
  if (/\.docx$/i.test(file.name)) return file.arrayBuffer();
  const res = await fetch("/api/doc2docx", { method: "POST", body: file, signal: job.signal || undefined });
  if (!res.ok) throw new Error(await readError(res));
  return res.arrayBuffer();
}

export function mountWord2Pdf(tool, host) {
  const ctx = createToolPage(tool, host, {
    test: (f) => DOC_RE.test(f.name),
    accept: ".docx,.doc,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword",
    wrongType: "Please choose a Word file (.docx or .doc).",
    multiple: true,
    pickLabel: "Select Word files",
    dropHint: "or drop DOC and DOCX files here",
    sideTitle: "Word to PDF",
    actionLabel: "Convert to PDF",
  });
  const files = [];
  ctx.canvas.innerHTML = '<div class="grid files"></div>';
  const grid = $(".grid", ctx.canvas);
  ctx.side.innerHTML = `
    <div class="note">Your document is converted on this Mac. Page size, margins, headers, footers, page numbers, lists, tables, pictures and shapes follow the Word file.</div>
    <div class="stat-list"><div><span>Files</span><strong data-k="n">0</strong></div></div>
    <div class="hint">Several files at once are saved together as a ZIP.</div>`;

  const wordThumb = (f, t) => {
    t.classList.remove("loading");
    t.innerHTML = `<div class="docglyph"><svg viewBox="0 0 64 64" width="64" height="64"><rect x="8" y="4" width="48" height="56" rx="8" fill="var(--tc)"/><text x="32" y="43" text-anchor="middle" font-family="Manrope,Arial,sans-serif" font-weight="800" font-size="30" fill="#fff">W</text></svg><span>${esc((f.name.split(".").pop() || "").toUpperCase())}</span></div>`;
  };

  function paint() {
    ctx.setStage(files.length ? "work" : "pick");
    renderFileGrid(grid, {
      items: files, reorder: false, thumb: wordThumb,
      meta: (f) => fmtSize(f.size),
      onChange: paint,
      onRemove: (f, i) => { files.splice(i, 1); paint(); },
      onAdd: () => ctx.openPicker(), addLabel: "Add Word files",
    });
    $('[data-k="n"]', ctx.side).textContent = files.length;
    ctx.setEnabled(files.length > 0);
  }
  ctx.onFiles = (list) => { list.forEach((file) => files.push({ file, name: file.name, size: file.size })); paint(); };

  /** One Word file to PDF. The job's bar goes from "from" to "to" while this file is converted.
   *  step: what the card says meanwhile ("File 2 of 3" when several files are converted). */
  async function convertOne(f, from = 0, to = 0.95, step = null) {
    ctx.jobName(f.name);
    ctx.progress(from, step || "Reading the document");
    const buffer = await docToDocxBuffer(f.file);
    const printable = await wordToPrintable(buffer);
    ctx.progress(from + (to - from) * 0.25);
    ctx.estimate(2500 + estMs(f.size, 0, 400), step || "Converting", to);
    return postBlob("/api/word2pdf", printable);
  }

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    if (files.length === 1) {
      const f = files[0];
      ctx.plan({ name: f.name });
      const name = await saveFile(`${stem(f.name)}.pdf`, () => convertOne(f));
      if (name) ctx.summary("1 Word file converted to PDF");
      return;
    }
    const name = await saveFile(`${fname("word_to_pdf")}.zip`, async () => {
      const zip = new window.JSZip();
      for (let k = 0; k < files.length; k++) {
        const from = (k / files.length) * 0.96, to = ((k + 1) / files.length) * 0.96;
        zip.file(`${stem(files[k].name)}.pdf`, await convertOne(files[k], from, to, `File ${k + 1} of ${files.length}`));
      }
      ctx.progress(0.96, "Packing files");
      return zip.generateAsync({ type: "blob", compression: "STORE" });
    });
    if (name) ctx.summary(`${files.length} Word files converted to PDF`);
  }));
  ctx.setEnabled(false);
  paint();
  return ctx;
}

/* ================================================================== */
/* PDF to Word                                                         */
/* ================================================================== */
export function mountPdf2Word(tool, host) {
  const ctx = pdfSource(tool, host, { sideTitle: "PDF to Word", actionLabel: "Convert to Word" });
  const st = ctx.state;
  const opt = { breaks: true };
  ctx.side.innerHTML = `
    <div class="note">The text of your PDF is rebuilt as an editable Word document, with paragraphs, headings, bold and italic.</div>
    <label class="check"><input type="checkbox" data-role="breaks" checked> <span>Start a new Word page for every PDF page</span></label>
    <div class="callout"><strong>Good to know</strong><span>Pictures, tables and colors are not carried over, and scanned PDFs need text recognition first because they contain no real text.</span></div>
    <div class="stat-list"><div><span>Pages</span><strong data-k="n">0</strong></div></div>`;
  $('[data-role="breaks"]', ctx.side).addEventListener("change", (e) => { opt.breaks = e.target.checked; });

  ctx.onFiles = ([file]) => ctx.loadFile(file, (f) => {
    ctx.mountGrid();
    $('[data-k="n"]', ctx.side).textContent = f.pages;
    ctx.setEnabled(true);
  });

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const f = st.file;
    ctx.plan({ name: f.name });
    const name = await saveFile(`${f.base}.docx`, async () => {
      const pages = [];
      for (let n = 1; n <= f.pages; n++) {
        ctx.progress(((n - 1) / f.pages) * 0.85, `Reading page ${n} of ${f.pages}`);
        const page = await f.doc.getPage(n);
        pages.push(await extractLines(page));
        page.cleanup();
      }
      const chars = pages.reduce((s, p) => s + p.lines.reduce((t, l) => t + l.text.length, 0), 0);
      if (chars < 5) throw new Error("This PDF has no selectable text. It looks like a scan, so it needs text recognition (OCR) first.");
      ctx.progress(0.85);
      ctx.estimate(600 + f.pages * 15, "Building the Word file", 0.96);
      const { blocks, page } = buildBlocks(pages, { pageBreaks: opt.breaks });
      return postBlob("/api/build-docx", { page, blocks });
    });
    if (name) ctx.summary(`${plural(f.pages, "page")} converted to Word`);
  }));
  ctx.setEnabled(false);
  return ctx;
}

/* ================================================================== */
/* PDF to PowerPoint                                                   */
/* ================================================================== */
export function mountPdf2Ppt(tool, host) {
  const ctx = pdfSource(tool, host, { sideTitle: "PDF to PowerPoint", actionLabel: "Convert to PowerPoint" });
  const st = ctx.state;
  const opt = { mode: "image" };
  ctx.side.innerHTML = `
    <div class="note">Every PDF page becomes one slide.</div>
    <div class="label">Slide content</div>
    ${seg("mode", [{ value: "image", label: "Page images" }, { value: "text", label: "Editable text" }], opt.mode)}
    <div class="hint" data-k="hint"></div>
    <div class="stat-list"><div><span>Slides</span><strong data-k="n">0</strong></div></div>`;
  const hints = {
    image: "Each slide shows the page exactly as it looks in the PDF. Best for a faithful look.",
    text: "Text is placed in editable text boxes on blank slides. Best when you want to change the words. Pictures and colors are not carried over.",
  };
  const paintHint = () => { $('[data-k="hint"]', ctx.side).textContent = hints[opt.mode]; };
  bindSeg(ctx.side, "mode", (v) => { opt.mode = v; paintHint(); });
  paintHint();

  ctx.onFiles = ([file]) => ctx.loadFile(file, (f) => {
    ctx.mountGrid();
    $('[data-k="n"]', ctx.side).textContent = f.pages;
    ctx.setEnabled(true);
  });

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const f = st.file;
    ctx.plan({ name: f.name });
    const name = await saveFile(`${f.base}.pptx`, async () => {
      const slides = [];
      for (let n = 1; n <= f.pages; n++) {
        ctx.progress(((n - 1) / f.pages) * 0.85, `Slide ${n} of ${f.pages}`);
        const page = await f.doc.getPage(n);
        const base = page.getViewport({ scale: 1 }); // the page as displayed: rotation and crop box applied
        const w = base.width;
        const h = base.height;
        if (opt.mode === "image") {
          const canvas = document.createElement("canvas");
          await renderPage(f.doc, n, canvas, 0, { scale: safeScale(base, 2) });
          const blob = await canvasToBlob(canvas, "image/jpeg", 0.88);
          canvas.width = canvas.height = 0;
          if (!blob) throw new Error(`Page ${n} is too large to turn into an image.`);
          slides.push({ w, h, image: await blobToBase64(blob), boxes: [] });
        } else {
          const data = await extractLines(page);
          slides.push({ w: data.w, h: data.h, image: null, boxes: buildBoxes(data) });
        }
        page.cleanup();
      }
      if (opt.mode === "text" && slides.every((s) => !s.boxes.length)) {
        throw new Error("This PDF has no selectable text. Use Page images instead.");
      }
      ctx.progress(0.85);
      ctx.estimate(800 + f.pages * (opt.mode === "image" ? 90 : 20), "Building the presentation", 0.96);
      return postBlob("/api/build-pptx", { slides });
    });
    if (name) ctx.summary(`${plural(st.file.pages, "page")} converted to PowerPoint`);
  }));
  ctx.setEnabled(false);
  return ctx;
}
