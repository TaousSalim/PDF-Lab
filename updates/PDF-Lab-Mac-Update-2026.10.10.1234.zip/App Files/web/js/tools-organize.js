import {
  $, $$, el, esc, plural, fmtSize, toast, stem, fname, openPdf, discard, release, post, postBlob, saveFile, estMs, palette,
  parseSet, parseGroups, formatRanges,
} from "./core.js";
import {
  createToolPage, renderFileGrid, pdfThumb, createPageGrid, setTileRotation, seg, bindSeg, GROUP_COLORS,
} from "./components.js";

const isPdf = (f) => f.type === "application/pdf" || /\.pdf$/i.test(f.name);
const PDF_CFG = {
  test: isPdf,
  accept: "application/pdf,.pdf",
  wrongType: "Only PDF files are supported here.",
};

/** Page aspect ratio (w/h) of the first page, clamped, for thumbnail boxes. */
async function aspectOf(doc) {
  const page = await doc.getPage(1);
  const v = page.getViewport({ scale: 1 });
  return Math.min(Math.max(v.width / v.height, 0.5), 2);
}

/* ================================================================== */
/* MERGE                                                               */
/* ================================================================== */
export function mountMerge(tool, host) {
  const ctx = createToolPage(tool, host, {
    ...PDF_CFG, multiple: true,
    pickLabel: "Select PDF files",
    dropHint: "or drop PDFs here",
    sideTitle: "Merge PDF",
    actionLabel: "Merge PDF",
  });
  const files = [];
  ctx.onDispose(() => files.forEach(release));

  ctx.canvas.innerHTML = '<div class="grid files"></div>';
  const grid = $(".grid", ctx.canvas);

  ctx.side.innerHTML = `
    <div class="note">Drag the files to put them in the order you want. Pages are merged from first to last.</div>
    <div class="stat-list">
      <div><span>Files</span><strong data-k="files"></strong></div>
      <div><span>Pages</span><strong data-k="pages"></strong></div>
      <div><span>Size</span><strong data-k="size"></strong></div>
    </div>
    <div class="btn-row">
      <button class="pill-btn small" data-act="az">Sort A to Z</button>
      <button class="pill-btn small" data-act="rev">Reverse</button>
      <button class="pill-btn small ghost" data-act="clear">Clear all</button>
    </div>`;

  function render() {
    ctx.setStage(files.length ? "work" : "pick");
    renderFileGrid(grid, {
      items: files,
      thumb: (f, t) => pdfThumb(f, t),
      meta: (f) => `${plural(f.pages, "page")} &middot; ${fmtSize(f.size)}`,
      onChange: render,
      onRemove: (f, i) => { release(f); files.splice(i, 1); render(); },
      onAdd: () => ctx.openPicker(),
      addLabel: "Add PDFs",
    });
    $('[data-k="files"]', ctx.side).textContent = files.length;
    $('[data-k="pages"]', ctx.side).textContent = files.reduce((n, f) => n + f.pages, 0);
    $('[data-k="size"]', ctx.side).textContent = fmtSize(files.reduce((n, f) => n + f.size, 0));
    ctx.setEnabled(files.length >= 2);
    ctx.setActionLabel(files.length === 1 ? "Add one more PDF" : "Merge PDF");
  }

  ctx.onFiles = async (list) => {
    for (const file of list) {
      try {
        const f = await openPdf(file);
        if (ctx.dead) { release(f); return; }
        files.push(f); render();
      } catch (e) { toast(e.message, "error"); }
    }
  };

  ctx.side.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "az") files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    else if (act === "rev") files.reverse();
    else if (act === "clear") { files.forEach(release); files.length = 0; }
    else return;
    render();
  });

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const ids = files.map((f) => f.id);
    const total = files.reduce((n, f) => n + f.pages, 0);
    ctx.plan({ ms: estMs(files.reduce((n, f) => n + f.size, 0)), label: "Merging" });
    const name = await saveFile(`${fname("merged")}.pdf`, () => postBlob("/api/merge", { ids }));
    if (name) ctx.summary(`${files.length} files merged`);
  }));

  render();
  return ctx;
}

/* ------------------------------------------------------------------ */
/* shared base for tools that work on pages of ONE pdf                 */
/* ------------------------------------------------------------------ */
function singlePdfPage(tool, host, cfg) {
  const ctx = createToolPage(tool, host, { ...PDF_CFG, multiple: false, pickLabel: "Select PDF file", dropHint: "or drop a PDF here", ...cfg });
  const st = { file: null, aspect: 0.75, grid: null };
  ctx.state = st;
  ctx.onDispose(() => { release(st.file); st.grid?.disconnect(); });

  ctx.canvas.innerHTML = `
    <div class="doc-head">
      <div class="doc-title"><strong data-k="name" translate="no"></strong><span class="muted" data-k="meta"></span></div>
      <button class="pill-btn small ghost" data-act="change">Choose another file</button>
    </div>
    <div data-role="grid"></div>`;
  $('[data-act="change"]', ctx.canvas).addEventListener("click", () => ctx.openPicker());

  ctx.mountGrid = (gridOpts) => {
    st.grid?.disconnect();
    const holder = $('[data-role="grid"]', ctx.canvas);
    holder.innerHTML = "";
    const entries = Array.from({ length: st.file.pages }, (_, i) => ({ doc: st.file.doc, n: i + 1 }));
    st.grid = createPageGrid(entries, { scroller: ctx.canvas, aspect: st.aspect, ...gridOpts });
    holder.appendChild(st.grid.el);
    return st.grid;
  };

  ctx.loadFile = async (file, after) => {
    try {
      const f = await openPdf(file);
      if (ctx.dead) { release(f); return; }
      f.base = stem(f.name);
      st.grid?.disconnect();
      release(st.file);
      st.file = f;
      st.aspect = await aspectOf(f.doc);
      $('[data-k="name"]', ctx.canvas).textContent = f.name;
      $('[data-k="meta"]', ctx.canvas).textContent = `${plural(f.pages, "page")} · ${fmtSize(f.size)}`;
      ctx.canvas.scrollTop = 0;
      ctx.setStage("work");
      after(f);
    } catch (e) {
      toast(e.message || `Could not open ${file.name}`, "error");
    }
  };
  return ctx;
}

/** Bidirectional "type pages / click pages" selection input. */
function rangeInput(label, placeholder) {
  return `<label class="field"><span>${label}</span><input type="text" class="text-in" data-role="ranges" placeholder="${placeholder}" spellcheck="false" autocomplete="off"></label><div class="field-err" data-role="err"></div>`;
}

/* ================================================================== */
/* REMOVE PAGES                                                        */
/* ================================================================== */
export function mountRemove(tool, host) {
  const ctx = singlePdfPage(tool, host, { sideTitle: "Remove pages", actionLabel: "Remove pages" });
  const st = ctx.state;
  const sel = new Set();
  let last = null;

  ctx.side.innerHTML = `
    <div class="note">Click the pages you want to delete. Shift-click selects a range. You can also type page numbers.</div>
    ${rangeInput("Pages to remove", "e.g. 1, 3, 5-7")}
    <div class="stat-list">
      <div><span>Marked for removal</span><strong data-k="n">0</strong></div>
      <div><span>Pages remaining</span><strong data-k="keep">0</strong></div>
    </div>
    <div class="btn-row"><button class="pill-btn small ghost" data-act="clear">Clear selection</button></div>`;
  const input = $('[data-role="ranges"]', ctx.side);
  const err = $('[data-role="err"]', ctx.side);

  function paint({ syncInput = true } = {}) {
    st.grid.tiles.forEach((t, i) => t.classList.toggle("removed", sel.has(i + 1)));
    const keep = st.file.pages - sel.size;
    $('[data-k="n"]', ctx.side).textContent = sel.size;
    $('[data-k="keep"]', ctx.side).textContent = keep;
    if (syncInput) input.value = formatRanges(sel);
    ctx.setEnabled(sel.size > 0 && keep > 0);
    ctx.setActionLabel(sel.size ? `Remove ${plural(sel.size, "page")}` : "Remove pages");
    if (sel.size && !keep) err.textContent = "Keep at least one page.";
    else if (syncInput) err.textContent = "";
  }

  function build() {
    sel.clear(); last = null;
    ctx.mountGrid({
      keys: true,
      onTile: (tile, _e, i) => tile.addEventListener("click", (ev) => {
        const n = i + 1;
        if (ev.shiftKey && last != null) {
          const [a, b] = [Math.min(last, n), Math.max(last, n)];
          const on = !sel.has(n);
          for (let k = a; k <= b; k++) on ? sel.add(k) : sel.delete(k);
        } else sel.has(n) ? sel.delete(n) : sel.add(n);
        last = n;
        paint();
      }),
    });
    paint();
  }

  input.addEventListener("input", () => {
    try {
      const next = parseSet(input.value, st.file.pages);
      sel.clear(); next.forEach((n) => sel.add(n));
      err.textContent = "";
      paint({ syncInput: false });
    } catch (e) {
      err.textContent = e.message;
      ctx.setEnabled(false);
    }
  });
  $('[data-act="clear"]', ctx.side).addEventListener("click", () => { sel.clear(); last = null; paint(); });

  ctx.onFiles = ([file]) => ctx.loadFile(file, build);
  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const f = st.file;
    const pages = [];
    for (let n = 1; n <= f.pages; n++) if (!sel.has(n)) pages.push({ n: n - 1, rot: 0 });
    ctx.plan({ name: f.name, ms: estMs(f.size), label: "Removing pages" });
    const name = await saveFile(`${f.base}${fname("_edited")}.pdf`, () => postBlob("/api/pages", { id: f.id, pages }));
    if (name) ctx.summary(`${plural(sel.size, "page")} removed`);
  }));
  ctx.setEnabled(false);
  return ctx;
}

/* ================================================================== */
/* EXTRACT PAGES                                                       */
/* ================================================================== */
export function mountExtract(tool, host) {
  const ctx = singlePdfPage(tool, host, { sideTitle: "Extract pages", actionLabel: "Extract pages" });
  const st = ctx.state;
  const sel = new Set();
  let last = null;
  let output = "one";

  ctx.side.innerHTML = `
    <div class="note">Click the pages you want to keep. Shift-click selects a range. You can also type page numbers.</div>
    ${rangeInput("Pages to extract", "e.g. 2, 4-6")}
    <div class="label">Output</div>
    ${seg("out", [{ value: "one", label: "One PDF" }, { value: "each", label: "One PDF per page" }], output)}
    <div class="stat-list"><div><span>Selected pages</span><strong data-k="n">0</strong></div></div>
    <div class="btn-row"><button class="pill-btn small" data-act="all">Select all</button><button class="pill-btn small ghost" data-act="clear">Clear</button></div>`;
  const input = $('[data-role="ranges"]', ctx.side);
  const err = $('[data-role="err"]', ctx.side);
  bindSeg(ctx.side, "out", (v) => { output = v; paint({ syncInput: false }); });

  function paint({ syncInput = true } = {}) {
    st.grid.tiles.forEach((t, i) => t.classList.toggle("selected", sel.has(i + 1)));
    $('[data-k="n"]', ctx.side).textContent = sel.size;
    if (syncInput) { input.value = formatRanges(sel); err.textContent = ""; }
    ctx.setEnabled(sel.size > 0);
    ctx.setActionLabel(sel.size
      ? (output === "each" && sel.size > 1 ? `Extract ${sel.size} files (ZIP)` : `Extract ${plural(sel.size, "page")}`)
      : "Extract pages");
  }

  function build() {
    sel.clear(); last = null;
    ctx.mountGrid({
      keys: true,
      onTile: (tile, _e, i) => tile.addEventListener("click", (ev) => {
        const n = i + 1;
        if (ev.shiftKey && last != null) {
          const [a, b] = [Math.min(last, n), Math.max(last, n)];
          const on = !sel.has(n);
          for (let k = a; k <= b; k++) on ? sel.add(k) : sel.delete(k);
        } else sel.has(n) ? sel.delete(n) : sel.add(n);
        last = n;
        paint();
      }),
    });
    paint();
  }

  input.addEventListener("input", () => {
    try {
      const next = parseSet(input.value, st.file.pages);
      sel.clear(); next.forEach((n) => sel.add(n));
      err.textContent = "";
      paint({ syncInput: false });
    } catch (e) {
      err.textContent = e.message;
      ctx.setEnabled(false);
    }
  });
  $('[data-act="all"]', ctx.side).addEventListener("click", () => { for (let n = 1; n <= st.file.pages; n++) sel.add(n); paint(); });
  $('[data-act="clear"]', ctx.side).addEventListener("click", () => { sel.clear(); last = null; paint(); });

  ctx.onFiles = ([file]) => ctx.loadFile(file, build);
  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const f = st.file;
    const nums = [...sel].sort((a, b) => a - b);
    ctx.plan({ name: f.name, ms: estMs(f.size), label: "Extracting pages" });
    if (output === "each" && nums.length > 1) {
      const groups = nums.map((n) => [{ n: n - 1, rot: 0 }]);
      const name = await saveFile(`${f.base}${fname("_pages")}.zip`, () => postBlob("/api/split", { id: f.id, groups, base: f.base }));
      if (name) ctx.summary(`${nums.length} pages extracted, one PDF each`);
    } else {
      const pages = nums.map((n) => ({ n: n - 1, rot: 0 }));
      const name = await saveFile(`${f.base}${fname("_extracted")}.pdf`, () => postBlob("/api/pages", { id: f.id, pages }));
      if (name) ctx.summary(`${plural(pages.length, "page")} extracted`);
    }
  }));
  ctx.setEnabled(false);
  return ctx;
}

/* ================================================================== */
/* SPLIT                                                               */
/* ================================================================== */
export function mountSplit(tool, host) {
  const ctx = singlePdfPage(tool, host, { sideTitle: "Split PDF", actionLabel: "Split PDF" });
  const st = ctx.state;
  const s = { mode: "ranges", text: "", n: 2, merge: false };
  let groups = [];

  ctx.side.innerHTML = `
    ${seg("mode", [{ value: "ranges", label: "Ranges" }, { value: "fixed", label: "Every N" }, { value: "each", label: "Each page" }], s.mode)}
    <div data-pane="ranges">
      ${rangeInput("Pages for each file", "e.g. 1-3, 5, 8-")}
      <div class="hint">Each comma separated entry becomes its own PDF. Use "8-" for page 8 to the end.</div>
      <label class="check"><input type="checkbox" data-role="merge"> <span>Merge all ranges into one PDF</span></label>
    </div>
    <div data-pane="fixed" hidden>
      <label class="field"><span>Pages per file</span><input type="number" min="1" value="2" class="text-in" data-role="n"></label>
      <div class="field-err" data-role="err2"></div>
    </div>
    <div data-pane="each" hidden><div class="hint">Every page is saved as its own PDF.</div></div>
    <div class="stat-list"><div><span>Result</span><strong data-k="result">-</strong></div></div>`;
  const text = $('[data-role="ranges"]', ctx.side);
  const err = $('[data-role="err"]', ctx.side);
  const err2 = $('[data-role="err2"]', ctx.side);
  const nIn = $('[data-role="n"]', ctx.side);
  const mergeBox = $('[data-role="merge"]', ctx.side);

  function compute() {
    const total = st.file.pages;
    err.textContent = ""; err2.textContent = "";
    if (s.mode === "each") return Array.from({ length: total }, (_, i) => [i + 1]);
    if (s.mode === "fixed") {
      const n = Math.floor(Number(s.n));
      if (!(n >= 1)) { err2.textContent = "Enter a number of pages, 1 or more."; return []; }
      const out = [];
      for (let a = 1; a <= total; a += n) out.push(Array.from({ length: Math.min(n, total - a + 1) }, (_, k) => a + k));
      return out;
    }
    if (!s.text.trim()) { err.textContent = "Type the pages for each file."; return []; }
    try { return parseGroups(s.text, total); } catch (e) { err.textContent = e.message; return []; }
  }

  function paint() {
    groups = compute();
    const first = new Map();
    groups.forEach((g, gi) => g.forEach((n) => { if (!first.has(n)) first.set(n, gi); }));
    st.grid.tiles.forEach((t, i) => {
      const gi = first.get(i + 1);
      t.classList.toggle("grouped", gi != null);
      t.classList.toggle("dimmed", gi == null);
      const colour = gi != null ? GROUP_COLORS[gi % GROUP_COLORS.length] : null;
      t.style.setProperty("--grp", colour || "transparent");
      // the label under the page is text: it takes the readable shade of the group colour for each theme
      t.style.setProperty("--grp-tl", colour ? palette(colour).onLight : "inherit");
      t.style.setProperty("--grp-td", colour ? palette(colour).onDark : "inherit");
      $(".no", t).textContent = gi != null ? `${i + 1}  ·  file ${gi + 1}` : String(i + 1);
    });
    const files = s.mode === "ranges" && s.merge ? 1 : groups.length;
    $('[data-k="result"]', ctx.side).textContent = groups.length ? plural(files, "file") : "-";
    ctx.setEnabled(groups.length > 0);
    ctx.setActionLabel(files > 1 ? "Split PDF" : (groups.length ? "Extract PDF" : "Split PDF"));
  }

  bindSeg(ctx.side, "mode", (v) => {
    s.mode = v;
    $$("[data-pane]", ctx.side).forEach((p) => { p.hidden = p.dataset.pane !== v; });
    paint();
  });
  text.addEventListener("input", () => { s.text = text.value; paint(); });
  nIn.addEventListener("input", () => { s.n = nIn.value; paint(); });
  mergeBox.addEventListener("change", () => { s.merge = mergeBox.checked; paint(); });

  function build() {
    const total = st.file.pages;
    const half = Math.ceil(total / 2);
    s.text = total > 1 ? `1-${half}, ${half + 1}-${total}` : "1";
    text.value = s.text;
    ctx.mountGrid({ onTile: () => {} });
    paint();
  }

  ctx.onFiles = ([file]) => ctx.loadFile(file, build);
  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const f = st.file;
    const toPicks = (g) => g.map((n) => ({ n: n - 1, rot: 0 }));
    ctx.plan({ name: f.name, ms: estMs(f.size), label: "Splitting" });
    if ((s.mode === "ranges" && s.merge) || groups.length === 1) {
      const pages = toPicks(groups.flat());
      const name = await saveFile(`${f.base}${fname("_split")}.pdf`, () => postBlob("/api/pages", { id: f.id, pages }));
      if (name) ctx.summary(`${plural(pages.length, "page")} extracted`);
    } else {
      const payload = { id: f.id, groups: groups.map(toPicks), base: f.base };
      const name = await saveFile(`${f.base}${fname("_split")}.zip`, () => postBlob("/api/split", payload));
      if (name) ctx.summary(`Split into ${groups.length} PDFs`);
    }
  }));
  ctx.setEnabled(false);
  return ctx;
}

/* ================================================================== */
/* ORGANIZE PDF                                                        */
/* ================================================================== */
export function mountOrganize(tool, host) {
  const ctx = createToolPage(tool, host, {
    ...PDF_CFG, multiple: true,
    pickLabel: "Select PDF file",
    dropHint: "or drop a PDF here",
    sideTitle: "Organize PDF",
    actionLabel: "Save PDF",
  });
  const sources = [];      // opened PDFs
  let items = [];          // [{src, n, rot}] in output order
  let grid = null;
  let aspect = 0.75;
  ctx.onDispose(() => { grid?.disconnect(); sources.forEach(release); });

  ctx.canvas.innerHTML = '<div class="doc-head"><div class="doc-title"><strong data-k="name"></strong><span class="muted" data-k="meta"></span></div><button class="pill-btn small" data-act="add">Add more PDFs</button></div><div data-role="grid"></div>';
  ctx.side.innerHTML = `
    <div class="note">Drag pages to reorder them. Use the buttons on a page to rotate or delete it. Add more PDFs to bring their pages in at the end.</div>
    <div class="stat-list">
      <div><span>Pages</span><strong data-k="pages">0</strong></div>
      <div><span>Source files</span><strong data-k="src">0</strong></div>
    </div>
    <div class="btn-row">
      <button class="pill-btn small" data-act="rotl">Rotate all left</button>
      <button class="pill-btn small" data-act="rotr">Rotate all right</button>
      <button class="pill-btn small" data-act="rev">Reverse order</button>
      <button class="pill-btn small ghost" data-act="reset">Start over</button>
    </div>`;

  const ICON = {
    left: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
    right: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></svg>',
    del: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  };

  function draw() {
    grid?.disconnect();
    // A source whose pages were all deleted is let go, so it no longer counts or holds memory.
    for (let k = sources.length - 1; k >= 0; k--) {
      if (!items.some((it) => it.src === sources[k])) release(sources.splice(k, 1)[0]);
    }
    ctx.setStage(items.length ? "work" : "pick");
    const holder = $('[data-role="grid"]', ctx.canvas);
    holder.innerHTML = "";
    const nameEl = $('[data-k="name"]', ctx.canvas);
    nameEl.setAttribute("translate", sources.length === 1 ? "no" : "yes");  // a file name is never translated
    nameEl.textContent = sources.length === 1 ? sources[0].name : `${sources.length} PDF files`;
    $('[data-k="meta"]', ctx.canvas).textContent = plural(items.length, "page");
    $('[data-k="pages"]', ctx.side).textContent = items.length;
    $('[data-k="src"]', ctx.side).textContent = sources.length;
    ctx.setEnabled(items.length > 0);
    if (!items.length) return;
    const entries = items.map((it) => ({ doc: it.src.doc, n: it.n }));
    grid = createPageGrid(entries, {
      scroller: ctx.canvas, aspect,
      label: (_e, i) => i + 1,
      onReorder: (from, to) => { const [m] = items.splice(from, 1); items.splice(to, 0, m); draw(); },
      onTile: (tile, _e, i) => {
        tile.draggable = true;
        const it = items[i];
        setTileRotation(tile, it.rot, aspect);
        $(".tools", tile).innerHTML = `<button data-a="l" title="Rotate left">${ICON.left}</button><button data-a="r" title="Rotate right">${ICON.right}</button><button data-a="d" class="danger" title="Delete page">${ICON.del}</button>`;
        $(".tools", tile).addEventListener("click", (ev) => {
          const a = ev.target.closest("button")?.dataset.a;
          if (!a) return;
          ev.stopPropagation();
          if (a === "d") { items.splice(i, 1); draw(); return; }
          it.rot = (it.rot + (a === "l" ? 270 : 90)) % 360;
          setTileRotation(tile, it.rot, aspect);
        });
        if (it.src !== sources[0]) tile.dataset.extra = "1";
      },
    });
    holder.appendChild(grid.el);
  }

  ctx.onFiles = async (list) => {
    for (const file of list) {
      try {
        const f = await openPdf(file);
        if (ctx.dead) { release(f); return; }
        if (!sources.length) aspect = await aspectOf(f.doc);
        sources.push(f);
        for (let n = 1; n <= f.pages; n++) items.push({ src: f, n, rot: 0 });
        draw();
      } catch (e) { toast(e.message, "error"); }
    }
  };
  $('[data-act="add"]', ctx.canvas).addEventListener("click", () => ctx.openPicker());
  ctx.side.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "rotl") items.forEach((it) => (it.rot = (it.rot + 270) % 360));
    else if (act === "rotr") items.forEach((it) => (it.rot = (it.rot + 90) % 360));
    else if (act === "rev") items.reverse();
    else if (act === "reset") { grid?.disconnect(); sources.forEach(release); sources.length = 0; items = []; }
    else return;
    draw();
  });

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const payload = { items: items.map((it) => ({ id: it.src.id, n: it.n - 1, rot: it.rot })) };
    const base = sources.length === 1 ? stem(sources[0].name) + fname("_organized") : fname("organized");
    ctx.plan({ name: sources.length === 1 ? sources[0].name : null, ms: estMs(sources.reduce((n, f) => n + f.size, 0)), label: "Organizing pages" });
    const name = await saveFile(`${base}.pdf`, () => postBlob("/api/organize", payload));
    if (name) ctx.summary(`${plural(items.length, "page")} saved in the new order`);
  }));
  ctx.setEnabled(false);
  return ctx;
}

/* ================================================================== */
/* ROTATE PDF (several files at once)                                  */
/* ================================================================== */
export function mountRotate(tool, host) {
  const ctx = createToolPage(tool, host, {
    ...PDF_CFG, multiple: true,
    pickLabel: "Select PDF files",
    dropHint: "or drop PDFs here",
    sideTitle: "Rotate PDF",
    actionLabel: "Rotate PDF",
  });
  ctx.root.classList.add("tool-rotate");
  const files = [];        // opened PDFs, each with .rots: the turn of every page (0, 90, 180, 270)
  let grids = [];
  ctx.onDispose(() => { grids.forEach((g) => g.disconnect()); files.forEach(release); });

  ctx.canvas.innerHTML = '<div class="doc-head"><div class="doc-title"><strong data-k="name"></strong><span class="muted" data-k="meta"></span></div><button class="pill-btn small" data-act="add">Add more PDFs</button></div><div data-role="files"></div>';
  ctx.side.innerHTML = `
    <div class="note">Every page is shown. Click a page to turn it to the right, or use the buttons on it to turn it either way. The buttons below turn every page at once.</div>
    <div class="btn-row">
      <button class="pill-btn small" data-act="rotl">Rotate all left</button>
      <button class="pill-btn small" data-act="rotr">Rotate all right</button>
      <button class="pill-btn small ghost" data-act="reset">Reset</button>
    </div>
    <div class="stat-list">
      <div><span>Files</span><strong data-k="files">0</strong></div>
      <div><span>Pages</span><strong data-k="pages">0</strong></div>
      <div><span>Pages to rotate</span><strong data-k="rot">0</strong></div>
    </div>`;

  const ICON = {
    left: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
    right: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></svg>',
    del: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  };
  const turn = (deg, dir) => (deg + (dir === "l" ? 270 : 90)) % 360;
  const label = (i, rot) => (rot ? `${i + 1} · ${rot}°` : String(i + 1));

  /** One page shows its turn: the picture, the number under it, the outline of a turned page. */
  function showPage(f, tile, i) {
    const rot = f.rots[i];
    setTileRotation(tile, rot, f.aspect);
    tile.classList.toggle("turned", rot !== 0);
    $(".no", tile).textContent = label(i, rot);
  }

  function stats() {
    const pages = files.reduce((n, f) => n + f.pages, 0);
    const turned = files.reduce((n, f) => n + f.rots.filter(Boolean).length, 0);
    $('[data-k="files"]', ctx.side).textContent = files.length;
    $('[data-k="pages"]', ctx.side).textContent = pages;
    $('[data-k="rot"]', ctx.side).textContent = turned;
    $('[data-k="meta"]', ctx.canvas).textContent = plural(pages, "page");
    ctx.setEnabled(turned > 0);
  }

  function draw() {
    grids.forEach((g) => g.disconnect());
    grids = [];
    ctx.setStage(files.length ? "work" : "pick");
    const holder = $('[data-role="files"]', ctx.canvas);
    holder.innerHTML = "";
    const nameEl = $('[data-k="name"]', ctx.canvas);
    nameEl.setAttribute("translate", files.length === 1 ? "no" : "yes");  // a file name is never translated
    nameEl.textContent = files.length === 1 ? files[0].name : `${files.length} PDF files`;
    stats();
    files.forEach((f) => {
      const box = el("section", "rot-file");
      if (files.length > 1) {
        // several files: each one gets its name and its own buttons above its pages
        const head = el("div", "rot-file-head");
        head.innerHTML = `<div class="doc-title"><strong translate="no"></strong><span class="muted"></span></div>
          <div class="rot-row">
            <button type="button" data-f="l" title="Rotate this file left" aria-label="Rotate this file left">${ICON.left}</button>
            <button type="button" data-f="r" title="Rotate this file right" aria-label="Rotate this file right">${ICON.right}</button>
            <button type="button" data-f="x" class="danger" title="Remove this file" aria-label="Remove this file">${ICON.del}</button>
          </div>`;
        $("strong", head).textContent = f.name;
        $(".muted", head).textContent = `${plural(f.pages, "page")} · ${fmtSize(f.size)}`;
        head.addEventListener("click", (e) => {
          const a = e.target.closest("button")?.dataset.f;
          if (!a) return;
          if (a === "x") { files.splice(files.indexOf(f), 1); release(f); draw(); return; }
          f.rots = f.rots.map((r) => turn(r, a));
          grid.tiles.forEach((t, i) => showPage(f, t, i));
          stats();
        });
        box.appendChild(head);
      }
      const entries = Array.from({ length: f.pages }, (_v, i) => ({ doc: f.doc, n: i + 1 }));
      const grid = createPageGrid(entries, {
        scroller: ctx.canvas, aspect: f.aspect, keys: true,
        label: (_e, i) => label(i, f.rots[i]),
        onTile: (tile, _e, i) => {
          tile.title = "Click to rotate this page right";
          $(".tools", tile).innerHTML = `<button type="button" data-a="l" title="Rotate left" aria-label="Rotate left">${ICON.left}</button><button type="button" data-a="r" title="Rotate right" aria-label="Rotate right">${ICON.right}</button>`;
          tile.addEventListener("click", (ev) => {
            const a = ev.target.closest("button")?.dataset.a || "r";   // a click on the page itself turns it right
            f.rots[i] = turn(f.rots[i], a);
            showPage(f, tile, i);
            stats();
          });
          showPage(f, tile, i);
        },
      });
      grids.push(grid);
      box.appendChild(grid.el);
      holder.appendChild(box);
    });
  }

  ctx.onFiles = async (list) => {
    for (const file of list) {
      try {
        const f = await openPdf(file);
        if (ctx.dead) { release(f); return; }
        f.aspect = await aspectOf(f.doc);
        f.rots = new Array(f.pages).fill(0);
        files.push(f);
        draw();
      } catch (e) { toast(e.message, "error"); }
    }
  };
  $('[data-act="add"]', ctx.canvas).addEventListener("click", () => ctx.openPicker());
  ctx.side.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "rotl" || act === "rotr") files.forEach((f) => (f.rots = f.rots.map((r) => turn(r, act === "rotl" ? "l" : "r"))));
    else if (act === "reset") files.forEach((f) => f.rots.fill(0));
    else return;
    grids.forEach((g, k) => g.tiles.forEach((t, i) => showPage(files[k], t, i)));
    stats();
  });

  ctx.action.addEventListener("click", () => ctx.run(async () => {
    const turned = files.filter((f) => f.rots.some(Boolean)); // a file with no page turned is not saved again
    const jobs = turned.map((f) => ({ id: f.id, pages: f.rots }));
    const pages = turned.reduce((n, f) => n + f.rots.filter(Boolean).length, 0);
    const one = jobs.length === 1;
    const target = one ? `${stem(turned[0].name)}${fname("_rotated")}.pdf` : `${fname("rotated_pdfs")}.zip`;
    ctx.plan({ name: one ? turned[0].name : null, ms: estMs(turned.reduce((n, f) => n + f.size, 0)), label: "Rotating" });
    const name = await saveFile(target, () => postBlob("/api/rotate-all", { jobs, suffix: fname("_rotated") }));
    if (name) ctx.summary(one ? `${plural(pages, "page")} rotated` : `${plural(pages, "page")} rotated in ${plural(jobs.length, "file")}`);
  }));
  ctx.setEnabled(false);
  return ctx;
}
