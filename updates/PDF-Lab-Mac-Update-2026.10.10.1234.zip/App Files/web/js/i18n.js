/* PDF Lab language layer (English and French).
 *
 * The app is written in English. This file shows it in French without touching the tools:
 *   - every piece of text the app puts on the page (labels, hints, buttons, messages, tooltips, placeholders,
 *     the window title) is looked up in the French dictionary (lang-fr.js) and replaced on the spot;
 *   - the English original of each piece is remembered, so switching back is instant and nothing is reloaded:
 *     open files, selections and edits stay exactly as they are;
 *   - anything marked translate="no" is never touched: file names, the text of the user's PDF, the letters shown
 *     in the font report, and the hidden copy of a Word document that is being converted.
 *
 * Plain script (not a module) loaded in <head>, so the first paint is already in the right language.
 * The dictionary must be loaded before this file.
 */
(function () {
  "use strict";

  var DICT = window.PDFLAB_FR;
  if (!DICT) { DICT = {}; if (window.console) console.warn("PDF Lab: the French dictionary (js/lang-fr.js) did not load, the app stays in English."); }
  var EXACT = DICT.exact || {};
  var PATTERNS = DICT.patterns || [];
  var NAMES = DICT.names || {};
  var STORE_KEY = "pdflab-lang";
  var ATTRS = ["title", "placeholder", "aria-label", "alt"];
  // Never looked at: user content, code, drawings.
  var SKIP = '[translate="no"], [contenteditable]:not([contenteditable="false"]), script, style, noscript, textarea, svg, canvas';
  var root = document.documentElement;
  var has = Object.prototype.hasOwnProperty;

  // The choice is kept in two places: the page's storage, and a cookie. The storage belongs to one port
  // (127.0.0.1:8765); when that port is taken and the app moves to the next one, the cookie still has the choice.
  function saved() {
    var v = null;
    try { v = localStorage.getItem(STORE_KEY); } catch (e) { /* no storage */ }
    if (v !== "fr" && v !== "en") {
      var m = /(?:^|;\s*)pdflab-lang=(fr|en)\b/.exec(document.cookie || "");
      v = m ? m[1] : null;
    }
    return v;
  }
  function remember(v) {
    try { localStorage.setItem(STORE_KEY, v); } catch (e) { /* no storage */ }
    try { document.cookie = STORE_KEY + "=" + v + "; path=/; max-age=315360000; SameSite=Lax"; } catch (e) { /* no cookies */ }
  }
  var lang = saved();
  if (lang !== "fr" && lang !== "en") lang = window.PDFLAB_DEFAULT_LANG === "fr" ? "fr" : "en";

  /* ---------------- audit: which English texts have no French yet (used by the tests) ---------------- */
  var audit = false;
  try { audit = localStorage.getItem("pdflab-i18n-audit") === "1"; } catch (e) { /* no storage */ }
  var MISS_KEY = "pdflab-i18n-misses";   // kept across reloads while the audit is on
  var misses = new Set();
  if (audit) { try { JSON.parse(localStorage.getItem(MISS_KEY) || "[]").forEach(function (m) { misses.add(m); }); } catch (e) { /* empty */ } }
  function miss(core) {
    if (!/[A-Za-z]{2}/.test(core) || /^#[0-9a-f]{3,8}$/i.test(core) || misses.has(core)) return;
    misses.add(core);
    try { localStorage.setItem(MISS_KEY, JSON.stringify(Array.from(misses))); } catch (e) { /* no storage */ }
  }

  /* ---------------- looking a text up ---------------- */
  function lookup(core, node, kind) {
    if (has.call(EXACT, core)) {
      var hit = EXACT[core];
      return typeof hit === "function" ? hit(node) : hit;
    }
    for (var i = 0; i < PATTERNS.length; i++) {
      var p = PATTERNS[i];
      if (p[2] === "attr" && kind !== "attr") continue;
      var m = p[0].exec(core);
      if (m) return p[1](m, phrase, node);
    }
    return undefined;
  }

  /** French for one phrase, or undefined. "a · b" is translated part by part. */
  function french(core, node, kind) {
    var out = lookup(core, node, kind);
    if (out !== undefined) return out;
    if (core.indexOf("·") > 0) {
      var parts = core.split(/\s*·\s*/);
      for (var i = 0; i < parts.length; i++) {
        if (!/[A-Za-z%]|\d\.\d/.test(parts[i])) continue;
        var one = lookup(parts[i], node, kind);
        if (one === undefined) return undefined;
        parts[i] = one;
      }
      return parts.join(" · ");
    }
    return undefined;
  }

  /** A phrase used inside another one (a count inside a message, a tool name inside the window title). */
  function phrase(s) {
    var out = french(String(s));
    return out === undefined ? String(s) : out;
  }

  /** The text to show for an English source text in the current language. */
  function render(src, node, kind) {
    if (lang !== "fr" && !audit) return src;
    var core = src.replace(/\s+/g, " ").trim();
    if (!core || !/[A-Za-z%]|\d\.\d/.test(core)) return src;   // nothing to say: empty, or a plain whole number
    var out = french(core, node, kind);
    if (out === undefined) {
      if (audit) miss(core);
      return src;
    }
    if (lang !== "fr") return src;
    return src.match(/^\s*/)[0] + out + src.match(/\s*$/)[0];
  }

  /* ---------------- the page ---------------- */
  var texts = new WeakMap();   // text node -> { src: English, out: what this file last wrote }
  var attrs = new WeakMap();   // element -> { attribute: { src, out } }

  function doText(n) {
    var cur = n.data;
    var rec = texts.get(n);
    if (!rec || cur !== rec.out) { rec = { src: cur, out: cur }; texts.set(n, rec); }  // the app wrote a new text
    var want = render(rec.src, n, "text");
    rec.out = want;
    if (want !== cur) n.data = want;
  }

  function doAttr(el, name) {
    var cur = el.getAttribute(name);
    if (cur == null) return;
    var all = attrs.get(el);
    if (!all) { all = {}; attrs.set(el, all); }
    var rec = all[name];
    if (!rec || cur !== rec.out) rec = all[name] = { src: cur, out: cur };
    var want = render(rec.src, el, "attr");
    rec.out = want;
    if (want !== cur) el.setAttribute(name, want);
  }

  function doAttrs(el) {
    for (var i = 0; i < ATTRS.length; i++) if (el.hasAttribute(ATTRS[i])) doAttr(el, ATTRS[i]);
  }

  var FILTER = {
    acceptNode: function (n) {
      return n.nodeType === 1 && n.matches(SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
    },
  };

  function walk(node) {
    if (!node.isConnected) return;   // removed again before we got here: its place on the page is unknown
    if (node.nodeType === 3) {
      var parent = node.parentElement;
      if (parent && !parent.closest(SKIP)) doText(node);
      return;
    }
    if (node.nodeType !== 1 || node.closest(SKIP)) return;
    doAttrs(node);
    var w = document.createTreeWalker(node, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, FILTER);
    var n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 1) doAttrs(n); else doText(n);
    }
  }

  var usedFrench = lang === "fr";
  var observer = new MutationObserver(function (list) {
    // English is what the app writes: nothing to do, unless French was shown before (a piece put back on the page
    // may still carry its French text)
    if (lang !== "fr" && !audit && !usedFrench) return;
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.type === "childList") {
        for (var k = 0; k < r.addedNodes.length; k++) walk(r.addedNodes[k]);
      } else if (r.type === "characterData") {
        walk(r.target);
      } else if (r.attributeName === "translate") {
        walk(r.target);
      } else if (!r.target.closest(SKIP)) {
        doAttr(r.target, r.attributeName);
      }
    }
  });
  observer.observe(root, {
    subtree: true, childList: true, characterData: true,
    attributes: true, attributeFilter: ATTRS.concat("translate"),
  });

  /* ---------------- the FR | EN switch ---------------- */
  function paintSwitch() {
    var buttons = document.querySelectorAll("[data-set-lang]");
    for (var i = 0; i < buttons.length; i++) {
      var on = buttons[i].getAttribute("data-set-lang") === lang;
      buttons[i].setAttribute("aria-pressed", on ? "true" : "false");
    }
  }

  function set(next, keep) {
    lang = next === "fr" ? "fr" : "en";
    if (lang === "fr") usedFrench = true;
    if (keep !== false) remember(lang);
    root.lang = lang;
    walk(root);
    paintSwitch();
    window.dispatchEvent(new CustomEvent("pdflab:lang", { detail: lang }));
  }

  root.lang = lang;
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-set-lang]");
    if (b) set(b.getAttribute("data-set-lang"));
  });
  document.addEventListener("DOMContentLoaded", function () { walk(root); paintSwitch(); });

  window.PDFLabI18n = {
    /** "en" or "fr". */
    lang: function () { return lang; },
    set: set,
    /** A text that is not shown through the page (none today, kept for future use): French when French is on. */
    t: function (s) { return lang === "fr" ? phrase(s) : String(s); },
    /** Part of a suggested file name: name("_edited") is "_edited" in English and "_modifié" in French. */
    name: function (key) { return lang === "fr" && has.call(NAMES, key) ? NAMES[key] : key; },
    /** Tests: turn the audit on, list the English texts seen so far that have no French. */
    audit: function (on) { audit = on !== false; if (audit) walk(root); },
    missing: function () { return Array.from(misses); },
  };
})();
