import { $, $$, el, esc, plural, toast, post, readError, stem, fname, openPdf, release, enqueue, renderPage, DPR, saveFile, fmtSize, estMs, job } from "./core.js";
import { createToolPage } from "./components.js";

const isPdf = (f) => f.type === "application/pdf" || /\.pdf$/i.test(f.name);
const NS = "http://www.w3.org/2000/svg";

/* ------------------------------------------------------------------ */
/* small helpers                                                       */
/* ------------------------------------------------------------------ */
const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
const r2 = (v) => Math.round(v * 100) / 100;
const uid = (() => { let n = 0; return () => `e${Date.now().toString(36)}${(n++).toString(36)}`; })();
const clone = (o) => JSON.parse(JSON.stringify(o));
const svgEl = (tag, attrs = {}) => {
  const n = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
  return n;
};
const EXACT_TYPES = new Set(["edit", "delete", "cover"]);
const isExact = (e) => e.t === "edit" || e.t === "delete" || (e.t === "cover" && e.remove !== false);

const CSS_FAMILY = {
  sans: '"Helvetica Neue", Helvetica, Arial, sans-serif',
  serif: '"Times New Roman", Times, serif',
  mono: '"Courier New", Courier, Menlo, monospace',
};
// Arabic is written by the server with Arial, Times New Roman or Courier New, so the page previews it the same way.
const CSS_FAMILY_AR = { ...CSS_FAMILY, sans: 'Arial, "Helvetica Neue", Helvetica, sans-serif' };
const hasArabic = (s) => /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFC]/.test(s || "");
function cssFamily(fam, fallbackCls = "sans", arabic = false) {
  const set = arabic ? CSS_FAMILY_AR : CSS_FAMILY;
  if (fam && fam.startsWith("sys:")) return `"${fam.slice(4).replace(/"/g, "")}", ${set[fallbackCls]}`;
  return set[fam] || set[fallbackCls];
}

const ICONS = {
  select: '<path d="M5 3l14 7-6 2-2 6z"/>',
  edittext: '<path d="M4 7V5h10v2M9 5v12M7 17h4"/><path d="M15 20l1-3 5-5 2 2-5 5z" transform="translate(-3 -1) scale(.9)"/>',
  text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M4 17l5-5 4 4 3-3 4 4"/>',
  rect: '<rect x="4" y="6" width="16" height="12" rx="2"/>',
  ellipse: '<ellipse cx="12" cy="12" rx="8.5" ry="6.5"/>',
  line: '<path d="M5 19L19 5"/>',
  arrow: '<path d="M5 19L19 5M10 5h9v9"/>',
  ink: '<path d="M4 20c3 0 4-5 6-5s2 3 4 3 3-8 6-12"/>',
  highlight: '<path d="M4 20h7M14 4l6 6-8 8H8l-4-4z"/>',
  cover: '<path d="M4 15l9-9 7 7-6 6H8zM8 19l-4-4"/>',
  undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 0 1 0 12" transform="translate(0 -4) scale(1 .85)"/>',
  redo: '<path d="M15 7l5 5-5 5"/><path d="M20 12H10a6 6 0 0 0 0 12" transform="translate(0 -4) scale(1 .85)"/>',
  zin: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.5-4.5M11 8v6M8 11h6"/>',
  zout: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.5-4.5M8 11h6"/>',
  fit: '<path d="M4 9V5h4M20 9V5h-4M4 15v4h4M20 15v4h-4"/>',
  trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
};
const ic = (k, s = 18) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[k]}</svg>`;

const SHORT = { select: "Edit", text: "Text", image: "Image", rect: "Box", ellipse: "Oval", line: "Line", arrow: "Arrow", ink: "Draw", highlight: "Mark", cover: "Erase" };
const TOOL_LIST = [
  ["select", "Select and edit text", "Click any text to edit it, or click a shape to move it"],
  ["text", "Add text", "Click on the page and type"],
  ["image", "Add image", "Choose a picture to place on the page"],
  ["rect", "Rectangle", "Drag on the page"],
  ["ellipse", "Ellipse", "Drag on the page"],
  ["line", "Line", "Drag on the page"],
  ["arrow", "Arrow", "Drag on the page"],
  ["ink", "Draw", "Draw freehand on the page"],
  ["highlight", "Highlight", "Drag over the text to highlight"],
  ["cover", "Cover or erase", "Drag over anything to hide it"],
];

/* ================================================================== */
/* EDIT PDF                                                            */
/* ================================================================== */
export function mountEdit(tool, host) {
  const ctx = createToolPage(tool, host, {
    test: isPdf, accept: "application/pdf,.pdf", wrongType: "Only PDF files are supported here.",
    multiple: false, pickLabel: "Select PDF file", dropHint: "or drop a PDF here",
    sideTitle: "Edit PDF", actionLabel: "Save PDF",
  });
  ctx.root.classList.add("tool-edit");
  let disposed = false;
  const S = {
    file: null, geo: [], fonts: [], zoom: 1, tool: "select", edits: [], undo: [], redo: [],
    sel: null, selLine: null, lines: [], pages: [], report: new Map(), cover: "#ffffff",
    style: {
      stroke: "#e5484d", fill: null, width: 2.5, opacity: 1,
      text: { family: "sans", size: 16, color: "#1b1b1f", bold: false, italic: false, align: "left", lh: 1.25 },
      hl: { color: "#ffe34d", opacity: 0.45 },
    },
  };
  let editor = null;          // the open line editor
  let io = null;
  const exactSeq = new Map();  // page -> request counter
  const blobUrls = new Set();
  const pictures = new Map();  // picture id -> data URL, kept out of the edit list so undo snapshots stay small

  ctx.canvas.innerHTML = `
    <div class="ed-toolbar" data-role="toolbar"></div>
    <div class="ed-scroll" data-role="scroll"><div class="ed-pages" data-role="pages"></div></div>`;
  const toolbar = $('[data-role="toolbar"]', ctx.canvas);
  const scroller = $('[data-role="scroll"]', ctx.canvas);
  const pagesBox = $('[data-role="pages"]', ctx.canvas);

  ctx.side.innerHTML = `
    <div class="note" data-role="hint"></div>
    <div class="ed-props" data-role="props"></div>
    <div class="label">Changes</div>
    <div class="stat-list"><div><span>Edits</span><strong data-k="count">0</strong></div><div><span>Pages touched</span><strong data-k="pages">0</strong></div></div>
    <div class="btn-row"><button class="pill-btn small" data-act="undo">Undo</button><button class="pill-btn small" data-act="redo">Redo</button><button class="pill-btn small ghost" data-act="reset">Discard all</button></div>
    <div class="ed-fid" data-role="fid"></div>`;
  const hintEl = $('[data-role="hint"]', ctx.side);
  const propsEl = $('[data-role="props"]', ctx.side);
  const fidEl = $('[data-role="fid"]', ctx.side);

  /* ---------------- toolbar ---------------- */
  toolbar.innerHTML = `
    <div class="ed-tools">${TOOL_LIST.map(([id, title]) => `<button class="ed-tool" data-tool="${id}" title="${esc(title)}" aria-label="${esc(title)}">${ic(id === "select" ? "select" : id)}<span>${esc(SHORT[id])}</span></button>`).join("")}</div>
    <div class="ed-tb-sep"></div>
    <div class="ed-zoom">
      <button class="ed-ib" data-act="zout" title="Zoom out">${ic("zout")}</button>
      <span data-role="zlabel">100%</span>
      <button class="ed-ib" data-act="zin" title="Zoom in">${ic("zin")}</button>
      <button class="ed-ib" data-act="zfit" title="Fit to width">${ic("fit")}</button>
    </div>
    <span class="ed-pageind" data-role="pageind"></span>`;
  const imgInput = document.createElement("input");
  imgInput.type = "file"; imgInput.accept = "image/png,image/jpeg,image/gif,image/webp"; imgInput.hidden = true;
  ctx.root.appendChild(imgInput);

  toolbar.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tool]");
    if (t) return setTool(t.dataset.tool);
    const a = e.target.closest("[data-act]")?.dataset.act;
    if (a === "zin") setZoom(S.zoom * 1.15);
    else if (a === "zout") setZoom(S.zoom / 1.15);
    else if (a === "zfit") setZoom(fitZoom());
  });
  ctx.side.addEventListener("click", (e) => {
    const a = e.target.closest("[data-act]")?.dataset.act;
    if (a === "undo") undo();
    else if (a === "redo") redo();
    else if (a === "reset") discardAll();
  });

  function setTool(id) {
    commitEditor();
    S.tool = id;
    if (id !== "select") select(null);
    $$(".ed-tool", toolbar).forEach((b) => b.classList.toggle("on", b.dataset.tool === id));
    pagesBox.dataset.tool = id;
    renderSide();
    if (id === "image") { imgInput.value = ""; imgInput.click(); }
  }

  /* ---------------- file loading ---------------- */
  ctx.onDispose(() => {
    disposed = true;
    io?.disconnect();
    release(S.file);
    blobUrls.forEach((u) => URL.revokeObjectURL(u));
    document.removeEventListener("keydown", onKey, true);
  });
  document.addEventListener("keydown", onKey, true);

  ctx.onFiles = async (files) => {
    const f = files[0];
    if (!f) return;
    ctx.run(async () => {
      let opened = null;
      try {
        opened = await openPdf(f);
        const res = await post("/api/edit/open", { id: opened.id });
        if (!res.ok) throw new Error(await readError(res));
        const info = await res.json();
        if (ctx.dead || disposed) { release(opened); return; }
        resetAll();
        S.file = opened;
        S.geo = info.pages;
        S.fonts = info.fonts || [];
        S.lines = S.geo.map(() => null);
        ctx.setStage("work");
        buildPages();
        setZoom(fitZoom(), true);
        setTool("select");
        toast(`${f.name} is ready. Click any text to edit it.`, "");
      } catch (e) {
        if (opened) release(opened);
        throw e;
      }
    });
  };

  function resetAll() {
    commitEditor(true);
    if (S.file) release(S.file);
    io?.disconnect();
    blobUrls.forEach((u) => URL.revokeObjectURL(u));
    blobUrls.clear();
    pictures.clear();
    S.edits = []; S.undo = []; S.redo = []; S.sel = null; S.selLine = null; S.pages = []; S.report.clear();
    pagesBox.innerHTML = "";
    ctx.setStage("pick");
    updateStats();
  }

  /* ---------------- pages ---------------- */
  const fitZoom = () => {
    const maxW = Math.max(...S.geo.map((g) => g.w), 1);
    const avail = scroller.clientWidth - 56;
    return clamp(avail / maxW, 0.4, 3);
  };

  function buildPages() {
    pagesBox.innerHTML = "";
    S.pages = [];
    io = new IntersectionObserver((entries) => {
      for (const en of entries) {
        const pi = Number(en.target.dataset.page);
        if (en.isIntersecting) { ensureRendered(pi); continue; }
        // far from view: give the page bitmap back, it is drawn again when the page comes near
        const P = S.pages[pi];
        if (P && P.canvas.width) { P.canvas.width = P.canvas.height = 0; P.rendered = false; }
      }
    }, { root: scroller, rootMargin: "900px 0px" });
    S.geo.forEach((g, pi) => {
      const wrap = el("div", "ed-page-wrap");
      wrap.innerHTML = `
        <div class="ed-page" data-page="${pi}">
          <canvas class="ed-canvas"></canvas>
          <img class="ed-exact" alt="" hidden>
          <div class="ed-lines"></div>
          <div class="ed-objs"></div>
          <div class="ed-over"></div>
          <div class="ed-busy" hidden><span></span></div>
        </div>
        <div class="ed-pno">Page ${pi + 1} of ${S.geo.length}</div>`;
      pagesBox.appendChild(wrap);
      const page = $(".ed-page", wrap);
      const P = {
        wrap, page, canvas: $(".ed-canvas", page), exact: $(".ed-exact", page), linesEl: $(".ed-lines", page),
        objs: $(".ed-objs", page), over: $(".ed-over", page), busy: $(".ed-busy", page),
        svg: null, rendered: false, renderedZoom: 0, linesLoading: false,
      };
      P.svg = svgEl("svg", { class: "ed-svg" });
      P.objs.appendChild(P.svg);
      S.pages.push(P);
      bindPage(P, pi);
      io.observe(page);
    });
    scroller.onscroll = () => updatePageInd();
  }

  function layoutPages() {
    S.geo.forEach((g, pi) => {
      const P = S.pages[pi];
      P.page.style.width = `${g.w * S.zoom}px`;
      P.page.style.height = `${g.h * S.zoom}px`;
      P.svg.setAttribute("viewBox", `0 0 ${g.w} ${g.h}`);
      P.svg.style.width = `${g.w * S.zoom}px`;
      P.svg.style.height = `${g.h * S.zoom}px`;
    });
  }

  let zoomTimer = null;
  function setZoom(z, immediate) {
    commitEditor();
    S.zoom = clamp(z, 0.3, 4);
    $('[data-role="zlabel"]', toolbar).textContent = `${Math.round(S.zoom * 100)}%`;
    layoutPages();
    S.pages.forEach((P, pi) => { renderLinesLayer(pi); renderObjects(pi); });
    clearTimeout(zoomTimer);
    zoomTimer = setTimeout(() => {
      S.pages.forEach((P, pi) => { if (P.rendered) { P.rendered = false; if (visible(P)) ensureRendered(pi); } });
      S.pages.forEach((P, pi) => { if (pageHasExact(pi) && visible(P)) refreshExact(pi); });
    }, immediate ? 0 : 220);
    updatePageInd();
  }

  const visible = (P) => {
    const r = P.page.getBoundingClientRect(), v = scroller.getBoundingClientRect();
    return r.bottom > v.top - 900 && r.top < v.bottom + 900;
  };

  function updatePageInd() {
    const v = scroller.getBoundingClientRect();
    let cur = 0;
    S.pages.forEach((P, i) => { if (P.page.getBoundingClientRect().top < v.top + v.height * 0.45) cur = i; });
    $('[data-role="pageind"]', toolbar).textContent = S.pages.length ? `Page ${cur + 1} / ${S.pages.length}` : "";
    S.curPage = cur;
  }

  function ensureRendered(pi) {
    const P = S.pages[pi];
    if (!P || !S.file) return;
    if (!P.rendered) {
      P.rendered = true;
      const cssW = S.geo[pi].w * S.zoom;
      enqueue(async () => {
        if (disposed || !S.file || !P.rendered) return;
        await renderPage(S.file.doc, pi + 1, P.canvas, cssW, { scale: (cssW * DPR) / S.geo[pi].w * (S.geo[pi].rot % 180 ? 1 : 1) });
        P.canvas.style.width = `${cssW}px`;
        P.canvas.style.height = `${S.geo[pi].h * S.zoom}px`;
        P.renderedZoom = S.zoom;
      });
    }
    if (S.lines[pi] == null && !P.linesLoading) loadLines(pi);
  }

  async function loadLines(pi) {
    const P = S.pages[pi];
    P.linesLoading = true;
    try {
      const res = await post("/api/edit/lines", { id: S.file.id, page: pi });
      if (!res.ok) throw new Error(await readError(res));
      const j = await res.json();
      if (disposed || !S.file) return;
      S.lines[pi] = j.lines;
      renderLinesLayer(pi);
      if (!j.lines.length) {
        const n = el("div", "ed-noedit", "No editable text on this page. You can still add text, images and shapes.");
        P.page.appendChild(n);
        setTimeout(() => n.classList.add("fade"), 4500);
        setTimeout(() => n.remove(), 5200);
      }
    } catch (e) {
      S.lines[pi] = [];
      toast(e.message || "The text of this page could not be read.", "error");
    } finally {
      P.linesLoading = false;
    }
  }

  function renderLinesLayer(pi) {
    const P = S.pages[pi];
    P.linesEl.innerHTML = "";
    const lines = S.lines[pi];
    if (!lines) return;
    const z = S.zoom;
    for (const ln of lines) {
      if (!ln.editable) continue;
      const [x0, y0, x1, y1] = ln.bbox;
      const d = el("div", "ed-line");
      d.dataset.line = ln.id;
      d.style.left = `${(x0 - 1.5) * z}px`;
      d.style.top = `${(y0 - 1) * z}px`;
      d.style.width = `${(x1 - x0 + 3) * z}px`;
      d.style.height = `${(y1 - y0 + 2) * z}px`;
      if (lineEdit(pi, ln.id)) d.classList.add("edited");
      P.linesEl.appendChild(d);
    }
  }

  /* ---------------- edits model ---------------- */
  const lineEdit = (pi, id) => S.edits.find((e) => (e.t === "edit" || e.t === "delete") && e.page === pi && e.line === id);
  const byUid = (u) => S.edits.find((e) => e.uid === u);
  const pageHasExact = (pi) => S.edits.some((e) => e.page === pi && isExact(e));

  let pending = null;
  function pushUndo(snapshot) {
    S.undo.push(snapshot);
    if (S.undo.length > 120) S.undo.shift();
    S.redo = [];
  }
  /** Run a change that is one undo step. */
  function mutate(fn, pagesChanged) {
    pushUndo(JSON.stringify(S.edits));
    fn();
    afterChange(pagesChanged);
  }
  /** Live changes (sliders, dragging): the undo step is stored once, when the gesture starts. */
  function beginLive() { if (!pending) pending = JSON.stringify(S.edits); }
  function endLive() { if (pending) { if (pending !== JSON.stringify(S.edits)) pushUndo(pending); pending = null; } }

  function afterChange(pages) {
    const set = pages ? new Set([].concat(pages)) : new Set(S.pages.map((_, i) => i));
    for (const pi of set) {
      renderObjects(pi);
      renderLinesLayer(pi);
      scheduleExact(pi);
    }
    updateStats();
    renderSide();
  }

  function undo() {
    commitEditor();
    if (!S.undo.length) return;
    S.redo.push(JSON.stringify(S.edits));
    S.edits = JSON.parse(S.undo.pop());
    select(null);
    afterChange();
  }
  function redo() {
    commitEditor();
    if (!S.redo.length) return;
    S.undo.push(JSON.stringify(S.edits));
    S.edits = JSON.parse(S.redo.pop());
    select(null);
    afterChange();
  }
  function discardAll() {
    if (!S.edits.length) return;
    commitEditor(true);
    mutate(() => { S.edits = []; }, undefined);
    select(null);
    toast("All changes were discarded. Undo brings them back.", "");
  }

  function updateStats() {
    $('[data-k="count"]', ctx.side).textContent = S.edits.length;
    $('[data-k="pages"]', ctx.side).textContent = new Set(S.edits.map((e) => e.page)).size;
    ctx.setEnabled(S.edits.length > 0);
    $('[data-act="undo"]', ctx.side).disabled = !S.undo.length;
    $('[data-act="redo"]', ctx.side).disabled = !S.redo.length;
    renderFidelity();
  }

  /* ---------------- exact layer (the engine's own render) ---------------- */
  const exactTimers = new Map();
  function scheduleExact(pi, delay = 120) {
    clearTimeout(exactTimers.get(pi));
    exactTimers.set(pi, setTimeout(() => refreshExact(pi), delay));
  }
  const serialize = (e) => {
    const o = {};
    for (const [k, v] of Object.entries(e)) {
      if (k === "pic") o.data = pictures.get(v);
      else if (k !== "uid" && !k.startsWith("_")) o[k] = v;
    }
    return o;
  };

  async function refreshExact(pi) {
    if (disposed || !S.file) return;
    const P = S.pages[pi];
    const edits = S.edits.filter((e) => e.page === pi && isExact(e)).map(serialize);
    const seq = (exactSeq.get(pi) || 0) + 1;
    exactSeq.set(pi, seq);
    if (!edits.length) {
      P.exact.hidden = true;
      P.canvas.style.visibility = "";
      S.report.delete(pi);
      renderFidelity();
      return;
    }
    P.busy.hidden = false;
    try {
      const res = await post("/api/edit/preview", { id: S.file.id, page: pi, edits, scale: clamp(S.zoom * DPR, 1, 4) });
      if (!res.ok) throw new Error(await readError(res));
      let rep = null;
      try { rep = JSON.parse(res.headers.get("X-Edit-Report") || "null"); } catch (e) { /* optional */ }
      const blob = await res.blob();
      if (exactSeq.get(pi) !== seq || disposed) return;
      const url = URL.createObjectURL(blob);
      blobUrls.add(url);
      const old = P.exact.dataset.url;
      await new Promise((ok) => { P.exact.onload = ok; P.exact.onerror = ok; P.exact.src = url; });
      P.exact.dataset.url = url;
      if (old) { URL.revokeObjectURL(old); blobUrls.delete(old); }
      P.exact.hidden = false;
      if (rep) S.report.set(pi, rep);
      renderFidelity();
    } catch (e) {
      if (exactSeq.get(pi) === seq) toast(e.message || "The preview could not be updated.", "error");
    } finally {
      if (exactSeq.get(pi) === seq) P.busy.hidden = true;
    }
  }

  function renderFidelity() {
    let exact = 0;
    const sub = {};
    let missing = "";
    for (const r of S.report.values()) {
      exact += r.exact || 0;
      for (const [k, v] of Object.entries(r.substituted || {})) sub[k] = (sub[k] || "") + v;
      missing += r.missing || "";
    }
    const subChars = [...new Set(Object.values(sub).join(""))].join("");
    if (!exact && !subChars && !missing) { fidEl.innerHTML = ""; return; }
    const rows = [];
    if (exact) rows.push(`<div class="fid ok"><b>${exact}</b> letters use the original font</div>`);
    if (subChars) rows.push(`<div class="fid warn"><b>${[...subChars].length}</b> letters use a matching installed font: <span class="chars" translate="no">${esc(subChars)}</span></div>`);
    if (missing) rows.push(`<div class="fid bad">No font has: <span class="chars" translate="no">${esc([...new Set(missing)].join(""))}</span></div>`);
    fidEl.innerHTML = `<div class="label">Fidelity</div>${rows.join("")}<div class="hint">Letters that already exist in the PDF keep their exact shape and spacing. New letters use the closest installed font.</div>`;
  }

  /* ---------------- selection ---------------- */
  function select(u) {
    if (S.sel === u) return;
    S.sel = u;
    if (u) S.selLine = null;
    S.pages.forEach((_, pi) => renderSelection(pi));
    renderSide();
  }

  /* ---------------- rendering objects ---------------- */
  function renderObjects(pi) {
    const P = S.pages[pi];
    if (!P) return;
    const z = S.zoom;
    P.svg.innerHTML = "";
    P.objs.querySelectorAll(".ed-obj").forEach((n) => n.remove());
    for (const e of S.edits) {
      if (e.page !== pi) continue;
      if (e.t === "text") drawText(P, e, z);
      else if (e.t === "image") drawImage(P, e, z);
      else if (["rect", "ellipse", "line", "ink", "highlight", "cover"].includes(e.t)) drawShape(P, e);
    }
    renderSelection(pi);
  }

  function drawShape(P, e) {
    const g = svgEl("g", { "data-uid": e.uid, class: "ed-shape" });
    const stroke = e.stroke || "none";
    const common = { stroke, "stroke-width": e.width || 0, "stroke-linecap": "round", "stroke-linejoin": "round", opacity: e.opacity ?? 1 };
    if (e.t === "rect") {
      const [x0, y0, x1, y1] = normRect(e.rect);
      g.appendChild(svgEl("rect", { x: x0, y: y0, width: x1 - x0, height: y1 - y0, rx: e.radius || 0, fill: e.fill || "none", ...common }));
    } else if (e.t === "ellipse") {
      const [x0, y0, x1, y1] = normRect(e.rect);
      g.appendChild(svgEl("ellipse", { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, rx: (x1 - x0) / 2, ry: (y1 - y0) / 2, fill: e.fill || "none", ...common }));
    } else if (e.t === "line") {
      const [a, b] = [e.p1, e.p2];
      g.appendChild(svgEl("path", { d: `M${a[0]} ${a[1]}L${b[0]} ${b[1]}`, fill: "none", ...common }));
      if (e.arrow) {
        const len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
        const ux = (b[0] - a[0]) / len, uy = (b[1] - a[1]) / len;
        const hl = Math.min(Math.max(8, (e.width || 2) * 4.5), len * 0.6);
        let d = "";
        for (const s of [1, -1]) {
          const ang = (26 * Math.PI / 180) * s;
          const bx = -(ux * Math.cos(ang) - uy * Math.sin(ang)) * hl, by = -(ux * Math.sin(ang) + uy * Math.cos(ang)) * hl;
          d += `M${b[0]} ${b[1]}L${b[0] + bx} ${b[1] + by}`;
        }
        g.appendChild(svgEl("path", { d, fill: "none", ...common }));
      }
      g.appendChild(svgEl("path", { d: `M${a[0]} ${a[1]}L${b[0]} ${b[1]}`, fill: "none", stroke: "transparent", "stroke-width": Math.max(12, e.width || 2), class: "hit" }));
    } else if (e.t === "ink") {
      const pts = e.pts || [];
      const d = pts.length > 1 ? "M" + pts.map((p) => `${p[0]} ${p[1]}`).join("L") : pts.length ? `M${pts[0][0]} ${pts[0][1]}l0.01 0` : "";
      g.appendChild(svgEl("path", { d, fill: "none", ...common }));
      g.appendChild(svgEl("path", { d, fill: "none", stroke: "transparent", "stroke-width": Math.max(12, e.width || 2), "stroke-linecap": "round", class: "hit" }));
    } else if (e.t === "highlight") {
      const [x0, y0, x1, y1] = normRect(e.rect);
      g.appendChild(svgEl("rect", { x: x0, y: y0, width: x1 - x0, height: y1 - y0, fill: e.color, opacity: e.opacity, style: "mix-blend-mode:multiply" }));
    } else if (e.t === "cover") {
      const [x0, y0, x1, y1] = normRect(e.rect);
      g.appendChild(svgEl("rect", { x: x0, y: y0, width: x1 - x0, height: y1 - y0, fill: e.color, class: "cover" }));
    }
    P.svg.appendChild(g);
  }

  function drawText(P, e, z) {
    const d = el("div", "ed-obj ed-text");
    d.setAttribute("translate", "no");  // the user's own words
    d.dataset.uid = e.uid;
    Object.assign(d.style, {
      left: `${e.x * z}px`, top: `${e.y * z}px`, fontSize: `${e.size * z}px`, lineHeight: `${(e.lh || 1.25) * e.size * z}px`,
      color: e.color, fontFamily: cssFamily(e.family, "sans", hasArabic(e.text)), fontWeight: e.bold ? "700" : "400", fontStyle: e.italic ? "italic" : "normal",
      textAlign: e.align || "left", unicodeBidi: "plaintext",
    });
    if (e.align && e.align !== "left" && e.w) d.style.width = `${e.w * z}px`;
    d.textContent = e.text;
    P.objs.appendChild(d);
  }

  function drawImage(P, e, z) {
    const [x0, y0, x1, y1] = normRect(e.rect);
    const d = el("div", "ed-obj ed-img");
    d.dataset.uid = e.uid;
    Object.assign(d.style, { left: `${x0 * z}px`, top: `${y0 * z}px`, width: `${(x1 - x0) * z}px`, height: `${(y1 - y0) * z}px` });
    const im = document.createElement("img");
    im.src = pictures.get(e.pic) || ""; im.draggable = false;
    d.appendChild(im);
    P.objs.appendChild(d);
  }

  const normRect = (r) => [Math.min(r[0], r[2]), Math.min(r[1], r[3]), Math.max(r[0], r[2]), Math.max(r[1], r[3])];

  /** Bounding box of an object in points. */
  function bboxOf(e, P) {
    if (["rect", "ellipse", "highlight", "cover", "image"].includes(e.t)) return normRect(e.rect);
    if (e.t === "line") return [Math.min(e.p1[0], e.p2[0]), Math.min(e.p1[1], e.p2[1]), Math.max(e.p1[0], e.p2[0]), Math.max(e.p1[1], e.p2[1])];
    if (e.t === "ink") {
      const xs = e.pts.map((p) => p[0]), ys = e.pts.map((p) => p[1]);
      return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
    }
    if (e.t === "text") {
      const n = P.objs.querySelector(`.ed-text[data-uid="${e.uid}"]`);
      if (n) return [e.x, e.y, e.x + Math.max(n.offsetWidth, 8) / S.zoom, e.y + Math.max(n.offsetHeight, 8) / S.zoom];
      return [e.x, e.y, e.x + 40, e.y + e.size * 1.3];
    }
    return [0, 0, 0, 0];
  }

  const RESIZABLE = new Set(["rect", "ellipse", "highlight", "cover", "image"]);
  function renderSelection(pi) {
    const P = S.pages[pi];
    P.objs.querySelectorAll(".ed-sel").forEach((n) => n.remove());
    P.objs.querySelectorAll(".sel").forEach((n) => n.classList.remove("sel"));
    const e = S.sel && byUid(S.sel);
    if (!e || e.page !== pi) return;
    P.objs.querySelectorAll(`[data-uid="${e.uid}"]`).forEach((n) => n.classList.add("sel"));
    const z = S.zoom;
    const [x0, y0, x1, y1] = bboxOf(e, P);
    const pad = e.t === "line" || e.t === "ink" ? 6 : 2;
    const box = el("div", "ed-sel");
    Object.assign(box.style, { left: `${(x0 - pad) * z}px`, top: `${(y0 - pad) * z}px`, width: `${(x1 - x0 + 2 * pad) * z}px`, height: `${(y1 - y0 + 2 * pad) * z}px` });
    const handles = [];
    if (RESIZABLE.has(e.t)) handles.push(["nw", 0, 0], ["n", 0.5, 0], ["ne", 1, 0], ["e", 1, 0.5], ["se", 1, 1], ["s", 0.5, 1], ["sw", 0, 1], ["w", 0, 0.5]);
    else if (e.t === "text") handles.push(["se", 1, 1]);
    for (const [k, fx, fy] of handles) {
      const h = el("i", `ed-h ${k}`);
      h.dataset.h = k;
      h.style.left = `${fx * 100}%`; h.style.top = `${fy * 100}%`;
      box.appendChild(h);
    }
    if (e.t === "line") {
      for (const [k, p] of [["p1", e.p1], ["p2", e.p2]]) {
        const h = el("i", "ed-h pt");
        h.dataset.h = k;
        h.style.left = `${(p[0] - (x0 - pad)) * z}px`; h.style.top = `${(p[1] - (y0 - pad)) * z}px`;
        box.appendChild(h);
      }
    }
    P.objs.appendChild(box);
  }

  /* ---------------- pointer handling ---------------- */
  function pt(P, ev) {
    const r = P.page.getBoundingClientRect();
    return [(ev.clientX - r.left) / S.zoom, (ev.clientY - r.top) / S.zoom];
  }

  function bindPage(P, pi) {
    P.page.addEventListener("pointerdown", (ev) => onPointerDown(ev, P, pi));
  }

  function onPointerDown(ev, P, pi) {
    if (ev.button !== 0) return;
    if (ev.target.closest(".ed-line-edit, .ed-card")) return;
    const tool = S.tool;
    if (tool === "select") return selectDown(ev, P, pi);
    if (tool === "image") return;
    if (editor) commitEditor();
    ev.preventDefault();
    const [x, y] = pt(P, ev);
    if (tool === "text") return createText(P, pi, x, y);
    startDraw(ev, P, pi, tool, x, y);
  }

  function selectDown(ev, P, pi) {
    const handle = ev.target.closest(".ed-h");
    const objNode = ev.target.closest("[data-uid]");
    if (handle && S.sel) {
      ev.preventDefault();
      return startResize(ev, P, pi, handle.dataset.h);
    }
    if (objNode) {
      ev.preventDefault();
      if (editor) commitEditor();
      const e = byUid(objNode.dataset.uid);
      if (!e) return;
      const wasSel = S.sel === e.uid;
      select(e.uid);
      if (e.t === "text" && wasSel && ev.detail >= 2) return editTextObject(P, e);
      return startMove(ev, P, pi, e);
    }
    const lineNode = ev.target.closest(".ed-line");
    if (lineNode) {
      ev.preventDefault();
      const ln = S.lines[pi]?.find((l) => l.id === Number(lineNode.dataset.line));
      if (ln) { select(null); openLineEditor(P, pi, ln); }
      return;
    }
    if (editor) commitEditor();
    select(null);
    S.selLine = null;
    renderSide();
  }

  function startMove(ev, P, pi, e) {
    const start = pt(P, ev);
    const orig = clone(e);
    let moved = false;
    beginLive();
    const mv = (m) => {
      const [x, y] = pt(P, m);
      const dx = x - start[0], dy = y - start[1];
      if (!moved && Math.hypot(dx, dy) * S.zoom < 3) return;
      moved = true;
      applyMove(e, orig, dx, dy);
      renderObjects(pi);
    };
    const up = () => {
      document.removeEventListener("pointermove", mv);
      document.removeEventListener("pointerup", up);
      if (moved) { endLive(); afterChange(pi); } else pending = null;
    };
    document.addEventListener("pointermove", mv);
    document.addEventListener("pointerup", up);
  }

  function applyMove(e, o, dx, dy) {
    if (e.t === "text") { e.x = r2(o.x + dx); e.y = r2(o.y + dy); }
    else if (e.rect) e.rect = [o.rect[0] + dx, o.rect[1] + dy, o.rect[2] + dx, o.rect[3] + dy].map(r2);
    else if (e.t === "line") { e.p1 = [o.p1[0] + dx, o.p1[1] + dy].map(r2); e.p2 = [o.p2[0] + dx, o.p2[1] + dy].map(r2); }
    else if (e.t === "ink") e.pts = o.pts.map((p) => [r2(p[0] + dx), r2(p[1] + dy)]);
  }

  function startResize(ev, P, pi, h) {
    const e = byUid(S.sel);
    if (!e) return;
    const orig = clone(e);
    beginLive();
    const [sx0, sy0, sx1, sy1] = bboxOf(orig, P);
    const ratio = (sx1 - sx0) / Math.max(1, sy1 - sy0);
    const mv = (m) => {
      const [x, y] = pt(P, m);
      if (e.t === "line") { e[h] = [r2(x), r2(y)]; }
      else if (e.t === "text") {
        const w0 = Math.max(10, sx1 - sx0);
        e.size = r2(clamp(orig.size * (Math.max(x - sx0, 8) / w0), 4, 400));
      } else {
        let [x0, y0, x1, y1] = [sx0, sy0, sx1, sy1];
        if (h.includes("w")) x0 = x; if (h.includes("e")) x1 = x;
        if (h.includes("n")) y0 = y; if (h.includes("s")) y1 = y;
        if (e.t === "image" && h.length === 2) { // keep the picture's proportions on corner drags
          const wNew = Math.abs(x1 - x0);
          const hNew = wNew / ratio;
          if (h.includes("n")) y0 = y1 - hNew; else y1 = y0 + hNew;
        }
        e.rect = [x0, y0, x1, y1].map(r2);
      }
      renderObjects(pi);
    };
    const up = () => {
      document.removeEventListener("pointermove", mv);
      document.removeEventListener("pointerup", up);
      endLive(); afterChange(pi);
    };
    document.addEventListener("pointermove", mv);
    document.addEventListener("pointerup", up);
  }

  /* ---- drawing new shapes ---- */
  function startDraw(ev, P, pi, tool, x0, y0) {
    const st = S.style;
    const e = { uid: uid(), page: pi };
    if (tool === "rect" || tool === "ellipse") Object.assign(e, { t: tool, rect: [x0, y0, x0, y0], stroke: st.stroke, fill: st.fill, width: st.width, opacity: st.opacity });
    else if (tool === "line" || tool === "arrow") Object.assign(e, { t: "line", p1: [x0, y0], p2: [x0, y0], stroke: st.stroke, width: st.width, opacity: st.opacity, arrow: tool === "arrow" });
    else if (tool === "ink") Object.assign(e, { t: "ink", pts: [[x0, y0]], stroke: st.stroke, width: st.width, opacity: st.opacity });
    else if (tool === "highlight") Object.assign(e, { t: "highlight", rect: [x0, y0, x0, y0], color: st.hl.color, opacity: st.hl.opacity });
    else if (tool === "cover") Object.assign(e, { t: "cover", rect: [x0, y0, x0, y0], color: sampleColor(pi, x0, y0), remove: true });
    else return;
    const snapshot = JSON.stringify(S.edits);
    S.edits.push(e);
    const mv = (m) => {
      let [x, y] = pt(P, m);
      x = clamp(x, 0, S.geo[pi].w); y = clamp(y, 0, S.geo[pi].h);
      if (e.rect) e.rect = [x0, y0, x, y].map(r2);
      else if (e.t === "line") {
        if (m.shiftKey) { // snap to 15 degree steps
          const dx = x - x0, dy = y - y0, len = Math.hypot(dx, dy), a = Math.round(Math.atan2(dy, dx) / (Math.PI / 12)) * (Math.PI / 12);
          x = x0 + len * Math.cos(a); y = y0 + len * Math.sin(a);
        }
        e.p2 = [r2(x), r2(y)];
      } else if (e.t === "ink") {
        const last = e.pts[e.pts.length - 1];
        if (Math.hypot(x - last[0], y - last[1]) >= 0.8) e.pts.push([r2(x), r2(y)]);
      }
      renderObjects(pi);
    };
    const up = () => {
      document.removeEventListener("pointermove", mv);
      document.removeEventListener("pointerup", up);
      const bb = bboxOf(e, P);
      const tiny = e.t === "ink" ? false : Math.hypot(bb[2] - bb[0], bb[3] - bb[1]) * S.zoom < 4;
      if (tiny) { S.edits.pop(); renderObjects(pi); return; }
      if (e.t === "cover") e.color = sampleColor(pi, ...cornerOf(e.rect));
      pushUndo(snapshot);
      afterChange(pi);
      if (tool !== "ink" && tool !== "highlight") { setTool("select"); select(e.uid); }
    };
    document.addEventListener("pointermove", mv);
    document.addEventListener("pointerup", up);
    renderObjects(pi);
  }
  const cornerOf = (r) => [Math.min(r[0], r[2]) + 1.5, Math.min(r[1], r[3]) + 1.5];

  let probe = null;
  function sampleColor(pi, x, y) {
    try {
      const P = S.pages[pi];
      const c = P.canvas;
      if (!c.width) return "#ffffff";
      const k = c.width / S.geo[pi].w;
      // read through a one-pixel canvas made for reading: the page canvas stays a fast drawing surface
      if (!probe) { const one = document.createElement("canvas"); one.width = one.height = 1; probe = one.getContext("2d", { willReadFrequently: true }); }
      probe.drawImage(c, Math.floor(x * k), Math.floor(y * k), 1, 1, 0, 0, 1, 1);
      const d = probe.getImageData(0, 0, 1, 1).data;
      return "#" + [d[0], d[1], d[2]].map((v) => v.toString(16).padStart(2, "0")).join("");
    } catch (e) { return "#ffffff"; }
  }

  /* ---- text objects ---- */
  function createText(P, pi, x, y) {
    const st = S.style.text;
    const e = { uid: uid(), t: "text", page: pi, x: r2(x), y: r2(y - st.size * 0.6), w: 0, text: "", ...clone(st) };
    e._new = true;
    S.edits.push(e);
    renderObjects(pi);
    select(e.uid);
    editTextObject(P, e);
  }

  function editTextObject(P, e) {
    commitEditor();
    const node = P.objs.querySelector(`.ed-text[data-uid="${e.uid}"]`);
    if (!node) return;
    const before = e._new ? null : JSON.stringify(S.edits);
    node.classList.add("editing");
    node.contentEditable = "plaintext-only";
    if (node.contentEditable !== "plaintext-only") node.contentEditable = "true";
    node.spellcheck = false;
    node.focus();
    const sel = getSelection();
    const range = document.createRange();
    range.selectNodeContents(node);
    if (e._new) range.collapse(false);
    sel.removeAllRanges(); sel.addRange(range);
    P.objs.querySelectorAll(".ed-sel").forEach((n) => n.remove());
    editor = { kind: "text", node, e, P, before };
    const finish = (cancel) => {
      if (!editor || editor.node !== node) return;
      node.removeEventListener("blur", onBlur);
      node.removeEventListener("keydown", onKeyEd);
      node.removeEventListener("input", onInputEd);
      const text = node.innerText.replace(/\n$/, "");
      node.contentEditable = "false";
      node.classList.remove("editing");
      editor = null;
      const pi = e.page;
      if (cancel || !text.trim()) {
        if (e._new) S.edits = S.edits.filter((x) => x !== e);
        else if (!text.trim() && !cancel) { S.edits = S.edits.filter((x) => x !== e); pushUndo(before); }
        select(null);
      } else {
        e.text = text;
        e.w = e.align !== "left" ? r2(measureWidth(node)) : 0;
        if (e._new) { delete e._new; pushUndo(JSON.stringify(S.edits.filter((x) => x !== e))); }
        else if (before && before !== JSON.stringify(S.edits)) pushUndo(before);
      }
      afterChange(pi);
      if (S.edits.includes(e)) renderSelection(pi);
    };
    const onBlur = () => setTimeout(() => { if (editor && editor.node === node && document.activeElement !== node) finish(false); }, 0);
    const onKeyEd = (k) => {
      if (k.key === "Escape") { k.preventDefault(); finish(false); }
      k.stopPropagation();
    };
    const onInputEd = () => { node.style.fontFamily = cssFamily(e.family, "sans", hasArabic(node.innerText)); };
    node.addEventListener("blur", onBlur);
    node.addEventListener("keydown", onKeyEd);
    node.addEventListener("input", onInputEd);
    editor.finish = finish;
  }
  const measureWidth = (node) => {
    const prev = node.style.width;
    node.style.width = "auto";
    const w = node.offsetWidth / S.zoom;
    node.style.width = prev;
    return w;
  };

  /* ---------------- editing existing text ---------------- */
  function openLineEditor(P, pi, ln) {
    commitEditor();
    const z = S.zoom;
    const existing = lineEdit(pi, ln.id);
    const startText = existing && existing.t === "edit" ? existing.text : existing && existing.t === "delete" ? "" : ln.text;
    const style = existing && existing.t === "edit" ? existing : {};
    const size = (style.size || ln.size);
    const angle = Math.atan2(ln.dir[1], ln.dir[0]);
    const [ox, oy] = ln.origin;
    const up = [ln.dir[1], -ln.dir[0]];
    const topLeft = [ox + up[0] * size * 0.88, oy + up[1] * size * 0.88];
    const node = el("div", "ed-line-edit");
    node.setAttribute("translate", "no");  // text of the PDF
    Object.assign(node.style, {
      left: `${topLeft[0] * z}px`, top: `${topLeft[1] * z}px`, transformOrigin: "0 0",
      transform: angle ? `rotate(${angle}rad)` : "none",
      minWidth: `${(ln.bbox[2] - ln.bbox[0]) * z}px`, height: `${size * 1.25 * z}px`, lineHeight: `${size * 1.25 * z}px`,
      fontSize: `${size * z}px`, color: style.color || ln.color,
      fontFamily: cssFamily(style.family || (ln.font ? `sys:${ln.font.replace(/[-_].*$/, "")}` : null), ln.cls, !!ln.shaped),
      fontWeight: (style.bold ?? ln.bold) ? "700" : "400", fontStyle: (style.italic ?? ln.italic) ? "italic" : "normal",
      background: sampleColor(pi, ln.bbox[0] - 2, ln.bbox[1] - 2),
    });
    node.contentEditable = "plaintext-only";
    if (node.contentEditable !== "plaintext-only") node.contentEditable = "true";
    node.spellcheck = false;
    // an Arabic line keeps the direction of its paragraph; text without Arabic letters reads left to right (as saved)
    const setDir = () => { node.dir = !hasArabic(node.innerText) ? "ltr" : ln.shaped ? (ln.rtl ? "rtl" : "ltr") : "auto"; };
    if (ln.rtl && !angle) {  // grow to the left
      node.style.left = "auto";
      node.style.right = `${(S.geo[pi].w - ln.bbox[2]) * z}px`;
    }
    node.textContent = startText;
    setDir();
    P.over.appendChild(node);
    const card = el("div", "ed-card");
    card.innerHTML = `<div class="ed-card-img"><img alt=""></div><div class="ed-card-badge"></div><div class="ed-card-keys">Enter to apply &middot; Esc to cancel</div>`;
    P.over.appendChild(card);
    positionCard(card, ln, z);
    node.focus();
    const range = document.createRange();
    range.selectNodeContents(node);
    getSelection().removeAllRanges(); getSelection().addRange(range);
    S.selLine = { page: pi, id: ln.id };
    renderSide();
    editor = { kind: "line", node, card, ln, P, pi, startText, base: existing ? clone(existing) : null };
    const update = () => { setDir(); updateCardBadge(); scheduleCardPreview(); };
    node.addEventListener("input", update);
    node.addEventListener("keydown", (k) => {
      if (k.key === "Enter") { k.preventDefault(); commitEditor(); }
      else if (k.key === "Escape") { k.preventDefault(); commitEditor(true); }
      k.stopPropagation();
    });
    node.addEventListener("blur", () => setTimeout(() => {
      if (editor && editor.node === node && document.activeElement !== node && !card.matches(":hover")) commitEditor();
    }, 80));
    updateCardBadge();
    scheduleCardPreview(true);
  }

  function positionCard(card, ln, z) {
    const [x0, y0, x1, y1] = ln.bbox;
    const P = editor?.P || S.pages[S.selLine?.page || 0];
    const above = y0 * z > 120;
    card.style.left = `${Math.max(0, x0 * z - 4)}px`;
    card.style.top = above ? "auto" : `${(y1 + 8) * z}px`;
    card.style.bottom = above ? `${P.page.offsetHeight - (y0 - 8) * z}px` : "auto";
  }

  function updateCardBadge() {
    if (!editor || editor.kind !== "line") return;
    const { ln, node, card } = editor;
    const text = node.innerText.replace(/\n/g, " ");
    const base = lineEdit(editor.pi, ln.id);
    const custom = base && base.t === "edit" && (base.family || base.bold != null || base.italic != null);
    const miss = [...new Set([...text].filter((c) => c !== " " && !ln.avail.includes(c)))];
    const b = $(".ed-card-badge", card);
    if (custom) b.innerHTML = '<span class="fid warn">Custom font selected</span>';
    else if (!ln.exact) b.innerHTML = '<span class="fid warn">Close font used for this line</span>';
    else if (miss.length) b.innerHTML = `<span class="fid warn">Close font for: <span class="chars" translate="no">${esc(miss.join(""))}</span></span>`;
    else b.innerHTML = '<span class="fid ok">Original font</span>';
  }

  let cardTimer = null, cardSeq = 0;
  function scheduleCardPreview(now) {
    clearTimeout(cardTimer);
    cardTimer = setTimeout(runCardPreview, now ? 0 : 260);
  }
  async function runCardPreview() {
    if (!editor || editor.kind !== "line" || !S.file) return;
    const { ln, node, card, pi } = editor;
    const text = node.innerText.replace(/\n/g, " ");
    const edits = S.edits.filter((e) => e.page === pi && isExact(e) && !((e.t === "edit" || e.t === "delete") && e.line === ln.id)).map(serialize);
    const prior = lineEdit(pi, ln.id);
    const cur = { t: "edit", page: pi, line: ln.id, text };
    if (prior && prior.t === "edit") for (const k of ["size", "color", "family", "bold", "italic", "fit"]) if (prior[k] != null) cur[k] = prior[k];
    edits.push(cur);
    const w = Math.max(ln.bbox[2] - ln.bbox[0], text.length * ln.size * 0.62);
    const clip = ln.rtl && Math.abs(ln.dir[1]) < 0.01
      ? [Math.max(0, ln.bbox[2] - w - 10), Math.max(0, ln.bbox[1] - 5), Math.min(S.geo[pi].w, ln.bbox[2] + 8), Math.min(S.geo[pi].h, ln.bbox[3] + 5)]
      : [Math.max(0, ln.bbox[0] - 8), Math.max(0, ln.bbox[1] - 5), Math.min(S.geo[pi].w, ln.bbox[0] + w + 10), Math.min(S.geo[pi].h, ln.bbox[3] + 5)];
    const seq = ++cardSeq;
    try {
      const res = await post("/api/edit/preview", { id: S.file.id, page: pi, edits, scale: 3, clip });
      if (!res.ok) throw new Error(await readError(res));
      const blob = await res.blob();
      if (seq !== cardSeq || !editor || editor.node !== node) return;
      const url = URL.createObjectURL(blob);
      const im = $("img", card);
      const old = im.dataset.url;
      im.src = url; im.dataset.url = url;
      if (old) URL.revokeObjectURL(old);
      const cw = (clip[2] - clip[0]) * Math.min(S.zoom * 1.6, 2.6);
      im.style.width = `${Math.min(cw, 560)}px`;
      let rep = null;
      try { rep = JSON.parse(res.headers.get("X-Edit-Report") || "null"); } catch (e) { /* optional */ }
      if (rep) {
        const subs = [...new Set(Object.values(rep.substituted || {}).join(""))];
        const b = $(".ed-card-badge", card);
        if (rep.missing) b.innerHTML = `<span class="fid bad">No font has: <span class="chars" translate="no">${esc(rep.missing)}</span></span>`;
        else if (subs.length && (ln.shaped || hasArabic(text))) b.innerHTML = '<span class="fid warn">Close font used for this line</span>';
        else if (subs.length) b.innerHTML = `<span class="fid warn">Close font for: <span class="chars" translate="no">${esc(subs.join(""))}</span></span>`;
        else b.innerHTML = '<span class="fid ok">Original font</span>';
      }
    } catch (e) { /* the badge already tells the story; a failed preview must not interrupt typing */ }
  }

  function commitEditor(cancel) {
    if (!editor) return;
    if (editor.kind === "text") return editor.finish(!!cancel);
    const { node, card, ln, pi, startText, base } = editor;
    const text = node.innerText.replace(/\n/g, " ");
    const old = editor;
    editor = null;
    clearTimeout(cardTimer);
    const im = $("img", card);
    if (im?.dataset.url) URL.revokeObjectURL(im.dataset.url);
    node.remove(); card.remove();
    if (cancel || text === startText) { renderLinesLayer(pi); return; }
    mutate(() => {
      let e = lineEdit(pi, ln.id);
      if (!text.trim()) {
        S.edits = S.edits.filter((x) => x !== e);
        S.edits.push({ uid: uid(), t: "delete", page: pi, line: ln.id });
      } else if (text === ln.text && !(e && e.t === "edit" && (e.size || e.color || e.family || e.bold != null || e.italic != null || e.fit))) {
        S.edits = S.edits.filter((x) => x !== e); // typed back to the original
      } else {
        if (!e || e.t === "delete") {
          S.edits = S.edits.filter((x) => x !== e);
          e = { uid: uid(), t: "edit", page: pi, line: ln.id, text };
          S.edits.push(e);
        } else e.text = text;
      }
    }, pi);
    void old;
  }

  /* line style overrides come from the sidebar */
  function lineOverride(patch) {
    const sl = S.selLine;
    if (!sl) return;
    const ln = S.lines[sl.page]?.find((l) => l.id === sl.id);
    if (!ln) return;
    beginLive();
    let e = lineEdit(sl.page, sl.id);
    if (!e || e.t === "delete") {
      S.edits = S.edits.filter((x) => x !== e);
      e = { uid: uid(), t: "edit", page: sl.page, line: sl.id, text: ln.text };
      S.edits.push(e);
    }
    if (editor && editor.kind === "line") e.text = editor.node.innerText.replace(/\n/g, " ");
    for (const [k, v] of Object.entries(patch)) { if (v == null || v === "") delete e[k]; else e[k] = v; }
    if (editor && editor.kind === "line") {
      const n = editor.node;
      if ("size" in patch) { const s = e.size || ln.size; n.style.fontSize = `${s * S.zoom}px`; n.style.height = `${s * 1.25 * S.zoom}px`; n.style.lineHeight = n.style.height; }
      if ("color" in patch) n.style.color = e.color || ln.color;
      if ("bold" in patch) n.style.fontWeight = (e.bold ?? ln.bold) ? "700" : "400";
      if ("italic" in patch) n.style.fontStyle = (e.italic ?? ln.italic) ? "italic" : "normal";
      if ("family" in patch) n.style.fontFamily = cssFamily(e.family, ln.cls, !!ln.shaped);
      updateCardBadge();
      scheduleCardPreview();
    } else {
      scheduleExact(sl.page, 200);
      renderLinesLayer(sl.page);
    }
    updateStats();
    renderSideSoft();
  }

  /* ---------------- images ---------------- */
  imgInput.addEventListener("change", async () => {
    const f = imgInput.files[0];
    if (!f) { setTool("select"); return; }
    try {
      const { data, w, h } = await readImage(f);
      const pi = clamp(S.curPage || 0, 0, S.geo.length - 1);
      const g = S.geo[pi];
      const maxW = g.w * 0.45, k = Math.min(1, maxW / w, (g.h * 0.6) / h);
      const iw = (w * k) || 100, ih = (h * k) || 100;
      const scr = scroller.getBoundingClientRect(), pr = S.pages[pi].page.getBoundingClientRect();
      const cy = clamp((scr.top + scr.height / 2 - pr.top) / S.zoom, ih / 2, g.h - ih / 2);
      const pic = uid();
      pictures.set(pic, data);
      const e = { uid: uid(), t: "image", page: pi, rect: [g.w / 2 - iw / 2, cy - ih / 2, g.w / 2 + iw / 2, cy + ih / 2].map(r2), pic };
      mutate(() => S.edits.push(e), pi);
      setTool("select");
      select(e.uid);
    } catch (err) {
      toast(err.message || "That image could not be read.", "error");
      setTool("select");
    }
  });
  imgInput.addEventListener("cancel", () => setTool("select"));

  function readImage(file) {
    return new Promise((ok, fail) => {
      const rd = new FileReader();
      rd.onerror = () => fail(new Error("That image could not be read."));
      rd.onload = () => {
        const im = new Image();
        im.onerror = () => fail(new Error("That file is not a picture PDF Lab can read."));
        im.onload = () => {
          let { naturalWidth: w, naturalHeight: h } = im;
          let data = rd.result;
          if (Math.max(w, h) > 3200 || file.size > 6 * 1024 * 1024) { // keep the PDF a sane size
            const k = Math.min(1, 3200 / Math.max(w, h));
            const c = document.createElement("canvas");
            c.width = Math.round(w * k); c.height = Math.round(h * k);
            c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
            data = c.toDataURL(file.type === "image/png" ? "image/png" : "image/jpeg", 0.9);
          }
          if (!/^data:image\/(png|jpeg)/.test(data)) { // gif or webp: convert
            const c = document.createElement("canvas");
            c.width = w; c.height = h;
            c.getContext("2d").drawImage(im, 0, 0);
            data = c.toDataURL("image/png");
          }
          ok({ data, w, h });
        };
        im.src = rd.result;
      };
      rd.readAsDataURL(file);
    });
  }

  /* ---------------- keyboard ---------------- */
  function onKey(ev) {
    if (ctx.dead || disposed || ctx.root.closest("[hidden]")) return;
    const typing = ev.target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(ev.target.tagName);
    const mod = ev.metaKey || ev.ctrlKey;
    if (mod && ev.key.toLowerCase() === "z" && !typing) { ev.preventDefault(); ev.shiftKey ? redo() : undo(); return; }
    if (mod && ev.key.toLowerCase() === "y" && !typing) { ev.preventDefault(); redo(); return; }
    if (typing || !S.file) return;
    if (ev.key === "Escape") { select(null); setTool("select"); return; }
    const e = S.sel && byUid(S.sel);
    if (!e) return;
    if (ev.key === "Delete" || ev.key === "Backspace") {
      ev.preventDefault();
      mutate(() => { S.edits = S.edits.filter((x) => x !== e); }, e.page);
      S.sel = null; renderSide();
    } else if (ev.key.startsWith("Arrow")) {
      ev.preventDefault();
      const step = ev.shiftKey ? 10 : 1;
      const dx = ev.key === "ArrowLeft" ? -step : ev.key === "ArrowRight" ? step : 0;
      const dy = ev.key === "ArrowUp" ? -step : ev.key === "ArrowDown" ? step : 0;
      beginLive();
      applyMove(e, clone(e), dx, dy);
      endLive();
      afterChange(e.page);
    }
  }

  /* ---------------- sidebar ---------------- */
  const HINTS = {
    select: "Click any text on the page to edit it. Your new text keeps the original font and spacing, and a live preview shows the exact result. Click a shape or picture to move it.",
    text: "Click where the text should go, then type. Press Esc or click away when you are done.",
    image: "Pick a picture and it is placed on the page. Drag it to move it, drag a corner to resize.",
    rect: "Drag on the page to draw a rectangle.", ellipse: "Drag on the page to draw an ellipse.",
    line: "Drag to draw a line. Hold Shift for straight angles.", arrow: "Drag to draw an arrow. Hold Shift for straight angles.",
    ink: "Draw freely with the mouse or trackpad.", highlight: "Drag over text to highlight it.",
    cover: "Drag over anything to hide it. The content underneath is removed for good, and the colour matches the page.",
  };

  const FONT_OPTIONS = () => [
    ["sans", "Sans (Helvetica style)"], ["serif", "Serif (Times style)"], ["mono", "Mono (Courier style)"],
    ...S.fonts.map((f) => [`sys:${f.name}`, f.name]),
  ];
  const fontSelect = (value, withOriginal) => `<select class="text-in" data-p="family">${withOriginal ? `<option value="">Original font</option>` : ""}${FONT_OPTIONS().map(([v, n]) => `<option value="${esc(v)}" ${v.startsWith("sys:") ? 'translate="no"' : ""} ${v === value ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>`;

  let sideSig = "";
  function renderSide() {
    hintEl.textContent = HINTS[S.tool] || "";
    const sel = S.sel && byUid(S.sel);
    let html = "";
    if (S.selLine && !sel) html = lineProps();
    else if (sel) html = objectProps(sel);
    else if (S.tool === "text") html = textProps(S.style.text, "Text style");
    else if (["rect", "ellipse", "line", "arrow", "ink"].includes(S.tool)) html = strokeProps(S.style, S.tool, "Style");
    else if (S.tool === "highlight") html = hlProps(S.style.hl, "Highlight");
    sideSig = html;
    propsEl.innerHTML = html;
    bindProps();
    updateStats();
  }
  /** Refresh only values, so a control being dragged keeps focus. */
  function renderSideSoft() { /* controls keep their own state while changing */ }

  const row = (label, inner) => `<label class="ed-row"><span>${label}</span>${inner}</label>`;
  const seg3 = (key, val, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v, t]) => `<button type="button" data-v="${v}" class="${String(val) === String(v) ? "on" : ""}">${t}</button>`).join("")}</div>`;

  function lineProps() {
    const sl = S.selLine;
    const ln = S.lines[sl.page]?.find((l) => l.id === sl.id);
    if (!ln) return "";
    const e = lineEdit(sl.page, sl.id);
    const o = e && e.t === "edit" ? e : {};
    const size = o.size || ln.size;
    const color = o.color || ln.color;
    return `<div class="label">Selected text</div>
      <div class="ed-card-mini"><strong${ln.font ? ' translate="no"' : ""}>${esc(ln.font || "Font")}</strong><span>${r2(ln.size)} pt${ln.exact ? "" : " &middot; close font used"}</span></div>
      ${row("Size", `<input class="text-in" type="number" min="2" max="400" step="0.5" value="${r2(size)}" data-l="size">`)}
      ${row("Color", `<input type="color" value="${color}" data-l="color" class="ed-color">`)}
      ${row("Font", fontSelect(o.family || "", true).replace('data-p="family"', 'data-l="family"'))}
      <div class="btn-row"><button type="button" class="pill-btn small ${o.bold ? "on" : ""}" data-lt="bold"><b>B</b></button><button type="button" class="pill-btn small ${o.italic ? "on" : ""}" data-lt="italic"><i>I</i></button>
        <button type="button" class="pill-btn small ghost" data-lt="reset">Original style</button></div>
      <label class="check"><input type="checkbox" data-l="fit" ${o.fit ? "checked" : ""}> Squeeze to the original width</label>
      <div class="hint">Changing the font here uses an installed font instead of the one in the PDF.</div>`;
  }

  function textProps(t, title) {
    return `<div class="label">${title}</div>
      ${row("Font", fontSelect(t.family, false))}
      ${row("Size", `<input class="text-in" type="number" min="4" max="400" step="0.5" value="${t.size}" data-p="size">`)}
      ${row("Color", `<input type="color" value="${t.color}" data-p="color" class="ed-color">`)}
      <div class="btn-row"><button type="button" class="pill-btn small ${t.bold ? "on" : ""}" data-t="bold"><b>B</b></button><button type="button" class="pill-btn small ${t.italic ? "on" : ""}" data-t="italic"><i>I</i></button></div>
      ${seg3("align", t.align, [["left", "Left"], ["center", "Center"], ["right", "Right"]])}
      ${row("Line height", `<input class="text-in" type="number" min="0.8" max="3" step="0.05" value="${t.lh}" data-p="lh">`)}`;
  }
  function strokeProps(o, kind, title) {
    const hasFill = kind === "rect" || kind === "ellipse";
    return `<div class="label">${title}</div>
      ${row("Line color", `<input type="color" value="${o.stroke || "#000000"}" data-p="stroke" class="ed-color">`)}
      ${hasFill ? `<label class="check"><input type="checkbox" data-p="hasfill" ${o.fill ? "checked" : ""}> Fill</label>${o.fill ? row("Fill color", `<input type="color" value="${o.fill}" data-p="fill" class="ed-color">`) : ""}` : ""}
      ${row("Thickness", `<input type="range" min="0.5" max="20" step="0.5" value="${o.width}" data-p="width"><b class="ed-val">${o.width}</b>`)}
      ${row("Opacity", `<input type="range" min="0.1" max="1" step="0.05" value="${o.opacity}" data-p="opacity"><b class="ed-val">${Math.round(o.opacity * 100)}%</b>`)}`;
  }
  function hlProps(o, title) {
    return `<div class="label">${title}</div>
      <div class="ed-swatches">${["#ffe34d", "#9be15d", "#7fd4ff", "#ff9ecd", "#ffb15c"].map((c) => `<button type="button" class="sw ${o.color === c ? "on" : ""}" style="background:${c}" data-sw="${c}" aria-label="${c}"></button>`).join("")}</div>
      ${row("Color", `<input type="color" value="${o.color}" data-p="color" class="ed-color">`)}
      ${row("Strength", `<input type="range" min="0.1" max="1" step="0.05" value="${o.opacity}" data-p="opacity"><b class="ed-val">${Math.round(o.opacity * 100)}%</b>`)}`;
  }
  function objectProps(e) {
    const del = `<div class="btn-row"><button type="button" class="pill-btn small" data-obj="front">Bring to front</button><button type="button" class="pill-btn small" data-obj="back">Send to back</button><button type="button" class="pill-btn small ghost danger" data-obj="delete">Delete</button></div>`;
    if (e.t === "text") return textProps(e, "Text") + del;
    if (e.t === "rect" || e.t === "ellipse") return strokeProps(e, e.t, e.t === "rect" ? "Rectangle" : "Ellipse") + del;
    if (e.t === "line") return strokeProps(e, "line", e.arrow ? "Arrow" : "Line") + del;
    if (e.t === "ink") return strokeProps(e, "ink", "Drawing") + del;
    if (e.t === "highlight") return hlProps(e, "Highlight") + del;
    if (e.t === "cover") return `<div class="label">Cover</div>${row("Color", `<input type="color" value="${e.color}" data-p="color" class="ed-color">`)}
      <label class="check"><input type="checkbox" data-p="remove" ${e.remove !== false ? "checked" : ""}> Remove what is underneath</label>
      <div class="hint">When on, text and pictures under the box are deleted from the file, not just hidden.</div>${del}`;
    if (e.t === "image") return `<div class="label">Picture</div><div class="hint">Drag the picture to move it. Drag a corner to resize it.</div>${del}`;
    return del;
  }

  function target() { return (S.sel && byUid(S.sel)) || null; }
  function setProp(key, value, live) {
    const e = target();
    const dst = e || (S.tool === "text" ? S.style.text : ["highlight"].includes(S.tool) ? S.style.hl : S.style);
    if (live) beginLive();
    if (key === "hasfill") dst.fill = value ? (dst.stroke || "#e5484d") : null;
    else if (key === "size" || key === "width" || key === "opacity" || key === "lh") dst[key] = Number(value) || dst[key];
    else dst[key] = value;
    if (e) {
      if (e.t === "text" && key !== "text") e.w = e.align !== "left" ? (e.w || 0) : 0;
      renderObjects(e.page);
      if (e.t === "text" && e.align !== "left") {
        const n = S.pages[e.page].objs.querySelector(`.ed-text[data-uid="${e.uid}"]`);
        if (n) { e.w = r2(measureWidth(n)); n.style.width = `${e.w * S.zoom}px`; }
      }
      renderSelection(e.page);
      if (e.t === "cover") scheduleExact(e.page, 150);
    }
  }

  function bindProps() {
    propsEl.querySelectorAll("[data-p]").forEach((inp) => {
      const key = inp.dataset.p;
      const isChk = inp.type === "checkbox";
      inp.addEventListener("input", () => {
        const v = isChk ? inp.checked : inp.value;
        setProp(key, v, true);
        const out = inp.parentElement.querySelector(".ed-val");
        if (out) out.textContent = key === "opacity" ? `${Math.round(v * 100)}%` : v;
      });
      inp.addEventListener("change", () => {
        endLive();
        updateStats();
        if (key === "hasfill" || key === "family" || key === "remove") { if (target()) afterChange(target().page); renderSide(); }
        else if (target()) afterChange(target().page);
      });
    });
    propsEl.querySelectorAll("[data-t]").forEach((b) => b.addEventListener("click", () => {
      const e = target();
      const dst = e || S.style.text;
      beginLive();
      dst[b.dataset.t] = !dst[b.dataset.t];
      endLive();
      if (e) { renderObjects(e.page); afterChange(e.page); }
      renderSide();
    }));
    propsEl.querySelectorAll("[data-seg]").forEach((seg) => seg.addEventListener("click", (ev) => {
      const b = ev.target.closest("button");
      if (!b) return;
      const e = target();
      const dst = e || S.style.text;
      beginLive();
      dst[seg.dataset.seg] = b.dataset.v;
      if (e && e.t === "text") { renderObjects(e.page); e.w = e.align !== "left" ? r2(measureWidth(S.pages[e.page].objs.querySelector(`.ed-text[data-uid="${e.uid}"]`))) : 0; renderObjects(e.page); }
      endLive();
      if (e) afterChange(e.page);
      renderSide();
    }));
    propsEl.querySelectorAll("[data-sw]").forEach((b) => b.addEventListener("click", () => {
      beginLive(); setProp("color", b.dataset.sw); endLive();
      if (target()) afterChange(target().page);
      renderSide();
    }));
    propsEl.querySelectorAll("[data-obj]").forEach((b) => b.addEventListener("click", () => {
      const e = target();
      if (!e) return;
      const a = b.dataset.obj;
      mutate(() => {
        if (a === "delete") { S.edits = S.edits.filter((x) => x !== e); S.sel = null; }
        else { S.edits = S.edits.filter((x) => x !== e); a === "front" ? S.edits.push(e) : S.edits.unshift(e); }
      }, e.page);
      renderSide();
    }));
    // existing line overrides
    propsEl.querySelectorAll("[data-l]").forEach((inp) => {
      const key = inp.dataset.l;
      const handler = () => {
        let v = inp.type === "checkbox" ? inp.checked : inp.value;
        if (key === "size") v = Number(v) > 0 ? Number(v) : null;
        if (key === "fit") v = v ? true : null;
        lineOverride({ [key]: v });
      };
      inp.addEventListener("input", handler);
      inp.addEventListener("change", () => { handler(); endLive(); });
    });
    propsEl.querySelectorAll("[data-lt]").forEach((b) => b.addEventListener("click", () => {
      const k = b.dataset.lt;
      const sl = S.selLine;
      const e = sl && lineEdit(sl.page, sl.id);
      if (k === "reset") { lineOverride({ size: null, color: null, family: null, bold: null, italic: null, fit: null }); }
      else {
        const ln = S.lines[sl.page].find((l) => l.id === sl.id);
        const cur = e && e.t === "edit" && e[k] != null ? e[k] : ln[k];
        lineOverride({ [k]: !cur });
      }
      endLive();
      renderSide();
    }));
  }

  /* ---------------- save ---------------- */
  ctx.setActionLabel("Save PDF");
  ctx.setEnabled(false);
  ctx.action.addEventListener("click", () => ctx.run(async () => {
    if (!S.file || !S.edits.length) return;
    commitEditor();
    if (editor) return;
    let report = null;
    ctx.plan({ name: S.file.name });
    const name = await saveFile(`${stem(S.file.name)}${fname("_edited")}.pdf`, async () => {
      ctx.estimate(700 + S.geo.length * 40 + S.edits.length * 15 + estMs(S.file.size || 0, 0, 30), "Applying your edits");
      const res = await post("/api/edit/export", { id: S.file.id, edits: S.edits.map(serialize) }, job.signal);
      if (!res.ok) throw new Error(await readError(res));
      try { report = JSON.parse(res.headers.get("X-Edit-Report") || "null"); } catch (e) { /* optional */ }
      return res.blob();
    });
    if (!name) return;
    const subs = report ? [...new Set(Object.values(report.substituted || {}).join(""))] : [];
    ctx.summary(`${plural(S.edits.length, "edit")} applied`, subs.length ? `Letters ${subs.join("")} use a close font, everything else keeps the original.` : "");
  }));

  window.addEventListener("resize", () => { if (S.file && !disposed && ctx.root.offsetParent) { /* keep the zoom the user chose */ } });
  void fmtSize;
  return ctx;
}
