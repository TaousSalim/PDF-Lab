"""Minimal, dependency free writers for .docx and .pptx files (zip plus XML)."""
import base64
import io
import re
import zipfile
from xml.sax.saxutils import escape

_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")  # not allowed in XML (lone surrogates too)


def esc(text):
    return escape(_BAD.sub("", str(text)), {'"': "&quot;"})


def _num(v, default):
    """A finite float, or the default for anything else (None, text, NaN, infinity)."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return default
    return v if v == v and abs(v) != float("inf") else default


def _zip(files):
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files:
            z.writestr(name, data if isinstance(data, bytes) else data.encode("utf-8"))
    return out.getvalue()


XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'

# ------------------------------------------------------------------ DOCX

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _style(sid, name, size, bold=False, before=0, after=120, outline=None, based="Normal"):
    ol = f'<w:outlineLvl w:val="{outline}"/>' if outline is not None else ""
    b = "<w:b/>" if bold else ""
    nxt = '<w:next w:val="Normal"/>' if sid != "Normal" else ""
    base = f'<w:basedOn w:val="{based}"/>' if sid != "Normal" else ""
    default = ' w:default="1"' if sid == "Normal" else ""
    return (
        f'<w:style w:type="paragraph"{default} w:styleId="{sid}"><w:name w:val="{name}"/>{base}{nxt}'
        f'<w:qFormat/><w:pPr><w:spacing w:before="{before}" w:after="{after}"/>{ol}</w:pPr>'
        f'<w:rPr>{b}<w:sz w:val="{size}"/><w:szCs w:val="{size}"/></w:rPr></w:style>'
    )


def _styles_xml(body_pt):
    half = int(round(body_pt * 2))
    return (
        XML
        + f'<w:styles xmlns:w="{W_NS}"><w:docDefaults><w:rPrDefault><w:rPr>'
        '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/>'
        f'<w:sz w:val="{half}"/><w:szCs w:val="{half}"/><w:lang w:val="en-US"/></w:rPr></w:rPrDefault>'
        '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault>'
        "</w:docDefaults>"
        + _style("Normal", "Normal", half)
        + _style("Heading1", "heading 1", 40, True, 240, 120, 0)
        + _style("Heading2", "heading 2", 32, True, 200, 100, 1)
        + _style("Heading3", "heading 3", 26, True, 160, 80, 2)
        + "</w:styles>"
    )


def _run(r):
    props = ""
    if r.get("b"):
        props += "<w:b/>"
    if r.get("i"):
        props += "<w:i/>"
    if _num(r.get("sz"), 0) > 0:
        hp = min(max(int(round(_num(r["sz"], 11) * 2)), 2), 3276)  # Word allows 1 to 1638 pt
        props += f'<w:sz w:val="{hp}"/><w:szCs w:val="{hp}"/>'
    rpr = f"<w:rPr>{props}</w:rPr>" if props else ""
    out = []
    for k, piece in enumerate(str(r.get("t", "")).split("\t")):
        if k:
            out.append(f"<w:r>{rpr}<w:tab/></w:r>")
        if piece != "":
            out.append(f'<w:r>{rpr}<w:t xml:space="preserve">{esc(piece)}</w:t></w:r>')
    return "".join(out)


def build_docx(page, blocks):
    if not isinstance(page, dict) or not isinstance(blocks, list):
        raise ValueError("Bad request.")
    # Word accepts pages up to 22 inches (1584 pt) a side, and the margins must leave room for text.
    w_pt = min(max(_num(page.get("w"), 0) or 595.3, 72), 1584)
    h_pt = min(max(_num(page.get("h"), 0) or 841.9, 72), 1584)
    body_pt = min(max(_num(page.get("body"), 0) or 11, 1), 400)
    margin = int(min(max(_num(page.get("margin"), 54), 0), min(w_pt, h_pt) / 4) * 20)
    parts = []
    for b in blocks:
        style = b.get("style", "p")
        if style == "pb":
            parts.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')
            continue
        ppr = ""
        sid = {"h1": "Heading1", "h2": "Heading2", "h3": "Heading3"}.get(style)
        if sid:
            ppr += f'<w:pStyle w:val="{sid}"/>'
        if b.get("keep"):
            ppr += "<w:keepNext/>"
        if _num(b.get("indent"), 0) > 0:  # the schema wants w:ind before w:jc
            ppr += f'<w:ind w:left="{int(min(_num(b["indent"], 0), w_pt / 2) * 20)}"/>'
        if b.get("align") in ("center", "right"):
            ppr += f'<w:jc w:val="{b["align"]}"/>'
        ppr = f"<w:pPr>{ppr}</w:pPr>" if ppr else ""
        runs = "".join(_run(r) for r in b.get("runs", []) if r.get("t") != "")
        parts.append(f"<w:p>{ppr}{runs}</w:p>")
    if not parts:
        parts.append("<w:p/>")
    sect = (
        f'<w:sectPr><w:pgSz w:w="{int(w_pt * 20)}" w:h="{int(h_pt * 20)}"/>'
        f'<w:pgMar w:top="{margin}" w:right="{margin}" w:bottom="{margin}" w:left="{margin}" '
        'w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>'
    )
    document = (
        XML + f'<w:document xmlns:w="{W_NS}" xmlns:r="{R_NS}"><w:body>' + "".join(parts) + sect + "</w:body></w:document>"
    )
    content_types = (
        XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
        "</Types>"
    )
    rels = (
        XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'<Relationship Id="rId1" Type="{R_NS}/officeDocument" Target="word/document.xml"/></Relationships>'
    )
    doc_rels = (
        XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'<Relationship Id="rId1" Type="{R_NS}/styles" Target="styles.xml"/></Relationships>'
    )
    return _zip([
        ("[Content_Types].xml", content_types),
        ("_rels/.rels", rels),
        ("word/document.xml", document),
        ("word/_rels/document.xml.rels", doc_rels),
        ("word/styles.xml", _styles_xml(body_pt)),
    ])


# ------------------------------------------------------------------ PPTX

A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
EMU = 12700  # per point

THEME = (
    XML
    + f'<a:theme xmlns:a="{A_NS}" name="PDF Lab"><a:themeElements>'
    '<a:clrScheme name="PDF Lab"><a:dk1><a:srgbClr val="000000"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1>'
    '<a:dk2><a:srgbClr val="1F2937"/></a:dk2><a:lt2><a:srgbClr val="F3F4F6"/></a:lt2>'
    '<a:accent1><a:srgbClr val="0B8F83"/></a:accent1><a:accent2><a:srgbClr val="DE7355"/></a:accent2>'
    '<a:accent3><a:srgbClr val="6A84C2"/></a:accent3><a:accent4><a:srgbClr val="D4BF4A"/></a:accent4>'
    '<a:accent5><a:srgbClr val="8B5CF6"/></a:accent5><a:accent6><a:srgbClr val="E5484D"/></a:accent6>'
    '<a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>'
    '<a:fontScheme name="PDF Lab"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>'
    '<a:minorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>'
    '<a:fmtScheme name="PDF Lab"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>'
    '<a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
    '<a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
    '<a:ln w="28575"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>'
    '<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle>'
    '<a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>'
    '<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst>'
    "</a:fmtScheme></a:themeElements></a:theme>"
)

GROUP_HEAD = (
    '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
    '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
)

MASTER = (
    XML
    + f'<p:sldMaster xmlns:a="{A_NS}" xmlns:r="{R_NS}" xmlns:p="{P_NS}">'
    '<p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>'
    f"<p:spTree>{GROUP_HEAD}</p:spTree></p:cSld>"
    '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" '
    'accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
    '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>'
)

LAYOUT = (
    XML
    + f'<p:sldLayout xmlns:a="{A_NS}" xmlns:r="{R_NS}" xmlns:p="{P_NS}" type="blank" preserve="1">'
    f'<p:cSld name="Blank"><p:spTree>{GROUP_HEAD}</p:spTree></p:cSld>'
    "<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"
)


def _rels(items):
    body = "".join(f'<Relationship Id="{i}" Type="{t}" Target="{tg}"/>' for i, t, tg in items)
    return XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + body + "</Relationships>"


def _emu(v):
    return int(round(float(v) * EMU))


def _pptx_run(r, scale, default_font="Arial"):
    sz = min(max(int(round((_num(r.get("sz"), 0) or 12) * scale * 100)), 100), 400000)
    attrs = f'lang="en-US" sz="{sz}"' + (' b="1"' if r.get("b") else "") + (' i="1"' if r.get("i") else "")
    color = re.sub(r"[^0-9A-Fa-f]", "", str(r.get("color") or "000000"))[:6].rjust(6, "0")
    font = esc(r.get("font") or default_font)
    return (
        f'<a:r><a:rPr {attrs}><a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
        f'<a:latin typeface="{font}"/><a:cs typeface="{font}"/></a:rPr><a:t>{esc(r.get("text", ""))}</a:t></a:r>'
    )


def _textbox(sid, box, scale, ox, oy):
    x, y = ox + _num(box.get("x"), 0) * scale, oy + _num(box.get("y"), 0) * scale
    w, h = max(_num(box.get("w"), 10), 4) * scale, max(_num(box.get("h"), 10), 4) * scale
    runs = box.get("runs") or [box]
    runs_xml = "".join(_pptx_run(r, scale) for r in runs)
    algn = {"center": "ctr", "right": "r"}.get(box.get("align"), "l")
    return (
        f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="Text {sid}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
        f'<p:spPr><a:xfrm><a:off x="{_emu(x)}" y="{_emu(y)}"/><a:ext cx="{_emu(w)}" cy="{_emu(h)}"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
        '<p:txBody><a:bodyPr wrap="none" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:noAutofit/></a:bodyPr><a:lstStyle/>'
        f'<a:p><a:pPr algn="{algn}"/>{runs_xml}</a:p></p:txBody></p:sp>'
    )


def build_pptx(slides):
    if not slides or not isinstance(slides, list):
        raise ValueError("No pages to convert.")
    for s in slides:
        if not isinstance(s, dict) or not (_num(s.get("w"), 0) > 0 and _num(s.get("h"), 0) > 0):
            raise ValueError("A page has an invalid size.")
    W = float(slides[0]["w"])
    H = float(slides[0]["h"])
    # PowerPoint only opens slides between 1 and 56 inches (72 to 4032 pt) a side: scale the deck to fit.
    k = min(1.0, 4032 / max(W, H))
    k = max(k, min(72 / min(W, H), 4032 / max(W, H)))
    W, H = min(max(W * k, 72), 4032), min(max(H * k, 72), 4032)
    files, ct_over, pres_rels, sld_ids = [], [], [], []
    has_jpg = False
    for n, s in enumerate(slides, start=1):
        sw, sh = float(s["w"]), float(s["h"])
        scale = min(W / sw, H / sh)
        ox, oy = (W - sw * scale) / 2, (H - sh * scale) / 2
        shapes, next_id = [], 2
        rels = [("rId1", f"{R_NS}/slideLayout", "../slideLayouts/slideLayout1.xml")]
        if s.get("image"):
            has_jpg = True
            files.append((f"ppt/media/image{n}.jpg", base64.b64decode(s["image"])))
            rels.append(("rId2", f"{R_NS}/image", f"../media/image{n}.jpg"))
            shapes.append(
                f'<p:pic><p:nvPicPr><p:cNvPr id="{next_id}" name="Page {n}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
                '<p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
                f'<p:spPr><a:xfrm><a:off x="{_emu(ox)}" y="{_emu(oy)}"/><a:ext cx="{_emu(sw * scale)}" cy="{_emu(sh * scale)}"/></a:xfrm>'
                '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>'
            )
            next_id += 1
        for box in s.get("boxes") or []:
            has_text = any(str(r.get("text", "")).strip() for r in (box.get("runs") or [box]))
            if not has_text:
                continue
            shapes.append(_textbox(next_id, box, scale, ox, oy))
            next_id += 1
        xml = (
            XML + f'<p:sld xmlns:a="{A_NS}" xmlns:r="{R_NS}" xmlns:p="{P_NS}"><p:cSld><p:spTree>{GROUP_HEAD}'
            + "".join(shapes) + "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"
        )
        files.append((f"ppt/slides/slide{n}.xml", xml))
        files.append((f"ppt/slides/_rels/slide{n}.xml.rels", _rels(rels)))
        ct_over.append(
            f'<Override PartName="/ppt/slides/slide{n}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
        )
        pres_rels.append((f"rId{n + 2}", f"{R_NS}/slide", f"slides/slide{n}.xml"))
        sld_ids.append(f'<p:sldId id="{255 + n}" r:id="rId{n + 2}"/>')

    presentation = (
        XML + f'<p:presentation xmlns:a="{A_NS}" xmlns:r="{R_NS}" xmlns:p="{P_NS}" saveSubsetFonts="1">'
        '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
        f'<p:sldIdLst>{"".join(sld_ids)}</p:sldIdLst>'
        f'<p:sldSz cx="{_emu(W)}" cy="{_emu(H)}"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>'
    )
    content_types = (
        XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        + ('<Default Extension="jpg" ContentType="image/jpeg"/>' if has_jpg else "")
        + '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
        '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>'
        '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
        '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
        + "".join(ct_over) + "</Types>"
    )
    base = [
        ("[Content_Types].xml", content_types),
        ("_rels/.rels", _rels([("rId1", f"{R_NS}/officeDocument", "ppt/presentation.xml")])),
        ("ppt/presentation.xml", presentation),
        ("ppt/_rels/presentation.xml.rels", _rels(
            [("rId1", f"{R_NS}/slideMaster", "slideMasters/slideMaster1.xml"),
             ("rId2", f"{R_NS}/theme", "theme/theme1.xml")] + pres_rels)),
        ("ppt/slideMasters/slideMaster1.xml", MASTER),
        ("ppt/slideMasters/_rels/slideMaster1.xml.rels", _rels(
            [("rId1", f"{R_NS}/slideLayout", "../slideLayouts/slideLayout1.xml"),
             ("rId2", f"{R_NS}/theme", "../theme/theme1.xml")])),
        ("ppt/slideLayouts/slideLayout1.xml", LAYOUT),
        ("ppt/slideLayouts/_rels/slideLayout1.xml.rels", _rels(
            [("rId1", f"{R_NS}/slideMaster", "../slideMasters/slideMaster1.xml")])),
        ("ppt/theme/theme1.xml", THEME),
    ]
    return _zip(base + files)
