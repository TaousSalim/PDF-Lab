"""PDF Lab: updates. One file for the Mac app and for the Windows version.

At each start the app looks, once and quietly, at one small file on the internet (the "feed"). When that file names
a newer version, the page shows a bar. When the user accepts, the new version is downloaded, checked, and put in
place; the app then starts again by itself.

What goes out: one plain request for the feed, and later one for the download. Nothing about the user, the
computer or the documents is ever sent. Without internet nothing happens and nothing is shown.

Two ways of putting the new version in place:
  "installer"  Windows. The download is the installer (PDF-Lab-Setup.exe). It is started in its update mode
               (/UPDATE /WAITPID=<this app>), the app closes, the installer replaces the program and opens it again.
  "files"      Mac. The download is a ZIP with a new "App Files" folder (and the launcher script). It is unpacked
               next to the folder in use, the two folders are swapped, and the app starts its new code in place:
               same Dock icon, same window. The big PDF engine (vendor_mu) is carried over when the ZIP has none.

Files:
  update.json                     {"version": "2026.10.7.1552", "feed": "https://..."}, written by the build.
                                  Missing file or empty feed: updates are off.
  the feed (on the internet)      {"version", "url" and/or "file", "size", "sha256", "notes": {"fr", "en"}}
                                  "url" is the full address of the download; "file" is a name next to the feed.
                                  With both, "url" is tried first.

Safety:
  - only https (plain http is accepted for 127.0.0.1 alone, which the tests use), also after a redirect,
  - the download must have exactly the size and the SHA-256 the feed announces, or it is thrown away,
  - a version is installed only when it is newer than the running one,
  - a ZIP is unpacked only into its own new folder: no entry may point outside it, links are refused, and it must
    hold the version the feed announced. The folder in use is replaced by renaming, and put back when a step fails.
The feed address can be replaced with the environment variable PDFLAB_UPDATE_FEED (tests).
"""
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import zipfile

IS_WIN = os.name == "nt"
VERSION_RE = re.compile(r"\d{1,5}(\.\d{1,5}){1,3}")
FILE_RE = {"installer": re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,80}\.exe"), "files": re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,80}\.zip")}
MAX_FEED = 64 * 1024                 # the feed is a few hundred bytes
MAX_DOWNLOAD = 400 * 1024 * 1024
MIN_DOWNLOAD = {"installer": 200 * 1024, "files": 20 * 1024}
MAX_UNPACKED = 1024 * 1024 * 1024    # a ZIP that claims to unpack to more than this is refused
FEED_TIMEOUT = 6
DOWNLOAD_TIMEOUT = 30                # per read: a stalled connection is given up, a slow one is not
LOOK_AGAIN = 6 * 3600                # an app that is left open looks again after this many seconds
CARRY_OVER = ("vendor_mu",)          # folders of "App Files" that stay when the ZIP does not bring them


def version_key(text):
    """"2026.10.7.1552" -> (2026, 10, 7, 1552). None when the text is not a version."""
    text = str(text or "").strip()
    if not VERSION_RE.fullmatch(text):
        return None
    parts = [int(p) for p in text.split(".")]
    return tuple(parts + [0] * (4 - len(parts)))


def _local(url):
    return urllib.parse.urlparse(url).hostname in ("127.0.0.1", "localhost")


def allowed(url):
    """https everywhere; http only towards this computer (tests)."""
    u = urllib.parse.urlparse(url)
    return u.scheme == "https" or (u.scheme == "http" and _local(url))


class _SafeRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not allowed(newurl) or (_local(newurl) and not _local(req.full_url)):
            raise urllib.error.URLError("redirect to an address that is not allowed")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _open(url, timeout, agent):
    if not allowed(url):
        raise urllib.error.URLError("address not allowed")
    opener = urllib.request.build_opener(_SafeRedirects())
    return opener.open(urllib.request.Request(url, headers={"User-Agent": agent, "Accept": "*/*", "Cache-Control": "no-cache"}), timeout=timeout)


def bundle_of(app_files):
    """The Resources folder of the Mac app bundle that holds this "App Files" folder, or None when the code does
    not run from inside an app bundle (the project folder is never updated)."""
    resources = os.path.dirname(os.path.abspath(app_files))
    if os.path.basename(resources) == "Resources" and os.path.basename(os.path.dirname(resources)) == "Contents" \
            and os.path.dirname(os.path.dirname(resources)).endswith(".app"):
        return resources
    return None


class Updater:
    """state: "off" (no feed), "checking", "none" (up to date, or the feed could not be read), "available",
    "downloading", "installing", "failed" (the download or the last step failed; can be tried again)."""

    def __init__(self, conf, data_dir, kind="installer", log=print, quit_app=None, pid=None, app_files=None, restart=None):
        """conf: path of update.json. kind: "installer" or "files". quit_app: closes the app (installer).
        app_files: the folder to replace, and restart: starts the new code (files)."""
        self.kind, self.data_dir = kind, data_dir
        self.log, self.quit_app, self.pid = log, quit_app, pid or os.getpid()
        self.app_files, self.restart = app_files, restart
        self.lock = threading.Lock()
        self.version, self.feed = "", ""
        self.offer = None                  # the checked content of the feed, when it names a newer version
        self.state, self.progress, self.error = "off", 0.0, ""
        self.updated_from = None           # set when this start is the first one after an update
        self.checked = 0.0                 # when the feed was last looked at
        self.folder = os.path.join(data_dir, "updates")
        try:
            with open(conf, encoding="utf-8") as f:
                c = json.load(f)
            if version_key(c.get("version")):
                self.version = str(c["version"]).strip()
            self.feed = str(c.get("feed") or "").strip()
        except (OSError, ValueError, AttributeError):
            pass
        self.feed = os.environ.get("PDFLAB_UPDATE_FEED", self.feed).strip()
        if self.version and self.feed and allowed(self.feed):
            self.state = "checking"
        if self.state == "checking" and kind == "files" and not self._can_replace():
            self.log("updates: off (this copy of the app cannot be changed where it is; move it to the Applications folder)")
            self.state = "off"
        self._note_version()

    def _can_replace(self):
        parent = os.path.dirname(os.path.abspath(self.app_files or ""))
        return bool(self.app_files) and os.path.isdir(self.app_files) and os.access(parent, os.W_OK) and os.access(self.app_files, os.W_OK)

    # ------------------------------------------------------------------ what the page asks
    def status(self):
        again = False
        with self.lock:
            if self.state == "none" and self.checked and time.time() - self.checked > LOOK_AGAIN:
                self.state, again = "checking", True      # the app was left open for hours: look once more
            out = {"state": self.state, "current": self.version}
            if self.offer and self.state != "none":
                out["version"] = self.offer["version"]
                out["size"] = self.offer["size"]
                out["notes"] = self.offer["notes"]
            if self.state == "downloading":
                out["progress"] = round(self.progress, 3)
            if self.state == "failed":
                out["error"] = self.error
            if self.updated_from:
                out["updated"] = True
        if again:
            threading.Thread(target=self._check, args=(0,), daemon=True).start()
        return out

    def seen_updated(self):
        """The page has told the user that the app was updated: say it once only."""
        with self.lock:
            self.updated_from = None

    # ------------------------------------------------------------------ at start
    def _note_version(self):
        """Remembers which version ran last. A different one now means: this is the first start after an update."""
        if not self.version:
            return
        mark = os.path.join(self.data_dir, "version.txt")
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            try:
                with open(mark, encoding="utf-8") as f:
                    last = f.read().strip()
            except OSError:
                last = ""
            if last and last != self.version and version_key(last) and version_key(last) < version_key(self.version):
                self.updated_from = last
                self.log(f"updated from {last} to {self.version}")
            if last != self.version:
                with open(mark, "w", encoding="utf-8") as f:
                    f.write(self.version)
        except OSError:
            pass

    def start(self, delay=1.5):
        """Look at the feed in the background. Never raises, never blocks the start of the app."""
        if self.state != "checking":
            self.log("updates: off (no update.json, or no feed in it)" if not self.feed or not self.version else "updates: off")
            return
        threading.Thread(target=self._check, args=(delay,), daemon=True).start()

    def _clear_folder(self, keep=None):
        try:
            for name in os.listdir(self.folder):
                if name != keep:
                    try:
                        os.remove(os.path.join(self.folder, name))
                    except OSError:
                        pass
        except OSError:
            pass

    def _check(self, delay):
        time.sleep(delay)
        self._clear_folder()          # downloads of earlier updates are not kept
        offer, why = None, ""
        try:
            with _open(self.feed, FEED_TIMEOUT, f"PDF-Lab/{self.version}") as r:
                raw = r.read(MAX_FEED + 1)
            if len(raw) > MAX_FEED:
                raise ValueError("the feed is too large")
            offer = self._read_feed(json.loads(raw.decode("utf-8-sig")))   # (Notepad adds a mark in front: accepted)
        except Exception as e:      # no internet, a firewall, a broken feed: the app simply stays as it is
            why = f"{type(e).__name__}: {e}"
        with self.lock:
            self.checked = time.time()
            if offer:
                self.offer, self.state = offer, "available"
            else:
                self.state = "none"
        self.log(f"updates: version {offer['version']} is available (this is {self.version})" if offer
                 else f"updates: nothing to install ({why or 'this is the newest version'})")

    def _read_feed(self, feed):
        """The feed as a clean offer, or None when it does not name a newer version. Raises on nonsense."""
        if not isinstance(feed, dict):
            raise ValueError("the feed is not an object")
        new = version_key(feed.get("version"))
        if new is None:
            raise ValueError("the feed has no version")
        if new <= version_key(self.version):
            return None
        name, url, size, digest = feed.get("file"), feed.get("url"), feed.get("size"), str(feed.get("sha256") or "").lower()
        urls = []
        if url is not None:
            if not isinstance(url, str) or not allowed(url) or len(url) > 500:
                raise ValueError("the download address is not allowed")
            urls.append(url)
        if name is not None:
            if not isinstance(name, str) or not FILE_RE[self.kind].fullmatch(name):
                raise ValueError("the feed names no download of the right kind")
            urls.append(urllib.parse.urljoin(self.feed, name))      # a file that lies next to the feed
        if not urls or not all(allowed(u) for u in urls):
            raise ValueError("the feed names no download")
        if not isinstance(size, int) or isinstance(size, bool) or not MIN_DOWNLOAD[self.kind] <= size <= MAX_DOWNLOAD:
            raise ValueError("the feed gives no believable size")
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("the feed gives no SHA-256")
        notes = feed.get("notes") if isinstance(feed.get("notes"), dict) else {}
        clean = {k: str(notes.get(k) or "")[:300] for k in ("fr", "en")}
        return {"version": str(feed["version"]).strip(), "size": size, "sha256": digest, "urls": urls, "notes": clean}

    # ------------------------------------------------------------------ when the user accepts
    def install(self):
        """Start downloading and installing. Returns at once; the page follows the progress."""
        with self.lock:
            if self.state not in ("available", "failed") or not self.offer:
                return
            self.state, self.progress, self.error = "downloading", 0.0, ""
        threading.Thread(target=self._install, daemon=True).start()

    def _fail(self, code, detail=""):
        self.log(f"updates: failed ({code}) {detail}")
        with self.lock:
            self.state, self.error = "failed", code

    def _download(self, url, part, offer):
        digest, got = hashlib.sha256(), 0
        with self.lock:
            self.progress = 0.0
        with _open(url, DOWNLOAD_TIMEOUT, f"PDF-Lab/{self.version}") as r, open(part, "wb") as f:
            while True:
                block = r.read(256 * 1024)
                if not block:
                    break
                got += len(block)
                if got > offer["size"]:
                    raise ValueError("more data than announced")
                digest.update(block)
                f.write(block)
                with self.lock:
                    self.progress = got / offer["size"]
        if got != offer["size"] or digest.hexdigest() != offer["sha256"]:
            raise ValueError(f"the file does not match the feed ({got} bytes)")

    def _install(self):
        offer = self.offer
        ext = ".exe" if self.kind == "installer" else ".zip"
        path = os.path.join(self.folder, f"PDF-Lab-{'Setup' if self.kind == 'installer' else 'Update'}-{offer['version']}{ext}")
        part = path + ".part"
        why = ""
        try:
            os.makedirs(self.folder, exist_ok=True)
            self._clear_folder()
        except OSError as e:
            return self._fail("download", f"{type(e).__name__}: {e}")
        for url in offer["urls"]:       # the full address first, then the file next to the feed
            try:
                self._download(url, part, offer)
                os.replace(part, path)
                why = ""
                break
            except Exception as e:
                why = f"{type(e).__name__}: {e}"
                self.log(f"updates: {urllib.parse.urlparse(url).hostname} did not give the right file ({why})")
                try:
                    os.remove(part)
                except OSError:
                    pass
        if why:
            return self._fail("download", why)
        with self.lock:
            self.state, self.progress = "installing", 1.0
        self.log(f"updates: {os.path.basename(path)} downloaded and checked")
        time.sleep(0.9)                 # the page shows "installing" before the app goes
        try:
            if self.kind == "installer":
                self._run_installer(path)
            else:
                self._replace_files(path, offer["version"])
        except Exception as e:
            self.log(traceback.format_exc())
            return self._fail("start", f"{type(e).__name__}: {e}")
        if self.kind == "installer":
            if self.quit_app:
                self.quit_app()
        elif self.restart:
            self.log(f"updates: version {offer['version']} is in place, starting it")
            self.restart()

    # ------------------------------------------------------------------ Windows: hand over to the installer
    def _run_installer(self, path):
        """Start the installer in its update mode: it waits for this app to end, replaces the program, opens it again.
        It must outlive this app: on Windows every program the launcher starts is tied to it (a "job"), so the
        installer is started outside that tie."""
        args = [path, "/UPDATE", f"/WAITPID={self.pid}"]
        quiet = dict(stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=self.folder, close_fds=True)
        if not IS_WIN:                  # tests on macOS and Linux run a stand-in script
            os.chmod(path, 0o755)
            subprocess.Popen(args, start_new_session=True, **quiet)
            return
        base = 0x00000008 | 0x00000200          # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        why = None
        for attempt in range(3):                # (a file that was just written can be held for a moment by a virus scanner)
            try:
                subprocess.Popen(args, creationflags=base | 0x01000000, **quiet)   # CREATE_BREAKAWAY_FROM_JOB
                return
            except OSError as e:
                why = e
                time.sleep(0.7)
        self.log(f"updates: could not start the installer outside the job ({why}); asking Windows to start it")
        # Second way: Windows itself creates the process (WMI), so it belongs to nobody's job.
        line = subprocess.list2cmdline(args)
        script = ("$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $env:PDFLAB_RUN; "
                  "CurrentDirectory = $env:PDFLAB_DIR }; if ($r.ReturnValue -ne 0) { exit 1 }")
        done = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout=25,
                              creationflags=0x08000000, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              env=dict(os.environ, PDFLAB_RUN=line, PDFLAB_DIR=self.folder))
        if done.returncode != 0:
            raise OSError("Windows could not start the installer")

    # ------------------------------------------------------------------ Mac: swap the "App Files" folder
    def _replace_files(self, path, version):
        """Unpack the ZIP next to the folder in use, check it, then swap the two folders by renaming."""
        live = os.path.abspath(self.app_files)
        parent = os.path.dirname(live)
        fresh, old = os.path.join(parent, ".PDF Lab update"), os.path.join(parent, ".PDF Lab previous")
        for leftover in (fresh, old):           # of an update that was interrupted
            shutil.rmtree(leftover, ignore_errors=True)
        try:
            self._unpack(path, fresh)
            new_files, script = os.path.join(fresh, "App Files"), os.path.join(fresh, "script")
            with open(os.path.join(new_files, "update.json"), encoding="utf-8") as f:
                if str(json.load(f).get("version")) != version:
                    raise ValueError("the ZIP does not hold the announced version")
            if not os.path.isfile(os.path.join(new_files, "server.py")) or not os.path.isdir(os.path.join(new_files, "web")):
                raise ValueError("the ZIP does not hold the app")
            os.rename(live, old)
            try:
                os.rename(new_files, live)
                for name in CARRY_OVER:          # the PDF engine stays when the new version does not bring its own
                    if os.path.isdir(os.path.join(old, name)) and not os.path.exists(os.path.join(live, name)):
                        os.rename(os.path.join(old, name), os.path.join(live, name))
            except Exception:
                # put everything back exactly as it was
                if os.path.isdir(live):
                    for name in CARRY_OVER:
                        if os.path.isdir(os.path.join(live, name)) and not os.path.exists(os.path.join(old, name)):
                            os.rename(os.path.join(live, name), os.path.join(old, name))
                    shutil.rmtree(live, ignore_errors=True)
                os.rename(old, live)
                raise
            if os.path.isfile(script):           # the launcher script: used from the next start on
                try:
                    os.chmod(script, 0o755)
                    os.replace(script, os.path.join(parent, "script"))
                except OSError as e:
                    self.log(f"updates: the launcher script was left as it is ({e})")
        finally:
            shutil.rmtree(fresh, ignore_errors=True)
        shutil.rmtree(old, ignore_errors=True)

    def _unpack(self, path, into):
        """Unpack only what belongs to the app ("App Files/..." and "script"), only into `into`."""
        root = os.path.realpath(into)
        with zipfile.ZipFile(path) as z:
            infos = z.infolist()
            if sum(i.file_size for i in infos) > MAX_UNPACKED or len(infos) > 20000:
                raise ValueError("the ZIP is too large")
            os.makedirs(root)
            for info in infos:
                name = info.filename
                mode = (info.external_attr >> 16) & 0xFFFF
                parts = name.rstrip("/").split("/")
                if name.startswith(("/", "\\")) or "\\" in name or ":" in name or "\x00" in name or any(p in ("", ".", "..") for p in parts):
                    raise ValueError(f"the ZIP has an entry that points outside ({name!r})")
                if stat.S_ISLNK(mode):
                    raise ValueError(f"the ZIP has a link ({name!r})")
                if parts[0] != "App Files" and name != "script":
                    continue                    # anything else in the ZIP is not for the app
                target = os.path.realpath(os.path.join(root, *parts))
                if target != root and not target.startswith(root + os.sep):
                    raise ValueError(f"the ZIP has an entry that points outside ({name!r})")
                if name.endswith("/"):
                    os.makedirs(target, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(info) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst, 1024 * 1024)
                os.chmod(target, 0o755 if mode & 0o111 else 0o644)
