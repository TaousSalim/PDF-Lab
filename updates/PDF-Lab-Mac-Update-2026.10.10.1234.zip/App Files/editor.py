"""Edit PDF engine for PDF Lab.

Text edits keep the look of the document:
  * the old line is removed from the page content (real removal, no cover-up),
  * the new line is written with the PDF's own embedded font whenever that font holds every letter,
  * unchanged letters keep their exact original positions (kerning, tracking, justification),
  * only letters the font does not contain fall back to the closest installed font.

Everything here works on a PyMuPDF document that is opened fresh for each request.
"""
import base64
import difflib
import glob
import math
import os
import re
import statistics
import sys
import unicodedata

pymupdf = None
ENGINE_ERROR = None


def load_engine(here):
    """Import the bundled PyMuPDF for this Mac (Apple Silicon or Intel), or a normal install as a fallback."""
    global pymupdf, ENGINE_ERROR
    if pymupdf is not None:
        return True
    import platform
    arch = "arm64" if platform.machine().lower() in ("arm64", "aarch64") else "x86_64"
    path = os.path.join(here, "vendor_mu", arch)
    added = False
    if os.path.isdir(os.path.join(path, "pymupdf")):
        sys.path.insert(0, path)
        added = True
    try:
        import pymupdf as _mu  # noqa: WPS433
        pymupdf = _mu
        return True
    except BaseException as e:  # a broken or missing binary must never stop the rest of the app
        ENGINE_ERROR = f"{type(e).__name__}: {e}"
        if added:
            try:
                sys.path.remove(path)
            except ValueError:
                pass
            for m in [k for k in sys.modules if k.split(".")[0] in ("pymupdf", "fitz")]:
                del sys.modules[m]
            try:  # a normal installation of PyMuPDF, if the Mac has one
                import pymupdf as _mu2  # noqa: WPS433
                pymupdf = _mu2
                ENGINE_ERROR = None
                return True
            except BaseException:
                pass
        return False


class EditError(ValueError):
    pass


def free_cache():
    """Give back what MuPDF keeps in its own cache (decoded pictures and fonts of files that were open)."""
    if pymupdf is not None:
        try:
            pymupdf.TOOLS.store_shrink(100)
        except Exception:
            pass


# French typography puts a no-break space (often a thin one) before ; : ! ? and inside guillemets. Fonts that have no
# glyph for these still have to leave the gap: (width as a share of an ordinary space).
SPACE_LIKE = {"\u00a0": 1.0, "\u202f": 0.6, "\u2009": 0.6, "\u2007": 1.8, "\u2002": 1.8, "\u2003": 3.6, "\u200a": 0.3}
LATIN_LIGATURES = {"\ufb00": "ff", "\ufb01": "fi", "\ufb02": "fl", "\ufb03": "ffi", "\ufb04": "ffl", "\ufb05": "st", "\ufb06": "st"}


# ------------------------------------------------------------------ small helpers

def hex_to_rgb(h, default=(0, 0, 0)):
    if isinstance(h, (list, tuple)) and len(h) == 3:
        return tuple(float(x) for x in h)
    if not isinstance(h, str):
        return default
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if not re.fullmatch(r"[0-9a-fA-F]{6}", h):
        return default
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def int_to_rgb(v):
    return ((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255


def num(x, default=0.0):
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def fmt(x):
    s = f"{x:.4f}".rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"


SUBSET_TAG = re.compile(r"^[A-Z]{6}\+")


def clean_font_name(name):
    return SUBSET_TAG.sub("", name or "")


# ------------------------------------------------------------------ PDF object access

def _key(doc, xref, key):
    try:
        t, v = doc.xref_get_key(xref, key)
    except Exception:
        return None, None
    return t, v


def _resolve(doc, t, v):
    """Return the object text for a key value that may be an indirect reference."""
    if t == "xref":
        m = re.match(r"(\d+) 0 R", v)
        if m:
            try:
                return doc.xref_object(int(m.group(1)), compressed=True)
            except Exception:
                return None
        return None
    if t in ("array", "dict", "int", "real", "name", "string"):
        return v
    return None


def _numbers(s):
    return [float(x) for x in re.findall(r"-?\d+\.?\d*(?:[eE]-?\d+)?|-?\.\d+", s or "")]


def parse_tounicode(data):
    """CMap text -> {code: str}."""
    try:
        txt = data.decode("latin-1")
    except Exception:
        return {}
    out = {}

    def uni(hexs):
        try:
            if len(hexs) % 4:
                return chr(int(hexs, 16))
            return bytes.fromhex(hexs).decode("utf-16-be")
        except Exception:
            return ""

    for block in re.findall(r"beginbfchar(.*?)endbfchar", txt, re.S):
        for a, b in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]*)>", block):
            out[int(a, 16)] = uni(b)
    for block in re.findall(r"beginbfrange(.*?)endbfrange", txt, re.S):
        for m in re.finditer(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(\[(.*?)\]|<([0-9A-Fa-f]*)>)", block, re.S):
            lo, hi = int(m.group(1), 16), int(m.group(2), 16)
            if hi - lo > 70000:
                continue
            if m.group(4) is not None:
                items = re.findall(r"<([0-9A-Fa-f]*)>", m.group(4))
                for k, it in enumerate(items):
                    if lo + k <= hi:
                        out[lo + k] = uni(it)
            else:
                base = uni(m.group(5))
                if not base:
                    continue
                for k in range(hi - lo + 1):
                    out[lo + k] = base[:-1] + chr(ord(base[-1]) + k) if len(base) else ""
    return out


_AGL = None


def glyph_to_unicode(name):
    global _AGL
    if _AGL is None:
        _AGL = {}
        for cp in list(range(32, 0x2FF)) + list(range(0x2000, 0x2200)) + [0xFB01, 0xFB02]:
            try:
                n = pymupdf.unicode_to_glyph_name(cp)
            except Exception:
                continue
            if n and n != ".notdef":
                _AGL.setdefault(n, cp)
    if name in _AGL:
        return _AGL[name]
    m = re.fullmatch(r"uni([0-9A-Fa-f]{4})", name)
    if m:
        return int(m.group(1), 16)
    m = re.fullmatch(r"u([0-9A-Fa-f]{4,6})", name)
    if m:
        return int(m.group(1), 16)
    return None


BASE_ENCODINGS = {"WinAnsiEncoding": "cp1252", "MacRomanEncoding": "mac_roman", "StandardEncoding": "latin-1"}


class FontKit:
    """What the editor needs to know about one font object of the document."""

    def __init__(self, doc, xref, used, cache_fonts):
        self.doc, self.xref = doc, xref
        self.used = used or set()
        self.ok = False
        self.reason = ""
        self.u2c = {}
        self.multi = {}  # "ti", "fi", ...: several letters drawn by one glyph (ligature) -> its code
        self.code_len = 1
        self.widths = {}
        self.dw = 0.0
        self.default_w = None
        self.avail = set()
        self.type3 = False
        self.embedded = False
        self.subset = False
        self.name = ""
        try:
            self._load(cache_fonts)
        except Exception as e:  # unusual font structures simply mean "cannot reuse"
            self.ok = False
            self.reason = f"{type(e).__name__}: {e}"

    # -- reading ----------------------------------------------------------
    def _obj(self, xref):
        return self.doc.xref_object(xref, compressed=True)

    def _load(self, cache_fonts):
        doc, xref = self.doc, self.xref
        obj = self._obj(xref)
        sub = (re.search(r"/Subtype\s*/(\w+)", obj) or [None, ""])[1]
        base = (re.search(r"/BaseFont\s*/([^\s/\[\]<>()]+)", obj) or [None, ""])[1]
        self.name = base
        self.subset = bool(SUBSET_TAG.match(base))
        desc_obj, desc_font_obj = obj, obj
        if sub == "Type0":
            enc = (re.search(r"/Encoding\s*/([^\s/\[\]<>()]+)", obj) or [None, ""])[1]
            if enc not in ("Identity-H",):
                self.reason = f"encoding {enc or 'custom'}"
                return
            self.code_len = 2
            t, v = _key(doc, xref, "DescendantFonts")
            m = re.search(r"(\d+) 0 R", v or "")
            if not m:
                self.reason = "no descendant"
                return
            dx = int(m.group(1))
            desc_font_obj = self._obj(dx)
            self._read_cid_widths(dx, desc_font_obj)
            fdm = re.search(r"/FontDescriptor\s+(\d+) 0 R", desc_font_obj)
            desc_obj = self._obj(int(fdm.group(1))) if fdm else ""
            self.embedded = bool(re.search(r"/FontFile[23]?\s", desc_obj + " "))
        elif sub == "Type3":
            self.type3 = True
            self.embedded = True
            self._read_simple_widths(obj, type3=True)
        elif sub in ("TrueType", "Type1", "MMType1"):
            fdm = re.search(r"/FontDescriptor\s+(\d+) 0 R", obj)
            desc_obj = self._obj(int(fdm.group(1))) if fdm else ""
            self.embedded = bool(re.search(r"/FontFile[23]?\s", desc_obj + " "))
            self._read_simple_widths(obj)
        else:
            self.reason = f"font type {sub}"
            return

        # code <-> unicode
        tu = re.search(r"/ToUnicode\s+(\d+) 0 R", obj)
        c2u = {}
        if tu:
            c2u = parse_tounicode(doc.xref_stream(int(tu.group(1))) or b"")
        if not c2u and self.code_len == 1:
            c2u = self._encoding_map(obj, base)
        for code, s in c2u.items():
            if len(s) == 1 and code not in self.u2c.values():
                self.u2c.setdefault(s, code)
        # prefer lowest code for each char (stable)
        best = {}
        for code, s in sorted(c2u.items()):
            if len(s) == 1:
                best.setdefault(s, code)
        self.u2c = best
        for code, s in sorted(c2u.items()):
            if len(s) > 1:
                self.multi.setdefault(s, code)
            elif s in LATIN_LIGATURES:  # MuPDF reports these as their separate letters
                self.multi.setdefault(LATIN_LIGATURES[s], code)
        if not self.u2c:
            self.reason = "no character map"
            return

        # which characters can really be drawn
        if not self.embedded and not self.type3:
            self.avail = set(self.u2c)  # a viewer supplies its own glyphs
        else:
            self.avail = set(c for c in self.used if c in self.u2c)
            if self.embedded and not self.subset and not self.type3 and self.code_len == 1:
                self.avail |= self._full_font_chars(desc_obj, cache_fonts)
        self.ok = bool(self.avail)

    def _full_font_chars(self, desc_obj, cache_fonts):
        """Characters of an embedded, untagged font that has a real full glyph set."""
        m = re.search(r"/FontFile[23]?\s+(\d+) 0 R", desc_obj)
        if not m:
            return set()
        try:
            data = self.doc.xref_stream(int(m.group(1)))
            f = pymupdf.Font(fontbuffer=data)
            if f.glyph_count < 400:
                return set()
            return set(c for c in self.u2c if f.has_glyph(ord(c)))
        except Exception:
            return set()

    def _encoding_map(self, obj, base):
        out = {}
        enc_name = (re.search(r"/Encoding\s*/(\w+)", obj) or [None, None])[1]
        diffs = []
        em = re.search(r"/Encoding\s+(\d+) 0 R", obj)
        enc_obj = self._obj(int(em.group(1))) if em else (obj if "/Differences" in obj else "")
        if enc_obj:
            bm = re.search(r"/BaseEncoding\s*/(\w+)", enc_obj)
            if bm:
                enc_name = bm.group(1)
            dm = re.search(r"/Differences\s*\[(.*?)\]", enc_obj, re.S)
            if dm:
                diffs = re.findall(r"/[^\s/\[\]]+|\d+", dm.group(1))
        codec = BASE_ENCODINGS.get(enc_name or "", "cp1252" if "Symbol" not in base and "Dingbats" not in base else None)
        if codec is None:
            return out
        for code in range(32, 256):
            try:
                ch = bytes([code]).decode(codec)
            except Exception:
                continue
            if ch.isprintable() or ch == " ":
                out[code] = ch
        cur = 0
        for tok in diffs:
            if tok.startswith("/"):
                u = glyph_to_unicode(tok[1:])
                if u:
                    out[cur] = chr(u)
                cur += 1
            else:
                cur = int(tok)
        return out

    def _read_simple_widths(self, obj, type3=False):
        first = int((re.search(r"/FirstChar\s+(\d+)", obj) or [0, 0])[1])
        t, v = _key(self.doc, self.xref, "Widths")
        txt = _resolve(self.doc, t, v)
        ws = _numbers(txt)
        scale = 0.001
        if type3:
            fm = re.search(r"/FontMatrix\s*\[(.*?)\]", obj)
            if fm:
                nums = _numbers(fm.group(1))
                if nums:
                    scale = abs(nums[0])
        for i, w in enumerate(ws):
            self.widths[first + i] = w * scale
        mw = re.search(r"/MissingWidth\s+([\d.]+)", obj)
        self.default_w = float(mw.group(1)) * 0.001 if mw else None

    def _read_cid_widths(self, dx, dobj):
        dw = re.search(r"/DW\s+([\d.]+)", dobj)
        self.dw = float(dw.group(1)) * 0.001 if dw else 1.0
        t, v = _key(self.doc, dx, "W")
        txt = _resolve(self.doc, t, v) or ""
        toks = re.findall(r"\[[^\]]*\]|-?[\d.]+", txt.strip().lstrip("[").rstrip("]") if txt.startswith("[") and "[" not in txt[1:] else txt)
        # tokenise the W array: c [w w w] or c1 c2 w
        txt2 = txt.strip()
        if txt2.startswith("[") and txt2.endswith("]"):
            txt2 = txt2[1:-1]
        toks = re.findall(r"\[[^\]]*\]|-?\d+\.?\d*", txt2)
        i = 0
        while i < len(toks):
            a = toks[i]
            if i + 1 < len(toks) and toks[i + 1].startswith("["):
                c = int(float(a))
                for k, w in enumerate(_numbers(toks[i + 1])):
                    self.widths[c + k] = w * 0.001
                i += 2
            elif i + 2 < len(toks):
                lo, hi, w = int(float(a)), int(float(toks[i + 1])), float(toks[i + 2])
                if hi - lo < 70000:
                    for c in range(lo, hi + 1):
                        self.widths[c] = w * 0.001
                i += 3
            else:
                break

    # -- use --------------------------------------------------------------
    def can(self, ch):
        return self.ok and ch in self.avail and ch in self.u2c

    def encode(self, ch):
        code = self.u2c[ch]
        return code.to_bytes(self.code_len, "big").hex()

    def encode_code(self, code):
        return code.to_bytes(self.code_len, "big").hex()

    def advance_code(self, code):
        """Advance in em of a glyph given by its code, or None when the PDF does not say."""
        if self.code_len == 2:
            return self.widths.get(code, self.dw or None)
        return self.widths.get(code) or self.default_w

    def _metric_font(self):
        if getattr(self, "_mf", None) is None:
            n = self.name.lower()
            fam = "cour" if any(k in n for k in ("courier", "mono", "consol")) else ("tiro" if any(k in n for k in ("times", "serif")) and "sans" not in n else "helv")
            bold = "bold" in n or "black" in n
            italic = "italic" in n or "oblique" in n
            key = builtin_key({"cour": "mono", "tiro": "serif", "helv": "sans"}[fam], bold, italic)
            try:
                self._mf = pymupdf.Font(key)
            except Exception:
                self._mf = False
        return self._mf or None

    def advance(self, ch):
        """Advance in em, or None when the PDF does not say."""
        code = self.u2c.get(ch)
        if code is None:
            return None
        if self.code_len == 2:
            return self.widths.get(code, self.dw or None)
        w = self.widths.get(code)
        if w:
            return w
        if self.default_w:
            return self.default_w
        if not self.embedded and not self.type3:  # one of the standard fonts: its metrics are well known
            mf = self._metric_font()
            if mf:
                a = mf.glyph_advance(ord(ch))
                if a:
                    return a
        return None


# ------------------------------------------------------------------ installed fonts

_SYS_DIRS = [
    "/System/Library/Fonts", "/System/Library/Fonts/Supplemental", "/Library/Fonts",
    os.path.expanduser("~/Library/Fonts"),
    "/usr/share/fonts", "/usr/local/share/fonts", os.path.expanduser("~/.fonts"),
]
_STYLE_TOKENS = {"regular", "roman", "book", "normal", "bold", "italic", "oblique", "bolditalic", "boldoblique", "bd", "bi", "it", "mt", "ps", "std"}
_SYS_INDEX = None


def _style_of(stem):
    s = stem.lower().replace("-", " ").replace("_", " ")
    bold = bool(re.search(r"\b(bold|bd|black|heavy|semibold|demi)\b|bold", s))
    italic = bool(re.search(r"italic|oblique|\bit\b", s))
    return bold, italic


def _family_of(stem):
    s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", stem)  # CamelCase
    toks = [t for t in re.split(r"[-_ ]+", s) if t]
    keep = [t for t in toks if t.lower() not in _STYLE_TOKENS]
    return " ".join(keep) or stem


def ttf_names(path):
    """(family, subfamily) read from a font file's name table, or None."""
    import struct
    try:
        with open(path, "rb") as f:
            head = f.read(12)
            if head[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
                return None
            n = struct.unpack(">H", head[4:6])[0]
            tabs = f.read(16 * n)
            off = ln = None
            for i in range(n):
                tag, _cs, o, l = struct.unpack(">4sIII", tabs[16 * i:16 * i + 16])
                if tag == b"name":
                    off, ln = o, l
                    break
            if off is None:
                return None
            f.seek(off)
            blob = f.read(min(ln, 65536))
        _fmt, count, str_off = struct.unpack(">HHH", blob[:6])
        names, rank = {}, {}
        for i in range(count):
            plat, enc, lang, nid, length, o = struct.unpack(">HHHHHH", blob[6 + 12 * i:18 + 12 * i])
            if nid not in (1, 2, 16, 17):
                continue
            raw = blob[str_off + o:str_off + o + length]
            try:
                txt = raw.decode("utf-16-be") if plat in (0, 3) else raw.decode("mac_roman")
            except Exception:
                continue
            # the English name wins: style names also come translated ("Gras", "Fett", "Negrita"), which says nothing here
            r = 3 if (plat == 3 and lang == 0x409) else 2 if (plat == 1 and lang == 0) else 1 if plat in (0, 3) else 0
            if txt and (nid not in names or r > rank[nid]):
                names[nid], rank[nid] = txt, r
        fam = names.get(16) or names.get(1)
        sub = names.get(17) or names.get(2) or "Regular"
        return (fam, sub) if fam else None
    except Exception:
        return None


def system_fonts():
    """{family: {(bold, italic): path}} for the TrueType/OpenType files found on this machine."""
    global _SYS_INDEX
    if _SYS_INDEX is not None:
        return _SYS_INDEX
    idx = {}
    for d in _SYS_DIRS:
        if not os.path.isdir(d):
            continue
        for root, _dirs, files in os.walk(d):
            if root.count(os.sep) - d.count(os.sep) > 3:
                continue
            for fn in files:
                if not fn.lower().endswith((".ttf", ".otf")):
                    continue
                stem = os.path.splitext(fn)[0]
                path = os.path.join(root, fn)
                nm = ttf_names(path)
                if nm:
                    fam = nm[0]
                    key = _style_of(nm[1] if nm[1].lower() not in ("regular", "roman", "book") else "regular")
                    if re.search(r"\b(light|thin|extralight|ultralight|medium|condensed|narrow|black|heavy|semibold|demibold|extrabold)\b", nm[1], re.I) and not re.fullmatch(r"(?i)(bold|bold italic|bold oblique)", nm[1].strip()):
                        continue  # only the four classic styles of a family are offered
                else:
                    fam = _family_of(stem)
                    key = _style_of(stem)
                idx.setdefault(fam, {}).setdefault(key, path)
    _SYS_INDEX = idx
    return idx


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def find_system_font(basefont, bold, italic):
    """Try to find the installed file of the very family a PDF font was named after."""
    name = clean_font_name(basefont)
    fam_part = re.split(r"[-,]", name, 1)[0]
    target = _norm(fam_part)
    for suffix in ("mt", "ps", "std", "pro"):
        if target.endswith(suffix) and len(target) > len(suffix) + 3:
            target = target[: -len(suffix)]
    if len(target) < 3:
        return None
    for fam, styles in system_fonts().items():
        nf = _norm(fam)
        if nf == target or nf == target + "mt":
            return styles.get((bold, italic)) or (styles.get((False, False)) if not (bold or italic) else None)
    return None


BUILTIN = {
    ("sans", False, False): "helv", ("sans", True, False): "hebo", ("sans", False, True): "heit", ("sans", True, True): "hebi",
    ("serif", False, False): "tiro", ("serif", True, False): "tibo", ("serif", False, True): "tiit", ("serif", True, True): "tibi",
    ("mono", False, False): "cour", ("mono", True, False): "cobo", ("mono", False, True): "coit", ("mono", True, True): "cobi",
}


def builtin_key(cls, bold, italic):
    return BUILTIN.get((cls, bool(bold), bool(italic)), "helv")


def classify_font(name, flags):
    n = (name or "").lower()
    if flags & 8 or "mono" in n or "courier" in n or "consol" in n or "menlo" in n:
        return "mono"
    if flags & 4 or any(k in n for k in ("times", "serif", "georgia", "garamond", "caladea", "cambria", "minion", "palatino", "bookman", "charter")) and "sans" not in n:
        return "serif"
    return "sans"


class FontResolver:
    """Finds a font to draw characters the original font does not hold, or a chosen font family."""

    def __init__(self):
        self.cache = {}

    def get(self, spec):
        """spec: ('builtin', key) | ('file', path). Returns (pymupdf.Font, ident)."""
        if spec in self.cache:
            return self.cache[spec]
        kind, val = spec
        if kind == "builtin":
            f = pymupdf.Font(val)
        else:
            f = pymupdf.Font(fontfile=val)
        self.cache[spec] = (f, f"{kind}:{val}")
        return self.cache[spec]

    def spec_for(self, basefont, flags, bold, italic, family=None):
        """Choose a font spec. family: None (follow the original), 'sans'/'serif'/'mono', or 'sys:Name'."""
        if family and family.startswith("sys:"):
            fam = family[4:]
            styles = system_fonts().get(fam)
            if styles:
                p = styles.get((bold, italic)) or styles.get((False, False)) or next(iter(styles.values()))
                return ("file", p), ("exact" if styles.get((bold, italic)) else "close")
        if family in ("sans", "serif", "mono"):
            return ("builtin", builtin_key(family, bold, italic)), "chosen"
        p = find_system_font(basefont, bold, italic)
        if p:
            return ("file", p), "same-family"
        return ("builtin", builtin_key(classify_font(basefont, flags), bold, italic)), "approximate"


# ------------------------------------------------------------------ analysis

class Line:
    __slots__ = ("idx", "chars", "dir", "bbox", "text", "origin", "size", "color", "basefont", "flags", "wmode", "xrefs", "lid", "rtl", "looks", "sure")

    def __init__(self):
        self.chars = []
        self.rtl = False  # True for a paragraph that runs right to left
        self.looks = None  # Arabic lines: (colour, font, flags, size) of every character of text
        self.sure = True  # False when no typing order could be found that gives the line as the page shows it


def _tag_fonts(doc, page):
    """Give ambiguously named fonts a unique name (in this throw-away copy only) so spans can be tied to font objects."""
    fonts = page.get_fonts(full=True)
    by_name = {}
    for f in fonts:
        xref, ext, ftype, base, name, enc, ref = f
        by_name.setdefault(clean_font_name(base) if ftype != "Type3" else "", []).append(f)
    mapping = {}
    for nm, group in by_name.items():
        unique = len(group) == 1 and nm
        for f in group:
            xref, ext, ftype, base, name, enc, ref = f
            if unique:
                mapping.setdefault(nm.replace(" ", ""), xref)
                continue
            if nm:
                mapping[("name", xref)] = nm  # what the font is really called, for finding it on this Mac
            try:
                if ftype == "Type3":
                    doc.xref_set_key(xref, "Name", f"/PLF{xref}")
                elif ext != "n/a":  # embedded: safe to rename, metrics come from the file
                    doc.xref_set_key(xref, "BaseFont", f"/PLF{xref}")
                    obj = doc.xref_object(xref, compressed=True)
                    m = re.search(r"/DescendantFonts\s*\[\s*(\d+) 0 R", obj)
                    if m:
                        doc.xref_set_key(int(m.group(1)), "BaseFont", f"/PLF{xref}")
                    for fd in re.findall(r"/FontDescriptor\s+(\d+) 0 R", obj + (doc.xref_object(int(m.group(1)), compressed=True) if m else "")):
                        doc.xref_set_key(int(fd), "FontName", f"/PLF{xref}")
                else:
                    mapping.setdefault(nm.replace(" ", ""), xref)
            except Exception:
                mapping.setdefault(nm.replace(" ", ""), xref)
    return mapping


def _xref_of(span_font, mapping):
    m = re.fullmatch(r"PLF(\d+)", span_font or "")
    if m:
        return int(m.group(1))
    return mapping.get((span_font or "").replace(" ", ""))


def analyze_page(doc, pno, arabic=True):
    """Return the editable text lines of one page, in reading order (index = line id).
    arabic=False skips rebuilding Arabic lines, for callers that only count which letters each font shows."""
    page = doc[pno]
    mapping = _tag_fonts(doc, page)
    # The page is read shape by shape: every shape with its own place, and the letters a PDF attaches to shapes
    # (ActualText) as extra characters without width. MuPDF's ordinary reading swaps shapes for attached text
    # itself; that loses shapes of Arabic letter groups and crashes on a page that begins with a vowelled
    # Arabic letter, as browsers write them.
    flags = pymupdf.TEXT_PRESERVE_LIGATURES | pymupdf.TEXT_PRESERVE_WHITESPACE | getattr(pymupdf, "TEXT_IGNORE_ACTUALTEXT", 2048)
    lines = _raw_lines(page.get_text("rawdict", flags=flags), mapping)
    if not (arabic and any(has_arabic(ln.text) for ln in lines)):
        for ln in lines:
            if arabic or not has_arabic(ln.text):
                _attached_text(ln)
        return lines
    parts = []
    for ln in lines:
        if has_arabic(ln.text):
            ln.chars = [c for c in ln.chars if not c["syn"]]  # spaces MuPDF made up: gaps are measured below instead
            parts += _split_gaps(ln)
        else:
            _in_page_order(ln)
            _attached_text(ln)
            parts.append(ln)
    lines = _merge_arabic(sorted(parts, key=lambda ln: (ln.bbox[1], ln.bbox[0])))
    # paragraphs that run right to left are aligned on the right: a hint for lines that can be read both ways
    edges = [(ln.bbox[0], ln.bbox[2]) for ln in lines if has_arabic(ln.text) and abs(ln.dir[1]) < 0.01]
    lefts = sum(1 for a in edges if sum(1 for b in edges if abs(a[0] - b[0]) < 1.5) > 1)
    rights = sum(1 for a in edges if sum(1 for b in edges if abs(a[1] - b[1]) < 1.5) > 1)
    side = 1 if rights > lefts else 0 if lefts > rights else None
    for k, ln in enumerate(lines):
        ln.idx = k
        if has_arabic(ln.text):
            try:
                _prepare_arabic(ln, side)
            except Exception:
                ln.looks = None  # one line that cannot be rebuilt must not take the page down: it stays as stored
    return lines


def _in_page_order(ln):
    """After right to left text MuPDF sometimes swaps the first characters of a left to right line. Put the
    characters of the line back in the order they stand on the page."""
    dx, dy = ln.dir
    eps = 0.02 * ln.size
    groups = []  # a shape with the widthless characters that follow it
    for i, c in enumerate(ln.chars):
        if _char_adv(ln, i) > eps or not groups:
            groups.append((c["o"][0] * dx + c["o"][1] * dy, [c]))
        else:
            groups[-1][1].append(c)
    if all(a[0] <= b[0] + 0.01 for a, b in zip(groups, groups[1:])):
        return
    groups.sort(key=lambda g: g[0])
    ln.chars = [c for _t, g in groups for c in g]
    ln.text = "".join(c["c"] for c in ln.chars)
    first = ln.chars[0]
    ln.origin, ln.color, ln.basefont, ln.flags = first["o"], first["color"], first["font"], first["flags"]


def _attached_text(ln):
    """English and French lines: fold the letters a PDF attaches to a shape into the line. A ligature shape with
    "fi" attached becomes f + i; attached text that only repeats what the shapes already say is dropped."""
    eps = 0.02 * ln.size
    dx, dy = ln.dir
    if any(c["syn"] for c in ln.chars):
        # MuPDF adds a space wherever the next shape is not where it expects it. An accent drawn before its
        # letter gives such a space on top of the letter: that one is not a gap between words.
        cells = [(c["o"][0] * dx + c["o"][1] * dy, _char_adv(ln, i)) for i, c in enumerate(ln.chars) if not c["syn"]]
        cells = [(t, w) for t, w in cells if w > eps]
        keep = []
        for i, c in enumerate(ln.chars):
            mid = c["o"][0] * dx + c["o"][1] * dy + _char_adv(ln, i) / 2
            if c["syn"] and any(t + eps < mid < t + w - eps for t, w in cells):
                continue
            keep.append(c)
        if len(keep) != len(ln.chars):
            ln.chars = keep
            ln.text = "".join(c["c"] for c in keep)
    chars = ln.chars
    n = len(chars)
    W = [_char_adv(ln, i) for i in range(n)]
    if all(w > eps for w in W):
        return
    T = [c["o"][0] * dx + c["o"][1] * dy for c in chars]
    P = [-c["o"][0] * dy + c["o"][1] * dx for c in chars]
    tol = 0.01 * ln.size
    out, i = [], 0
    while i < n:
        c = chars[i]
        if W[i] <= eps:
            out.append(c)
            i += 1
            continue
        j = i + 1
        while j < n and W[j] <= eps and abs(T[j] - T[i] - W[i]) < tol and abs(P[j] - P[i]) < 2 * tol:
            j += 1
        label, side = c["c"], "".join(x["c"] for x in chars[i + 1:j])
        keep = None  # the letters this shape stands for, when the attached text decides it
        if side:
            before = "".join(x["c"] for x in out[-40:])
            if LATIN_LIGATURES.get(label) == side or (unicodedata.normalize("NFKC", label) == side and label != side):
                keep = side
            elif label == "\ufffd" or unicodedata.category(label)[0] == "C":
                keep = side  # the shape has no label of its own
            elif side != label and unicodedata.normalize("NFD", side)[:1] == label and all(
                    unicodedata.combining(x) for x in unicodedata.normalize("NFD", side)[1:]):
                keep = side  # the letter with its accent; the accent's own shape is listed next to it
                while out and all(unicodedata.combining(x) for x in out[-1]["c"]) and _char_adv_of(out[-1]) <= eps:
                    out.pop()
                while j < n and W[j] <= eps and all(unicodedata.combining(x) for x in chars[j]["c"]):
                    j += 1
            else:
                for k in range(len(side)):  # the shape's own further letters, then attached text that repeats the shapes
                    own, rep_ = side[:k], side[k:]
                    if (before + label + own).endswith(rep_) and (k or len(rep_) > len(label)):
                        keep = label + own
                        break
        if keep is None:
            out.extend(chars[i:j])
        else:
            out.append(dict(c, c=keep[0]))
            for m, ch in enumerate(keep[1:]):
                out.append(dict(chars[min(i + 1 + m, j - 1)], c=ch))
        i = j
    ln.chars = out
    ln.text = "".join(c["c"] for c in out)


def _raw_lines(raw, mapping):
    lines = []
    for b in raw.get("blocks", []):
        if b.get("type") != 0:
            continue
        for l in b.get("lines", []):
            ln = Line()
            ln.idx = len(lines)
            ln.dir = tuple(l["dir"])
            ln.wmode = l.get("wmode", 0)
            for s in l["spans"]:
                xref = _xref_of(s["font"], mapping)
                col = int_to_rgb(s["color"])
                font = mapping.get(("name", xref)) or s["font"]
                for c in s["chars"]:
                    ln.chars.append({
                        "c": c["c"], "o": tuple(c["origin"]), "bb": tuple(c["bbox"]),
                        "size": s["size"], "color": col, "xref": xref, "font": font, "flags": s["flags"],
                        "syn": bool(c.get("synthetic")),
                    })
            if not ln.chars:
                continue
            ln.text = "".join(ch["c"] for ch in ln.chars)
            if not ln.text.strip():
                continue
            first = ln.chars[0]
            ln.origin = first["o"]
            bb = [min(c["bb"][0] for c in ln.chars), min(c["bb"][1] for c in ln.chars),
                  max(c["bb"][2] for c in ln.chars), max(c["bb"][3] for c in ln.chars)]
            ln.bbox = tuple(bb)
            ln.size = max(c["size"] for c in ln.chars)
            ln.color = first["color"]
            ln.basefont = first["font"]
            ln.flags = first["flags"]
            ln.xrefs = sorted({c["xref"] for c in ln.chars if c["xref"]})
            lines.append(ln)
    return lines


def _group_key(doc, xref, ftype, base):
    """Fonts that are really one face split into several objects (Chrome does this with Type 3) share a key."""
    if ftype == "Type3":
        try:
            m = re.search(r"/FontDescriptor\s+(\d+) 0 R", doc.xref_object(xref, compressed=True))
            return ("fd", int(m.group(1))) if m else None
        except Exception:
            return None
    return ("name", clean_font_name(base)) if base else None


def doc_usage(doc, max_pages=250):
    """(usage, groups): usage maps font xref to the characters shown with it anywhere in the document (first
    max_pages pages); groups maps a font xref to the other xrefs that are the same face."""
    usage, keys = {}, {}
    n = min(len(doc), max_pages)
    for p in range(n):
        try:
            for f in doc[p].get_fonts(full=True):
                keys.setdefault(f[0], _group_key(doc, f[0], f[2], f[3]))
            for ln in analyze_page(doc, p, arabic=False):
                for c in ln.chars:
                    if c["xref"]:
                        usage.setdefault(c["xref"], set()).add(c["c"])
        except Exception:
            continue
    by_key = {}
    for x, k in keys.items():
        if k:
            by_key.setdefault(k, []).append(x)
    groups = {x: [y for y in by_key[k] if y != x] for x, k in keys.items() if k}
    return usage, groups


def _line_t(ln, pt):
    dx, dy = ln.dir
    return (pt[0] - ln.origin[0]) * dx + (pt[1] - ln.origin[1]) * dy


def _char_adv_of(ch):
    return min(ch["bb"][2] - ch["bb"][0], ch["bb"][3] - ch["bb"][1])


def _char_adv(ln, i):
    """Advance of char i as drawn in the original (along the line direction)."""
    ch = ln.chars[i]
    dx, dy = ln.dir
    x0, y0, x1, y1 = ch["bb"]
    w = abs(dx) * (x1 - x0) + abs(dy) * (y1 - y0)
    return w


class Edits:
    """Applies a list of edit dicts to one page."""

    def __init__(self, doc, page, usage, resolver):
        self.doc, self.page, self.usage, self.resolver = doc, page, usage, resolver
        self.pm = ~page.transformation_matrix  # mupdf space (y down) -> PDF user space
        self.der = page.derotation_matrix  # view space -> mupdf space
        self.ops = []
        self.kits = {}
        self.fonts_res = {}  # ident -> resource name
        self.font_xref = {}  # resource name -> font object
        self.unicode = {}  # resource name -> {glyph id: text}, for glyphs a font only reaches through shaping
        self.report = []
        self._n = 0

    # fonts ---------------------------------------------------------------
    def kit(self, xref):
        if xref not in self.kits:
            self.kits[xref] = FontKit(self.doc, xref, self.usage.get(xref), None)
        return self.kits[xref]

    def res_for_xref(self, xref):
        key = ("x", xref)
        if key not in self.fonts_res:
            self.fonts_res[key] = ensure_font_resource(self.doc, self.page, xref)
        return self.fonts_res[key]

    def res_for_font(self, spec):
        key = ("s", spec)
        if key not in self.fonts_res:
            font, ident = self.resolver.get(spec)
            # A file saved by this editor before already has PLS names on the page. Reusing one would make
            # PyMuPDF hand back that older font, and the new text would be drawn with the wrong letters.
            taken = {f[4] for f in self.page.get_fonts()} | set(self.fonts_res.values())
            for f in self.page.get_fonts():  # the same font file, added by an earlier save: use it again
                if f[4].startswith("PLS") and f[2] == "Type0" and f[4] not in self.fonts_res.values():
                    try:
                        same = self.doc.extract_font(f[0])[3] == font.buffer
                    except Exception:
                        same = False
                    if same:
                        self.fonts_res[key] = f[4]
                        self.font_xref[f[4]] = f[0]
                        return f[4]
            num_ = 1
            while f"PLS{num_}" in taken:
                num_ += 1
            name = f"PLS{num_}"
            xref = self.page.insert_font(fontname=name, fontbuffer=font.buffer)
            self.fonts_res[key] = name
            self.font_xref[name] = xref
        return self.fonts_res[key]

    # drawing -------------------------------------------------------------
    def _to_pdf(self, pt):
        p = pymupdf.Point(pt) * self.pm
        return p.x, p.y

    def put_glyph(self, res, size, color, origin, direction, hexcode, xscale=1.0):
        """One glyph at an absolute position. origin is in mupdf space, direction a unit vector there."""
        ox, oy = self._to_pdf(origin)
        dx, dy = direction
        # glyph x axis along direction, y axis = up (rotate direction by -90 degrees in a y-down space)
        ux, uy = dy, -dx
        a = pymupdf.Point(dx, dy) * pymupdf.Matrix(self.pm.a, self.pm.b, self.pm.c, self.pm.d, 0, 0)
        u = pymupdf.Point(ux, uy) * pymupdf.Matrix(self.pm.a, self.pm.b, self.pm.c, self.pm.d, 0, 0)
        self.ops.append(
            f"/{res} {fmt(size)} Tf {fmt(color[0])} {fmt(color[1])} {fmt(color[2])} rg "
            f"{fmt(a.x * xscale)} {fmt(a.y * xscale)} {fmt(u.x)} {fmt(u.y)} {fmt(ox)} {fmt(oy)} Tm <{hexcode}> Tj"
        )

    def put_shaped(self, spec, shaped, size, color, start, direction, xscale=1.0):
        """A shaped run (see shape_text). start is the left end of its baseline, in mupdf space."""
        groups, _width, _missing, labels = shaped
        res = self.res_for_font(spec)
        dx, dy = direction
        ux, uy = dy, -dx
        for attach, glyphs in groups:
            if attach:  # the letters of this group, for search, copy and later editing
                self.ops.append(f"/Span <</ActualText <feff{attach.encode('utf-16-be').hex()}>>> BDC")
            for gid, x, rise in glyphs:
                origin = (start[0] + dx * x * size * xscale + ux * rise * size, start[1] + dy * x * size * xscale + uy * rise * size)
                self.put_glyph(res, size, color, origin, direction, f"{gid:04x}", xscale)
            if attach:
                self.ops.append("EMC")
        known = self.unicode.setdefault(res, {})
        for gid, text in labels.items():
            known.setdefault(gid, text)

    def flush_text(self):
        if not self.ops:
            return b""
        body = "\n".join(self.ops)
        self.ops = []
        return f"q BT\n{body}\nET Q\n".encode("latin-1")

    def patch_unicode(self):
        """Shaped Arabic uses glyph variants the font file gives no character for. Record what each one stands
        for, so the text of the saved PDF can still be searched, copied and edited again."""
        for res, extra in self.unicode.items():
            xref = self.font_xref.get(res)
            if not xref:
                continue
            try:
                m = re.search(r"/ToUnicode\s+(\d+) 0 R", self.doc.xref_object(xref, compressed=True))
                if m:
                    tu = int(m.group(1))
                    table = parse_tounicode(self.doc.xref_stream(tu) or b"")
                else:
                    tu, table = self.doc.get_new_xref(), {}
                    self.doc.update_object(tu, "<<>>")
                table.update(extra)
                self.doc.update_stream(tu, build_tounicode(table))
                if not m:
                    self.doc.xref_set_key(xref, "ToUnicode", f"{tu} 0 R")
            except Exception:
                continue  # the text is drawn either way; only its searchability is at stake
        self.unicode = {}


def ensure_font_resource(doc, page, xref):
    """Make sure the page's Resources/Font dictionary knows font object xref. Returns its resource name."""
    return ensure_resource(doc, page, "Font", f"PLX{xref}", xref)


def ensure_resource(doc, page, category, name, xref):
    """Register object xref under /Resources/<category>/<name> of the page (creating or un-inheriting as needed)."""
    res_t, res_v = doc.xref_get_key(page.xref, "Resources")
    res_xref = None
    if res_t == "xref":
        res_xref = int(re.match(r"(\d+) 0 R", res_v).group(1))
    elif res_t == "dict":
        pass
    else:
        # inherited: find it on a parent and give the page its own reference
        parent_t, parent_v = doc.xref_get_key(page.xref, "Parent")
        cur = page.xref
        found = None
        while True:
            pt, pv = doc.xref_get_key(cur, "Parent")
            if pt != "xref":
                break
            cur = int(re.match(r"(\d+) 0 R", pv).group(1))
            rt, rv = doc.xref_get_key(cur, "Resources")
            if rt in ("xref", "dict"):
                found = (rt, rv)
                break
        if found is None:
            doc.xref_set_key(page.xref, "Resources", "<<>>")
        elif found[0] == "xref":
            doc.xref_set_key(page.xref, "Resources", found[1])
        else:
            doc.xref_set_key(page.xref, "Resources", found[1])
        res_t, res_v = doc.xref_get_key(page.xref, "Resources")
        if res_t == "xref":
            res_xref = int(re.match(r"(\d+) 0 R", res_v).group(1))
    holder = res_xref if res_xref is not None else page.xref
    prefix = "" if res_xref is not None else "Resources/"
    ft, fv = doc.xref_get_key(holder, prefix + category)
    if ft == "null" or ft is None:
        doc.xref_set_key(holder, prefix + category, "<<>>")
        ft, fv = doc.xref_get_key(holder, prefix + category)
    if ft == "xref":
        target, path = int(re.match(r"(\d+) 0 R", fv).group(1)), ""
    else:
        target, path = holder, f"{prefix}{category}/"
    # never take over a name that already points at another object (left by an earlier editing session)
    base, tries = name, 0
    while True:
        kt, kv = doc.xref_get_key(target, path + name)
        if kt in ("null", None) or kv == f"{xref} 0 R":
            break
        tries += 1
        name = f"{base}n{tries}"
    doc.xref_set_key(target, path + name, f"{xref} 0 R")
    return name


def append_content(doc, page, data):
    """Add drawing operators on top of the page, wrapped so they cannot disturb the existing content."""
    if not data:
        return
    page.wrap_contents()
    xref = doc.get_new_xref()
    doc.update_object(xref, "<<>>")
    doc.update_stream(xref, data)
    contents = page.get_contents()
    refs = " ".join(f"{x} 0 R" for x in contents + [xref])
    doc.xref_set_key(page.xref, "Contents", f"[{refs}]")


# ------------------------------------------------------------------ line edits

def _flags_bold(flags):
    return bool(flags & 16)


def _flags_italic(flags):
    return bool(flags & 2)


def redact_rect(ln):
    """A thin band around the baseline: it touches every glyph of the line but not the lines around it."""
    x0, y0, x1, y1 = ln.bbox
    dx, dy = ln.dir
    s = ln.size
    ox, oy = ln.origin
    inset = -0.3 if ln.looks is not None else 0.1  # Arabic: vowel marks sit a little outside the letters at both ends
    if abs(dy) < 0.5:  # horizontal text
        return pymupdf.Rect(x0 + inset, oy - 0.35 * s, x1 - inset, oy + 0.05 * s)
    return pymupdf.Rect(ox - 0.35 * s, y0 + inset, ox + 0.05 * s, y1 - inset) if abs(dx) < 0.5 else pymupdf.Rect(*ln.bbox)


def _median(vals, default=0.0):
    vals = [v for v in vals if v is not None]
    return statistics.median(vals) if vals else default


class Report:
    def __init__(self):
        self.exact = 0
        self.substituted = {}
        self.missing = set()

    def sub(self, ch, label):
        self.substituted.setdefault(label, set()).add(ch)

    def as_dict(self):
        return {
            "exact": self.exact,
            "substituted": {k: "".join(sorted(v)) for k, v in self.substituted.items()},
            "missing": "".join(sorted(self.missing)),
        }


def edit_line(E, ln, new_text, opt, groups, report):
    """Write new_text in place of line ln (its old glyphs are removed separately)."""
    old = ln.text
    new = re.sub(r"[\r\n\t]+", " ", new_text)
    n = len(old)
    chars = ln.chars
    if any(len(c["c"]) != 1 for c in chars):
        raise EditError("This line contains special glyph groups and cannot be edited safely.")
    dx, dy = ln.dir
    t = [_line_t(ln, c["o"]) for c in chars]
    scale = 1.0
    if opt.get("size"):
        scale = max(0.1, num(opt["size"], ln.size) / ln.size)
    force_family = opt.get("family") or None
    ov_bold, ov_italic = opt.get("bold"), opt.get("italic")
    force_sub = bool(force_family) or ov_bold is not None or ov_italic is not None
    color_override = hex_to_rgb(opt["color"]) if opt.get("color") else None

    # One glyph can stand for several letters (ligatures such as "ti" or "fi"): the letters after the first have
    # no width of their own. first_of[i] is the index of the first letter of the group letter i belongs to.
    groups_lig, first_of = {}, [None] * n
    i = 0
    while i < n:
        j = i + 1
        while j < n and chars[j]["xref"] == chars[i]["xref"] and chars[j]["c"] != " " and _char_adv(ln, j) < 0.02 * chars[j]["size"]:
            j += 1
        if j > i + 1 and chars[i]["xref"]:
            k = E.kit(chars[i]["xref"])
            s = "".join(c["c"] for c in chars[i:j])
            if k.ok and s in k.multi:
                groups_lig[i] = (j - i, k, k.multi[s])
                for m in range(i, j):
                    first_of[m] = i
        i = j

    observed = {}
    for i, c in enumerate(chars):
        if first_of[i] is None:
            observed.setdefault((c["xref"], c["c"]), _char_adv(ln, i) / c["size"])
    E_OBS.clear()
    E_OBS.update(observed)

    # nominal advance of every original glyph (font width, plus the tracking the line was set with)
    adv_o = []
    for i, c in enumerate(chars):
        a = None
        if first_of[i] is not None:
            if first_of[i] == i:
                ad = groups_lig[i][1].advance_code(groups_lig[i][2])
                a = ad * c["size"] if ad else None
        elif c["xref"]:
            ad = E.kit(c["xref"]).advance(c["c"])
            if ad:
                a = ad * c["size"]
        adv_o.append(a if a else _char_adv(ln, i))
    gaps, spaces = [], []
    for i in range(n - 1):
        same = chars[i]["xref"] == chars[i + 1]["xref"] and abs(chars[i]["size"] - chars[i + 1]["size"]) < 0.01
        if chars[i]["c"] == " ":
            spaces.append(t[i + 1] - t[i])
        elif chars[i + 1]["c"] != " " and same:
            gaps.append(t[i + 1] - t[i] - adv_o[i])
    extra_ch = 0.0 if force_sub else _median(gaps, 0.0)
    if abs(extra_ch) < 0.004 * ln.size:
        extra_ch = 0.0
    space_adv = _median(spaces, None)
    nom_o = [(space_adv if (c["c"] == " " and space_adv is not None) else adv_o[i] + (0.0 if c["c"] == " " else extra_ch)) for i, c in enumerate(chars)]
    ops = difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes()
    src_of = [None] * len(new)
    for tag, i1, i2, j1, j2 in ops:
        for k in range(j2 - j1):
            if tag == "equal":
                src_of[j1 + k] = i1 + k
            else:
                s0 = min(i1, n - 1) if tag == "replace" else (i1 - 1 if i1 > 0 else 0)
                src_of[j1 + k] = max(0, min(s0, n - 1))

    # which new letters are untouched letters of the original line
    old_idx = [None] * len(new)
    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal":
            for k in range(i2 - i1):
                old_idx[j1 + k] = i1 + k
    # a ligature that survived the edit whole is drawn again as its one glyph; a broken one flows as plain letters
    lig_at = {}
    for j, oi in enumerate(old_idx):
        if oi is None or first_of[oi] is None:
            continue
        g = first_of[oi]
        length = groups_lig[g][0]
        j0 = j - (oi - g)
        whole = not force_sub and j0 >= 0 and j0 + length <= len(new) and all(old_idx[j0 + m] == g + m for m in range(length))
        if whole:
            lig_at[j] = ("lig", groups_lig[g][1], groups_lig[g][2]) if oi == g else ("skip",)
        else:
            old_idx[j] = None

    # choose a drawing font for every new char
    plan = []
    last_draw = None
    for j, ch in enumerate(new):
        si = src_of[j]
        src = chars[si]
        size = src["size"] * scale
        color = color_override or src["color"]
        draw = lig_at.get(j)
        if draw is not None:
            plan.append((draw, size, color, src))
            continue
        if not force_sub and src["xref"]:
            kits = [E.kit(src["xref"])] + [E.kit(a) for a in groups.get(src["xref"], []) if a != src["xref"]]
            for k in kits:
                if k.can(ch):
                    draw = ("orig", k)
                    break
        if draw is None:
            bold = _flags_bold(src["flags"]) if ov_bold is None else bool(ov_bold)
            italic = _flags_italic(src["flags"]) if ov_italic is None else bool(ov_italic)
            spec, quality = E.resolver.spec_for(src["font"], src["flags"], bold, italic, force_family)
            font, ident = E.resolver.get(spec)
            gid = font.has_glyph(ord(ch))
            if not gid and ch != " ":  # try a general purpose font before giving up
                spec2 = ("builtin", builtin_key(classify_font(src["font"], src["flags"]), bold, italic))
                font2, _ = E.resolver.get(spec2)
                gid = font2.has_glyph(ord(ch))
                if gid:
                    spec, font, quality = spec2, font2, "approximate"
            if gid:
                draw = ("sub", spec, font, gid, quality)
            elif ch == " " or ch in SPACE_LIKE:
                draw = ("space",)
            else:
                report.missing.add(ch)
        plan.append((draw, size, color, src))
        last_draw = draw

    def nominal(j):
        draw, size, color, src = plan[j]
        ch = new[j]
        if ch == " ":
            return (space_adv if space_adv is not None else 0.28 * src["size"]) * scale
        if draw is None:
            return 0.5 * size
        if draw[0] == "space":
            return (space_adv if space_adv is not None else 0.28 * src["size"]) * scale * SPACE_LIKE.get(ch, 1.0)
        if draw[0] == "skip":
            return 0.0
        if draw[0] == "lig":
            return (draw[1].advance_code(draw[2]) or 0.5) * size + extra_ch * scale
        if draw[0] == "orig":
            a = draw[1].advance(ch) or E_OBS.get((draw[1].xref, ch)) or 0.5
            return a * size + extra_ch * scale
        return draw[2].glyph_advance(ord(ch)) * size + extra_ch * scale

    # positions along the baseline: letters kept from the original keep their exact spacing, new ones flow
    pos = [0.0] * len(new)
    cursor = t[0] if n else 0.0
    prev_oi = None
    for j in range(len(new)):
        oi = old_idx[j]
        draw = plan[j][0]
        keep = oi is not None and (
            (draw is not None and draw[0] in ("orig", "lig", "skip"))
            or (new[j] == " " and prev_oi is not None and oi == prev_oi + 1 and not force_sub))
        if keep:
            if prev_oi is not None and oi == prev_oi + 1:
                pos[j] = pos[j - 1] + (t[oi] - t[prev_oi]) * scale
            elif j == 0:
                pos[j] = t[0]
            else:
                gap = (t[oi] - (t[oi - 1] + nom_o[oi - 1])) if oi > 0 else 0.0
                if abs(gap) > 0.5 * ln.size:
                    gap = 0.0
                pos[j] = cursor + gap * scale
            cursor = pos[j] + nom_o[oi] * scale
            prev_oi = oi
        else:
            pos[j] = cursor
            cursor += nominal(j)
            prev_oi = None
    xscale = 1.0
    if opt.get("fit") and new:
        orig_w = (t[-1] + nom_o[-1]) - t[0]
        new_w = cursor - t[0]
        if new_w > orig_w + 0.5 and orig_w > 0:
            xscale = max(0.8, orig_w / new_w)
    base_t0 = t[0] if n else 0.0
    ox, oy = ln.origin
    prev_font = None  # a space follows the font of the letter before it, so text stays searchable
    for j, ch in enumerate(new):
        draw, size, color, src = plan[j]
        if draw and draw[0] == "space":
            draw = None
        if ch == " " and draw is None and prev_font is not None:
            draw = prev_font
            if draw[0] == "orig" and not draw[1].can(" "):
                draw = None
            elif draw[0] == "sub" and not draw[2].has_glyph(32):
                draw = None
            elif draw[0] == "sub":
                draw = ("sub", draw[1], draw[2], draw[2].has_glyph(32), draw[4])
        if not draw:
            continue
        if draw[0] == "skip":  # second letter of a ligature: its glyph was drawn with the first letter
            report.exact += 1
            continue
        tt = base_t0 + (pos[j] - base_t0) * xscale
        origin = (ox + dx * tt, oy + dy * tt)
        if draw[0] == "lig":
            k = draw[1]
            E.put_glyph(E.res_for_xref(k.xref), size, color, origin, ln.dir, k.encode_code(draw[2]), xscale)
            report.exact += 1
            prev_font = ("orig", k)
            continue
        if draw[0] == "orig":
            k = draw[1]
            E.put_glyph(E.res_for_xref(k.xref), size, color, origin, ln.dir, k.encode(ch), xscale)
            if ch != " ":
                report.exact += 1
        else:
            _, spec, font, gid, quality = draw
            E.put_glyph(E.res_for_font(spec), size, color, origin, ln.dir, f"{gid:04x}", xscale)
            if ch != " ":
                report.sub(ch, quality)
        if ch != " ":
            prev_font = draw
    return xscale


E_OBS = {}


# ------------------------------------------------------------------ Arabic (right to left) text
#
# English and French are written letter by letter. Arabic letters change shape with their neighbours and run
# from right to left, so an Arabic line is laid out as a whole by MuPDF's own text shaper (HarfBuzz) with an
# installed font, and then drawn glyph by glyph like everything else.

UNSUPPORTED_SCRIPT = "This text uses a script the editor cannot write."


def _arabic_cp(o):
    return 0x600 <= o <= 0x6FF or 0x750 <= o <= 0x77F or 0x8A0 <= o <= 0x8FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFC


def has_arabic(text):
    return any(_arabic_cp(ord(ch)) for ch in str(text or ""))


def unsupported_script(text):
    """Right to left writing other than Arabic. The editor writes Arabic, English and French."""
    return any(unicodedata.bidirectional(ch) in ("R", "AL") and not _arabic_cp(ord(ch)) and unicodedata.category(ch) != "Cf"
               for ch in str(text or ""))


def plain_arabic(s):
    """Presentation forms (the ready shaped variants some PDFs and keyboards produce) back to ordinary letters."""
    out = []
    for ch in s:
        o = ord(ch)
        if 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFC:
            d = unicodedata.normalize("NFKC", ch)
            if len(d) > 1 and any(unicodedata.combining(x) for x in d):
                d = d.replace("\u0640", "").replace(" ", "")  # the shaped forms of the vowel marks carry a filler
            out.append(d or ch)
        else:
            out.append(LATIN_LIGATURES.get(ch, ch))  # and "fi", "ffl" stored as one character
    return "".join(out)


def first_strong_rtl(text):
    """Direction of a paragraph the way browsers decide it: by its first letter."""
    for ch in text:
        b = unicodedata.bidirectional(ch)
        if b in ("R", "AL"):
            return True
        if b == "L":
            return False
    return False


_MIRROR = {"(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "<": ">", ">": "<",
           "\u00ab": "\u00bb", "\u00bb": "\u00ab", "\u2039": "\u203a", "\u203a": "\u2039"}
_BIDI_SKIP = ("LRE", "RLE", "PDF", "LRO", "RLO", "LRI", "RLI", "FSI", "PDI", "BN")
_NEUTRAL = ("B", "S", "WS", "ON", "BN")


def bidi_levels(text, base):
    """Embedding level of every character (Unicode bidirectional algorithm, implicit rules only).
    base is 0 for a left to right paragraph and 1 for a right to left one."""
    n = len(text)
    orig = [unicodedata.bidirectional(c) or "ON" for c in text]
    t = ["BN" if x in _BIDI_SKIP else x for x in orig]
    sor = "R" if base else "L"
    prev = sor
    for i in range(n):  # W1: marks take the type of their letter
        if t[i] == "NSM":
            t[i] = prev
        elif t[i] != "BN":
            prev = t[i]
    strong = sor
    for i in range(n):  # W2: western digits after Arabic letters behave like Arabic digits
        if t[i] in ("L", "R", "AL"):
            strong = t[i]
        elif t[i] == "EN" and strong == "AL":
            t[i] = "AN"
    t = ["R" if x == "AL" else x for x in t]  # W3
    for i in range(1, n - 1):  # W4: one separator inside a number belongs to the number
        if t[i] == "ES" and t[i - 1] == "EN" and t[i + 1] == "EN":
            t[i] = "EN"
        elif t[i] == "CS" and t[i - 1] == t[i + 1] and t[i - 1] in ("EN", "AN"):
            t[i] = t[i - 1]
    i = 0
    while i < n:  # W5: currency and percent signs next to western digits
        if t[i] == "ET":
            j = i
            while j < n and t[j] == "ET":
                j += 1
            if (i > 0 and t[i - 1] == "EN") or (j < n and t[j] == "EN"):
                t[i:j] = ["EN"] * (j - i)
            i = j
        else:
            i += 1
    t = ["ON" if x in ("ES", "ET", "CS") else x for x in t]  # W6
    strong = sor
    for i in range(n):  # W7
        if t[i] in ("L", "R"):
            strong = t[i]
        elif t[i] == "EN" and strong == "L":
            t[i] = "L"
    stack, pairs = [], []
    for i, ch in enumerate(text):  # N0: a pair of brackets follows the text it encloses
        if t[i] != "ON":
            continue
        if ch in "([{":
            stack.append(i)
        elif ch in ")]}":
            for k in range(len(stack) - 1, -1, -1):
                if text[stack[k]] == _MIRROR[ch]:
                    pairs.append((stack[k], i))
                    del stack[k:]
                    break
    for a, b in sorted(pairs):
        inside = {"L" if t[k] == "L" else "R" for k in range(a + 1, b) if t[k] in ("L", "R", "EN", "AN")}
        if not inside:
            continue
        d = sor
        if sor not in inside:
            before = next(("L" if t[k] == "L" else "R" for k in range(a - 1, -1, -1) if t[k] in ("L", "R", "EN", "AN")), sor)
            if before != sor:
                d = before
        t[a] = t[b] = d
    i = 0
    while i < n:  # N1, N2: spaces and punctuation follow the text around them
        if t[i] in _NEUTRAL:
            j = i
            while j < n and t[j] in _NEUTRAL:
                j += 1
            before = sor if i == 0 else ("L" if t[i - 1] == "L" else "R")
            after = sor if j == n else ("L" if t[j] == "L" else "R")
            t[i:j] = [before if before == after else sor] * (j - i)
            i = j
        else:
            i += 1
    if base:
        lv = [1 if x == "R" else 2 for x in t]
    else:
        lv = [0 if x == "L" else 1 if x == "R" else 2 for x in t]
    i = n - 1
    while i >= 0 and orig[i] in ("WS", "B", "S", "BN"):  # L1: spaces at the end of the line
        lv[i] = base
        i -= 1
    return lv


def _reorder(lv, order, levels):
    """Rule L2 (or its inverse, depending on the order of levels): reverse every run at a level or above."""
    n = len(order)
    for level in levels:
        i = 0
        while i < n:
            if lv[order[i]] >= level:
                j = i
                while j < n and lv[order[j]] >= level:
                    j += 1
                order[i:j] = order[i:j][::-1]
                i = j
            else:
                i += 1
    return order


def visual_order(lv):
    """Indices of the characters in the order they appear on the line, left to right."""
    odd = [x for x in lv if x % 2]
    if not odd:
        return list(range(len(lv)))
    return _reorder(lv, list(range(len(lv))), range(max(lv), min(odd) - 1, -1))


def _unit_class(text):
    """Direction class of a piece of a line: that of its first letter (a whole word recorded with its brackets is
    a word), else that of its first character."""
    first = None
    for ch in text:
        b = unicodedata.bidirectional(ch) or "ON"
        if b == "NSM":
            continue
        if b in ("R", "AL"):
            return "R"
        if b == "L":
            return "L"
        if first is None:
            first = b if b in ("EN", "AN", "ES", "ET", "CS", "WS") else "ON"
    return first or "ON"


def _visual_pairs(units):
    """Bracket pairs of a line as seen on the page (either bracket may come first)."""
    stack, out = [], []
    for i, u in enumerate(units):
        if len(u) != 1 or u not in "()[]{}":
            continue
        k = next((k for k in range(len(stack) - 1, -1, -1) if units[stack[k]] == _MIRROR[u]), None)
        if k is None:
            stack.append(i)
        else:
            out.append((stack[k], i))
            del stack[k:]
    return out


def _visual_levels(cls, units, base, sticky, hug, numbers="right"):
    """Levels of the pieces of a line as seen on the page (left to right), by the same rules as bidi_levels but
    applied to what is visible. The open questions are passed in: sticky (percent and currency signs belong to their
    number), hug (bit k: bracket pair k takes the direction of the text inside it) and numbers (in a left to
    right paragraph: a number belongs to the Arabic on its right, or only to Arabic on its left; in a right to left
    paragraph: a number reads on with the Latin text on its left, or "none": it stands by itself)."""
    n = len(cls)
    typ = [c if c in ("L", "R") else "N" if c in ("EN", "AN") else None for c in cls]
    for i in range(1, n - 1):  # separators inside a number
        if typ[i] is None and typ[i - 1] == "N" and typ[i + 1] == "N" and (cls[i] == "CS" or (sticky and cls[i] == "ES")):
            typ[i] = "N"
    if sticky:
        for i in range(n):
            if typ[i] is None and cls[i] == "ET" and ((i and typ[i - 1] == "N") or (i + 1 < n and typ[i + 1] == "N")):
                typ[i] = "N"
    last = None  # a number after Latin text reads on with it
    strong = [None] * n
    for i in range(n):
        if cls[i] in ("L", "R"):
            last = cls[i]
        strong[i] = last
    for i in range(n):
        if typ[i] != "N":
            continue
        after = next((cls[k] for k in range(i + 1, n) if cls[k] in ("L", "R")), None)
        if base:
            latin = numbers != "none" and strong[i] == "L" and cls[i] != "AN"
        elif numbers == "right":
            latin = not (after == "R" or strong[i] == "R")
        else:
            latin = strong[i] != "R"
        if latin and cls[i] != "AN":
            typ[i] = "L"
    emb = "R" if base else "L"
    for k, (a, b) in enumerate(_visual_pairs(units)):
        inside = {"L" if typ[m] == "L" else "R" for m in range(a + 1, b) if typ[m]}
        if emb in inside:
            typ[a] = typ[b] = emb
        elif inside:
            typ[a] = typ[b] = ("L" if base else "R") if hug >> k & 1 else emb
    i = 0
    while i < n:  # spaces and punctuation follow the text around them
        if typ[i] is None:
            j = i
            while j < n and typ[j] is None:
                j += 1
            left = emb if i == 0 else ("L" if typ[i - 1] == "L" else "R")
            right = emb if j == n else ("L" if typ[j] == "L" else "R")
            typ[i:j] = [(left if left == right else emb) + "n"] * (j - i)
            i = j
        else:
            i += 1
    if base:
        return [1 if t[0] == "R" else 2 for t in typ]
    return [0 if t[0] == "L" else 1 if t[0] == "R" else 2 for t in typ]


def _bracket_shapes(units, lv):
    """Brackets inside right to left text. PDFs made by browsers and office programs record the character that
    was typed, so a pair reads ")...(" from left to right. Some record the mirrored shape instead: a pair that
    reads "(...)" there. Returns the pieces that hold such a shape and must be swapped back."""
    idx = [k for k in range(len(units)) if lv[k] % 2 and units[k] in _MIRROR]
    left = "([{<\u00ab\u2039"

    def pairs(openers):
        stack, hits = [], []
        for k in idx:
            if units[k] in openers:
                stack.append(k)
            elif stack and units[stack[-1]] == _MIRROR[units[k]]:
                hits.append((stack.pop(), k))
        return hits

    as_shapes, as_typed = pairs(left), pairs("".join(_MIRROR[c] for c in left))
    return {k for pair in as_shapes for k in pair} if len(as_shapes) > len(as_typed) else set()


def _oddness(text):
    """How unlikely a text is to have been typed this way: brackets that close before they open, a sentence that
    starts with its full stop. Several texts can give the same line on the page; the least odd one is taken."""
    t = text.strip()
    odd = 1 if t and t[0] in ".,:;!?\u060c\u061b\u061f)]}\u00bb" else 0
    stack = []
    for ch in text:
        if ch in "([{\u00ab":
            stack.append(ch)
        elif ch in ")]}\u00bb":
            if stack and stack[-1] == _MIRROR[ch]:
                stack.pop()
            else:
                odd += 1
    return odd + len(stack)


def _drawn_oddness(text, base):
    """Brackets and quotes as they would be drawn for a text (those inside right to left text are mirrored): how
    many of them do not pair up on the page. Nobody leaves "1 250 >> word >>" on a page, so a reading that
    implies such shapes is less likely than one that implies "<< word >>"."""
    if not any(ch in _MIRROR for ch in text):
        return 0
    lv = bidi_levels(text, base)
    stack, odd = [], 0
    for i in visual_order(lv):
        ch = _MIRROR.get(text[i], text[i]) if lv[i] % 2 else text[i]
        if ch in "([{\u00ab":
            stack.append(ch)
        elif ch in ")]}\u00bb":
            if stack and stack[-1] == _MIRROR[ch]:
                stack.pop()
            else:
                odd += 1
    return odd + len(stack)


_LOGICAL_CACHE = {}


def to_logical(units, base_hint):
    """units: texts of the pieces of a line in the order seen on the page, left to right.
    Returns (text in typing order, True when the paragraph runs right to left, the piece every character came from).
    A page shows where the letters ended up, not how they were typed, so candidates are tried until one is found
    that, laid out again by the rules browsers use, gives exactly the line on the page."""
    key = (tuple(units), base_hint)
    if key in _LOGICAL_CACHE:
        return _LOGICAL_CACHE[key]
    n = len(units)
    cls = [_unit_class(u) for u in units]
    first, tries = [None], [0]

    def attempt(lv, base, shapes=False):
        """(score, result): score counts the pieces that land where the page has them."""
        tries[0] += 1
        odd = [x for x in lv if x % 2]
        order = _reorder(lv, list(range(n)), range(min(odd), max(lv) + 1)) if odd else list(range(n))
        flip = _bracket_shapes(units, lv) if shapes else set()
        parts = [(_MIRROR[units[k]] if k in flip else units[k]) for k in order]
        text = "".join(parts)
        owner = [k for k, p in zip(order, parts) for _ in p]
        if first[0] is None:
            first[0] = (text, bool(base), owner)
        flv = bidi_levels(text, base)
        seen = []
        for ci in visual_order(flv):
            if not seen or seen[-1] != owner[ci]:
                seen.append(owner[ci])
        score = sum(1 for i, k in enumerate(seen[:n]) if i == k)
        pos = 0
        for k, p in zip(order, parts):
            if units[k] in _MIRROR and lv[k] % 2 != flv[pos] % 2:  # a bracket would come out the other way round
                score -= 1
            pos += len(p)
        return score, (text, bool(base), owner) if (score == n and len(seen) == n) else None

    def search():
        pairs = len(_visual_pairs(units))
        hugs = range((1 << pairs) - 1, -1, -1) if pairs <= 4 else ((1 << pairs) - 1, 0)
        # brackets: first take them as the characters that were typed (what browsers and office programs record),
        # and only then as mirrored shapes
        best = None
        for shapes in (False, True):
            for base in (base_hint, 1 - base_hint):
                for numbers in (("right", "left") if base == 0 else ("right", "none")):
                    for hug in hugs:
                        for sticky in (True, False):
                            hit = attempt(_visual_levels(cls, units, base, sticky, hug, numbers), base, shapes)[1]
                            if hit:
                                odd = _oddness(hit[0]) + _drawn_oddness(hit[0], base)
                                if not odd:
                                    return hit
                                if best is None or odd < best[0]:
                                    best = (odd, hit)
            if best:
                return best[1]
        # still open: which side every space, sign and number next to Latin words and numbers belongs to.
        # Change one of them at a time, keeping every change that puts more pieces in their place.
        for base in (base_hint, 1 - base_hint):
            cur = _visual_levels(cls, units, base, True, (1 << pairs) - 1)
            slots, i = [], 0
            while i < n:
                c, j = cls[i], i + 1
                if c in ("L", "R"):
                    i += 1
                    continue
                if c in ("EN", "AN"):
                    while j < n and cls[j] in ("EN", "AN"):
                        j += 1
                    if base == 0:
                        slots.append((i, j, (0, 2)))
                else:
                    if c == "WS":
                        while j < n and cls[j] == "WS":
                            j += 1
                    left = next((cls[k] for k in range(i - 1, -1, -1) if cls[k] in ("L", "R", "EN", "AN")), "edge")
                    right = next((cls[k] for k in range(j, n) if cls[k] in ("L", "R", "EN", "AN")), "edge")
                    if units[i] in "()[]{}" or not ({left, right} == {"R"} or (base == 0 and {left, right} == {"L"})):
                        slots.append((i, j, (1, 2) if base else (0, 1, 2)))
                i = j
            score = attempt(cur, base)[0]
            for _round in range(40):
                if tries[0] > 1500:  # a line this tangled is not worth more time: take the first reading
                    return first[0]
                best = None
                moves = [(a, b, v) for a, b, opts in slots for v in opts if v != cur[a]]
                for a, b, v in moves:
                    lv = cur[:a] + [v] * (b - a) + cur[b:]
                    sc, hit = attempt(lv, base)
                    if hit:
                        return hit
                    if sc > score and (best is None or sc > best[0]):
                        best = (sc, lv)
                if best is None:  # no single change helps: try two at once
                    for x in range(min(len(moves), 40)):
                        if tries[0] > 1500:
                            break
                        for y in range(x + 1, min(len(moves), 40)):
                            (a, b, v), (a2, b2, v2) = moves[x], moves[y]
                            if a == a2:
                                continue
                            lv = cur[:a] + [v] * (b - a) + cur[b:]
                            lv = lv[:a2] + [v2] * (b2 - a2) + lv[b2:]
                            sc, hit = attempt(lv, base)
                            if hit:
                                return hit
                            if sc > score and (best is None or sc > best[0]):
                                best = (sc, lv)
                if best is None:
                    break
                score, cur = best
        return first[0]

    res = search()
    if len(_LOGICAL_CACHE) > 4000:
        _LOGICAL_CACHE.clear()
    _LOGICAL_CACHE[key] = res
    return res


def _unlabelled(label):
    """A shape the PDF gives no usable character for."""
    return not label or all(ch == "\ufffd" or unicodedata.category(ch)[0] == "C" for ch in label)


def _prepare_arabic(ln, page_side=None):
    """Work out what an Arabic line says. A PDF stores such a line as shapes placed from left to right, often with
    several letters on one shape or the letters of one group swapped, so the text is rebuilt from the geometry."""
    dx, dy = ln.dir
    chars = ln.chars
    n = len(chars)
    T = [c["o"][0] * dx + c["o"][1] * dy for c in chars]
    W = [_char_adv(ln, i) for i in range(n)]
    eps = 0.02 * ln.size
    wide = [i for i in range(n) if W[i] > eps]
    ln.rtl = False
    if not wide:
        return
    base = statistics.median(-chars[i]["o"][0] * dy + chars[i]["o"][1] * dx for i in wide)
    t0 = min(T[i] for i in wide)
    ln.origin = (dx * t0 - dy * base, dy * t0 + dx * base)  # left end of the baseline
    P = [-c["o"][0] * dy + c["o"][1] * dx for c in chars]
    tol = 0.01 * ln.size

    def near(i, j):  # how far character i is from the shape of j
        return 0.0 if T[j] - 1e-3 <= T[i] <= T[j] + W[j] + 1e-3 else min(abs(T[i] - T[j]), abs(T[i] - T[j] - W[j]))

    def carries(j):  # a shape that can have a vowel mark on it: a letter, or a shape the file does not name
        return chars[j]["c"] == "\ufffd" or any(ch.isalpha() for ch in chars[j]["c"])

    def is_mark(i):
        return chars[i]["c"] == "\ufffd" or bool(unicodedata.combining(chars[i]["c"]))

    def in_text(i):  # True when the widthless characters stored around i at the same place include a letter
        for step in (-1, 1):
            k = i + step
            while 0 <= k < n and W[k] <= eps and abs(T[k] - T[i]) < tol:
                if any(ch.isalpha() for ch in chars[k]["c"]):
                    return True
                k += step
        return False

    # Characters without a width are of two kinds: letters that have no shape of their own and ride at the right end
    # of their group (the second letter of a ligature, or the real letters the PDF attaches to a group), and vowel
    # marks, which are shapes placed above or below a letter.
    spare, loose = {j: [] for j in wide}, []
    for i in range(n):
        if W[i] > eps:
            continue
        cands = [j for j in (next((k for k in range(i - 1, -1, -1) if W[k] > eps), None),
                             next((k for k in range(i + 1, n) if W[k] > eps), None)) if j is not None]
        host = next((j for j in cands if abs(T[i] - T[j] - W[j]) < tol and abs(P[i] - base) < 2 * tol), None)
        if host is not None and not carries(host) and is_mark(i):
            # a vowel mark at the edge of a space belongs to the letter on its other side
            if chars[host]["c"].isspace() and any(j != host and not chars[j]["c"].isspace() and near(i, j) < 0.5 * ln.size for j in cands):
                host = None
            # and so does a mark drawn at the edge of a sign or a number, when it lies on a letter there (looked up
            # by place: the file may store the mark far from its letter). Letters attached to the sign are told
            # apart by the company they come in: marks that are drawn stand alone.
            elif not in_text(i) and any(j != host and carries(j) and near(i, j) < tol for j in (wide if len(wide) <= 400 else cands)):
                host = None
        if host is not None:
            spare[host].append(i)
        else:
            loose.append((i, cands))
    text, full, marks = {}, {}, {j: [] for j in wide}
    order = sorted(wide, key=lambda k: T[k])
    absorbed = set()
    bare = lambda t: "".join(ch for ch in unicodedata.normalize("NFD", t) if not unicodedata.combining(ch))
    for pos, j in enumerate(order):
        label = plain_arabic(chars[j]["c"])
        known = not _unlabelled(label)
        idx = spare[j]
        if idx and idx[0] < j:
            idx = idx[::-1]  # stored back to front
        side = "".join(plain_arabic(chars[i]["c"]) for i in idx)
        whole = None
        if side and side == _MIRROR.get(label):
            whole = side  # a mirrored bracket with the typed character attached
        elif side:
            # Text attached to a whole word: the shapes to the left of the one that carries it belong to it too,
            # when their own labels spell that word (a shape without a label stands for one letter or more).
            rtl_word, spelled = has_arabic(side), [bare(label) if known else None]
            for k in range(pos - 1, max(pos - 60, -1), -1):
                i2 = order[k]
                lab = plain_arabic(chars[i2]["c"])
                if spare[i2] or lab.isspace() or T[order[k + 1]] - T[i2] - W[i2] > 0.2 * ln.size:
                    break
                if lab and all(unicodedata.combining(ch) for ch in lab):
                    continue  # a vowel mark with a width of its own says nothing about the letters
                piece = None if _unlabelled(lab) else bare(lab)
                spelled = spelled + [piece] if rtl_word else [piece] + spelled
                pattern, gap = "", 0
                for piece in spelled + [""]:
                    if piece is None:
                        gap += 1
                        continue
                    # (a bracket may be named by the shape it shows or by the character that was typed)
                    pattern += (".{%d,}" % gap if gap else "") + "".join(
                        "[%s%s]" % (re.escape(c), re.escape(_MIRROR[c])) if c in _MIRROR else re.escape(c) for c in piece)
                    gap = 0
                if re.fullmatch(pattern, bare(side), re.S):
                    whole = side  # keep going: the word reaches as far as its shapes spell it
                    absorbed.update(order[k:pos])
            if whole is None and (has_arabic(side) or any(unicodedata.combining(ch) for ch in unicodedata.normalize("NFD", side))):
                if not known:
                    whole = side  # the shape itself is not labelled
                else:  # the attached letters start with the letter of the shape (which may lack its accent)
                    k = next((k for k in range(len(side)) if bare(side[k]) == bare(label)[:1]), -1)
                    whole = side[k:] if k >= 0 else None
        full[j] = whole is not None
        text[j] = whole if whole is not None else label + side
    for j in order:
        lab = plain_arabic(chars[j]["c"])
        if j in absorbed or spare[j] or not lab or not all(unicodedata.combining(ch) for ch in lab):
            continue
        letters = [k for k in order if k != j and k not in absorbed and (full[k] or any(ch.isalpha() for ch in text[k]))]
        if not letters:
            continue
        gap = lambda k: max(T[k] - T[j] - W[j], T[j] - T[k] - W[k], 0.0)
        over = lambda k: min(T[k] + W[k], T[j] + W[j]) - max(T[k], T[j])
        # the letter it touches: the one it lies over most, and the one on its right when that does not tell
        k = min(letters, key=lambda k: (round(gap(k), 2), -round(max(over(k), 0.0), 1), -T[k]))
        if gap(k) < 0.5 * ln.size:
            absorbed.add(j)
            if not full[k]:
                marks[k].append(lab)
    for i, cands in loose:
        s_ = plain_arabic(chars[i]["c"])
        if not s_ or not all(unicodedata.combining(ch) for ch in s_):
            continue
        close_by = [j for j in wide if near(i, j) < 0.5 * ln.size]  # by place: the file may store a mark far from its letter
        if any(full[j] or j in absorbed for j in close_by):
            continue  # already among the letters attached to that group
        letters = [j for j in close_by if any(ch.isalpha() for ch in text[j])]
        marks[min(letters or close_by or wide, key=lambda j: near(i, j))].append(s_)
    units, unit_look, prev_end = [], [], None
    for j in order:
        if j in absorbed:
            prev_end = T[j] + W[j]
            continue
        look = (chars[j]["color"], chars[j]["font"], chars[j]["flags"], chars[j]["size"])
        if prev_end is not None and T[j] - prev_end > 0.2 * ln.size and units and units[-1] != " " and chars[j]["c"] != " ":
            units.append(" ")  # a gap without a space character
            unit_look.append(look)
        prev_end = T[j] + W[j]
        units.append(text[j] + "".join(sorted("".join(marks[j]), key=unicodedata.combining)))
        unit_look.append(look)
    n_r = sum(1 for u in units if _unit_class(u) == "R")
    n_l = sum(1 for u in units if _unit_class(u) == "L")
    strong = [c for c in (_unit_class(u) for u in units) if c in ("L", "R")]
    hint = page_side if page_side is not None else 1 if n_r > n_l or (n_r == n_l and strong and strong[-1] == "R") else 0
    if page_side is None and strong and strong[0] == strong[-1]:
        hint = 1 if strong[0] == "R" else 0  # the same script at both ends: the paragraph begins in that script
    stops, ends = ".!?:;\u060c\u061b\u061f\u2026", [u for u in units if u != " "]
    if len(ends) > 1 and ends[0] in stops and ends[-1] not in stops:
        hint = 1  # the sentence ends on the left
    elif len(ends) > 1 and ends[-1] in stops and ends[0] not in stops:
        hint = 0
    ln.text, ln.rtl, owner = to_logical(units, hint)
    ln.looks = [unit_look[k] for k in owner]
    # Proof of the reading: laid out again, every piece must land where the page has it. A line that fails is
    # shown but not offered for editing, since writing it back would move its pieces around.
    seen = []
    for ci in visual_order(bidi_levels(ln.text, 1 if ln.rtl else 0)):
        if not seen or seen[-1] != owner[ci]:
            seen.append(owner[ci])
    ln.sure = seen == list(range(len(units)))
    count = {}  # what the editor shows as the style of the line: the one most of its Arabic letters have
    for ch, look in zip(ln.text, ln.looks):
        if has_arabic(ch):
            count[look[:3]] = count.get(look[:3], 0) + 1
    if count:
        ln.color, ln.basefont, ln.flags = max(count, key=count.get)


def _split_gaps(ln):
    """MuPDF also reads a whole table row of Arabic as one line. Cut a line where it has a wide empty stretch."""
    dx, dy = ln.dir
    n = len(ln.chars)
    T = [c["o"][0] * dx + c["o"][1] * dy for c in ln.chars]
    W = [_char_adv(ln, i) for i in range(n)]
    cells = sorted((T[i], T[i] + W[i]) for i in range(n) if W[i] > 0.02 * ln.size and ln.chars[i]["c"] != " ")
    cuts, end = [], None
    for a, b in cells:
        if end is not None and a - end > 1.2 * ln.size:
            cuts.append((end + a) / 2)
        end = b if end is None else max(end, b)
    if not cuts:
        return [ln]
    parts = [[] for _ in range(len(cuts) + 1)]
    for i, c in enumerate(ln.chars):
        at = T[i] + (W[i] / 2 if W[i] > 0.02 * ln.size else -0.01 * ln.size)
        parts[sum(1 for x in cuts if at > x)].append(c)
    out = []
    for chars in parts:
        text = "".join(c["c"] for c in chars)
        if not text.strip():
            continue
        m = Line()
        m.chars, m.dir, m.wmode, m.text, m.idx = chars, ln.dir, ln.wmode, text, 0
        m.bbox = (min(c["bb"][0] for c in chars), min(c["bb"][1] for c in chars), max(c["bb"][2] for c in chars), max(c["bb"][3] for c in chars))
        m.size = max(c["size"] for c in chars)
        m.origin, m.color, m.basefont, m.flags = chars[0]["o"], chars[0]["color"], chars[0]["font"], chars[0]["flags"]
        m.xrefs = sorted({c["xref"] for c in chars if c["xref"]})
        out.append(m)
    return out


def _merge_arabic(lines):
    """MuPDF cuts a right to left line into pieces wherever the direction changes. Put such pieces back together."""
    if not any(has_arabic(l.text) for l in lines):
        return lines
    info = []
    for l in lines:
        dx, dy = l.dir
        ws = [i for i in range(len(l.chars)) if _char_adv(l, i) > 0.02 * l.size] or list(range(len(l.chars)))
        t = [l.chars[i]["o"][0] * dx + l.chars[i]["o"][1] * dy for i in ws]
        info.append({
            "base": statistics.median(-l.chars[i]["o"][0] * dy + l.chars[i]["o"][1] * dx for i in ws),
            "t0": min(t), "t1": max(tt + _char_adv(l, i) for tt, i in zip(t, ws)), "ar": has_arabic(l.text),
        })
    group = list(range(len(lines)))

    def root(i):
        while group[i] != i:
            group[i] = group[group[i]]
            i = group[i]
        return i

    by_base = sorted(range(len(lines)), key=lambda k: info[k]["base"])
    reach = 0.15 * max(l.size for l in lines)
    changed = True
    while changed:
        changed = False
        for a_, i in enumerate(by_base):
            for j in by_base[a_ + 1:]:
                if info[j]["base"] - info[i]["base"] > reach:
                    break
                ri, rj = root(i), root(j)
                if ri == rj:
                    continue
                a, b = lines[i], lines[j]
                if a.wmode != b.wmode or abs(a.dir[0] - b.dir[0]) > 0.01 or abs(a.dir[1] - b.dir[1]) > 0.01:
                    continue
                size = max(a.size, b.size)
                if abs(info[i]["base"] - info[j]["base"]) > 0.15 * size:
                    continue
                gap = max(info[i]["t0"], info[j]["t0"]) - min(info[i]["t1"], info[j]["t1"])
                if gap > 1.2 * size or gap < -0.6 * size:
                    continue
                if not (info[ri]["ar"] or info[rj]["ar"]):
                    continue
                group[rj] = ri
                info[ri]["ar"] = True
                changed = True
    out, at = [], {}
    for i, l in enumerate(lines):
        r = root(i)
        if r not in at:
            at[r] = l
            out.append(l)
        else:
            m = at[r]
            m.chars.extend(l.chars)
            m.text += l.text
            m.bbox = (min(m.bbox[0], l.bbox[0]), min(m.bbox[1], l.bbox[1]), max(m.bbox[2], l.bbox[2]), max(m.bbox[3], l.bbox[3]))
            m.size = max(m.size, l.size)
            m.xrefs = sorted(set(m.xrefs) | set(l.xrefs))
    return out


_AR_FAMILIES = {  # installed fonts that hold Arabic and Latin letters, by kind (every Mac has the first of each)
    "sans": ["Arial", "Tahoma", "Microsoft Sans Serif", "SF Arabic", "DejaVu Sans", "Noto Sans Arabic", "Noto Naskh Arabic"],
    "serif": ["Times New Roman", "Noto Naskh Arabic", "FreeSerif"],
    "mono": ["Courier New", "DejaVu Sans Mono", "FreeMono"],
}


def _uncovered(font, text):
    # (spaces of any kind need no shape: they are written as gaps)
    return sum(1 for ch in set(text) if not ch.isspace() and unicodedata.category(ch) != "Cf" and not font.has_glyph(ord(ch)))


def shaping_font(resolver, text, spec, cls, bold, italic):
    """Path of an installed font for a line with Arabic in it: the font asked for when it holds the letters, else
    the usual Arabic capable font of the same kind. Returns (path, True when it is the font asked for)."""
    cands = [spec[1]] if spec and spec[0] == "file" else []
    fams = _AR_FAMILIES.get(cls, []) + [f for f in _AR_FAMILIES["sans"] if f not in _AR_FAMILIES.get(cls, [])]
    for fam in fams:
        styles = system_fonts().get(fam)
        for key in ((bool(bold), bool(italic)), (bool(bold), False), (False, False)):
            p = styles.get(key) if styles else None
            if p and p not in cands:
                cands.append(p)
    need_arabic = has_arabic(text)
    best = None
    for p in cands:
        try:
            font, _ = resolver.get(("file", p))
        except Exception:
            continue
        if need_arabic and not font.has_glyph(0x0628):
            continue  # no Arabic in this font at all
        miss = _uncovered(font, text)
        if not miss:
            return p, bool(spec and p == spec[1])
        if best is None or miss < best[0]:
            best = (miss, p)
    if best:
        return best[1], bool(spec and best[1] == spec[1])
    raise EditError("No installed font with Arabic letters was found on this Mac.")


_SHAPE_CACHE = {}
_SHAPE_FONT = {}  # font path -> (archive, name MuPDF reports for it)


def _story_spans(arch, text, rtl):
    import html
    import io
    css = ("@font-face {font-family: plf; src: url(f.ttf);} "
           "body {margin: 0;} p {font-family: plf; font-size: 100px; margin: 0; white-space: pre; text-align: left;}")
    story = pymupdf.Story(f'<p dir="{"rtl" if rtl else "ltr"}">{html.escape(text)}</p>', user_css=css, archive=arch)
    buf = io.BytesIO()
    writer = pymupdf.DocumentWriter(buf)
    box = pymupdf.Rect(0, 0, 200000, 1000)
    more, _filled = story.place(box)
    dev = writer.begin_page(box)
    story.draw(dev)
    writer.end_page()
    writer.close()
    doc = pymupdf.open(stream=buf.getvalue(), filetype="pdf")
    try:
        return doc[0].get_texttrace(), bool(more)
    finally:
        doc.close()


def shape_text(resolver, path, text, rtl):
    """Lay one line out with the font at path. Returns (groups, width, missing, labels), in units of the font size.
    groups, left to right: (text to attach or None, [(glyph id, x, rise), ...]); a group is one letter shape with the
    vowel marks drawn on it. labels: {glyph id: the text that glyph stands for}."""
    key = (path, text, bool(rtl))
    hit = _SHAPE_CACHE.get(key)
    if hit is not None:
        return hit
    font, _ = resolver.get(("file", path))
    try:
        if path not in _SHAPE_FONT:
            arch = pymupdf.Archive()
            arch.add(font.buffer, "f.ttf")
            probe = next((ch for ch in "\u0627a.0" if font.has_glyph(ord(ch))), " ")
            spans, _more = _story_spans(arch, probe, False)
            _SHAPE_FONT[path] = (arch, spans[0]["font"] if spans else "")
        arch, own = _SHAPE_FONT[path]
        # a kind of space the font has no shape for (thin and no-break spaces of French text) is laid out as an
        # ordinary space, and given its own width below
        lay = "".join(" " if ch.isspace() and ch != " " and not font.has_glyph(ord(ch)) else ch for ch in text)
        spans, more = _story_spans(arch, lay, rtl)
    except Exception as e:
        raise EditError(f"This text could not be laid out ({type(e).__name__}).")
    items, missing = [], set()  # items come in typing order
    for sp in spans:
        for ucs, gid, org, bb in sp["chars"]:
            ch = chr(ucs) if 0 < ucs < 0x110000 and ucs != 0xFFFD else ""
            if ch and unicodedata.category(ch) == "Cf":
                continue
            if ch.isspace():  # every kind of space is a gap (drawn only when the font has a shape for it)
                items.append((gid if sp["font"] == own and gid > 0 else -1, org[0], org[1], bb[2] - bb[0], " "))
                continue
            if sp["font"] != own or gid <= 0:
                if ch:
                    missing.add(ch)
                continue
            items.append((gid, org[0], org[1], bb[2] - bb[0], plain_arabic(ch)))
    if lay != text:
        factor = [SPACE_LIKE.get(ch, 1.0) if lay[i] != ch else 1.0 for i, ch in enumerate(text) if ch.isspace()]
        at = [k for k, it in enumerate(items) if it[4] == " "]
        if len(at) == len(factor):
            for k, f in zip(at, factor):
                delta, edge = (f - 1.0) * items[k][3], items[k][1]
                if abs(delta) > 0.01:  # everything to the right of this space moves with its new width
                    items = [(g, x + delta if x > edge + 0.01 else x, y, w + delta if m == k else w, lab)
                             for m, (g, x, y, w, lab) in enumerate(items)]
    solid = [it for it in items if it[3] > 0.5]
    if not solid:
        res = ([], 0.0, missing, {})
    else:
        ys = sorted(round(it[2], 1) for it in solid)
        base = ys[len(ys) // 2]
        if more or any(abs(it[2] - base) > 60 for it in solid):
            raise EditError("This line is too long to be written in one piece.")
        x0 = min(it[1] for it in solid)
        width = (max(it[1] + it[3] for it in solid) - x0) / 100
        packs = []  # a letter shape and the marks that sit on it
        for it in items:
            if packs and ((it[3] <= 0.5 and not it[4]) or (it[4] and all(unicodedata.combining(c) for c in it[4]))):
                packs[-1].append(it)
            else:
                packs.append([it])
        # What each group says is read off the typed text, word by word (a font file does not name every shape).
        # (compared in decomposed form: a font may draw an accented letter as letter plus accent)
        nfd, nfc = (lambda t: unicodedata.normalize("NFD", t)), (lambda t: unicodedata.normalize("NFC", t))
        typed = nfd("".join(" " if ch.isspace() else ch for ch in text if unicodedata.category(ch) != "Cf" and ch not in missing))

        def said_for(word, tw, ligate):
            """The typed letters each group of a word stands for, or None when they cannot be matched up."""
            p, n, out = 0, len(tw), []
            for pack in word:
                if p >= n:
                    return None
                label, got = nfd(pack[0][4] or ""), None
                if label and ord(tw[p]) > 0xFFFF:
                    label = None  # MuPDF reads characters beyond U+FFFF back wrongly
                if label:
                    q, acc = p, []
                    for ch in label:
                        while q < n and tw[q] != ch and unicodedata.combining(tw[q]):
                            acc.append(tw[q])
                            q += 1
                        if q < n and tw[q] == ch:
                            acc.append(ch)
                            q += 1
                        else:
                            acc = None
                            break
                    if acc:
                        got, p = "".join(acc), q
                    elif _MIRROR.get(label) == tw[p]:
                        got, p = tw[p], p + 1  # a bracket shown mirrored
                    else:
                        return None
                else:
                    got, p = tw[p], p + 1
                    if ligate and got == "\u0644":  # lam and alef are drawn as one shape
                        q = p
                        while q < n and unicodedata.combining(tw[q]):
                            q += 1
                        if q < n and tw[q] in "\u0627\u0622\u0623\u0625\u0671":
                            got, p = tw[p - 1:q + 1], q + 1
                while p < n and unicodedata.combining(tw[p]):
                    got += tw[p]
                    p += 1
                out.append(got)
            return out if p == n else None

        words, cur = [], []  # (groups of the word, True for a space)
        for pack in packs:
            if pack[0][4] == " " and len(pack) == 1:
                words += [(cur, False), ([pack], True)]
                cur = []
            else:
                cur.append(pack)
        words.append((cur, False))
        texts = typed.split(" ")
        if len(texts) != (len(words) + 1) // 2:
            words, texts = [(packs, False)], [typed]  # spaces do not line up: match the line as one piece
        place = lambda pack: [(it[0], (it[1] - x0) / 100, (base - it[2]) / 100) for it in pack[1:] + pack[:1] if it[0] > 0]
        groups, labels = [], {}
        for k, (word, space) in enumerate(words):
            if space:
                if word[0][0][0] > 0:
                    labels.setdefault(word[0][0][0], " ")
                    groups.append((word[0][0][1], None, place(word[0])))
                continue
            tw = texts[k // 2] if len(words) > 1 else texts[0]
            if not word:
                continue
            said = said_for(word, tw, False) or said_for(word, tw, True)
            if said is None:
                # the shapes of this word cannot be told apart: record the word as a whole
                glyphs = [g for pack in sorted(word, key=lambda pk: pk[0][1]) for g in place(pack)]
                groups.append((min(pack[0][1] for pack in word), nfc(tw) or None, glyphs))
                continue
            for pack, got in zip(word, said):
                label, got = pack[0][4], nfc(got)
                if not label or (len(got) and ord(got[0]) > 0xFFFF) or (label != got and _MIRROR.get(label) != got and not nfd(got).startswith(nfd(label)[0])):
                    label = "".join(c for c in got if not unicodedata.combining(c))
                if label:
                    labels.setdefault(pack[0][0], label)
                for it in pack[1:]:
                    if it[4]:
                        labels.setdefault(it[0], it[4])
                attach = got if (len(pack) > 1 or got != label) else None
                groups.append((pack[0][1], attach, place(pack)))
        groups.sort(key=lambda g: g[0])
        res = ([(attach, glyphs) for _x, attach, glyphs in groups], width, missing, labels)
    if len(_SHAPE_CACHE) > 400:
        _SHAPE_CACHE.clear()
    _SHAPE_CACHE[key] = res
    return res


def build_tounicode(table):
    """A ToUnicode CMap for two byte codes from {code: text}."""
    rows = []
    for code in sorted(table):
        s = table[code]
        if s and 0 <= code <= 0xFFFF:
            rows.append(f"<{code:04x}> <{s.encode('utf-16-be').hex()}>")
    out = ["/CIDInit /ProcSet findresource begin", "12 dict begin", "begincmap",
           "/CIDSystemInfo <</Registry(Adobe)/Ordering(UCS)/Supplement 0>> def", "/CMapName /Adobe-Identity-UCS def",
           "/CMapType 2 def", "1 begincodespacerange", "<0000> <FFFF>", "endcodespacerange"]
    for i in range(0, len(rows), 100):
        chunk = rows[i:i + 100]
        out += [f"{len(chunk)} beginbfchar"] + chunk + ["endbfchar"]
    out += ["endcmap", "CMapName currentdict /CMap defineresource pop", "end", "end", ""]
    return "\n".join(out).encode("ascii")


def line_runs(text, rtl, looks=None):
    """Cut a line into stretches of one direction (and one look), in the order they stand on the page from left
    to right: (start, end, True when the stretch runs right to left). The order follows the Unicode rules that
    browsers use, so the saved line matches what the editor shows; each stretch is then shaped by itself."""
    lv = bidi_levels(text, 1 if rtl else 0)
    order = visual_order(lv)
    out, j = [], 0
    while j < len(order):
        k = j + 1
        while (k < len(order) and lv[order[k]] == lv[order[j]] and abs(order[k] - order[k - 1]) == 1
               and (looks is None or looks[order[k]] == looks[order[j]])):
            k += 1
        span = sorted(order[j:k])
        out.append((span[0], span[-1] + 1, bool(lv[order[j]] % 2)))
        j = k
    return out


def shape_line(resolver, path, text, rtl):
    """A whole line in one font, as one shaped run (see shape_text)."""
    groups, labels, missing, at = [], {}, set(), 0.0
    for a, b, odd in line_runs(text, rtl):
        g, w, m, lab = shape_text(resolver, path, text[a:b], odd)
        groups += [(attach, [(gid, x + at, rise) for gid, x, rise in glyphs]) for attach, glyphs in g]
        at += w
        missing |= m
        for gid, t in lab.items():
            labels.setdefault(gid, t)
    return groups, at, missing, labels


def _stretch_spaces(shaped, extra):
    """Widen (or narrow) every space of a shaped run by extra, in units of the font size."""
    groups, width, missing, labels = shaped
    if not extra:
        return shaped
    out, shift = [], 0.0
    for attach, glyphs in groups:
        out.append((attach, [(g, x + shift, r) for g, x, r in glyphs]))
        if len(glyphs) == 1 and labels.get(glyphs[0][0]) == " ":
            shift += extra
    return out, width + shift, missing, labels


def edit_line_shaped(E, ln, new_text, opt, report):
    """Write new_text in place of a line when Arabic is involved. The line is set again with installed fonts: every
    letter keeps the colour, weight and size of the letter it replaces, and the line keeps its place and word spacing."""
    new = plain_arabic(re.sub(r"[\r\n\t]+", " ", new_text))
    old = ln.text
    was_arabic = ln.looks is not None
    # an Arabic line keeps the direction of its paragraph; text without any Arabic letter reads left to right
    rtl = has_arabic(new) and (ln.rtl if was_arabic else first_strong_rtl(new))
    looks = ln.looks if was_arabic else [(c["color"], c["font"], c["flags"], c["size"]) for c in ln.chars]
    scale = max(0.1, num(opt["size"], ln.size) / ln.size) if opt.get("size") else 1.0
    family = opt.get("family") or None
    color_override = hex_to_rgb(opt["color"]) if opt.get("color") else None

    # which old letter every new letter takes its look from
    src = [0] * len(new)
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes():
        for k in range(j2 - j1):
            i = i1 + k if tag == "equal" else (i1 + min(k, i2 - i1 - 1) if tag == "replace" else (i1 - 1 if i1 > 0 else 0))
            src[j1 + k] = max(0, min(i, len(looks) - 1))
    for j, ch in enumerate(new):  # a vowel mark belongs to its letter, a space to the word before it
        if j and (unicodedata.combining(ch) or ch == " "):
            src[j] = src[j - 1]

    fonts = {}

    def resolved(look):
        if look not in fonts:
            color, basefont, flags, size = look
            bold = _flags_bold(flags) if opt.get("bold") is None else bool(opt.get("bold"))
            italic = _flags_italic(flags) if opt.get("italic") is None else bool(opt.get("italic"))
            spec, quality = E.resolver.spec_for(basefont, flags, bold, italic, family)
            cls = family if family in ("sans", "serif", "mono") else classify_font(basefont, flags)
            mine = "".join(ch for j, ch in enumerate(new) if looks[src[j]] == look)
            path, asked = shaping_font(E.resolver, mine, spec, cls, bold, italic)
            fonts[look] = (path, size * scale, color_override or color, quality if asked else "approximate")
        return fonts[look]

    keys = [resolved(looks[src[j]])[:3] for j in range(len(new))]
    quality = {resolved(looks[src[j]])[:3]: resolved(looks[src[j]])[3] for j in range(len(new))}
    # (shaped run, (path, size, colour)) in the order the runs stand on the line, left to right
    pieces = [(shape_text(E.resolver, keys[a][0], new[a:b], odd), keys[a]) for a, b, odd in line_runs(new, rtl, keys)]

    # the line keeps the spacing between its words (justified text stays justified)
    dx, dy = ln.dir
    n = len(ln.chars)
    T = [_line_t(ln, c["o"]) for c in ln.chars]
    W = [_char_adv(ln, i) for i in range(n)]
    cells = sorted((T[i], W[i], ln.chars[i]["c"], ln.chars[i]["size"]) for i in range(n) if W[i] > 0.02 * ln.size)
    t0, t1 = (cells[0][0], max(c[0] + c[1] for c in cells)) if cells else (0.0, 0.0)
    gaps = [(b[0] - a[0]) / a[3] for a, b in zip(cells, cells[1:]) if a[2] == " " and b[2] != " "]
    total = 0.0
    placed = []
    for shaped, (path, size, color) in pieces:
        report.missing |= shaped[2]
        if gaps and not family:
            font, _ = E.resolver.get(("file", path))
            natural = font.glyph_advance(32)
            extra = max(-0.6 * natural, min(3.0, statistics.median(gaps) - natural))
            shaped = _stretch_spaces(shaped, extra if abs(extra) > 0.01 else 0.0)
        placed.append((total, shaped, path, size, color))
        total += shaped[1] * size
    xscale = 1.0
    if opt.get("fit") and t1 > t0 and total > (t1 - t0) + 0.5:
        xscale = max(0.8, (t1 - t0) / total)
    left = t1 - total * xscale if ln.rtl else t0  # a right to left line keeps its right end
    for at, shaped, path, size, color in placed:
        tt = left + at * xscale
        E.put_shaped(("file", path), shaped, size, color, (ln.origin[0] + dx * tt, ln.origin[1] + dy * tt), ln.dir, xscale)
    for j, ch in enumerate(new):
        if not ch.isspace() and ch not in report.missing and unicodedata.category(ch) != "Cf":
            report.sub(ch, quality[keys[j]])
    return xscale


# ------------------------------------------------------------------ added content

def _view_to_native_pt(page, pt):
    p = pymupdf.Point(pt) * page.derotation_matrix
    return p


def _view_to_native_rect(page, r):
    rr = pymupdf.Rect(r[0], r[1], r[2], r[3]) * page.derotation_matrix
    rr.normalize()
    return rr


def add_text_box(E, item, report):
    page = E.page
    text = str(item.get("text") or "")
    if not text.strip():
        return
    if unsupported_script(text):
        raise EditError(UNSUPPORTED_SCRIPT)
    size = max(1.0, min(500.0, num(item.get("size"), 14)))
    color = hex_to_rgb(item.get("color"), (0, 0, 0))
    fam = item.get("family") or "sans"
    bold, italic = bool(item.get("bold")), bool(item.get("italic"))
    lh = max(0.8, min(3.0, num(item.get("lh"), 1.25)))
    align = item.get("align") if item.get("align") in ("left", "center", "right") else "left"
    spec, quality = E.resolver.spec_for(fam, 0, bold, italic, fam if fam in ("sans", "serif", "mono") or fam.startswith("sys:") else "sans")
    font, _ = E.resolver.get(spec)
    fb_spec = ("builtin", builtin_key("sans", bold, italic))
    fb, _ = E.resolver.get(fb_spec)
    arabic = has_arabic(text)
    if arabic:  # one Arabic capable font for the whole box, the same one the page shows while typing
        text = plain_arabic(text)
        cls = fam if fam in ("sans", "serif", "mono") else "sans"
        path, _asked = shaping_font(E.resolver, text, spec, cls, bold, italic)
        spec = ("file", path)
        font, _ = E.resolver.get(spec)
    x, y = num(item.get("x")), num(item.get("y"))
    box_w = num(item.get("w"), 0)
    # direction of the view's x axis in native space
    rot = page.rotation_matrix
    dirv = pymupdf.Point(1, 0) * pymupdf.Matrix(*(~page.rotation_matrix)[:4], 0, 0)
    ang = math.radians(num(item.get("rot"), 0))
    for li, line in enumerate(text.split("\n")):
        widths, glyphs, shaped = 0.0, [], None
        if arabic and has_arabic(line):
            shaped = shape_line(E.resolver, spec[1], line, first_strong_rtl(line))
            report.missing |= shaped[2]
            widths = shaped[1] * size
            line = ""
        for ch in line:
            f, sp = font, spec
            gid = f.has_glyph(ord(ch)) if ch != " " else 1
            if not gid and ch != " ":
                f, sp = fb, fb_spec
                gid = f.has_glyph(ord(ch))
            adv = (f.glyph_advance(ord(ch)) if gid or ch == " " else 0.5) * size
            if not gid and ch in SPACE_LIKE:
                adv = font.glyph_advance(32) * SPACE_LIKE[ch] * size
            glyphs.append((ch, f, sp, gid, adv))
            widths += adv
        base_off = size * (lh / 2 + 0.345) + li * lh * size
        if align == "left" or not box_w:
            x_start = 0.0
        elif align == "center":
            x_start = (box_w - widths) / 2
        else:
            x_start = box_w - widths
        pen = x_start
        d_view = (math.cos(ang), math.sin(ang))
        dn = pymupdf.Point(*d_view) * pymupdf.Matrix(page.derotation_matrix.a, page.derotation_matrix.b, page.derotation_matrix.c, page.derotation_matrix.d, 0, 0)
        if shaped is not None:
            # start of the baseline, rotated around the box's top-left corner
            vx = x + pen * math.cos(ang) - base_off * math.sin(ang)
            vy = y + pen * math.sin(ang) + base_off * math.cos(ang)
            p = pymupdf.Point(vx, vy) * page.derotation_matrix
            E.put_shaped(spec, shaped, size, color, (p.x, p.y), (dn.x, dn.y))
        for ch, f, sp, gid, adv in glyphs:
            if ch != " " and gid:
                vx, vy = x + pen, y + base_off
                if ang:
                    # rotate around the box's top-left corner
                    rx, ry = pen, base_off
                    vx = x + rx * math.cos(ang) - ry * math.sin(ang)
                    vy = y + rx * math.sin(ang) + ry * math.cos(ang)
                p = pymupdf.Point(vx, vy) * page.derotation_matrix
                res = E.res_for_font(sp)
                E.put_glyph(res, size, color, (p.x, p.y), (dn.x, dn.y), f"{gid:04x}", 1.0)
            pen += adv


def _draw_opts(item):
    stroke = hex_to_rgb(item.get("stroke"), (0, 0, 0)) if item.get("stroke") else None
    fill = hex_to_rgb(item.get("fill")) if item.get("fill") else None
    width = max(0.1, min(100.0, num(item.get("width"), 2)))
    op = max(0.0, min(1.0, num(item.get("opacity"), 1)))
    return stroke, fill, width, op


def add_shape(page, item):
    kind = item["t"]
    stroke, fill, width, op = _draw_opts(item)
    sh = page.new_shape()
    if kind in ("rect", "ellipse"):
        r = _view_to_native_rect(page, item["rect"])
        if r.is_empty or r.width < 0.1 or r.height < 0.1:
            return
        if kind == "rect":
            rad = max(0.0, min(0.5, num(item.get("radius"), 0) / max(1.0, min(r.width, r.height))))
            sh.draw_rect(r, radius=rad if rad else None)
        else:
            sh.draw_oval(r)
        sh.finish(color=stroke, fill=fill, width=width if stroke else 0, fill_opacity=op, stroke_opacity=op, closePath=True)
    elif kind == "line":
        p1 = pymupdf.Point(item["p1"]) * page.derotation_matrix
        p2 = pymupdf.Point(item["p2"]) * page.derotation_matrix
        sh.draw_line(p1, p2)
        if item.get("arrow"):
            v = p2 - p1
            ln = math.hypot(v.x, v.y) or 1
            ux, uy = v.x / ln, v.y / ln
            hl = min(max(8.0, width * 4.5), ln * 0.6)
            for sgn in (1, -1):
                ang = math.radians(26) * sgn
                bx = -(ux * math.cos(ang) - uy * math.sin(ang)) * hl
                by = -(ux * math.sin(ang) + uy * math.cos(ang)) * hl
                sh.draw_line(p2, pymupdf.Point(p2.x + bx, p2.y + by))
        sh.finish(color=stroke or (0, 0, 0), width=width, stroke_opacity=op, lineCap=1, lineJoin=1, closePath=False)
    elif kind == "ink":
        pts = [pymupdf.Point(p) * page.derotation_matrix for p in item.get("pts", [])[:20000]]
        if len(pts) < 2:
            if len(pts) == 1:
                sh.draw_circle(pts[0], width / 2)
                sh.finish(color=None, fill=stroke or (0, 0, 0), fill_opacity=op)
            else:
                return
        else:
            sh.draw_polyline(pts)
            sh.finish(color=stroke or (0, 0, 0), width=width, stroke_opacity=op, lineCap=1, lineJoin=1, closePath=False)
    else:
        return
    sh.commit(overlay=True)


def add_image(page, item):
    data = item.get("data") or ""
    m = re.match(r"data:image/[\w.+-]+;base64,(.*)", data, re.S)
    if not m:
        raise EditError("An image could not be read.")
    r = _view_to_native_rect(page, item["rect"])
    if r.is_empty:
        return
    rot = (int(num(item.get("rot"), 0)) // 90 * 90) % 360
    try:
        raw = base64.b64decode(m.group(1))
        page.insert_image(r, stream=raw, keep_proportion=False, overlay=True, rotate=(rot - page.rotation) % 360)
    except Exception:
        raise EditError("An image could not be read.")


def add_highlight(doc, page, item):
    """A marker-pen style highlight: translucent colour that multiplies with what is underneath."""
    r = _view_to_native_rect(page, item["rect"])
    if r.is_empty:
        return
    col = hex_to_rgb(item.get("color"), (1, 0.92, 0.23))
    op = max(0.05, min(1.0, num(item.get("opacity"), 0.45)))
    gs = doc.get_new_xref()
    doc.update_object(gs, f"<< /Type /ExtGState /BM /Multiply /ca {fmt(op)} /CA {fmt(op)} >>")
    name = ensure_resource(doc, page, "ExtGState", f"PLG{gs}", gs)
    pm = ~page.transformation_matrix
    p0 = pymupdf.Point(r.x0, r.y0) * pm
    p1 = pymupdf.Point(r.x1, r.y1) * pm
    x, y, w, h = min(p0.x, p1.x), min(p0.y, p1.y), abs(p1.x - p0.x), abs(p1.y - p0.y)
    ops = f"q /{name} gs {fmt(col[0])} {fmt(col[1])} {fmt(col[2])} rg {fmt(x)} {fmt(y)} {fmt(w)} {fmt(h)} re f Q\n"
    append_content(doc, page, ops.encode("latin-1"))


def erase_bands(page, rects):
    """Thin rectangles through the middle of every letter whose centre lies inside one of the erase boxes.
    Redacting these removes exactly those letters; a line the box only grazes keeps all of its text."""
    out = []
    # every shape with its own place (the plain reading can lose shapes of Arabic letter groups, see analyze_page)
    flags = (pymupdf.TEXT_PRESERVE_LIGATURES | pymupdf.TEXT_PRESERVE_WHITESPACE | pymupdf.TEXT_INHIBIT_SPACES
             | getattr(pymupdf, "TEXT_IGNORE_ACTUALTEXT", 2048))
    raw = page.get_text("rawdict", flags=flags)
    gone, kept, marks = [], [], []
    for b in raw.get("blocks", []):
        if b.get("type") != 0:
            continue
        for l in b.get("lines", []):
            for s in l["spans"]:
                run = None
                for c in s["chars"] + [None]:
                    box = None
                    if c is not None:
                        x0, y0, x1, y1 = c["bbox"]
                        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
                        inside = any(r.x0 <= cx <= r.x1 and r.y0 <= cy <= r.y1 for r in rects)
                        if min(x1 - x0, y1 - y0) < 0.01:  # no width: a vowel mark, or a letter that shares a shape
                            if inside:
                                marks.append((cx, cy))
                            continue
                        if inside:
                            hw, hh = max(0.1, 0.3 * (x1 - x0)), max(0.1, 0.2 * (y1 - y0))
                            box = (cx - hw, cy - hh, cx + hw, cy + hh)
                            gone.append((x0, y0, x1, y1))
                        else:
                            kept.append((x0, y0, x1, y1))
                    if box is not None:
                        run = box if run is None else (min(run[0], box[0]), min(run[1], box[1]), max(run[2], box[2]), max(run[3], box[3]))
                    elif run is not None:
                        out.append(pymupdf.Rect(run))
                        run = None
    for cx, cy in marks:  # a mark goes with its letter: when it sits on a removed letter and touches no letter that stays
        if any(x0 - 0.1 <= cx <= x1 + 0.1 and y0 - 0.1 <= cy <= y1 + 0.1 for x0, y0, x1, y1 in kept):
            continue
        for x0, y0, x1, y1 in gone:
            reach = 0.25 * max(x1 - x0, y1 - y0)
            if x0 - reach < cx < x1 + reach and y0 - reach < cy < y1 + reach:
                out.append(pymupdf.Rect(cx - 0.05, cy - 0.05, cx + 0.05, cy + 0.05))
                break
    return out


def _restore_links(page, before):
    now = page.get_links()
    keyf = lambda l: (tuple(round(v, 1) for v in l["from"]), l.get("uri"), l.get("page"))
    have = {keyf(l) for l in now}
    for l in before:
        if keyf(l) not in have:
            l = dict(l)
            l.pop("xref", None)
            l.pop("id", None)
            try:
                page.insert_link(l)
            except Exception:
                pass


def apply_page(data, pno, edits, usage, groups, resolver):
    """Apply every edit that belongs to page pno. Returns (doc, report dict). The doc is opened here."""
    raise NotImplementedError


class Session:
    """One open copy of the PDF with edits applied to it."""

    def __init__(self, data, usage, groups, resolver):
        self.data, self.usage, self.groups, self.resolver = data, usage, groups, resolver
        self.doc = pymupdf.open(stream=data, filetype="pdf")
        self.report = {}
        self._lines_cache = {}

    def close(self):
        """Release the document now. MuPDF is not thread safe, so this must not be left to the garbage collector."""
        try:
            self.doc.close()
        except Exception:
            pass

    def lines(self, pno):
        if pno not in self._lines_cache:
            scratch = pymupdf.open(stream=self.data, filetype="pdf")  # font renaming happens on this copy only
            try:
                self._lines_cache[pno] = analyze_page(scratch, pno)
            finally:
                scratch.close()
        return self._lines_cache[pno]

    def apply(self, edits, only_page=None):
        by_page = {}
        for e in edits:
            if not isinstance(e, dict):
                continue
            p = e.get("page")
            if isinstance(p, int) and 0 <= p < len(self.doc) and (only_page is None or p == only_page):
                by_page.setdefault(p, []).append(e)
        for pno, items in sorted(by_page.items()):
            self.apply_one(pno, items)

    def apply_one(self, pno, items):
        doc = self.doc
        page = doc[pno]
        links = page.get_links()
        lines = None
        line_edits, erase, others = [], [], []
        seen_lines = set()
        for e in items:
            t = e.get("t")
            if t in ("edit", "delete"):
                if lines is None:
                    lines = self.lines(pno)
                idx = e.get("line")
                if not isinstance(idx, int) or not (0 <= idx < len(lines)):
                    raise EditError("The page changed since the text was selected. Please reopen the file.")
                if idx in seen_lines:
                    continue
                seen_lines.add(idx)
                if t == "delete" or (e.get("text") is not None and not str(e.get("text")).strip()):
                    line_edits.append((lines[idx], None, e))
                else:
                    ln = lines[idx]
                    unchanged = str(e.get("text")) == ln.text and not any(e.get(k) not in (None, "") for k in ("size", "color", "family", "bold", "italic")) and not e.get("fit")
                    if not unchanged:
                        if unsupported_script(ln.text) or unsupported_script(e.get("text")):
                            raise EditError(UNSUPPORTED_SCRIPT)
                        if has_arabic(ln.text) and min(abs(ln.dir[0]), abs(ln.dir[1])) > 0.02:
                            raise EditError("Arabic text set at a slant cannot be edited. Erase it and add new text instead.")
                        if has_arabic(ln.text) and (ln.looks is None or not ln.sure):
                            raise EditError("This line could not be read reliably. Erase it and add new text instead.")
                        line_edits.append((ln, str(e.get("text")), e))
            elif t == "cover" and e.get("remove", True):
                erase.append(e)
            else:
                others.append(e)
        # 1. take the old text out of the page content
        for ln, new, e in line_edits:
            page.add_redact_annot(redact_rect(ln))
        if line_edits:
            page.apply_redactions(images=0, graphics=0, text=0)
        if erase:
            rects = [_view_to_native_rect(page, e["rect"]) for e in erase]
            bands = erase_bands(page, rects)
            for e, r in zip(erase, rects):
                page.add_redact_annot(r, fill=hex_to_rgb(e.get("color"), (1, 1, 1)))
            # The box itself cuts pictures and drawings. Text goes letter by letter (centre inside the box), because
            # MuPDF would otherwise also delete the lines above and below that the box merely touches.
            page.apply_redactions(images=2, graphics=1, text=1)
            for band in bands:
                page.add_redact_annot(band, fill=False)
            if bands:
                page.apply_redactions(images=0, graphics=0, text=0)
        if line_edits or erase:
            _restore_links(page, links)
        # 2. write the new text
        E = Edits(doc, page, self.usage, self.resolver)
        rep = Report()
        for ln, new, e in line_edits:
            if new is None:
                continue
            if has_arabic(ln.text) or has_arabic(new):
                edit_line_shaped(E, ln, new, e, rep)
            else:
                edit_line(E, ln, new, e, self.groups, rep)
        for e in others:
            if e.get("t") == "text":
                add_text_box(E, e, rep)
        append_content(doc, page, E.flush_text())
        E.patch_unicode()
        # 3. shapes, images, highlights, in the order they were added
        for e in others:
            t = e.get("t")
            if t in ("rect", "ellipse", "line", "ink"):
                add_shape(page, e)
            elif t == "image":
                add_image(page, e)
            elif t == "highlight":
                add_highlight(doc, page, e)
            elif t == "cover":
                r = _view_to_native_rect(page, e["rect"])
                sh = page.new_shape()
                sh.draw_rect(r)
                sh.finish(color=None, fill=hex_to_rgb(e.get("color"), (1, 1, 1)))
                sh.commit(overlay=True)
        agg = self.report.setdefault("lines", {"exact": 0, "substituted": {}, "missing": set()})
        agg["exact"] += rep.exact
        for k, v in rep.substituted.items():
            agg["substituted"].setdefault(k, set()).update(v)
        agg["missing"] |= rep.missing

    def summary(self):
        a = self.report.get("lines")
        if not a:
            return {"exact": 0, "substituted": {}, "missing": ""}
        return {"exact": a["exact"], "substituted": {k: "".join(sorted(v)) for k, v in a["substituted"].items()}, "missing": "".join(sorted(a["missing"]))}

    def save(self):
        out = self.doc.tobytes(garbage=3, deflate=True)
        return out

    def png(self, pno, scale=2.0, clip=None):
        page = self.doc[pno]
        kw = {}
        area = page.rect
        if clip:
            r = pymupdf.Rect(*clip) & page.rect
            if not r.is_empty:
                kw["clip"] = area = r
        # poster sized pages would otherwise need gigabytes for one preview: keep it under 40 megapixels
        scale = min(scale, math.sqrt(40e6 / max(1.0, area.width * area.height)))
        pix = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False, **kw)
        return pix.tobytes("png")


# ------------------------------------------------------------------ what the page shows the editor

def view_pages(doc):
    out = []
    for p in doc:
        r = p.rect
        out.append({"w": round(r.width, 3), "h": round(r.height, 3), "rot": p.rotation})
    return out


def _hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v * 255)))) for v in rgb)


def lines_payload(data, pno, usage, groups):
    scratch = pymupdf.open(stream=data, filetype="pdf")
    page = scratch[pno]
    rot = page.rotation_matrix
    lin = pymupdf.Matrix(rot.a, rot.b, rot.c, rot.d, 0, 0)
    lines = analyze_page(scratch, pno)
    kit_doc = pymupdf.open(stream=data, filetype="pdf")  # un-renamed fonts for reading widths and maps
    kits = {}

    def kit(x):
        if x not in kits:
            kits[x] = FontKit(kit_doc, x, usage.get(x), None)
        return kits[x]

    out = []
    for ln in lines:
        bb = pymupdf.Rect(ln.bbox) * rot
        bb.normalize()
        d = pymupdf.Point(*ln.dir) * lin
        o = pymupdf.Point(*ln.origin) * rot
        avail = set()
        exact = True
        for x in ln.xrefs:
            for y in [x] + groups.get(x, []):
                k = kit(y)
                if k.ok:
                    avail |= k.avail
        for c in ln.chars:
            if not c["xref"] or not kit(c["xref"]).ok:
                exact = False
        shaped = has_arabic(ln.text)
        editable = ln.wmode == 0 and all(len(c["c"]) == 1 for c in ln.chars) and not unsupported_script(ln.text)
        if shaped and (ln.looks is None or not ln.sure or min(abs(ln.dir[0]), abs(ln.dir[1])) > 0.02):
            editable = False  # Arabic set at a slant, or a line that could not be read back with certainty
        base = clean_font_name(ln.basefont)
        out.append({
            "id": ln.idx, "text": ln.text, "bbox": [round(v, 2) for v in (bb.x0, bb.y0, bb.x1, bb.y1)],
            "origin": [round(o.x, 2), round(o.y, 2)], "dir": [round(d.x, 4), round(d.y, 4)],
            "size": round(ln.size, 2), "color": _hex(ln.color), "font": base,
            "bold": _flags_bold(ln.flags), "italic": _flags_italic(ln.flags),
            "cls": classify_font(ln.basefont, ln.flags), "avail": "".join(sorted(avail)),
            "exact": exact and not shaped, "editable": editable, "rtl": ln.rtl, "shaped": shaped,
        })
    scratch.close()
    kit_doc.close()
    return out


def font_families():
    """Installed font families the user can pick for new text, with the styles each one offers."""
    out = []
    for fam, styles in sorted(system_fonts().items(), key=lambda kv: kv[0].lower()):
        out.append({"name": fam, "styles": sorted("".join(["b" if b else "", "i" if i else ""]) or "r" for (b, i) in styles)})
    return out
